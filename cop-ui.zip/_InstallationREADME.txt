Step 1 make sure you have NPM and NodeJS isnstalled.
Step 2 is to avoid any issues with the webpack installation for Angular.
Step 3 is to open project locally

1. npm install
2. npm i webpack --save-dev
3. ng serve --open