module.exports = function (grunt) {
	grunt.loadNpmTasks('grunt-contrib-copy');
	grunt.loadNpmTasks('grunt-war');

	// param
	var configuration = grunt.option('configuration');

	// Project configuration.
	var prod = {
		pkg: grunt.file.readJSON('package.json'),
		war: {
			target: {
				options: {
					war_dist_folder: './', /* Folder where to generate the WAR. */
					war_name: 'TracfoneUI' /* The name of the WAR file (.war will be the extension) */
				},

				files: [
					{ expand: true,	cwd: 'dist/prod', src: ['**'], dest: ''}
				]
			}
		},copy: {
            prod: {
              expand: true,

              src: 'weblogic.xml',
              dest: 'dist/prod/WEB-INF/',
            },
          },
	};

	grunt.initConfig(prod);

	grunt.registerTask('default', ['copy','war']);
};

