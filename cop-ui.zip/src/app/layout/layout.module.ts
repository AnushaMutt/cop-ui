import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';

import { LayoutRoutingModule } from './layout-routing.module';
import { LayoutComponent } from './layout.component';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { HeaderComponent } from './components/header/header.component';

import { AdminService } from './../Services/admin.service';
import { AuthService } from './../Services/auth.service';
import { CarrierService } from './../Services/carrier.service';
import { ClockComponent } from './components/clock/clock.component';

// TODO think of moving this import module to parent 
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
    imports: [
        CommonModule,
        LayoutRoutingModule,
        NgbDropdownModule.forRoot() ,
        ReactiveFormsModule,
        NgbModule.forRoot()
    ],
    declarations: [LayoutComponent, SidebarComponent, HeaderComponent, ClockComponent],
    providers: [],
})
export class LayoutModule {}
