import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LayoutComponent } from './layout.component';

const routes: Routes = [
    {
        path: '',
        component: LayoutComponent,
        children: [
            { path: '', redirectTo: 'dashboard' },
            { path: 'dashboard', loadChildren: './dashboard/dashboard.module#DashboardModule' },
            { path: 'user', loadChildren: './admin/user/user.module#UserModule' },
            { path: 'user-audit', loadChildren: './admin/user-audit/user-audit.module#UserAuditModule' },
            { path: 'view-users', loadChildren: './admin/view-users/view-users.module#ViewUsersModule' },
            { path: 'view-actions', loadChildren: './admin/view-actions/view-actions.module#ViewActionsModule' },
            { path: 'view-groups', loadChildren: './admin/view-groups/view-groups.module#ViewGroupsModule' },
            { path: 'view-aid', loadChildren: './research/view-aid/view-aid.module#ViewAidModule' },
            { path: 'group', loadChildren: './admin/group/group.module#GroupModule' },
            { path: 'qs-monitor-report', loadChildren: './report/monitor/monitor-qs/charts.module#ChartsModule' },
            { path: 'monitor-adhoc-report', loadChildren: './report/monitor/monitor-qs-adhoc/charts.module#ChartsModule' },
            { path: 'monitor-status-report', loadChildren: './report/monitor/monitor-qs-status/charts.module#ChartsModule' },
            { path: 'ngp-tool', loadChildren: './operation/nearest-ngp-tool/neartest-ngp-tool.module#NearestNgpToolComponentModule' },
            { path: 'insert-transaction', loadChildren: './research/insert-transaction/insert-transaction.module#InsertTransactionModule' },
            { path: 'user-inquiry', loadChildren: './user-inquiry/user-inquiry.module#UserInquiryModule' },
            { path: 'insert-wizard', loadChildren: './research/insert-transaction-wizard/insert-transaction-wizard.module#InsertTransactionWizardModule' },
            { path: 'insert-wizard-history', loadChildren: './research/insert-transaction-wizard/transaction-history-all/transaction-history-all.module#TransactionHistoryAllModule' },
            { path: 'service-rateplan-maintenance', loadChildren: './research/service-rateplan-maintenance/service-rateplan-maintenance.module#ServiceRateplanMaintenanceModule' },
            { path: 'service-rateplan-view', loadChildren: './research/service-plan-view/service-plan-view.module#ServicePlanViewModule' },
            { path: 'tracfone360', loadChildren: './research/novak-tool-wizard/novak-tool-wizard.module#NovakToolWizardModule' },
            { path: 'service-plan-wizard', loadChildren: './research/mirror-service-plans/mirror-service-plans.module#MirrorServicePlansModule' },
            { path: 'carriermaintenance', loadChildren: './research/carrier-maintenance/carrier-maintenance.module#CarrierMaintenanceModule' },
            { path: 'retailmanagement', loadChildren: './research/retail-store/retail-store.module#RetailStoreModule' },
            { path: 'retailmanagementview', loadChildren: './research/retail-traits/retail-traits.module#RetailTraitsModule' },
            { path: 'carrieroutage', loadChildren: './research/carrier-outage/carrier-outage.module#CarrierOutageModule' },
            { path: 'userreporting', loadChildren: './research/user-reporting/user-reporting.module#UserReportModule' },
            { path: 'throttletransactions', loadChildren: './research/throttle/throttle.module#ThrottleModule' },
            { path: 'pcrftransactions', loadChildren: './research/pcrf/pcrf.module#PCRFModule' },
            { path: 'db2igview', loadChildren: './research/db2intergate-view/db2intergate-view.module#DB2IntergateModule' },
            { path: 'db2igmaintenance', loadChildren: './research/db2intergate-view/db2intergate-view.module#DB2IntergateModule' },
            { path: 'igconfig', loadChildren: './research/carrier-config/carrier-config.module#CarrierConfigModule' },
            { path: 'igconfigmaintenance', loadChildren: './research/carrier-config/carrier-config.module#CarrierConfigModule' },
            { path: 'zip2techmaintenance', loadChildren: './research/carrier-zip2tech/carrier-zip2tech.module#CarrierZip2TechModule' },
            { path: 'coverage-map', loadChildren: './research/coverage-map/coverage-map.module#CoverageMapModule' },
			{ path: 'carrierzonesdplymnt', loadChildren: './research/carrier-zones/carrier-zones.module#CarrierZonesModule' },
			{ path: 'geocode', loadChildren: './research/geo-coder/geo-coder.module#GeoCoderModule' },
            { path: 'igcarrier', loadChildren: './research/ig-carrier-notification/ig-carrier-notification.module#IGCarrierNotificationModule' },
            { path: 'igfaillogs', loadChildren: './research/ig-fail-logs/ig-fail-logs.module#IgFailLogsModule' },
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class LayoutRoutingModule {}
