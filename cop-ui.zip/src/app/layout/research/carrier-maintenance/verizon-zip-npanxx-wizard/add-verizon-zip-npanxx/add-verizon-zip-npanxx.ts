import { Component, OnInit, ViewEncapsulation, ViewChildren, Output, EventEmitter } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { ConfirmationService } from 'primeng/primeng';
import { takeUntil } from 'rxjs/operators';
import { Subject } from "rxjs";
import { CarrierMaintenanceService } from '../../../../../Services/carrierMaintenance.service';
import { CarrierMaintenanceHelper } from "../../carrier-maintenance-helper";
import { ToasterService } from "../../../../../Services/toaster.service";
import { VerizonZipNPANXXHelper } from "../verizon-zip-npanxx-wizard-helper";
import { VerizonZipNPANXXService } from "../verizon-zip-npanxx-wizard-service";
import { MatDialog } from "@angular/material";
import { BulkInsertVerizonZipNPANXXComponent } from "../bulk-insert-verizon-zip-npanxx/bulk-insert-vzn";

@Component({
    selector: 'add-verizon-zip-npanxx',
    templateUrl: './add-verizon-zip-npanxx.html',
    styleUrls: ['./add-verizon-zip-npanxx.scss',
        "../../../../components/ngxtable/material.scss",
        "../../../../components/ngxtable/datatable.component.scss",
        "../../../../components/ngxtable/icons.css",
        "../../../../components/ngxtable/app.css"],
    animations: [],
    encapsulation: ViewEncapsulation.None,
})

export class AddVerizonZipNPANXXComponent implements OnInit {
    @ViewChildren(DatatableComponent)
    table: any;
    private unsubscribe = new Subject<void>();
    public frmVerizonZipNpanxx: FormGroup;
    public showLoadingScreen: boolean;
    public displayTable = false;
    private checkedAnother = false;
    public tableRows: any = [];
    public tableRowsMainData: any = [];
    public errorMessage = "";
    public enteredZipCodes: any;
    isEditable = {};
    private editedRow: any = {};
    private defaultEditedRow: any = {};
    public tableColumns:any = [];
    public alerts = [];
    public bulkInsertData = [];
    public showMssg = false;
    @Output("returnedData") returnedData: any = new EventEmitter();
    public alreadyEnabled = true;
    public checkDuplicate = false;

    constructor(
        private formBuilder: FormBuilder,
        private wizardService: CarrierMaintenanceService,
        private verizonZipNPANXXHelper: VerizonZipNPANXXHelper,
        private toasterService: ToasterService,
        private wizardHelper: CarrierMaintenanceHelper,
        private confirmationService: ConfirmationService,
        private verizonZipNPANXXService: VerizonZipNPANXXService,
        public dialog: MatDialog,
    ) {
        this.frmVerizonZipNpanxx = new FormGroup({});
    }

    ngOnInit() { 
        this.createForm();
        this.enteredZipCodes = "";
        this.errorMessage = "";
        this.tableColumns = [
            { name: 'Zip', prop: 'zip', width: "200" },
            { name: 'NPA', prop: 'nPA', width: "200" },
            { name: 'NXX', prop: 'nXX', width: "200" },
            { name: 'NPANXX', prop: 'nPANXX', width: "250" },
            { name: 'Account Num', prop: 'accountNum', width: "250" },
            { name: 'Template', prop: 'template', width: "250" },
        ];
        this.showMssg = false;
        this.verizonZipNPANXXService.setAddData([]);
    }

        //to create form
        private createForm() {
            this.frmVerizonZipNpanxx = this.formBuilder.group({
                zip: ['', [Validators.pattern("^[0-9\n ,]*$"), Validators.required]],
                nPA: ['', [Validators.maxLength(30), Validators.required]],
                nXX: ['', [Validators.maxLength(30), Validators.required]],
                nPANXX: ['', [Validators.maxLength(30), Validators.required]],
                accountNum: ['', [Validators.maxLength(30), Validators.required]],
                template: ['', [Validators.maxLength(30), Validators.required]],
            })
        }

    //to add Verizon Zip Npanxx
    private addVerizonZipNpanxx(f) {
        this.showLoadingScreen = true;
        this.alreadyEnabled = true;
        let obj = f.value;
        if (this.enteredZipCodes) {
            let zipCodes:any = [];
    zipCodes = [...this.enteredZipCodes.split(",")];
        let uniqueZips = zipCodes.filter((v, i) =>
        zipCodes.findIndex(item => item == v) === i);
            obj.zip = uniqueZips.toString();
        }
        obj = this.wizardHelper.checkRequestObject(obj);
        obj.dbEnv = this.wizardHelper.dbEnv;
        this.wizardService.addVerizonZipNpanxx(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.verizonZipNPANXXHelper.getTracfoneConstantMethod("TRACFONE_ADD_VERIZON_ZIP_NPANXX_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                const d = data[0].message;
                if(d==""){
                    this.toasterService.showErrorMessage(
                    this.verizonZipNPANXXHelper.getTracfoneConstantMethod("TRACFONE_DUPLICATE_VERIZON_ZIP_NPANXX_ERROR_MESSAGE")
                );
                }else{
                let fullObject = [];
                if (!this.verizonZipNPANXXService.getAddData() || (this.verizonZipNPANXXService.getAddData() && this.verizonZipNPANXXService.getAddData().length == 0)) {
                    let zipValue = {...obj}
                    obj.zip.split(",").forEach(e1 => {
                        zipValue.zip = e1
                        obj = { ...obj, ...zipValue }
                        fullObject.push(obj);
                    });                    
                } else if (this.verizonZipNPANXXService.getAddData().length > 0) {
                    fullObject = this.verizonZipNPANXXService.getAddData();
                   let zipValue = {...obj}
                    obj.zip.split(",").forEach(e1 => {
                        zipValue.zip = e1
                        obj = { ...obj, ...zipValue }
                        fullObject.push(obj);
                    }); 
                }
                this.verizonZipNPANXXService.setAddData(fullObject);
                this.tableRowsMainData = [];
                this.tableRows = [];
                for (let i = 0; i < this.verizonZipNPANXXService.getAddData().length; i++) {
                    this.tableRowsMainData.push(this.verizonZipNPANXXService.getAddData()[i]);
                }
                let rowId = 1;
                this.tableRowsMainData.forEach(element => {
                    element.rowId = rowId;
                    rowId++;
                });
                this.tableRows = [...this.tableRowsMainData];
                if (this.checkedAnother) {
                    this.displayTable = false;
                } else {
                    this.displayTable = true;
                }
                this.frmVerizonZipNpanxx.reset();
                this.toasterService.showSuccessMessage(
                    this.verizonZipNPANXXHelper.getTracfoneConstantMethod("TRACFONE_ADD_VERIZON_ZIP_NPANXX_SUCCESS_MESSAGE")
                );
            }
            this.checkDuplicate = false;
            this.showLoadingScreen = false;
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.verizonZipNPANXXHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }

    onChangeCheckbox(event) {
        if (event.checked) this.checkedAnother = true;
        else this.checkedAnother = false;
    }

    //show summary confirm
    public showSummaryConfirm(f, index) {
        this.confirmationService.confirm({
            key: 'confirm-add-show-summary',
            message: this.verizonZipNPANXXHelper.getTracfoneConstantMethod("TRACFONE_DONE_CREATING_VERIZON_ZIP_NPANXX_CONFIRM_MESSAGE"),
            accept: () => {
                this.displayTable = true;
                this.checkedAnother = false;
            }
        });
    }

    /*
     * Validate Zip Code text area
     * Validation Criteria- Limit -> 40,000 | Size -> 5 per zip code
     */
    zipCodeValidation(event) {
        this.errorMessage = "";
        //Splitting string based on the new line
        let zip = event.split("\n")
        let zipcodes: any = [];
        for (let i = 0; i < zip.length; i++) {
            //removing spaces
            zip[i] = zip[i].replace(/\s/g, "");
            //checking if any value with comma exists
            if (zip[i].indexOf(',') > -1) {
                //Sliting String based on the comma
                let commaSeperatedArr = zip[i].split(",");
                /*
                 * Validate Zip Code based on the length
                 * if Zip Codes are valid then pushing into 'zipcodes' array
                */
                for (let j = 0; j < commaSeperatedArr.length; j++) {
                    if (commaSeperatedArr[j].length != 0) {
                        if (commaSeperatedArr[j].length < 5) {
                            this.errorMessage = "Zip Code cannot have less than 5 digits."
                            break;
                        } else if (commaSeperatedArr[j].length > 5) {
                            this.errorMessage = "Zip Code cannot have more than 5 digits."
                            break;
                        } else {
                            zipcodes.push(commaSeperatedArr[j]);
                            //check if zip codes exceeds 40,000
                            if (zipcodes.length > 40000) {
                                this.errorMessage = "Zip Codes cannot exceed 40,000 limit"
                                break;
                            }
                        }
                    }
                }
            }//Validate Zip Code based on the length 
            else if (zip[i].length < 5) {
                if (zip[i].length != 0) {
                    this.errorMessage = "Zip Code cannot have less than 5 digits."
                    break;
                }
            }//Validate Zip Code based on the length 
            else if (zip[i].length > 5) {
                this.errorMessage = "Zip Code cannot have more than 5 digits."
                break;
            }//if Zip Codes are valid then pushing into 'zipcodes' array
            else {
                zipcodes.push(zip[i]);
                //check if zip codes exceeds 40,000
                if (zipcodes.length > 40000) {
                    this.errorMessage = "Zip Codes cannot exceed 40,000 limit"
                    break;
                }
            }
        }
        let returnedZip: any = [];
        this.enteredZipCodes = ""
        if (this.errorMessage == "") {
            zipcodes.forEach(element => {
                if (element.length != 0)
                    returnedZip.push(element);
            });
            this.enteredZipCodes = returnedZip.toString();
        } else {
            this.enteredZipCodes = null;
        }
    }

    // reset the form
    revert() {
        this.frmVerizonZipNpanxx.reset();
        this.enteredZipCodes = "";
        this.errorMessage = "";
        this.alerts = [];
        this.bulkInsertData = [];
        let filterKeys = Object.keys(this.frmVerizonZipNpanxx.controls);
        filterKeys.forEach(_e1 => {
            this.frmVerizonZipNpanxx.controls[`${_e1}`].setValidators([Validators.required]);
            this.frmVerizonZipNpanxx.controls[`${_e1}`].updateValueAndValidity();
        });
    }

    public  editButtonClicked(rowData,rowIndex) {
        this.alreadyEnabled = false;
        this.defaultEditedRow = { ...rowData }
        for (let i = 0; i < this.tableRowsMainData.length; i++) {
          if (this.isEditable[i])
            this.alreadyEnabled = true;
        }
        if (!this.alreadyEnabled)
          this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        else{
          this.alreadyEnabled = false;
          this.toasterService.showErrorMessage(
            this.verizonZipNPANXXHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE")
          );
        }
      }
    
    private inputValueChanged(event, column, row, oldValue) {
            this.editedRow[column] = event.target.value;
            this.defaultEditedRow[column] = event.target.defaultValue;
    
    }
    
    //to update order types
    public updateVerizonZipNpanxx(editData, rowIndex) {
        if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
            this.toasterService.showErrorMessage(
                this.verizonZipNPANXXHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            return;
        }
        this.showLoadingScreen = true;
        let obj = { ...editData, ...this.editedRow }
    
        obj = this.wizardHelper.checkRequestObject(obj);
        obj.dbEnv = this.wizardHelper.dbEnv;
        obj.oldZip = this.defaultEditedRow.zip;
        obj.oldNPANXX = this.defaultEditedRow.nPANXX;
        obj.oldAccountNum = this.defaultEditedRow.accountNum;
        if(obj.zip != this.defaultEditedRow.zip || obj.nPANXX != this.defaultEditedRow.nPANXX || obj.accountNum != this.defaultEditedRow.accountNum){
            this.checkDuplicate = true;
        } else {
            this.checkDuplicate = false;
        }
        obj.checkDuplicate = this.checkDuplicate;
        this.wizardService.updateVerizonZipNpanxx(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.verizonZipNPANXXHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_VERIZON_ZIP_NPANXX_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                for (let i = 0; i < this.tableRowsMainData.length; i++) {
                    if (this.tableRowsMainData[i].rowId == this.defaultEditedRow.rowId) {
                        this.tableRowsMainData[i] = obj;
                    }
                }
                this.isEditable[rowIndex] = !this.isEditable[rowIndex];
                this.showLoadingScreen = false;
                this.editedRow = {};
                this.defaultEditedRow = {};
                this.tableRows = [...this.tableRowsMainData];
                this.alreadyEnabled = true;
                this.checkDuplicate = false;
    
                this.toasterService.showSuccessMessage(
                    this.verizonZipNPANXXHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_VERIZON_ZIP_NPANXX_SUCCESS_MESSAGE")
                );
    
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.verizonZipNPANXXHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }
    
    //to cancel update
    private cancelEditForm(rowData, rowIndex) {
        this.showLoadingScreen = true;
        this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        this.tableColumns.forEach(e1 => {
            if (document.getElementById(e1.prop + rowIndex)) {
                (<HTMLInputElement>(
                    document.getElementById(e1.prop + rowIndex)
                )).value = rowData[e1.prop] || '';
            }
        });
    
        this.editedRow = {};
        this.defaultEditedRow = {};
        this.showLoadingScreen = false;
        this.alreadyEnabled = true;
        this.checkDuplicate = false;
    }
    
    //to filter table
    private updateSummaryTable(event) {
        const val = event.target.value.toLowerCase();
    
        const temp = this.tableRowsMainData.filter(function (d) {
            return (d.zip ? d.zip.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.nPA ? d.nPA.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.nXX ? d.nXX.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.nPANXX ? d.nPANXX.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.accountNum ? d.accountNum.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.template ? d.template.toLowerCase().indexOf(val) !== -1 : !val)
        });
        this.tableRows = temp;
    }


// delete confirm
public showConfirm(esnData, rowIndex) {
    this.confirmationService.confirm({
      key: 'confirm-delete-vzn',
      message: "Are you sure you want to delete Verizon Zip NPANXX ?",
      accept: () => {
        this.deleteVerizonZipNpanxx(esnData, rowIndex)
      }
    });
  }

  // to delete verizon zip npanxx
  public deleteVerizonZipNpanxx(esnData, rowIndex) {
    this.showLoadingScreen = true;
    let obj:any = {};
    obj = esnData
    obj.dbEnv = this.wizardHelper.dbEnv;
    this.wizardService.deleteVerizonZipNpanxx(obj).pipe(takeUntil(this.unsubscribe))
      .subscribe(
      (data: any) => {
        if (data[0] === null || data[0] === undefined) {
          this.showLoadingScreen = false;
          this.toasterService.showErrorMessage(
            this.verizonZipNPANXXHelper.getTracfoneConstantMethod("TRACFONE_DELETE_VERIZON_ZIP_NPANXX_ERROR_MESSAGE")
          );
          return;
        }
        if (data[0] && data[0].ERR) {
          this.showLoadingScreen = false;
          const commaSeperatedArr = data[0].ERR.split(",");
          for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
            if (commaSeperatedArr[i] != "")
              this.toasterService.showErrorMessage(
                commaSeperatedArr[i]
              );
          }
          return;
        }
        this.toasterService.showSuccessMessage(
          this.verizonZipNPANXXHelper.getTracfoneConstantMethod("TRACFONE_DELETE_VERIZON_ZIP_NPANXX_SUCCESS_MESSAGE")
        );

        this.tableRows.forEach((rec: any, key) => {
            if (obj.zip == rec.zip && obj.nPANXX == rec.nPANXX && obj.accountNum == rec.accountNum) {
              this.tableRows.splice(key, 1);
              this.verizonZipNPANXXService.getAddData().splice(key, 1);
            }
          });
          this.tableRows = [...this.tableRows];
          this.tableRowsMainData = [...this.tableRows];
          if (this.tableRows.length === 0) {
            this.displayTable = false;
            this.checkedAnother = false;
            this.tableRows = [];
            this.revert();
            this.verizonZipNPANXXService.setAddData([]);
          }
        this.showLoadingScreen = false;
      },
      (err: any) => {
        this.showLoadingScreen = false;
        if (err.error === undefined || err.error === null)
          this.toasterService.showErrorMessage(
            this.verizonZipNPANXXHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
          );
        else if (err.error && err.error.ERR) {
          const commaSeperatedArr = err.error.ERR.split(",");
          for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
            if (commaSeperatedArr[i] != "")
              this.toasterService.showErrorMessage(
                commaSeperatedArr[i]
              );
          }
        }
        else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
          return;
        else this.toasterService.showErrorMessage(err.error);
      }
      );
  }

// to open ulk insert pop up
  openUploadCSVDialog() {
    const dialogRef = this.dialog.open(BulkInsertVerizonZipNPANXXComponent, {
        width: "90%",
        height: "90%",
    });
    // Create subscription
    dialogRef.afterClosed().subscribe((bulkInsertData) => {
        if (bulkInsertData && bulkInsertData.length > 0) {
            this.warningAlert("Your upload is complete. Please click on Submit to begin database insertions.")
            this.bulkInsertData = [...bulkInsertData];
            let filterKeys = Object.keys(this.frmVerizonZipNpanxx.controls);
        filterKeys.forEach(_e1 => {
            this.frmVerizonZipNpanxx.controls[`${_e1}`].setValidators([]);
            this.frmVerizonZipNpanxx.controls[`${_e1}`].updateValueAndValidity();
        });
        }
    });
}

//to add Verizon Zip Npanxx
private bulkInsertVerizonZipNpanxx() {
    this.showLoadingScreen = true;
    let obj: any = [];
    this.alreadyEnabled = true;
    // this.bulkInsertData.filter((v, i) =>
    //     this.bulkInsertData.findIndex(item => item.zip == v.zip) === i);
    obj = [...this.bulkInsertData];
    obj.forEach(element => {
        element.dbEnv = this.wizardHelper.dbEnv;
    });
    obj = this.wizardHelper.checkRequestObject(obj);
    obj.dbEnv = this.wizardHelper.dbEnv;
    this.wizardService.bulkInsertVerizonZipNpanxx(obj).pipe(takeUntil(this.unsubscribe))
        .subscribe(
        (data: any) => {
            if (data[0] === null || data[0] === undefined) {
                this.showLoadingScreen = false;
                this.toasterService.showErrorMessage(
                    this.verizonZipNPANXXHelper.getTracfoneConstantMethod("TRACFONE_ADD_VERIZON_ZIP_NPANXX_ERROR_MESSAGE")
                );
                return;
            }
            if (data[0] && data[0].ERR) {
                this.showLoadingScreen = false;
                const commaSeperatedArr = data[0].ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
                return;
            }
            this.showLoadingScreen = false;
            this.showMssg = true;
            this.revert();
        },
        (err: any) => {
            this.showLoadingScreen = false;
            if (err.error === undefined || err.error === null)
                this.toasterService.showErrorMessage(
                    this.verizonZipNPANXXHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                );
            else if (err.error && err.error.ERR) {
                const commaSeperatedArr = err.error.ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
            }
            else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                return;
            else this.toasterService.showErrorMessage(err.error);
        }
        );
}


private warningAlert(warningMsg: string) {
    window.scrollTo(0, 0);
    this.alerts = [];
    this.alerts.push({
        id: 3,
        type: 'warning',
        message: warningMsg
    });
  }

  public closeAlert(alert: any) {
    const index: number = this.alerts.indexOf(alert);
    this.alerts.splice(index, 1);
  }

  public showLastInsertedRecords() {
    this.returnedData.emit({ lastInsertedRecord: true });
  }


}


