import { Injectable } from "@angular/core";
import { Subject } from "rxjs";

@Injectable({
    providedIn: "root"
})
export class DataConfigMappingHelper {
    
    public breadcrumbListUpdate = new Subject<number>();
    public breadcrumbList = [];
    constructor() { }

    public carrierMaintenanceComponentConstantObject = {
        "TRACFONE_DEFAULT_ERROR_MESSAGE": "Unable to process request",
        "TRACFONE_UNABLE_RETRIEVE_RATEPLANS": "Unable to retrieve Rate Plans",
        "TRACFONE_ADD_DATA_CONFIG_MAPPING_ERROR_MESSAGE": "Unable to add Data Config Mapping",
        "TRACFONE_ADD_DATA_CONFIG_MAPPING_SUCCESS_MESSAGE": "Data Config Mapping has been added successfully",
		"TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE" : "Please complete previous operation",
		"TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE": "Please fix validation errors",
        "TRACFONE_UPDATE_DATA_CONFIG_MAPPING_ERROR_MESSAGE": "Unable to update Data Config Mapping",
        "TRACFONE_UPDATE_DATA_CONFIG_MAPPING_SUCCESS_MESSAGE": "Data Config Mapping has been updated successfully",
        "TRACFONE_DELETE_DATA_CONFIG_MAPPING_ERROR_MESSAGE": "Unable to delete Data Config Mapping",
        "TRACFONE_DELETE_DATA_CONFIG_MAPPING_SUCCESS_MESSAGE": "Data Config Mapping has been deleted successfully",
        "TRACFONE_DELETE_DATA_CONFIG_MAPPING_CONFIRM_MESSAGE": "Are you sure you want to delete Data Config Mapping ?",
        "TRACFONE_DONE_CREATING_DATA_CONFIG_MAPPING_CONFIRM_MESSAGE": "Are you done creating Data Config Mappings ?",
        "TRACFONE_RETRIEVE_DATA_CONFIG_MAPPING_ERROR_MESSAGE": "Unable to retrieve Data Config Mappings",
        "TRACFONE_SEARCH_DATA_CONFIG_MAPPING_ERROR_MESSAGE": "No Data Config Mappings Found",
        "TRACFONE_RETRIEVE_DATA_CONFIG_ERROR_MESSAGE": "Unable to retrieve Data Configs",
        "TRACFONE_DATA_CONFIG_NOT_FOUND_ERROR_MESSAGE": "No Data Configs found",
        "TRACFONE_UNABLE_RETRIEVE_PART_CLASS_OBJID": "Unable to retrieve part Class Obj Id",
        "TRACFONE_RETRIEVE_PARENT_ID_ERROR_MESSAGE": "Unable to retrieve Parent Id"
        
    }

    public getTracfoneConstantMethod(msg) {
        return this.carrierMaintenanceComponentConstantObject[msg];
    }

}