import { Component, OnInit } from "@angular/core";

@Component({
    selector: 'data-config-mapping-wizard',
    templateUrl: './data-config-mapping-wizard.html',
})
export class DataConfigMappingComponent implements OnInit {

    constructor() { }

    ngOnInit() { }
}


