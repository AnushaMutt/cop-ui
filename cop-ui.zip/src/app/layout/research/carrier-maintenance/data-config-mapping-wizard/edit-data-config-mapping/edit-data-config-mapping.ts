import { Subject } from "rxjs";
import { Component, ViewEncapsulation, OnInit, ViewChildren } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { ConfirmationService } from 'primeng/primeng';
import { takeUntil } from 'rxjs/operators';
import { MatSelect } from "@angular/material";
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CarrierMaintenanceService } from '../../../../../Services/carrierMaintenance.service';
import { CarrierMaintenanceHelper } from "../../carrier-maintenance-helper";
import { ToasterService } from "../../../../../Services/toaster.service";
import { DataConfigMappingService } from "../data-config-mapping-wizard.service";
import { DataConfigMappingHelper } from "../data-config-mapping-wizard.helper";

@Component({
    selector: 'edit-data-config-mapping',
    templateUrl: './edit-data-config-mapping.html',
    styleUrls: ['./edit-data-config-mapping.scss',
        "../../../../components/ngxtable/material.scss",
        "../../../../components/ngxtable/datatable.component.scss",
        "../../../../components/ngxtable/icons.css",
        "../../../../components/ngxtable/app.css"],
    animations: [],
    encapsulation: ViewEncapsulation.None,
})
export class EditDataConfigMappingComponent implements OnInit {
    @ViewChildren(DatatableComponent)
    table: any;
    @ViewChildren(MatSelect) matSelect: any;
    private unsubscribe = new Subject<void>();
    public frmGroupDataConfig: FormGroup;
    public showLoadingScreen: boolean;
    public parentName: any = [];
    public parentNameMainData: any = [];
    private allrateplans;
    private allrateplansMainData;
    public frmGroupData: FormGroup;
    showpfExtensionLoadingScreen:boolean;
    public dataConfigMapping: any = [];
    public mappingMaindata: any = [];
    public addConfigFields: any = [];
    public alerts: Array<any> = [];
    public dataConfigFields: any = [];
    public configIdData: any;
    public configIdMainData: any;
    public isEditable: any = {}
    public editedRow: any = {};
    public defaultEditedRow: any = {};
    public dataConfigs: any = [];
    public dataConfigMaindata: any = [];
    configRow: any;
    configBoolean: boolean = false;
    public displayTable = false;
    public availableDataConfigs:any = [];
    showConfigLoadingScreen: boolean;
    public partClassData: any = [];
    public partClassMainData: any = [];

     constructor(
        private _formBuilder: FormBuilder,
        private wizardService: CarrierMaintenanceService,
        private dataConfigHelper: DataConfigMappingHelper,
        private toasterService: ToasterService,
        private wizardHelper: CarrierMaintenanceHelper,
        private modalService: NgbModal,
        private confirmationService: ConfirmationService,
        private dataConfigService: DataConfigMappingService
        
    ) {
        this.frmGroupDataConfig = new FormGroup({});
        this.frmGroupData = new FormGroup({});
     }

    ngOnInit() {
        this.allrateplans = [];
        this.allrateplansMainData = [];
        this.parentName = [];
        this.parentNameMainData = [];
        this.mappingMaindata = [];
        this.dataConfigMapping = [];
        this.partClassData = [];
        this.partClassMainData = [];
        this.configIdData = "";
        this.configIdMainData = "";
        this.addConfigFields = [
            {name: "Parent Id", prop: "parentId",  width: '100' },
            {name: "Part Class ObjId", prop: "partClassObjId",  width: '250' },
            {name: "Rate Plan", prop: "ratePlan",  width: '350' },
            {name: "Data Config ObjId", prop: "dataConfigObjId",  width: '100' }
        ];
        this.availableDataConfigs = [
            { name: "ObjId", prop: "objId", width: '250' },
            { name: "Dev", prop: "dev", width: '250' },
            { name: "Parent Id", prop: "parentId", width: '250' },
            { name: "Part Class ObjId", prop: "partClassObjId", width: '250' },
            { name: "Default", prop: "xDefault", width: '250' },
            { name: "IP Address", prop: "ipAddress", width: '250' },
            { name: "APN", prop: "apn", width: '250' },
            { name: "Home Page", prop: "homePage", width: '300' },
            { name: "MMSC", prop: "mmsc", width: '300' },
            { name: "CMD 148 Carrier Data Switch", prop: "cmd148CarrierDataSwitch", width: '200' },
            { name: "Data Switch", prop: "dataSwitch", width: '250' },
            { name: "CMD 71 GPRS APN", prop: "cmd71GprsApn", width: '100' },
            { name: "CMD 150 Clear Proxy", prop: "cmd150ClearProxy", width: '150' },
            { name: "CMD 121 Gateway Port Update", prop: "cmd121GatewayPortUpdate", width: '200' },
            { name: "CMD 121 Gateway IP Update", prop: "cmd121GatewayIpUpdate", width: '180' },
            { name: "CMD 71 MMSC Update", prop: "cmd71MmscUpdate", width: '150' },
            { name: "CMD 71 Gateway Home", prop: "cmd71GatewayHome", width: '160' },
            { name: "CMD 121 Gateway IP Port Update", prop: "cmd121GatewayIpPortUpdate", width: '220' },
        ];
        this.createDataConfigForm();
        this.createSearchForm();
        if (this.dataConfigService.getRatePlan() && this.dataConfigService.getRatePlan().length > 0) {
        this.dataConfigService.getRatePlan().forEach(e1 => {
            this.allrateplans.push(e1)
        });
        this.allrateplansMainData = [...this.allrateplans];
        this.dataConfigService.getParentId().forEach(e2 => {
            this.parentName.push(e2)
        });
        this.parentNameMainData = [...this.parentName];
        this.dataConfigService.getPartClass().forEach(e3 => {
            this.partClassMainData.push(e3)
        });
        this.partClassData = [...this.partClassMainData];
    }else{
        this.retrieveRatePlans();
    }
    }

    public createDataConfigForm() {
        this.frmGroupDataConfig = this._formBuilder.group({
            parentId: ['', [Validators.maxLength(30)]],
            partClassObjId: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            ratePlan: ['', [Validators.maxLength(60)]],
            dataConfigObjId: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
        });
    }

    public createSearchForm() {
        this.frmGroupData = this._formBuilder.group({
            objId: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            dev: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            parentId: ['', [Validators.maxLength(30)]],
            partClassObjId: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            xDefault: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            ipAddress: ['', [Validators.maxLength(30)]],
            apn: ['', [Validators.maxLength(30)]],
            homePage: ['', [Validators.maxLength(150)]],
            mmsc: ['', [Validators.maxLength(150)]],
            cmd148CarrierDataSwitch: ['', [Validators.maxLength(1)]],
            dataSwitch: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            cmd71GprsApn: ['', [Validators.maxLength(1)]],
            cmd150ClearProxy: ['', [Validators.maxLength(1)]],
            cmd121GatewayPortUpdate: ['', [Validators.maxLength(1)]],
            cmd121GatewayIpUpdate: ['', [Validators.maxLength(1)]],
            cmd71MmscUpdate: ['', [Validators.maxLength(1)]],
            cmd71GatewayHome: ['', [Validators.maxLength(1)]],
            cmd121GatewayIpPortUpdate: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(22)]],
        });
    }

    // to retrieve rateplans
    public retrieveRatePlans(){
       this.showLoadingScreen = true;
        let obj: any = {};
         this.allrateplans = [];
        this.allrateplansMainData = [];
        obj.dbEnv = this.wizardHelper.dbEnv;
        this.wizardService
            .getAvailableRatePlans(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {

                        this.toasterService.showErrorMessage(
                            this.dataConfigHelper.getTracfoneConstantMethod("TRACFONE_UNABLE_RETRIEVE_RATEPLANS")
                        );
                        this.showLoadingScreen = false;
                        return;
                    }
                        if (data[0] && data[0].ERR) {
                            this.showLoadingScreen = false;
                            const commaSeperatedArr = data[0].ERR.split(",");
                            for (
                                let i = commaSeperatedArr.length - 1;
                                i >= 0;
                                i--
                            ) {
                                if (commaSeperatedArr[i] != "")
                                    this.toasterService.showErrorMessage(
                                        commaSeperatedArr[i]
                                    );
                              }
                            return;
                        }
                        if(data[0].length == 0)
                            this.toasterService.showErrorMessage("No Rate Plans found");
                    this.allrateplans = data[0];
                    this.allrateplansMainData = data[0];
                    this.dataConfigService.setRatePlan(this.allrateplansMainData);
                    this.showLoadingScreen = false;
                    this.retrieveParentId();
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null){
                        this.toasterService.showErrorMessage(
                            this.dataConfigHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    }
                    else if(err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    // to retrieve part class objid
    public retrievePartClassObjId() {
        this.showLoadingScreen = true;
        let obj: any = {};
        this.partClassData = [];
        this.partClassMainData = [];
        obj.dbEnv = this.wizardHelper.dbEnv;
        this.wizardService
            .retrievePartClassObjId(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {

                    this.toasterService.showErrorMessage(
                        this.dataConfigHelper.getTracfoneConstantMethod("TRACFONE_UNABLE_RETRIEVE_PART_CLASS_OBJID")
                    );
                    this.showLoadingScreen = false;
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (
                        let i = commaSeperatedArr.length - 1;
                        i >= 0;
                        i--
                    ) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                if (data[0].length == 0)
                    this.toasterService.showErrorMessage("No Part Class Obj Id found");
                this.partClassData = data[0];
                this.partClassMainData = data[0];
                this.dataConfigService.setPartClass(this.partClassMainData);
                this.showLoadingScreen = false;
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null) {
                    this.toasterService.showErrorMessage(
                        this.dataConfigHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }

    private retrieveParentId() {
        this.showLoadingScreen = true;
        var obj: any = {}
        this.wizardService
            .getParentName(this.wizardHelper.dbEnv, '')
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.toasterService.showErrorMessage(
                        this.dataConfigHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_PARENT_ID_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (
                        let i = commaSeperatedArr.length - 1;
                        i >= 0;
                        i--
                    ) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                this.showLoadingScreen = false;
                this.parentNameMainData = data[0];

                let uniqueValue = this.parentNameMainData.filter((v, i) =>
                 this.parentNameMainData.findIndex(item => item.parentId == v.parentId) === i);
                this.parentNameMainData = [...uniqueValue];
                this.parentName = [...this.parentNameMainData];
                this.dataConfigService.setParentId(this.parentName);
                this.retrievePartClassObjId();
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.dataConfigHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }

     // to search data config obj id
    public searchDataConfig(searchData) {
        this.dataConfigs = [];
        this.dataConfigMaindata = [];
        this.alerts = [];
        this.showConfigLoadingScreen = true;
        let obj = searchData.value;
        obj = this.wizardHelper.checkRequestObject(obj);
        obj.dbEnv = this.wizardHelper.dbEnv;
          this.wizardService.searchDataConfig(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
              if (data[0] === null || data[0] === undefined) {
                this.showConfigLoadingScreen = false;
                this.failedAlert(this.dataConfigHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_DATA_CONFIG_ERROR_MESSAGE")
        		);
                return;
              }
              if (data[0] && data[0].ERR) {
                this.showConfigLoadingScreen = false;
                const commaSeperatedArr = data[0].ERR.split(",");
                for (
                  let i = commaSeperatedArr.length - 1;
                  i >= 0;
                  i--
                ) {
                  if (commaSeperatedArr[i] != "")
                    this.toasterService.showErrorMessage(
                      commaSeperatedArr[i]
                    );
                }
                return;
              }
              this.showConfigLoadingScreen = false;
              this.dataConfigs = data[0];
              this.dataConfigMaindata = [...this.dataConfigs];

          if (data[0] && data[0].length == 0)
              this.failedAlert(this.dataConfigHelper.getTracfoneConstantMethod("TRACFONE_DATA_CONFIG_NOT_FOUND_ERROR_MESSAGE"));
            },
            (err: any) => {
              this.showConfigLoadingScreen = false;
              if (err.error === undefined || err.error === null)
                this.failedAlert(this.dataConfigHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE"));
              else if (err.error && err.error.ERR) {
                const commaSeperatedArr = err.error.ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                  if (commaSeperatedArr[i] != " ")
                    this.toasterService.showMultiple(
                      commaSeperatedArr[i]
                    );
                }
              } 
              else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
              return;
              else this.toasterService.showErrorMessage(err.error);
            }
            );
    }

    public onSearchForm() {
      this.showLoadingScreen = true;
      this.dataConfigMapping = [];
      this.mappingMaindata = [];

      let obj: any = {};
      obj = this.wizardHelper.checkRequestObject(
        this.frmGroupDataConfig.value
      );
      obj.dbEnv = this.wizardHelper.dbEnv;

      this.wizardService.searchDataConfigMapping(obj).pipe(takeUntil(this.unsubscribe))
        .subscribe(
        (data: any) => {
          if (data[0] === null || data[0] === undefined) {
            this.showLoadingScreen = false;
            this.toasterService.showErrorMessage(
              this.dataConfigHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_DATA_CONFIG_MAPPING_ERROR_MESSAGE")
            );
            return;
          }
          if (data[0] && data[0].ERR) {
            this.showLoadingScreen = false;
            const commaSeperatedArr = data[0].ERR.split(",");
            for (
              let i = commaSeperatedArr.length - 1;
              i >= 0;
              i--
            ) {
              if (commaSeperatedArr[i] != "")
                this.toasterService.showErrorMessage(
                  commaSeperatedArr[i]
                );
            }
            return;
          }
          this.showLoadingScreen = false;
         
          this.dataConfigMapping = data[0];

          let rowId = 1;
                    this.dataConfigMapping.forEach(element => {
                        element.rowId = rowId;
                        rowId++;
                    });

          this.mappingMaindata = [...this.dataConfigMapping];
         
          if (data[0] && data[0].length == 0)
            this.toasterService.showErrorMessage(
              this.dataConfigHelper.getTracfoneConstantMethod("TRACFONE_SEARCH_DATA_CONFIG_MAPPING_ERROR_MESSAGE")
            );
        },
        (err: any) => {
          this.showLoadingScreen = false;
          if (err.error === undefined || err.error === null)
            this.toasterService.showErrorMessage(
              this.dataConfigHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
            );
          else if (err.error && err.error.ERR) {
            const commaSeperatedArr = err.error.ERR.split(",");
            for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
              if (commaSeperatedArr[i] != " ")
                this.toasterService.showMultiple(
                  commaSeperatedArr[i]
                );
            }
          } 
          else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
          return;
          else this.toasterService.showErrorMessage(err.error);
        }
        );
  }

  public editButtonClicked(rowData, rowIndex) {
        let alreadyEnabled = false;
        this.defaultEditedRow = { ...rowData }
        for (let i = 0; i < this.dataConfigMapping.length; i++) {
            if (this.isEditable[i])
                alreadyEnabled = true;
        }
        if (!alreadyEnabled)
            this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        else
            this.toasterService.showErrorMessage(
                this.dataConfigHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE")
            );
    }

    // to cancel edit
    public cancelEditForm(rowData, rowIndex) {
        this.showLoadingScreen = true;
        this.isEditable[rowIndex] = !this.isEditable[rowIndex];

        for (let i = 0; i < this.dataConfigMapping.length; i++) {
            if (this.dataConfigMapping[i].rowId == this.defaultEditedRow.rowId ) {
                this.dataConfigMapping[i] = this.defaultEditedRow;
            }
        }
        let tableRows = [...this.dataConfigMapping];
        this.dataConfigMapping = [...tableRows];

        this.matSelect._results.forEach(matSelectData => {
            if (matSelectData.id.indexOf('parentId' + rowIndex) == 0)
                matSelectData.value = rowData['parentId'] || '';
            else if (matSelectData.id.indexOf('partClassObjId' + rowIndex) == 0)
                matSelectData.value = rowData['partClassObjId'] || '';
            else if (matSelectData.id.indexOf('ratePlan' + rowIndex) == 0)
                matSelectData.value = rowData['ratePlan'] || '';
        });
        this.editedRow = {};
        this.defaultEditedRow = {};
        this.showLoadingScreen = false;
    }

    public editDataConfigMapping(configdata, rowIndex) {
        if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
            this.toasterService.showErrorMessage(
                this.dataConfigHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            return;
        }
        this.showLoadingScreen = true;
        let obj = { ...configdata, ...this.editedRow }

        obj = this.wizardHelper.checkRequestObject(obj);
        obj.dbEnv = this.wizardHelper.dbEnv;
        obj.oldParentId = this.defaultEditedRow.parentId;
        obj.oldPartClassObjId = this.defaultEditedRow.partClassObjId;
        obj.oldRatePlan = this.defaultEditedRow.ratePlan;
        obj.oldDataConfigObjId = this.defaultEditedRow.dataConfigObjId;
        this.wizardService.updateDataConfigMapping(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.dataConfigHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_DATA_CONFIG_MAPPING_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                for (let i = 0; i < this.mappingMaindata.length; i++) {                    
                        if(configdata.rowId == this.mappingMaindata[i].rowId ){
                        this.mappingMaindata[i] = obj;
                    }
                }
                this.dataConfigMapping = [...this.mappingMaindata];
                this.dataConfigMapping = [...this.dataConfigMapping];

                 let getConfigdata = this.dataConfigService.getDataConfigMapping();

          if(getConfigdata.length > 0){
            for(let i = 0;i<getConfigdata.length;i++){
            if (configdata.parentId == getConfigdata[i].parentId && configdata.partClassObjId == getConfigdata[i].partClassObjId
            && configdata.rateplan == getConfigdata[i].rateplan && this.defaultEditedRow.dataConfigObjId == getConfigdata[i].dataConfigObjId) {
                getConfigdata[i] = obj;
                this.dataConfigService.setDataConfigMapping(getConfigdata);
              }
            }
          }
                this.toasterService.showSuccessMessage(
                    this.dataConfigHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_DATA_CONFIG_MAPPING_SUCCESS_MESSAGE")
                );

                this.isEditable[rowIndex] = !this.isEditable[rowIndex];
                this.showLoadingScreen = false;
                this.editedRow = {};
                this.defaultEditedRow = {};
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.dataConfigHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }

    public deleteRow(configData) {
        this.dataConfigMapping.forEach((data, key) => {            
            if (configData.rowId == data.rowId) {
                this.dataConfigMapping.splice(key, 1);
            }
        });
        this.dataConfigMapping = [...this.dataConfigMapping];
        this.mappingMaindata = [...this.dataConfigMapping];
        if (this.dataConfigMapping.length === 0) {
            this.displayTable = false;
            this.configBoolean = false;
            this.dataConfigMapping = [];
            this.mappingMaindata = [];
            this.revert();
        }

        let getConfigData = this.dataConfigService.getDataConfigMapping();

          if(getConfigData.length > 0){
            for(let i = 0; i<getConfigData.length;i++){
            if (configData.parentId == getConfigData[i].parentId  && configData.partClassObjId == getConfigData[i].partClassObjId &&
            configData.rateplan == getConfigData[i].rateplan && configData.dataConfigObjId == getConfigData[i].dataConfigObjId) {
                this.dataConfigService.getDataConfigMapping().splice(i,1);
              let addConfig = [...this.dataConfigService.getDataConfigMapping()];
              this.dataConfigService.setDataConfigMapping(addConfig);
              }
            }
          }
    }

    // to delete dta config mapping
    public deleteDataConfigMapping(configdata) {
        this.showLoadingScreen = true;
        let obj = configdata;
        obj.dbEnv = this.wizardHelper.dbEnv;
        this.wizardService.deleteDataConfigMapping(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.dataConfigHelper.getTracfoneConstantMethod("TRACFONE_DELETE_DATA_CONFIG_MAPPING_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }

                this.toasterService.showSuccessMessage(
                    this.dataConfigHelper.getTracfoneConstantMethod("TRACFONE_DELETE_DATA_CONFIG_MAPPING_SUCCESS_MESSAGE")
                );
                this.showLoadingScreen = false;
                this.deleteRow(configdata);
                this.editedRow = {};
                this.defaultEditedRow = {};
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.dataConfigHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }

    public inputValueChanged(event, column, row, oldValue) {
        if (column != "parentId" && column != "partClassObjId" && column != "ratePlan") {

            this.editedRow[column] = event.target.value;
            this.defaultEditedRow[column] = event.target.defaultValue;
        }
        else {
            this.editedRow[column] = event.value;
            this.defaultEditedRow[column] = oldValue;
        }
    }

    // delete confirm
    public showConfirm(dataConfigMapping) {
        this.confirmationService.confirm({
            key: 'confirm-delete-config',
            message: this.dataConfigHelper.getTracfoneConstantMethod("TRACFONE_DELETE_DATA_CONFIG_MAPPING_CONFIRM_MESSAGE"),
            accept: () => {
                this.deleteDataConfigMapping(dataConfigMapping)
            }
        });
    }

    private onSelect(row) {
        this.configIdData = row;
        this.configIdMainData = this.configIdData.objId;
    }

    setData() {
        if (this.configBoolean) {
            for (let i = 0; i < this.dataConfigMapping.length; i++) {
                if (this.dataConfigMapping[i].rowId == this.configRow.rowId ) {
                    this.dataConfigMapping[i].dataConfigObjId = this.configIdMainData;
                }
            }
            this.dataConfigMapping = [...this.dataConfigMapping]
            this.configIdMainData = [];
        }
    }

    // to close data config pop up
    closeModelPopUp() {
       this.dataConfigs = [];
       this.dataConfigMaindata = [];
       this.frmGroupData.reset();
    }

    public closeAlert(alert: any) {
        const index: number = this.alerts.indexOf(alert);
        this.alerts.splice(index, 1);
    }

    // to open pop up
    openSml(event, content, key, row) {
        this.configRow = {};
        this.modalService.open(content, { size: 'lg', backdrop: 'static', keyboard: false });
        if (key == 'config') {
            this.configBoolean = true;
            this.configRow = row;
        }
    }

    public openedChange(rowData) {
        if (rowData == "searchParentInput")
            this.parentName = [...this.parentNameMainData];
        else if (rowData == "searchRatePlanInput")
            this.allrateplans = [...this.allrateplansMainData];
        else if (rowData == "searchPartClass")
            this.partClassData = [...this.partClassMainData];
    }

    public onKey(value, rowData) {
        if (rowData == "searchParentInput") {
            this.parentName = [...this.parentNameMainData];
            this.parentName = this.search(value, "parentId");
        } else if (rowData == "searchRatePlanInput") {
            this.allrateplans = [...this.allrateplansMainData];
            this.allrateplans = this.search(value, "allrateplans");
        } else if (rowData == "searchPartClass") {
            this.partClassData = [...this.partClassMainData];
            this.partClassData = this.search(value, "partClass");
        }
    }

    //filter for dropdown
    public search(value: string, choice: string) {
        let filter = value.toLowerCase();
        if (choice == "parentId")
            return this.parentNameMainData.filter(option => option.parentId.indexOf(filter) > -1);
        else if (choice == "allrateplans")
            return this.allrateplansMainData.filter(option => option.ratePlanName.toLowerCase().indexOf(filter) > -1);
        else if (choice == "partClass")
            return this.partClassMainData.filter(option => (option.name &&option.name.toLowerCase().indexOf(filter) > -1) ||
                (option.objId && option.objId.indexOf(filter) > -1));
    }

    public updateDataConfig(event) {
    const val = event.target.value.toLowerCase();

    // filter our data
    const temp = this.mappingMaindata.filter(function (d) {
      return (d.parentId ? d.parentId.toLowerCase().indexOf(val) !== -1 : !val) || !val
        || (d.partClassObjId ? d.partClassObjId.indexOf(val) !== -1 : !val) || !val
        || (d.ratePlan ? d.ratePlan.toLowerCase().indexOf(val) !== -1 : !val) || !val
        || (d.dataConfigObjId ? d.dataConfigObjId.indexOf(val) !== -1 : !val) || !val;
    });
    // update the rows
    this.dataConfigMapping = temp;
    // Whenever the filter changes, always go back to the first page
    this.dataConfigMapping.offset = 0;
  }
  
    public revert() {
    this.frmGroupDataConfig.reset(); 
    this.mappingMaindata = [];
    this.dataConfigMapping = [];
    }

    // to reset search form
    public revertSearch() {
        this.frmGroupData.reset();
        this.dataConfigMaindata = [];
        this.dataConfigs = [];
    }

    private failedAlert(errorMsg: string) {
        this.alerts = [];
        this.alerts.push(
            {
                id: 4,
                type: 'danger',
                message: errorMsg
            }
        );
    }

    public gotTodoneStep() {
        window.location.reload();
    }

}
    