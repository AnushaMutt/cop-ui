import { Injectable } from "@angular/core";

@Injectable({
    providedIn: "root"
})
export class DataConfigMappingService {
configData: any = [];
ratePlanData: any = [];
parenIdData:any = [];
partClassData: any = [];

    constructor() { }

    public setDataConfigMapping(configData) {
        this.configData = configData;
    }

    public getDataConfigMapping() {
        return this.configData;
    }

    public setRatePlan(ratePlanData) {
        this.ratePlanData = ratePlanData;
    }

    public getRatePlan() {
        return this.ratePlanData;
    }
    public setParentId(parenIdData) {
        this.parenIdData = parenIdData;
    }

    public getParentId() {
        return this.parenIdData;
    }
    public setPartClass(partClassData) {
        this.partClassData = partClassData;
    }

    public getPartClass() {
        return this.partClassData;
    }

    public resetDataConfigMapping(){
        this.configData = [];
    }

    public resetConfigData(){
        this.ratePlanData = [];
        this.parenIdData = [];
        this.partClassData = [];
    }

}