import { Component, OnInit, ViewChild } from "@angular/core";
import { NgbTabset } from '@ng-bootstrap/ng-bootstrap';


@Component({
    selector: 'geo-loc',
    templateUrl: './geo-loc.component.html',
})
export class GeoLocComponent implements OnInit {
    @ViewChild('tabs')
    private tabs: NgbTabset;
    // readonly SUMMARY_TAB = "summaryTab";

    constructor() { }

    ngOnInit() { }


    public returnedDatas(data) {
        if (data.lastInsertedRecord) {
            // this.tabs.select(this.SUMMARY_TAB);
        }
    }

}