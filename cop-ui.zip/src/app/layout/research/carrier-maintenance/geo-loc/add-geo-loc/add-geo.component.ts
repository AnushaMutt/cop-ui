import { Component, OnInit, ViewEncapsulation, ViewChildren, Output, EventEmitter, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { ConfirmationService } from 'primeng/primeng';
import { takeUntil } from 'rxjs/operators';
import { Subject } from "rxjs";
import { CarrierMaintenanceService } from '../../../../../Services/carrierMaintenance.service';
import { CarrierMaintenanceHelper } from "../../carrier-maintenance-helper";
import { ToasterService } from "../../../../../Services/toaster.service";
import { GeoLoclocalService } from "../geo-loc-service";

@Component({
    selector: 'add-geo-loc',
    templateUrl: './add-geo.component.html',
    styleUrls: ['./add-geo.component.scss',
        "../../../../components/ngxtable/material.scss",
        "../../../../components/ngxtable/datatable.component.scss",
        "../../../../components/ngxtable/icons.css",
        "../../../../components/ngxtable/app.css"],
    animations: [],
    encapsulation: ViewEncapsulation.None,
})

export class AddGeoLocComponent implements OnInit {
    public alerts = [];
    private unsubscribe = new Subject<void>();
    public showLoadingScreen = false;
    public addFromGroup: FormGroup;
    public displayTable = false;
    public userData = [];
    public userMainData = [];
    public geoLocMainData: any = [];
    public geoLocData: any = [];
    private checkedAnother = false;
    public filteredValues: any = {};
    public geoLocColumns: any = [];
    public selected = [];
    public isEditable = {};
    public editAlreadyEnabled = false;
    public defaultEditedRow: any = {};
    private editedRow: any = {};
    public checkDuplicate = false;
    public alreadyEnabled = true;
    public latitudeValMsg = "";
    public longitudeValMsg = "";

    public rlatitudeValMsg = "";
    public rlongitudeValMsg = "";

    public srlatitudeValMsg = "";
    public crlatitudeValMsg = "";

    constructor(
        private formBuilder: FormBuilder,
        private toasterService: ToasterService,
        private wizardHelper: CarrierMaintenanceHelper,
        private confirmationService: ConfirmationService,
        private wizardService: CarrierMaintenanceService,
        private geoLoclocalService: GeoLoclocalService,
    ) { }

    ngOnInit() {
        this.createAddFormGroup();
        this.getUser();
        this.geoLoclocalService.setAddData([]);
        this.geoLocColumns = [
            { name: 'ZIP', prop: 'zip', width: "180" },
            { name: 'STATE', prop: 'state', width: "180" },
            { name: 'POPCY', prop: 'popcy', width: "180" },
            { name: 'POP05', prop: 'pop05', width: "180" },
            { name: 'LATITUDE', prop: 'latitude', width: "180" },
            { name: 'LONGITUDE', prop: 'longitude', width: "180" },
            { name: 'RLATITUDE', prop: 'rlatitude', width: "180" },
            { name: 'RLONGITUDE', prop: 'rlongitude', width: "180" },
            { name: 'SRLATITUDE', prop: 'srlatitude', width: "180" },
            { name: 'CRLATITUDE', prop: 'crlatitude', width: "180" },
            { name: 'RZG2USER', prop: 'rzg2user', width: "180" },
        ];
    }

    public checkNumValdationAdd(val, col){
        if(col == "latitude"){
            if(!/^[-+]?\d*\.?\d*$/.test(val)){
                this.latitudeValMsg = 'LATITUDE must be a number'
            }
            else if(!/^[-+]?\d{0,38}(\.\d{1,9})?$/.test(val)){
                this.latitudeValMsg = 'Invalid number.'
            }else{
                this.latitudeValMsg = ""; 
            }
        } 
        else if(col == "longitude"){
            if(!/^[-+]?\d*\.?\d*$/.test(val)){
                this.longitudeValMsg = 'LONGITUDE must be a number'
            }
            else if(!/^[-+]?\d{0,38}(\.\d{1,9})?$/.test(val)){
                this.longitudeValMsg = 'Invalid number.'
            }else{
                this.longitudeValMsg = ""; 
            }
        }
        else if(col == "rlatitude"){
            if(!/^[-+]?\d*\.?\d*$/.test(val)){
                this.rlatitudeValMsg = 'RLATITUDE must be a number'
            }
            else if(!/^[-+]?\d{0,38}(\.\d{1,20})?$/.test(val)){
                this.rlatitudeValMsg = 'Invalid number.'
            }else{
                this.rlatitudeValMsg = ""; 
            }
        }
        else if(col == "rlongitude"){
            if(!/^[-+]?\d*\.?\d*$/.test(val)){
                this.rlongitudeValMsg = 'RLONGITUDE must be a number'
            }
            else if(!/^[-+]?\d{0,38}(\.\d{1,20})?$/.test(val)){
                this.rlongitudeValMsg = 'Invalid number.'
            }else{
                this.rlongitudeValMsg = ""; 
            }
        }
        else if(col == "srlatitude"){
            if(!/^[-+]?\d*\.?\d*$/.test(val)){
                this.srlatitudeValMsg = 'SRLATITUDE must be a number'
            }
            else if(!/^[-+]?\d{0,38}(\.\d{1,40})?$/.test(val)){
                this.srlatitudeValMsg = 'Invalid number.'
            }else{
                this.srlatitudeValMsg = ""; 
            }
        }
        else if(col == "crlatitude"){
            if(!/^[-+]?\d*\.?\d*$/.test(val)){
                this.crlatitudeValMsg = 'CRLATITUDE must be a number'
            }
            else if(!/^[-+]?\d{0,38}(\.\d{1,40})?$/.test(val)){
                this.crlatitudeValMsg = 'Invalid number.'
            }else{
                this.crlatitudeValMsg = ""; 
            }
        }
    }

    public checkNumValdation(val, col, row){
        if(col == "latitude"){
            if(!/^[-+]?\d*\.?\d*$/.test(val)){
                row.latitudeValMsg = 'LATITUDE must be a number'
            }
            else if(!/^[-+]?\d{0,38}(\.\d{1,9})?$/.test(val)){
                row.latitudeValMsg = 'Invalid number.'
            }else{
                row.latitudeValMsg = ""; 
            }
        } 
        else if(col == "longitude"){
            if(!/^[-+]?\d*\.?\d*$/.test(val)){
                row.longitudeValMsg = 'LONGITUDE must be a number'
            }
            else if(!/^[-+]?\d{0,38}(\.\d{1,9})?$/.test(val)){
                row.longitudeValMsg = 'Invalid number.'
            }else{
                row.longitudeValMsg = ""; 
            }
        }
        else if(col == "rlatitude"){
            if(!/^[-+]?\d*\.?\d*$/.test(val)){
                row.rlatitudeValMsg = 'RLATITUDE must be a number'
            }
            else if(!/^[-+]?\d{0,38}(\.\d{1,20})?$/.test(val)){
                row.rlatitudeValMsg = 'Invalid number.'
            }else{
                row.rlatitudeValMsg = ""; 
            }
        }
        else if(col == "rlongitude"){
            if(!/^[-+]?\d*\.?\d*$/.test(val)){
                row.rlongitudeValMsg = 'RLONGITUDE must be a number'
            }
            else if(!/^[-+]?\d{0,38}(\.\d{1,20})?$/.test(val)){
                row.rlongitudeValMsg = 'Invalid number.'
            }else{
                row.rlongitudeValMsg = ""; 
            }
        }
        else if(col == "srlatitude"){
            if(!/^[-+]?\d*\.?\d*$/.test(val)){
                row.srlatitudeValMsg = 'SRLATITUDE must be a number'
            }
            else if(!/^[-+]?\d{0,38}(\.\d{1,40})?$/.test(val)){
                row.srlatitudeValMsg = 'Invalid number.'
            }else{
                row.srlatitudeValMsg = ""; 
            }
        }
        else if(col == "crlatitude"){
            if(!/^[-+]?\d*\.?\d*$/.test(val)){
                row.crlatitudeValMsg = 'CRLATITUDE must be a number'
            }
            else if(!/^[-+]?\d{0,38}(\.\d{1,40})?$/.test(val)){
                row.crlatitudeValMsg = 'Invalid number.'
            }else{
                row.crlatitudeValMsg = ""; 
            }
        }
        
    }


    //Enable inline editing
    public editButtonClicked(rowData, rowIndex) {
        this.editAlreadyEnabled = true;
        this.defaultEditedRow = { ...rowData }
        let alreadyEnabled = false;
        for (let i = 0; i < this.geoLocColumns.length; i++) {
            if (this.isEditable[i])
                alreadyEnabled = true;
        }
        if (!alreadyEnabled)
            this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        else
            this.toasterService.showErrorMessage(
                this.wizardHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE"),
            );
    }
    //to cancel update
    private cancelEditForm(rowData, rowIndex) {
        this.showLoadingScreen = true;
        this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        this.geoLocColumns.forEach(e1 => {
            if (document.getElementById(e1.prop + rowIndex)) {
                (<HTMLInputElement>(
                    document.getElementById(e1.prop + rowIndex)
                )).value = rowData[e1.prop] || '';
            }
        });
        this.editAlreadyEnabled = false;
        this.editedRow = {};
        this.defaultEditedRow = {};
        this.showLoadingScreen = false;
        this.alreadyEnabled = true;
        this.checkDuplicate = false;

        rowData.latitudeValMsg = '';
        rowData.longitudeValMsg = '';

        rowData.rlatitudeValMsg = '';
        rowData.rlongitudeValMsg = '';

        rowData.srlatitudeValMsg = '';
        rowData.crlatitudeValMsg = '';
    }

    private inputValueChanged(event, column, row, oldValue) {
        this.editedRow[column] = event.target.value;
        this.defaultEditedRow[column] = event.target.defaultValue;
    }

    public inlineUpdateGeoLoc(editData, rowIndex) {
        if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
            this.toasterService.showErrorMessage(
                this.wizardHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            return;
        }
        this.showLoadingScreen = true;

        let obj = { ...editData, ...this.editedRow }
        if (this.editedRow.zip) {
            obj.checkDuplicate = true;
        }
        obj.oldZip = editData.zip;

        obj = this.wizardHelper.checkRequestObject(obj);

        if (obj.oldZip == obj.zip) {
            obj.checkDuplicate = false;
        }

        this.wizardService.updateGeoLoc(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_GEO_LOC_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    for (let i = 0; i < this.geoLocMainData.length; i++) {
                        if (this.geoLocMainData[i].rowId == this.defaultEditedRow.rowId) {
                            this.geoLocMainData[i] = obj;
                        }
                    }

                    this.isEditable[rowIndex] = !this.isEditable[rowIndex];
                    this.showLoadingScreen = false;
                    this.editedRow = {};
                    this.defaultEditedRow = {};
                    this.geoLocData = [...this.geoLocMainData];
                    this.alreadyEnabled = true;
                    this.checkDuplicate = false;
                    this.toasterService.showSuccessMessage(
                        this.wizardHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_GEO_LOC_SUCCESS_MESSAGE")
                    );
                    this.editAlreadyEnabled = false;
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }
    createAddFormGroup() {
        this.addFromGroup = this.formBuilder.group({
            zip: ["", [Validators.required,  Validators.maxLength(5), Validators.minLength(5),Validators.pattern(/^-?(0|[0-9]\d*)?$/)]],
            state: ["", [Validators.maxLength(2)]],
            popcy: ["", [Validators.maxLength(38), Validators.pattern(/^-?(0|[1-9]\d*)?$/)]],
            pop05: ["", [Validators.maxLength(38), Validators.pattern(/^-?(0|[1-9]\d*)?$/)]],
            latitude: [""],
            longitude: [""],
            rlatitude: [""],
            rlongitude: [""],
            srlatitude: [""],
            crlatitude: [""],
            rzg2user: [""],
        });
    }
    public showSummaryConfirm() {
        this.confirmationService.confirm({
            key: 'confirm-add-show-summary',
            message: this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DONE_CREATING_GEO_LOC_CONFIRM_MESSAGE"),
            accept: () => {
                this.displayTable = true;
                this.checkedAnother = false;
            }
        });
    }
    public showConfirm(row) {
        this.confirmationService.confirm({
            key: 'confirm-delete-geoloc',
            message: "Are you sure you want to delete Geo Loc ?",
            accept: () => {
                this.deleteGeoLoc(row);
            }
        });
    }
    public deleteGeoLoc(row) {
        this.showLoadingScreen = true;
        let obj: any = {};
        obj.zip = row.zip;
        this.wizardService.deleteGeoLoc(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DELETE_GEO_LOC_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        return;
                    }
                    this.toasterService.showSuccessMessage(
                        this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DELETE_GEO_LOC_SUCCESS_MESSAGE")
                    );

                    this.geoLocData.forEach((rec: any, key) => {
                        if (obj.zip == rec.zip) {
                            this.geoLocData.splice(key, 1);
                            this.geoLoclocalService.getAddData().splice(key, 1);
                        }
                    });
                    this.geoLocData = [...this.geoLocData];
                    this.geoLocMainData = [...this.geoLocData];
                    if (this.geoLocData.length === 0) {
                        this.displayTable = false;
                        this.checkedAnother = false;
                        this.geoLocData = [];
                        this.revert();
                        this.geoLoclocalService.setAddData([]);
                    }
                    this.showLoadingScreen = false;
                },
                (err: any) => {
                    this.showErr(err);
                    return;
                }
            );
    }
    revert() {
        this.addFromGroup.reset();
        this.geoLocMainData = [];
        this.geoLocData = [];
        this.latitudeValMsg = "";
        this.longitudeValMsg = "";

        this.rlatitudeValMsg = "";
        this.rlongitudeValMsg = "";

        this.srlatitudeValMsg = "";
        this.crlatitudeValMsg = "";
    }

    //Filter Table data based on all the columns values
    public filterPostalZips(event) {
        let val: any;
        if (event.target)
            val = event.target.value.toLowerCase();
        else
            val = event.toLowerCase();
        // filter our data
        const temp = this.geoLocMainData.filter(function (d) {
            return (d.zip ? d.zip.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.state ? d.state.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.popcy ? d.popcy.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.pop05 ? d.pop05.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.latitude ? d.latitude.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.longitude ? d.longitude.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.rlatitude ? d.rlatitude.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.rlongitude ? d.rlongitude.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.srlatitude ? d.srlatitude.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.crlatitude ? d.crlatitude.toLowerCase().indexOf(val) !== -1 : !val) || !val
            // || (d.rzg2user ? d.rzg2user.toString().indexOf(val) !== -1 : !val) || !val
        });
        // update the rows
        this.geoLocData = temp;
    }

    public addGeoLoc(obj) {
        if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
            this.toasterService.showErrorMessage(
                this.wizardHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            this.showLoadingScreen = false;
            return;
        }

        this.showLoadingScreen = true;
        obj = this.wizardHelper.checkRequestObject(obj);
        this.wizardService
            .addGeoLoc(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_ADD_GEO_LOC_ERROR_MESSAGE")
                        );
                        this.showLoadingScreen = false;
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        return;
                    }

                    this.toasterService.showSuccessMessage(
                        this.wizardHelper.getTracfoneConstantMethod("TRACFONE_ADD_GEO_LOC_SUCCESS_MESSAGE")
                    );

                    let fullObject = this.geoLoclocalService.getAddData();
                    if (!this.geoLoclocalService.getAddData() ||
                        (this.geoLoclocalService.getAddData() && this.geoLoclocalService.getAddData().length == 0)) {
                        fullObject.push(obj);
                    } else if (this.geoLoclocalService.getAddData().length > 0) {
                        fullObject = this.geoLoclocalService.getAddData();
                        fullObject.forEach((data, key) => {
                            if (data.zip == obj.zip) {
                                fullObject.splice(key, 1);
                                fullObject = [...fullObject];
                            }
                        });
                        fullObject.push(obj);
                    }
                    this.geoLoclocalService.setAddData(fullObject);
                    this.geoLocMainData = [];
                    this.geoLocData = [];
                    for (let i = 0; i < this.geoLoclocalService.getAddData().length; i++) {
                        this.geoLocMainData.push(this.geoLoclocalService.getAddData()[i]);
                    }
                    let rowId = 1;
                    this.geoLocMainData.forEach(element => {
                        element.rowId = rowId;
                        rowId++;
                    });
                    this.geoLocData = [...this.geoLocMainData];

                    this.showLoadingScreen = false;
                    if (this.checkedAnother) {
                        this.displayTable = false;
                    } else {
                        this.displayTable = true;
                    }
                    this.addFromGroup.reset();

                },
                (err: any) => {
                    this.showErr(err);
                    return;
                }
            );
    }

    private openedChange(rowData) {
        if (rowData == "addSearchUserInput")
            this.userData = [...this.userMainData];
    }

    private onKey(value, rowData) {
        if (rowData == "addSearchUserInput") {
            this.userData = [...this.userMainData];
            this.userData = this.search(value, 'addSearchUserInput');
        }
    }

    private search(value: string, choice: string) {
        let filter = value.toLowerCase();
        if (choice == "addSearchUserInput") {
            return this.userMainData.filter(option => option.toString().indexOf(filter) > -1);
        }
    }

    // to retrieve state
    public getUser() {
        this.showLoadingScreen = true;
        this.userData = [];
        this.userMainData = [];
        this.wizardService
            .getUserId()
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {

                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_USER_ERROR_MESSAGE")
                        );
                        this.showLoadingScreen = false;
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        return;
                    }
                    if (data[0].length == 0)
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("NO_USER_FOUND")
                        );
                    this.userMainData = data[0];
                    this.userData = [...this.userMainData];


                    // // for state search
                    // this.filteredStateOptions = this.searchFrmGrp.controls.stateSearch.valueChanges
                    //     .pipe(
                    //         startWith<string>(''),
                    //         map((name: any) => this._filter(name, 'stateInput'))
                    //     );

                    this.showLoadingScreen = false;
                },
                (err: any) => {
                    this.showErr(err);
                    return;
                }
            );
    }

    onChangeCheckbox(event) {
        if (event.checked) this.checkedAnother = true;
        else this.checkedAnother = false;
    }
    public showServiceErr(data) {
        const commaSeperatedArr = data[0].ERR.split(",");
        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
            if (commaSeperatedArr[i] != "")
                this.toasterService.showErrorMessage(commaSeperatedArr[i]);
        }
        return;
    }
    public showErr(err) {
        this.showLoadingScreen = false;
        if (err.error === undefined || err.error === null)
            this.toasterService.showErrorMessage(
                this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
            );
        else if (err.error && err.error.ERR) {
            const commaSeperatedArr = err.error.ERR.split(",");
            for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                if (commaSeperatedArr[i] != "")
                    this.toasterService.showErrorMessage(
                        commaSeperatedArr[i]
                    );
            }
        }
        else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
            return;
        else this.toasterService.showErrorMessage(err.error);
    }
    public closeAlert(alert: any) {
        const index: number = this.alerts.indexOf(alert);
        this.alerts.splice(index, 1);
    }
}