import { Component, OnInit, ViewEncapsulation, ViewChildren, Output, EventEmitter, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup } from '@angular/forms';
import { ConfirmationService } from 'primeng/primeng';
import { takeUntil } from 'rxjs/operators';
import { Subject } from "rxjs";
import { CarrierMaintenanceService } from '../../../../../Services/carrierMaintenance.service';
import { CarrierMaintenanceHelper } from "../../carrier-maintenance-helper";
import { ToasterService } from "../../../../../Services/toaster.service";
import { GeoLoclocalService } from "../geo-loc-service";
import { ExportToCsvService } from "../../../../../Services/export-to-csv.service";

@Component({
    selector: 'update-geo-loc',
    templateUrl: './update-geo.component.html',
    styleUrls: [
        "../../../../components/ngxtable/material.scss",
        "../../../../components/ngxtable/datatable.component.scss",
        "../../../../components/ngxtable/icons.css",
        "../../../../components/ngxtable/app.css"],
    animations: [],
    encapsulation: ViewEncapsulation.None,
})

export class UpdateGeoLocComponent implements OnInit {
    public showLoadingScreen = false;
    public alerts = [];
    public alreadyEnabled = true;
    public filteredRows: any;
    private unsubscribe = new Subject<void>();
    public searchFromGroup: FormGroup;
    public errorMessage = "";
    public isEditable = {};
    public filteredValues: any = {};
    public selected = [];
    public editAlreadyEnabled = false;
    public geoLocData: any = [];
    public geoLocMainData: any = [];
    public geoLocColumns: any = [];
    public otherColumn: boolean = false;
    public defaultEditedRow: any = {};
    private editedRow: any = {};
    public checkDuplicate = false;
    public bulkEditColumns = [];
    public showBulkUpdateButton = false;
    public selectedGeoLocs = [];
    public bulkEditBoolean: boolean;
    @ViewChild('multicolumnEditValue') multicolumnEditValue: any;
    public enteredZipCodes: any;
    public latitudeValMsg = "";
    public longitudeValMsg = "";

    public rlatitudeValMsg = "";
    public rlongitudeValMsg = "";

    public srlatitudeValMsg = "";
    public crlatitudeValMsg = "";

    public latitudeValMsgBulkUpdate = "";
    public longitudeValMsgBulkUpdate  = "";

    public rlatitudeValMsgBulkUpdate  = "";
    public rlongitudeValMsgBulkUpdate  = "";

    public srlatitudeValMsgBulkUpdate  = "";
    public crlatitudeValMsgBulkUpdate  = "";

    constructor(
        private formBuilder: FormBuilder,
        private toasterService: ToasterService,
        private wizardHelper: CarrierMaintenanceHelper,
        private confirmationService: ConfirmationService,
        private wizardService: CarrierMaintenanceService,
        private geoLoclocalService: GeoLoclocalService,
        private exportToCsvService :ExportToCsvService,

    ) { }

    ngOnInit() {
        this.createSearchFormGroup();
        this.geoLocColumns = [
            { name: 'ZIP', prop: 'zip', width: "180" },
            { name: 'STATE', prop: 'state', width: "180" },
            { name: 'POPCY', prop: 'popcy', width: "180" },
            { name: 'POP05', prop: 'pop05', width: "180" },
            { name: 'LATITUDE', prop: 'latitude', width: "200" },
            { name: 'LONGITUDE', prop: 'longitude', width: "200" },
            { name: 'RLATITUDE', prop: 'rlatitude', width: "200" },
            { name: 'RLONGITUDE', prop: 'rlongitude', width: "200" },
            { name: 'SRLATITUDE', prop: 'srlatitude', width: "200" },
            { name: 'CRLATITUDE', prop: 'crlatitude', width: "200" },
            { name: 'RZG2USER', prop: 'rzg2user', width: "95" },
            { name: 'Insert Date', prop: 'insertDate', width: "150" },
            { name: 'Update Date', prop: 'updateDate', width: "150" },
        ];
        this.bulkEditColumns = [
            { name: 'ZIP', prop: 'zip', width: "180" },
            { name: 'STATE', prop: 'state', width: "180" },
            { name: 'POPCY', prop: 'popcy', width: "180" },
            { name: 'POP05', prop: 'pop05', width: "180" },
            { name: 'LATITUDE', prop: 'latitude', width: "180" },
            { name: 'LONGITUDE', prop: 'longitude', width: "180" },
            { name: 'RLATITUDE', prop: 'rlatitude', width: "180" },
            { name: 'RLONGITUDE', prop: 'rlongitude', width: "180" },
            { name: 'SRLATITUDE', prop: 'srlatitude', width: "180" },
            { name: 'CRLATITUDE', prop: 'crlatitude', width: "180" },
        ];
    }
    public checkNumValdationBulkUpdate(val, col){
        if(col == "LATITUDE"){
            if(!/^[-+]?\d*\.?\d*$/.test(val)){
                this.latitudeValMsgBulkUpdate = 'LATITUDE must be a number'
            }
            else if(!/^[-+]?\d{0,38}(\.\d{1,9})?$/.test(val)){
                this.latitudeValMsgBulkUpdate = 'Invalid number.'
            }else{
                this.latitudeValMsgBulkUpdate = ""; 
            }
        } 
        else if(col == "LONGITUDE"){
            if(!/^[-+]?\d*\.?\d*$/.test(val)){
                this.longitudeValMsgBulkUpdate = 'LONGITUDE must be a number'
            }
            else if(!/^[-+]?\d{0,38}(\.\d{1,9})?$/.test(val)){
                this.longitudeValMsgBulkUpdate = 'Invalid number.'
            }else{
                this.longitudeValMsgBulkUpdate = ""; 
            }
        }
        else if(col == "RLATITUDE"){
            if(!/^[-+]?\d*\.?\d*$/.test(val)){
                this.rlatitudeValMsgBulkUpdate = 'RLATITUDE must be a number'
            }
            else if(!/^[-+]?\d{0,38}(\.\d{1,20})?$/.test(val)){
                this.rlatitudeValMsgBulkUpdate = 'Invalid number.'
            }else{
                this.rlatitudeValMsgBulkUpdate = ""; 
            }
        }
        else if(col == "RLONGITUDE"){
            if(!/^[-+]?\d*\.?\d*$/.test(val)){
                this.rlongitudeValMsgBulkUpdate = 'RLONGITUDE must be a number'
            }
            else if(!/^[-+]?\d{0,38}(\.\d{1,20})?$/.test(val)){
                this.rlongitudeValMsgBulkUpdate = 'Invalid number.'
            }else{
                this.rlongitudeValMsgBulkUpdate = ""; 
            }
        }
        else if(col == "SRLATITUDE"){
            if(!/^[-+]?\d*\.?\d*$/.test(val)){
                this.srlatitudeValMsgBulkUpdate = 'SRLATITUDE must be a number'
            }
            else if(!/^[-+]?\d{0,38}(\.\d{1,40})?$/.test(val)){
                this.srlatitudeValMsgBulkUpdate = 'Invalid number.'
            }else{
                this.srlatitudeValMsgBulkUpdate = ""; 
            }
        }
        else if(col == "CRLATITUDE"){
            if(!/^[-+]?\d*\.?\d*$/.test(val)){
                this.crlatitudeValMsgBulkUpdate = 'CRLATITUDE must be a number'
            }
            else if(!/^[-+]?\d{0,38}(\.\d{1,40})?$/.test(val)){
                this.crlatitudeValMsgBulkUpdate = 'Invalid number.'
            }else{
                this.crlatitudeValMsgBulkUpdate = ""; 
            }
        }
    }

    public checkNumValdation(val, col, row){
        if(col == "latitude"){
            if(!/^[-+]?\d*\.?\d*$/.test(val)){
                row.latitudeValMsg = 'LATITUDE must be a number'
            }
            else if(!/^[-+]?\d{0,38}(\.\d{1,9})?$/.test(val)){
                row.latitudeValMsg = 'Invalid number.'
            }else{
                row.latitudeValMsg = ""; 
            }
        } 
        else if(col == "longitude"){
            if(!/^[-+]?\d*\.?\d*$/.test(val)){
                row.longitudeValMsg = 'LONGITUDE must be a number'
            }
            else if(!/^[-+]?\d{0,38}(\.\d{1,9})?$/.test(val)){
                row.longitudeValMsg = 'Invalid number.'
            }else{
                row.longitudeValMsg = ""; 
            }
        }
        else if(col == "rlatitude"){
            if(!/^[-+]?\d*\.?\d*$/.test(val)){
                row.rlatitudeValMsg = 'RLATITUDE must be a number'
            }
            else if(!/^[-+]?\d{0,38}(\.\d{1,20})?$/.test(val)){
                row.rlatitudeValMsg = 'Invalid number.'
            }else{
                row.rlatitudeValMsg = ""; 
            }
        }
        else if(col == "rlongitude"){
            if(!/^[-+]?\d*\.?\d*$/.test(val)){
                row.rlongitudeValMsg = 'RLONGITUDE must be a number'
            }
            else if(!/^[-+]?\d{0,38}(\.\d{1,20})?$/.test(val)){
                row.rlongitudeValMsg = 'Invalid number.'
            }else{
                row.rlongitudeValMsg = ""; 
            }
        }
        else if(col == "srlatitude"){
            if(!/^[-+]?\d*\.?\d*$/.test(val)){
                row.srlatitudeValMsg = 'SRLATITUDE must be a number'
            }
            else if(!/^[-+]?\d{0,38}(\.\d{1,40})?$/.test(val)){
                row.srlatitudeValMsg = 'Invalid number.'
            }else{
                row.srlatitudeValMsg = ""; 
            }
        }
        else if(col == "crlatitude"){
            if(!/^[-+]?\d*\.?\d*$/.test(val)){
                row.crlatitudeValMsg = 'CRLATITUDE must be a number'
            }
            else if(!/^[-+]?\d{0,38}(\.\d{1,40})?$/.test(val)){
                row.crlatitudeValMsg = 'Invalid number.'
            }else{
                row.crlatitudeValMsg = ""; 
            }
        }
    }
    exportToCSV() {
        let columns = [];
        this.geoLocColumns.forEach(x=>{
            columns.push(x.prop)            
        })
        this.exportToCsvService.downloadFile(this.selectedGeoLocs, "GeoLocExport", columns);
    }
    public zipCodeValidation(event) {
        this.errorMessage = "";
        let lengthError = "A Zip Code must have exactly 5 digits.";
        let limitError = "Zip Codes cannot exceed 40,000 limit";
        let stringError = "Zip Code must be number";
        let zipcodes: any = [];
        if (/\d/.test(event)) {
            //Splitting string based on the new line
            let zip = event.split("\n")
            zip = zip.filter(el => el !== '')
            for (let i = 0; i < zip.length; i++) {
                //removing spaces
                zip[i] = zip[i].replace(/\s/g, "");
                //checking if any value with comma exists
                if (zip[i].indexOf(',') > -1) {
                    //Sliting String based on the comma
                    let commaSeperatedArr = zip[i].split(",");
                    /*
                     * Validate Zip Code based on the length
                     * if Zip Codes are valid then pushing into 'zipcodes' array
                    */
                    for (let j = 0; j < commaSeperatedArr.length; j++) {
                        //validate Zip code if it is number or not
                        if (/^[0-9]*$/.test(commaSeperatedArr[j])) {
                            if (commaSeperatedArr[j].length != 0) {
                                if (commaSeperatedArr[j].length < 5) {
                                    this.errorMessage = lengthError;
                                    break;
                                } else if (commaSeperatedArr[j].length > 5) {
                                    this.errorMessage = lengthError;
                                    break;
                                } else {
                                    zipcodes.push(commaSeperatedArr[j]);
                                    //check if zip codes exceeds 40,000
                                    if (zipcodes.length > 40000) {
                                        this.errorMessage = limitError;
                                        break;
                                    }
                                }
                            }
                        } else {
                            this.errorMessage = stringError;
                            break;
                        }
                    }
                }//validate Zip code if it is number or not
                else if (!/^[0-9]*$/.test(zip[i])) {
                    this.errorMessage = stringError;
                    break;
                }//Validate Zip Code based on the length  
                else if (zip[i].length < 5) {
                    if (zip[i].length != 0) {
                        this.errorMessage = lengthError;
                        break;
                    }
                }//Validate Zip Code based on the length 
                else if (zip[i].length > 5) {
                    this.errorMessage = lengthError;
                    break;
                }//if Zip Codes are valid then pushing into 'zipcodes' array
                else {
                    zipcodes.push(zip[i]);
                    //check if zip codes exceeds 40,000
                    if (zipcodes.length > 40000) {
                        this.errorMessage = limitError;
                        break;
                    }
                }
            }
        } else {
            event = event.toUpperCase();
            if (event == "ALL")
                zipcodes.push(event);
            else if (event.length > 0)
                this.errorMessage = stringError;
        }

        let returnedZip: any = [];
        this.enteredZipCodes = "";
        if (this.errorMessage == "") {
            //filter duplicate zipcodes
            returnedZip = zipcodes.filter((val, index) => zipcodes.indexOf(val) == index);
            //removing empty elements
            returnedZip = returnedZip.filter(item => item);
            this.enteredZipCodes = returnedZip.toString();
        } else {
            this.enteredZipCodes = null;
        }
    }

    bulkUpdateColumn(column) {
        if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
            this.toasterService.showErrorMessage(
                this.wizardHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            return;
        }
        this.showLoadingScreen = true;
        let requestObj = [];
        this.selectedGeoLocs.forEach(e => {
            let obj: any = {};
            if (column == "ZIP") {
                obj.zip = this.multicolumnEditValue.nativeElement.value;
                obj.oldZip = e.zip;
                obj.checkDuplicate = true;
            } else {
                obj.zip = e.zip;
                obj.oldZip = e.zip;
                obj.checkDuplicate = false;
            }
            if (column == "STATE") {
                obj.state = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.state = e.state;
            }
            if (column == "POPCY") {
                obj.popcy = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.popcy = e.popcy;
            }
            if (column == "POP05") {
                obj.pop05 = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.pop05 = e.pop05;
            }
            if (column == "LATITUDE") {
                obj.latitude = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.latitude = e.latitude;
            } if (column == "LONGITUDE") {
                obj.longitude = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.longitude = e.longitude;
            }
            if (column == "RLATITUDE") {
                obj.rlatitude = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.rlatitude = e.rlatitude;
            } if (column == "RLONGITUDE") {
                obj.rlongitude = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.rlongitude = e.rlongitude;
            }
            if (column == "SRLATITUDE") {
                obj.srlatitude = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.srlatitude = e.srlatitude;
            } if (column == "CRLATITUDE") {
                obj.crlatitude = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.crlatitude = e.crlatitude;
            }
            requestObj.push(obj);
        });

        this.bulkUpdateGeoLocs(requestObj);
    }

    public bulkUpdateGeoLocs(request) {
        this.wizardService.bulkUpdateGeoLocs(request).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_BULK_UPDATE_GEO_LOC_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    this.showLoadingScreen = false;
                    this.alreadyEnabled = true;
                    this.editAlreadyEnabled = false;
                    this.bulkEditBoolean = false;
                    this.otherColumn = false;
                    this.showBulkUpdateButton = false;
                    this.selectedGeoLocs = [];
                    this.selected = [];
                    this.editedRow = {};
                    this.defaultEditedRow = {};
                    this.toasterService.showSuccessMessage(
                        this.wizardHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_GEO_LOC_SUCCESS_MESSAGE")
                    );
                    this.searchGeoLoc(this.searchFromGroup.value);
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    public showBulkUpdateButtonFun(event) {
        if (event)
            this.showBulkUpdateButton = true;
        else
            this.showBulkUpdateButton = false;
    }
    public assignmultiColumnName(column) {
        this.showBulkUpdateButton = false;
        this.otherColumn = true;
    }
    createSearchFormGroup() {
        this.searchFromGroup = this.formBuilder.group({
            zip: [""],
        });
    }
    public onSelect(row) {
        this.selectedGeoLocs = [];
        if (row && row.selected) {
            for (let i = 0; i < row.selected.length; i++) {
                let obj = { ...row.selected[i] };
                this.selectedGeoLocs.push(obj);
            }
        }
        this.selectedGeoLocs = [...this.selectedGeoLocs]
        if (this.selectedGeoLocs.length == 0) {
            this.bulkEditBoolean = false;
            this.otherColumn = false;
            this.showBulkUpdateButton = false;
        }
    }
    public inlineUpdateGeoLoc(editData, rowIndex) {
        if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
            this.toasterService.showErrorMessage(
                this.wizardHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            return;
        }
        this.showLoadingScreen = true;

        let obj = { ...editData, ...this.editedRow }
        if (this.editedRow.zip) {
            obj.checkDuplicate = true;
        }
        obj.oldZip = editData.zip;

        obj = this.wizardHelper.checkRequestObject(obj);
        if (obj.oldZip == obj.zip) {
            obj.checkDuplicate = false;
        }
        this.wizardService.updateGeoLoc(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_GEO_LOC_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    this.isEditable[rowIndex] = !this.isEditable[rowIndex];
                    this.showLoadingScreen = false;
                    this.editedRow = {};
                    this.defaultEditedRow = {};
                    this.alreadyEnabled = true;
                    this.checkDuplicate = false;

                    this.toasterService.showSuccessMessage(
                        this.wizardHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_GEO_LOC_SUCCESS_MESSAGE")
                    );
                    this.searchGeoLoc(this.searchFromGroup.value);
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    revert() {
        this.filteredValues = {};
        this.errorMessage = "";
        this.enteredZipCodes = "";
        this.searchFromGroup.reset();
        this.geoLocData = [];
        this.geoLocMainData = [];
        this.otherColumn = false;
        this.alreadyEnabled = true;
        this.latitudeValMsg = "";
        this.longitudeValMsg = "";

        this.rlatitudeValMsg = "";
        this.rlongitudeValMsg = "";

        this.srlatitudeValMsg = "";
        this.crlatitudeValMsg = "";

        this.latitudeValMsgBulkUpdate = "";
        this.longitudeValMsgBulkUpdate = "";

        this.rlatitudeValMsgBulkUpdate = "";
        this.rlongitudeValMsgBulkUpdate = "";

        this.srlatitudeValMsgBulkUpdate = "";
        this.crlatitudeValMsgBulkUpdate = "";
    }

    //Filter Table data based on all the columns values
    public filterGeoLocs(event) {
        let val: any;
        if (event.target)
            val = event.target.value.toLowerCase();
        else
            val = event.toLowerCase();
        // filter our data
        const temp = this.geoLocMainData.filter(function (d) {
            return (d.zip ? d.zip.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.state ? d.state.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.popcy ? d.popcy.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.pop05 ? d.pop05.toLowerCase().indexOf(val) !== -1 : !val) || !val

                || (d.latitude ? d.latitude.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.longitude ? d.longitude.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.rlatitude ? d.rlatitude.toLowerCase().indexOf(val) !== -1 : !val) || !val

                || (d.rlongitude ? d.rlongitude.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.srlatitude ? d.srlatitude.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.crlatitude ? d.crlatitude.toLowerCase().indexOf(val) !== -1 : !val) || !val
        });
        // update the rows
        this.geoLocData = temp;
    }
    private inputValueChanged(event, column, row, oldValue) {
        this.editedRow[column] = event.target.value;
        this.defaultEditedRow[column] = event.target.defaultValue;
    }
    // confirm box
    public showConfirm(row) {
        this.confirmationService.confirm({
            key: 'confirm-delete-geoloc',
            message: "Are you sure you want to delete Geo Loc ?",
            accept: () => {
                this.deleteGeoLoc(row);
            }
        });
    }
    public deleteGeoLoc(row) {
        this.showLoadingScreen = true;
        let obj: any = {};
        obj.zip = row.zip;
        this.wizardService.deleteGeoLoc(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DELETE_GEO_LOC_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        return;
                    }
                    this.toasterService.showSuccessMessage(
                        this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DELETE_GEO_LOC_SUCCESS_MESSAGE")
                    );
                    this.showLoadingScreen = false;
                    this.searchGeoLoc(this.searchFromGroup.value);
                },
                (err: any) => {
                    this.showErr(err);
                    return;
                }
            );
    }
    //Enable inline editing
    public editButtonClicked(rowData, rowIndex) {
        this.editAlreadyEnabled = true;
        this.defaultEditedRow = { ...rowData }
        let alreadyEnabled = false;
        for (let i = 0; i < this.geoLocColumns.length; i++) {
            if (this.isEditable[i])
                alreadyEnabled = true;
        }
        if (!alreadyEnabled)
            this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        else
            this.toasterService.showErrorMessage(
                this.wizardHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE"),
            );
    }
    public cancelEditForm(rowData, rowIndex) {
        this.showLoadingScreen = true;
        this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        this.geoLocColumns.forEach(e => {
            if (document.getElementById(e.prop + rowIndex)) {
                (<HTMLInputElement>(
                    document.getElementById(e.prop + rowIndex)
                )).value = rowData[e.prop] || '';
            }
        });
        rowData.latitudeValMsg = '';
        rowData.longitudeValMsg = '';

        rowData.rlatitudeValMsg = '';
        rowData.rlongitudeValMsg = '';

        rowData.srlatitudeValMsg = '';
        rowData.crlatitudeValMsg = '';
        this.editedRow = {};
        this.showLoadingScreen = false;
        this.editAlreadyEnabled = false;
    }

    searchGeoLoc(req) {
        this.showLoadingScreen = true;
        this.otherColumn = false;
        this.selected = [];
        this.isEditable = {};
        this.filteredValues = {};
        this.selectedGeoLocs = [];

        let obj: any = {};
        obj.zip = this.enteredZipCodes;

        this.wizardService.searchGeoLocs(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_GEO_LOC_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    this.showLoadingScreen = false;

                    this.geoLocMainData = data[0];
                    this.geoLocData = [...this.geoLocMainData];

                    if (this.filteredValues.mainTableFilter) {
                        this.filterGeoLocs(this.filteredValues.mainTableFilter);
                    }
                    this.editAlreadyEnabled = false;
                    if (this.geoLocMainData && this.geoLocMainData.length == 0) {
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("NO_GEO_LOC_FOUND")
                        );
                    }

                    this.bulkEditBoolean = false;
                    this.otherColumn = false;
                    this.showBulkUpdateButton = false;
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    public showErr(err) {
        this.showLoadingScreen = false;
        if (err.error === undefined || err.error === null)
            this.toasterService.showErrorMessage(
                this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
            );
        else if (err.error && err.error.ERR) {
            const commaSeperatedArr = err.error.ERR.split(",");
            for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                if (commaSeperatedArr[i] != "")
                    this.toasterService.showErrorMessage(
                        commaSeperatedArr[i]
                    );
            }
        }
        else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
            return;
        else this.toasterService.showErrorMessage(err.error);
    }

    /*
* Show error when service returns error
*/
    public showServiceErr(data) {
        const commaSeperatedArr = data[0].ERR.split(",");
        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
            if (commaSeperatedArr[i] != "")
                this.toasterService.showErrorMessage(commaSeperatedArr[i]);
        }
        return;
    }

    public closeAlert(alert: any) {
        const index: number = this.alerts.indexOf(alert);
        this.alerts.splice(index, 1);
    }
}