import { Injectable } from "@angular/core";
import { Subject } from "rxjs";

@Injectable({
    providedIn: "root"
})
export class GeoLoclocalService {
    addData: any = [];
    searchData: any = [];

    currentStep= new Subject<number>();;

    constructor() {}

    public setAddData(addData) {
        this.addData = addData;
    }

    public getAddData() {
        return this.addData;
    }

    public setSearchData(searchData) {
        this.searchData = searchData;
    }

    public getSearchData() {
        return this.searchData;
    }

    
    resetAll(){
        this.searchData = [];
        this.addData = [];
    }
}
