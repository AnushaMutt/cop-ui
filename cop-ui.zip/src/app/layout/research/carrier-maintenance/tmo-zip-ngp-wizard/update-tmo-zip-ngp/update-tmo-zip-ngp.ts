import { Component, OnInit, ViewChild, ViewEncapsulation } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ConfirmationService } from 'primeng/primeng';
import { takeUntil } from 'rxjs/operators';
import { Subject } from "rxjs";
import { CarrierMaintenanceService } from '../../../../../Services/carrierMaintenance.service';
import { CarrierMaintenanceHelper } from "../../carrier-maintenance-helper";
import { ToasterService } from "../../../../../Services/toaster.service";
import { TmoZipNgpHelper } from "../tmo-zip-ngp-wizard-helper";
import { TmoZipNgpService } from "../tmo-zip-ngp-wizard-service";

@Component({
    selector: 'update-tmo-zip-ngp',
    templateUrl: './update-tmo-zip-ngp.html',
    styleUrls: ['./update-tmo-zip-ngp.scss',
        "../../../../components/ngxtable/material.scss",
        "../../../../components/ngxtable/datatable.component.scss",
        "../../../../components/ngxtable/icons.css",
        "../../../../components/ngxtable/app.css"],
    animations: [],
    encapsulation: ViewEncapsulation.None,
})

export class UpdateTmoZipNgpComponent implements OnInit {
    private unsubscribe = new Subject<void>();
    public frmTmoZipNgp: FormGroup;
    public showLoadingScreen: boolean;
    public errorMessage = "";
    public enteredZipCodes: any;
    public tableRows: any = [];
    public tableRowsMainData: any = [];
    isEditable = {};
    private editedRow: any = {};
    private defaultEditedRow: any = {};
    public tableColumns:any = [];
    public alreadyEnabled = true;
    public showNoRecordsFoundMessage : Boolean = true;
    public filteredValues: any = {};
    public checkDuplicate = false;
    public multiColumnEditSection = false;
    public selectedTmoZipNgp = [];
    public bulkEditBoolean: boolean;
    public otherColumn: boolean = false;
    public showBulkUpdateButton: boolean = false;
    public editAlreadyEnabled = false;
    public selected = [];
    public bulkEditColumns = [];
    @ViewChild('multicolumnEditValue') multicolumnEditValue: any;
    public tableFrmGroupMain: FormGroup;
    public filteredRows: any;

    constructor(
        private formBuilder: FormBuilder,
        private wizardService: CarrierMaintenanceService,
        private tmoZipNgpHelper: TmoZipNgpHelper,
        private toasterService: ToasterService,
        private wizardHelper: CarrierMaintenanceHelper,
        private confirmationService: ConfirmationService,
        private tmoZipNgpService: TmoZipNgpService
    ) { }
    

    ngOnInit() { 
        this.createForm();
        this.createTableForm();
        this.enteredZipCodes = "";
        this.errorMessage = "";
        this.tableColumns = [
            { name: 'Zip', prop: 'zip', width: "200" },
            { name: 'NGP', prop: 'ngp', width: "200" },
            { name: 'NGP Name', prop: 'ngpName', width: "350" },
            { name: 'Priority', prop: 'priority', width: "250" }
        ];
        this.bulkEditColumns = [
            { name: 'Zip', prop: 'zip', width: "200" },
            { name: 'NGP', prop: 'ngp', width: "200" },
            { name: 'NGP Name', prop: 'ngpName', width: "350" }
        ];
        this.filteredValues = {};
    }

        //to create form
        private createForm() {
            this.frmTmoZipNgp = this.formBuilder.group({
                zip: ['', [Validators.pattern("^[0-9\n ,]*$")]],
                ngp: ['', [Validators.maxLength(30)]],
                ngpName: ['', [Validators.maxLength(255)]],
                priority: ['', [Validators.pattern("^[0-9\n ,]*$"), Validators.maxLength(38)]],
            })
        }

        //form for column level filter
        public createTableForm() {
            this.tableFrmGroupMain = this.formBuilder.group({
                zip: [""],
                ngp: [""],
                ngpName: [""],
                priority: [""],
            });
        }

    // reset the form
    revert() {
        this.frmTmoZipNgp.reset();
        this.enteredZipCodes = "";
        this.errorMessage = "";
        this.tableRows = [];
        this.tableRowsMainData = [];
        this.filteredValues = {};
        this.selected = [];
        this.selectedTmoZipNgp = [];
        this.editAlreadyEnabled = false;
        this.bulkEditBoolean = false;
        this.otherColumn = false;
        let filterKeys = Object.keys(this.tableFrmGroupMain.controls);
        filterKeys.forEach(_e1 => {
            this.tableFrmGroupMain.controls[`${_e1}`].patchValue([]);
        });
    }

    /*
     * Validate Zip Code text area
     * Validation Criteria- Limit -> 40,000 | Size -> 5 per zip code
     */
    zipCodeValidation(event) {
        this.errorMessage = "";
        //Splitting string based on the new line
        let zip = event.split("\n")
        let zipcodes: any = [];
        for (let i = 0; i < zip.length; i++) {
            //removing spaces
            zip[i] = zip[i].replace(/\s/g, "");
            //checking if any value with comma exists
            if (zip[i].indexOf(',') > -1) {
                //Sliting String based on the comma
                let commaSeperatedArr = zip[i].split(",");
                /*
                 * Validate Zip Code based on the length
                 * if Zip Codes are valid then pushing into 'zipcodes' array
                */
                for (let j = 0; j < commaSeperatedArr.length; j++) {
                    if (commaSeperatedArr[j].length != 0) {
                        if (commaSeperatedArr[j].length < 5) {
                            this.errorMessage = "Zip Code cannot have less than 5 digits."
                            break;
                        } else if (commaSeperatedArr[j].length > 5) {
                            this.errorMessage = "Zip Code cannot have more than 5 digits."
                            break;
                        } else {
                            zipcodes.push(commaSeperatedArr[j]);
                            //check if zip codes exceeds 40,000
                            if (zipcodes.length > 40000) {
                                this.errorMessage = "Zip Codes cannot exceed 40,000 limit"
                                break;
                            }
                        }
                    }
                }
            }//Validate Zip Code based on the length 
            else if (zip[i].length < 5) {
                if (zip[i].length != 0) {
                    this.errorMessage = "Zip Code cannot have less than 5 digits."
                    break;
                }
            }//Validate Zip Code based on the length 
            else if (zip[i].length > 5) {
                this.errorMessage = "Zip Code cannot have more than 5 digits."
                break;
            }//if Zip Codes are valid then pushing into 'zipcodes' array
            else {
                zipcodes.push(zip[i]);
                //check if zip codes exceeds 40,000
                if (zipcodes.length > 40000) {
                    this.errorMessage = "Zip Codes cannot exceed 40,000 limit"
                    break;
                }
            }
        }
        let returnedZip: any = [];
        this.enteredZipCodes = ""
        if (this.errorMessage == "") {
            zipcodes.forEach(element => {
                if (element.length != 0)
                    returnedZip.push(element);
            });
            this.enteredZipCodes = returnedZip.toString();
        } else {
            this.enteredZipCodes = null;
        }
    }

    public searchForm(){
        let obj = this.frmTmoZipNgp.value;
        this.editedRow = {};
        this.defaultEditedRow = {};
        this.isEditable = {};
        this.checkDuplicate = false;
        this.selected = [];
        this.selectedTmoZipNgp = [];
        this.editAlreadyEnabled = false;
        this.bulkEditBoolean = false;
        this.otherColumn = false;
        let filterKeys = Object.keys(this.tableFrmGroupMain.controls);
        filterKeys.forEach(_e1 => {
            this.tableFrmGroupMain.controls[`${_e1}`].patchValue([]);
        });
        this.filteredValues ={};
        this.tmoZipNgpService.setSearchData([]);
    if (this.enteredZipCodes) {
        obj.zip = this.enteredZipCodes;
    }
    obj = this.wizardHelper.checkRequestObject(obj);
    obj.dbEnv = this.wizardHelper.dbEnv;
    if(obj.zip && obj.zip.split(",").length>0){
        let zipCodes:any = [];
    zipCodes = [...obj.zip.split(",")];
        let uniqueZips = zipCodes.filter((v, i) =>
        zipCodes.findIndex(item => item == v) === i);
    let callTimes: number = Math.ceil(uniqueZips.length/1000);
        for(let i=0; i<callTimes; i++){
        let zip = [];
        for(let j=1000*i; j<uniqueZips.length; j++){
            if(j < (i+1)*1000)
                zip.push(uniqueZips[j]);
            else
                break;
        }
        obj.zip = zip.toString();
        this.searchTmoZipNgp(obj);
    }
}else{
    this.searchTmoZipNgp(obj);
}
}

   // search tmo zip ngp
   public searchTmoZipNgp(obj) {
    this.showLoadingScreen = true;
    this.alreadyEnabled = true;
    this.wizardService.searchTmoZipNgp(obj).pipe(takeUntil(this.unsubscribe))
        .subscribe(
        (data: any) => {
            if (data[0] === null || data[0] === undefined) {
                this.showLoadingScreen = false;
                this.toasterService.showErrorMessage(
                    this.tmoZipNgpHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_TMO_ZIP_NGP_ERROR_MESSAGE")
                );
                return;
            }
            if (data[0] && data[0].ERR) {
                this.showLoadingScreen = false;
                const commaSeperatedArr = data[0].ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
                return;
            }

            let response = data[0];
            let fullObject = [];
                if (!this.tmoZipNgpService.getSearchData() || (this.tmoZipNgpService.getSearchData() && this.tmoZipNgpService.getSearchData().length == 0)) {
                    response.forEach(e1 => {
                        fullObject.push(e1)
                    });
                    
                } else if (this.tmoZipNgpService.getSearchData().length > 0) {
                    fullObject = this.tmoZipNgpService.getSearchData();
                    response.forEach(e1 => {
                        fullObject.push(e1)
                    });
                }
                this.tmoZipNgpService.setSearchData(fullObject);
                this.tableRowsMainData = [];
                this.tableRows = [];
                for (let i = 0; i < this.tmoZipNgpService.getSearchData().length; i++) {
                    this.tableRowsMainData.push(this.tmoZipNgpService.getSearchData()[i]);
                }
                let rowId = 1;
                this.tableRowsMainData.forEach(element => {
                    element.rowId = rowId;
                    rowId++;
                });
                this.tableRows = [...this.tableRowsMainData];
            this.showLoadingScreen = false;
            this.editAlreadyEnabled = false;
            if (data[0] && data[0].length == 0  && this.showNoRecordsFoundMessage)
            this.toasterService.showErrorMessage(
            this.tmoZipNgpHelper.getTracfoneConstantMethod("TRACFONE_SEARCH_TMO_ZIP_NGP_ERROR_MESSAGE")
            );
            this.generateFilters();
            this.filterReportResults();
            this.showNoRecordsFoundMessage = true;
            if (this.filteredValues && this.filteredValues.mainTableFilter) {
                this.updateSummaryTable(this.filteredValues.mainTableFilter);
            }
        },
        (err: any) => {
            this.showLoadingScreen = false;
            if (err.error === undefined || err.error === null)
                this.toasterService.showErrorMessage(
                    this.tmoZipNgpHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                );
            else if (err.error && err.error.ERR) {
                const commaSeperatedArr = err.error.ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
            }
            else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                return;
            else this.toasterService.showErrorMessage(err.error);
        }
        );
}

public  editButtonClicked(rowData,rowIndex) {
    this.alreadyEnabled = false;
    this.editAlreadyEnabled = true;
    this.defaultEditedRow = { ...rowData }
    for (let i = 0; i < this.tableRowsMainData.length; i++) {
      if (this.isEditable[i])
        this.alreadyEnabled = true;
    }
    if (!this.alreadyEnabled)
      this.isEditable[rowIndex] = !this.isEditable[rowIndex];
    else{
      this.alreadyEnabled = false;
      this.toasterService.showErrorMessage(
        this.tmoZipNgpHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE")
      );
    }
  }


private inputValueChanged(event, column, row, oldValue) {
        this.editedRow[column] = event.target.value;
        this.defaultEditedRow[column] = event.target.defaultValue;

}

//to update tmo zip ngp
public updateTmoZipNgp(editData, rowIndex) {
    if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
        this.toasterService.showErrorMessage(
            this.tmoZipNgpHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
        )
        return;
    }
    this.showLoadingScreen = true;
    let obj = { ...editData, ...this.editedRow }

    obj = this.wizardHelper.checkRequestObject(obj);
    obj.dbEnv = this.wizardHelper.dbEnv;
    obj.oldZip = this.defaultEditedRow.zip;
    obj.oldPriority = this.defaultEditedRow.priority;
    if(obj.zip != this.defaultEditedRow.zip || obj.priority != this.defaultEditedRow.priority){
        this.checkDuplicate = true;
    } else {
        this.checkDuplicate = false;
    }
    obj.checkDuplicate = this.checkDuplicate;
    delete obj.rowId;
    this.wizardService.updateTmoZipNgp(obj).pipe(takeUntil(this.unsubscribe))
        .subscribe(
        (data: any) => {
            if (data[0] === null || data[0] === undefined) {
                this.showLoadingScreen = false;
                this.toasterService.showErrorMessage(
                    this.tmoZipNgpHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_TMO_ZIP_NGP_ERROR_MESSAGE")
                );
                return;
            }
            if (data[0] && data[0].ERR) {
                this.showLoadingScreen = false;
                const commaSeperatedArr = data[0].ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
                return;
            }
            for (let i = 0; i < this.tableRowsMainData.length; i++) {
                if (this.tableRowsMainData[i].rowId == this.defaultEditedRow.rowId) {
                    this.tableRowsMainData[i] = obj;
                }
            }
            this.isEditable[rowIndex] = !this.isEditable[rowIndex];
            this.showLoadingScreen = false;
            this.alreadyEnabled = true;
            this.editedRow = {};
            this.defaultEditedRow = {};
            this.tableRows = [...this.tableRowsMainData];
            this.checkDuplicate = false;
            this.searchForm();

            this.toasterService.showSuccessMessage(
                this.tmoZipNgpHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_TMO_ZIP_NGP_SUCCESS_MESSAGE")
            );

        },
        (err: any) => {
            this.showLoadingScreen = false;
            if (err.error === undefined || err.error === null)
                this.toasterService.showErrorMessage(
                    this.tmoZipNgpHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                );
            else if (err.error && err.error.ERR) {
                const commaSeperatedArr = err.error.ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
            }
            else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                return;
            else this.toasterService.showErrorMessage(err.error);
        }
        );
}

//to cancel update
private cancelEditForm(rowData, rowIndex) {
    this.showLoadingScreen = true;
    this.isEditable[rowIndex] = !this.isEditable[rowIndex];
    this.tableColumns.forEach(e1 => {
        if (document.getElementById(e1.prop + rowIndex)) {
            (<HTMLInputElement>(
                document.getElementById(e1.prop + rowIndex)
            )).value = rowData[e1.prop] || '';
        }
    });

    this.editedRow = {};
    this.defaultEditedRow = {};
    this.showLoadingScreen = false;
    this.alreadyEnabled = true;
    this.checkDuplicate = false;
    this.editAlreadyEnabled = false;
}

//to filter table
private updateSummaryTable(event) {
    let val: any;
        if (event.target)
            val = event.target.value.toLowerCase();
        else
            val = event.toLowerCase();

    const temp = this.tableRowsMainData.filter(function (d) {
        return (d.zip ? d.zip.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.ngpName ? d.ngpName.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.priority ? d.priority.indexOf(val) !== -1 : !val)
            || (d.ngp ? d.ngp.toLowerCase().indexOf(val) !== -1 : !val)
    });
    this.tableRows = temp;
}

// delete confirm
public showConfirm(esnData, rowIndex) {
    this.confirmationService.confirm({
      key: 'confirm-delete-tmo',
      message: "Are you sure you want to delete TMO Zip NGP ?",
      accept: () => {
        this.deleteTmoZipNgp(esnData, rowIndex)
      }
    });
  }

  // to delete tmo zip ngp
  public deleteTmoZipNgp(esnData, rowIndex) {
    this.showLoadingScreen = true;
    let obj:any = {};
    obj = esnData
    obj.dbEnv = this.wizardHelper.dbEnv;
    delete obj.rowId;
    this.wizardService.deleteTmoZipNgp(obj).pipe(takeUntil(this.unsubscribe))
      .subscribe(
      (data: any) => {
        if (data[0] === null || data[0] === undefined) {
          this.showLoadingScreen = false;
          this.toasterService.showErrorMessage(
            this.tmoZipNgpHelper.getTracfoneConstantMethod("TRACFONE_DELETE_TMO_ZIP_NGP_ERROR_MESSAGE")
          );
          return;
        }
        if (data[0] && data[0].ERR) {
          this.showLoadingScreen = false;
          const commaSeperatedArr = data[0].ERR.split(",");
          for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
            if (commaSeperatedArr[i] != "")
              this.toasterService.showErrorMessage(
                commaSeperatedArr[i]
              );
          }
          return;
        }
        this.toasterService.showSuccessMessage(
          this.tmoZipNgpHelper.getTracfoneConstantMethod("TRACFONE_DELETE_TMO_ZIP_NGP_SUCCESS_MESSAGE")
        );
        this.showNoRecordsFoundMessage = false;
        this.searchForm();
      },
      (err: any) => {
        this.showLoadingScreen = false;
        if (err.error === undefined || err.error === null)
          this.toasterService.showErrorMessage(
            this.tmoZipNgpHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
          );
        else if (err.error && err.error.ERR) {
          const commaSeperatedArr = err.error.ERR.split(",");
          for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
            if (commaSeperatedArr[i] != "")
              this.toasterService.showErrorMessage(
                commaSeperatedArr[i]
              );
          }
        }
        else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
          return;
        else this.toasterService.showErrorMessage(err.error);
      }
      );
  }

  // Checkbox selection from search result table
    public onSelect(row) {
        this.multiColumnEditSection = true;
        this.selectedTmoZipNgp = [];
        if (row && row.selected) {
            for (let i = 0; i < row.selected.length; i++) {
                let obj = { ...row.selected[i] };
                this.selectedTmoZipNgp.push(obj);
            }
        }
        this.selectedTmoZipNgp = [...this.selectedTmoZipNgp]
        if (this.selectedTmoZipNgp.length == 0) {
            this.bulkEditBoolean = false;
            this.otherColumn = false;
            this.showBulkUpdateButton = false;
        }
    }

    public assignmultiColumnName(column) {
        this.showBulkUpdateButton = false;
        this.otherColumn = true;
    }

    public showBulkUpdateButtonFun(event) {
        if(event)
            this.showBulkUpdateButton = true;
        else
            this.showBulkUpdateButton = false;
    }

    bulkUpdateTmoZipNgp(column) {
        if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
            this.toasterService.showErrorMessage(
                this.tmoZipNgpHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            return;
        }
        this.showLoadingScreen = true;
        let requestObj = [];
        this.selectedTmoZipNgp.forEach(e => {
            let obj: any = {};
            if (column == "Zip") {
                obj.zip = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.zip = e.zip;
            }
            if (column == "NGP") {
                obj.ngp = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.ngp = e.ngp;
            }
            if (column == "NGP Name") {
                obj.ngpName = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.ngpName = e.ngpName;
            }
            if (column == "Priority") {
                obj.priority = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.priority = e.priority;
            }
            obj.oldZip = e.zip;
            obj.oldPriority = e.priority;
            obj.dbEnv = this.wizardHelper.dbEnv;
            requestObj.push(obj);
        });

        this.bulkUpdateNgp(requestObj);
    }

    public bulkUpdateNgp(request){
        this.wizardService.bulkUpdateTmoZipNgp(request).pipe(takeUntil(this.unsubscribe))
        .subscribe(
        (data: any) => {
            if (data[0] === null || data[0] === undefined) {
                this.showLoadingScreen = false;
                this.toasterService.showErrorMessage(
                    this.tmoZipNgpHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_TMO_ZIP_NGP_ERROR_MESSAGE")
                );
                return;
            }
            if (data[0] && data[0].ERR) {
                this.showLoadingScreen = false;
                const commaSeperatedArr = data[0].ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
                return;
            }
            this.showLoadingScreen = false;
            this.alreadyEnabled = true;
            this.editAlreadyEnabled = false;
            this.bulkEditBoolean = false;
            this.otherColumn = false;
            this.showBulkUpdateButton = false;
            this.selectedTmoZipNgp = [];
            this.selected = [];
            this.editedRow = {};
            this.defaultEditedRow = {};
            this.checkDuplicate = false;
            this.searchForm();

            this.toasterService.showSuccessMessage(
                this.tmoZipNgpHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_TMO_ZIP_NGP_SUCCESS_MESSAGE")
            );

        },
        (err: any) => {
            this.showLoadingScreen = false;
            if (err.error === undefined || err.error === null)
                this.toasterService.showErrorMessage(
                    this.tmoZipNgpHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                );
            else if (err.error && err.error.ERR) {
                const commaSeperatedArr = err.error.ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
            }
            else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                return;
            else this.toasterService.showErrorMessage(err.error);
        }
        );
    }

   // to filter columns
public filterReportResults(): void {
    const filterFormObject = this.tableFrmGroupMain.value;
    this.filteredValues.zip = filterFormObject.zip;
    this.filteredValues.ngp = filterFormObject.ngp;
    this.filteredValues.ngpName = filterFormObject.ngpName;
    this.filteredValues.priority = filterFormObject.priority;
    const newRows = Object.keys(filterFormObject).reduce((acc, key) => {
        if (!filterFormObject[key].length) return acc;
        const filteredRows = acc.filter(val => filterFormObject[key].indexOf(val[key]) > -1);
        return filteredRows;
    }, this.tableRowsMainData);

    this.tableRows = newRows;
}

public generateFilters(): void {
    this.filteredRows = Object.keys(this.tableColumns)
        .map(i => this.tableColumns[i].prop)
        .reduce((filterObject, columnName) => {
            const uniqueValuesPerRow = this.tableRows.reduce((set, row) => set.add(row[columnName]), new Set());
            let val:any = Array.from(uniqueValuesPerRow);
          if( /^[0-9]*$/.test(val[0])){
               filterObject[columnName] = val.sort(function(a,b){return a - b});
          }else{
               filterObject[columnName] =val.sort((a, b) => {
                a = a || '';
                b = b || '';
                return a.localeCompare(b);
            });                   
          }
            return filterObject;
        }, {});
}
}