import { Injectable } from "@angular/core";
import { Subject } from "rxjs";

@Injectable({
    providedIn: "root"
})
export class TmoZipNgpHelper {
    
    public breadcrumbListUpdate = new Subject<number>();
    public breadcrumbList = [];
    constructor() { }

    public TmoZipNgpConstantObject = {
        "TRACFONE_DEFAULT_ERROR_MESSAGE": "Unable to process request",
        "TRACFONE_DONE_CREATING_TMO_ZIP_NGP_CONFIRM_MESSAGE": "Are you done creating TMO Zip NGP ?",
        "TRACFONE_ADD_TMO_ZIP_NGP_ERROR_MESSAGE": "Unable to add TMO Zip NGP",
        "TRACFONE_ADD_TMO_ZIP_NGP_SUCCESS_MESSAGE": "TMO Zip NGP has been added successfully",  
        "TRACFONE_RETRIEVE_TMO_ZIP_NGP_ERROR_MESSAGE" : "Unable to search TMO Zip NGP",
        "TRACFONE_SEARCH_TMO_ZIP_NGP_ERROR_MESSAGE" : "No TMO Zip NGP found",
        "TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE": "Please complete previous operation",  
        "TRACFONE_UPDATE_TMO_ZIP_NGP_ERROR_MESSAGE" : "Unable to update TMO Zip NGP",
        "TRACFONE_UPDATE_TMO_ZIP_NGP_SUCCESS_MESSAGE" : "TMO Zip NGP has been updated successfully",
        "TRACFONE_DELETE_TMO_ZIP_NGP_SUCCESS_MESSAGE": "TMO Zip NGP has been deleted successfully",
        "TRACFONE_DELETE_TMO_ZIP_NGP_ERROR_MESSAGE": "Unable to delete TMO Zip NGP",
        "TRACFONE_NO_SUMMARY_FOUND_ERROR_MESSAGE" : "No records found",
        "TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE" : "Please fix validation errors",
        "TRACFONE_DUPLICATE_TMO_ZIP_NGP_ERROR_MESSAGE" : "Duplicate TMO Zip NGP found",
        "TRACFONE_RETRIEVE_SUMMARY_ERROR_MESSAGE": "Unable to retrieve bulk insert TMO Zip NGP Summary",
        "TRACFONE_RETRIEVE_ERROR_DETAILS_ERROR_MESSAGE": "Unable to retrieve bulk insert TMO Zip NGP error details",
        "TRACFONE_NO_ERROR_DETAILS_FOUND_ERROR_MESSAGE": "No Details to display"
    }

    public getTracfoneConstantMethod(msg) {
        return this.TmoZipNgpConstantObject[msg];
    }

}