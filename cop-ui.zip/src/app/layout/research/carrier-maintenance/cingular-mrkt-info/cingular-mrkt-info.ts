import { Component, OnInit, ViewChild } from "@angular/core";
import { NgbTabset} from '@ng-bootstrap/ng-bootstrap';


@Component({
    selector: 'cingular-mrkt-info',
    templateUrl: './cingular-mrkt-info.html',
})
export class CingularMrktInfoComponent implements OnInit {
    @ViewChild('tabs')
	private tabs: NgbTabset;
    readonly SUMMARY_TAB = "summaryTab";

    constructor() { }

    ngOnInit() { }


public returnedDatas(data) {
    if (data.lastInsertedRecord) {
        this.tabs.select(this.SUMMARY_TAB);
      }
}

}
