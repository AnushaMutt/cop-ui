import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ConfirmationService } from 'primeng/primeng';
import { takeUntil } from 'rxjs/operators';
import { Subject } from "rxjs";
import { CarrierMaintenanceService } from '../../../../../Services/carrierMaintenance.service';
import { CarrierMaintenanceHelper } from "../../carrier-maintenance-helper";
import { ToasterService } from "../../../../../Services/toaster.service";
import { CingularMrktInfoHelper } from "../cingular-mrkt-info-helper";
import { CingularMrktInfoService } from "../cingular-mrkt-info-service";

@Component({
    selector: 'update-cingular-mrkt-info',
    templateUrl: './update-cingular-mrkt-info.html',
    styleUrls: ['./update-cingular-mrkt-info.scss',
        "../../../../components/ngxtable/material.scss",
        "../../../../components/ngxtable/datatable.component.scss",
        "../../../../components/ngxtable/icons.css",
        "../../../../components/ngxtable/app.css"],
    animations: [],
    encapsulation: ViewEncapsulation.None,
})

export class UpdateCingularMrktInfoComponent implements OnInit {
    private unsubscribe = new Subject<void>();
    public frmCingularMrktInfo: FormGroup;
    public showLoadingScreen: boolean;
    public errorMessage = "";
    public enteredZipCodes: any;
    public tableRows: any = [];
    public tableRowsMainData: any = [];
    isEditable = {};
    private editedRow: any = {};
    private defaultEditedRow: any = {};
    public tableColumns:any = [];
    public alreadyEnabled = true;
    public showNoRecordsFoundMessage : Boolean = true;
    public filteredValues: any = {};

    constructor(
        private formBuilder: FormBuilder,
        private wizardService: CarrierMaintenanceService,
        private cingularMrktInfoHelper: CingularMrktInfoHelper,
        private toasterService: ToasterService,
        private wizardHelper: CarrierMaintenanceHelper,
        private confirmationService: ConfirmationService,
        private cingularMrktInfoService: CingularMrktInfoService
    ) { }
    

    ngOnInit() { this.createForm();
        this.enteredZipCodes = "";
        this.errorMessage = "";
        this.tableColumns = [
            { name: 'Account Num', prop: 'accountNum', width: "250" },
            { name: 'Dealer Code', prop: 'dealerCode', width: "250" },
            { name: 'Market Code', prop: 'marketCode', width: "250" },
            { name: 'MKT', prop: 'mkt', width: "200" },
            { name: 'MKT Type', prop: 'mktType', width: "200" },
            { name: 'NPA', prop: 'npa', width: "200" },
            { name: 'NXX', prop: 'nxx', width: "200" },
            { name: 'NPANXX', prop: 'npanxx', width: "200" },
            { name: 'RC Name', prop: 'rcName', width: "200" },
            { name: 'RC Number', prop: 'rcNumber', width: "200" },
            { name: 'RC State', prop: 'rcState', width: "200" },
            { name: 'Sub Market Id', prop: 'subMarketId', width: "250" },
            { name: 'Template', prop: 'template', width: "200" },
            { name: 'Zip', prop: 'zip', width: "150" },
        ];
        this.filteredValues = {};
    }

        //to create form
        private createForm() {
            this.frmCingularMrktInfo = this.formBuilder.group({
                rcNumber: ['', [Validators.maxLength(20)]],
                rcName: ['', [Validators.maxLength(20)]],
                zip: ['', [Validators.pattern("^[0-9\n ,]*$")]],
                subMarketId: ['', [Validators.maxLength(30)]],
            })
        }

    // reset the form
    revert() {
        this.frmCingularMrktInfo.reset();
        this.enteredZipCodes = "";
        this.errorMessage = "";
        this.tableRows = [];
        this.tableRowsMainData = [];
        this.filteredValues = {};
    }

    /*
     * Validate Zip Code text area
     * Validation Criteria- Limit -> 40,000 | Size -> 5 per zip code
     */
    zipCodeValidation(event) {
        this.errorMessage = "";
        //Splitting string based on the new line
        let zip = event.split("\n")
        let zipcodes: any = [];
        for (let i = 0; i < zip.length; i++) {
            //removing spaces
            zip[i] = zip[i].replace(/\s/g, "");
            //checking if any value with comma exists
            if (zip[i].indexOf(',') > -1) {
                //Sliting String based on the comma
                let commaSeperatedArr = zip[i].split(",");
                /*
                 * Validate Zip Code based on the length
                 * if Zip Codes are valid then pushing into 'zipcodes' array
                */
                for (let j = 0; j < commaSeperatedArr.length; j++) {
                    if (commaSeperatedArr[j].length != 0) {
                        if (commaSeperatedArr[j].length < 5) {
                            this.errorMessage = "Zip Code cannot have less than 5 digits."
                            break;
                        } else if (commaSeperatedArr[j].length > 5) {
                            this.errorMessage = "Zip Code cannot have more than 5 digits."
                            break;
                        } else {
                            zipcodes.push(commaSeperatedArr[j]);
                            //check if zip codes exceeds 40,000
                            if (zipcodes.length > 40000) {
                                this.errorMessage = "Zip Codes cannot exceed 40,000 limit"
                                break;
                            }
                        }
                    }
                }
            }//Validate Zip Code based on the length 
            else if (zip[i].length < 5) {
                if (zip[i].length != 0) {
                    this.errorMessage = "Zip Code cannot have less than 5 digits."
                    break;
                }
            }//Validate Zip Code based on the length 
            else if (zip[i].length > 5) {
                this.errorMessage = "Zip Code cannot have more than 5 digits."
                break;
            }//if Zip Codes are valid then pushing into 'zipcodes' array
            else {
                zipcodes.push(zip[i]);
                //check if zip codes exceeds 40,000
                if (zipcodes.length > 40000) {
                    this.errorMessage = "Zip Codes cannot exceed 40,000 limit"
                    break;
                }
            }
        }
        let returnedZip: any = [];
        this.enteredZipCodes = ""
        if (this.errorMessage == "") {
            zipcodes.forEach(element => {
                if (element.length != 0)
                    returnedZip.push(element);
            });
            this.enteredZipCodes = returnedZip.toString();
        } else {
            this.enteredZipCodes = null;
        }
    }

    public searchForm(){
        let obj = this.frmCingularMrktInfo.value;
        this.editedRow = {};
        this.defaultEditedRow = {};
        this.isEditable = {};
        this.cingularMrktInfoService.setSearchData([]);
    if (this.enteredZipCodes) {
        obj.zip = this.enteredZipCodes;
    }
    obj = this.wizardHelper.checkRequestObject(obj);
    obj.dbEnv = this.wizardHelper.dbEnv;
    if(obj.zip && obj.zip.split(",").length>0){
        let zipCodes:any = [];
    zipCodes = [...obj.zip.split(",")];
        let uniqueZips = zipCodes.filter((v, i) =>
        zipCodes.findIndex(item => item == v) === i);
    let callTimes: number = Math.ceil(uniqueZips.length/1000);
        for(let i=0; i<callTimes; i++){
        let zip = [];
        for(let j=1000*i; j<uniqueZips.length; j++){
            if(j < (i+1)*1000)
                zip.push(uniqueZips[j]);
            else
                break;
        }
        obj.zip = zip.toString();
        this.searchCingularMrktInfo(obj);
    }
}else{
    this.searchCingularMrktInfo(obj);
}
}

   // search cingular mrkt info
   public searchCingularMrktInfo(obj) {
    this.showLoadingScreen = true;
    this.alreadyEnabled = true;
    this.wizardService.searchCingularMrktInfo(obj).pipe(takeUntil(this.unsubscribe))
        .subscribe(
        (data: any) => {
            if (data[0] === null || data[0] === undefined) {
                this.showLoadingScreen = false;
                this.toasterService.showErrorMessage(
                    this.cingularMrktInfoHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_CINGULAR_MRKT_INFO_ERROR_MESSAGE")
                );
                return;
            }
            if (data[0] && data[0].ERR) {
                this.showLoadingScreen = false;
                const commaSeperatedArr = data[0].ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
                return;
            }

            let response = data[0];
            let fullObject = [];
                if (!this.cingularMrktInfoService.getSearchData() || (this.cingularMrktInfoService.getSearchData() && this.cingularMrktInfoService.getSearchData().length == 0)) {
                    response.forEach(e1 => {
                        fullObject.push(e1)
                    });
                    
                } else if (this.cingularMrktInfoService.getSearchData().length > 0) {
                    fullObject = this.cingularMrktInfoService.getSearchData();
                    response.forEach(e1 => {
                        fullObject.push(e1)
                    });
                }
                this.cingularMrktInfoService.setSearchData(fullObject);
                this.tableRowsMainData = [];
                this.tableRows = [];
                for (let i = 0; i < this.cingularMrktInfoService.getSearchData().length; i++) {
                    this.tableRowsMainData.push(this.cingularMrktInfoService.getSearchData()[i]);
                }
                let rowId = 1;
                this.tableRowsMainData.forEach(element => {
                    element.rowId = rowId;
                    rowId++;
                });
                this.tableRows = [...this.tableRowsMainData];
            this.showLoadingScreen = false;
            if (data[0] && data[0].length == 0  && this.showNoRecordsFoundMessage)
            this.toasterService.showErrorMessage(
            this.cingularMrktInfoHelper.getTracfoneConstantMethod("TRACFONE_SEARCH_CINGULAR_MRKT_INFO_ERROR_MESSAGE")
            );
            this.showNoRecordsFoundMessage = true;
            if (this.filteredValues && this.filteredValues.mainTableFilter) {
                this.updateSummaryTable(this.filteredValues.mainTableFilter);
            }
        },
        (err: any) => {
            this.showLoadingScreen = false;
            if (err.error === undefined || err.error === null)
                this.toasterService.showErrorMessage(
                    this.cingularMrktInfoHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                );
            else if (err.error && err.error.ERR) {
                const commaSeperatedArr = err.error.ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
            }
            else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                return;
            else this.toasterService.showErrorMessage(err.error);
        }
        );
}

public  editButtonClicked(rowData,rowIndex) {
    this.alreadyEnabled = false;
    this.defaultEditedRow = { ...rowData }
    for (let i = 0; i < this.tableRowsMainData.length; i++) {
      if (this.isEditable[i])
        this.alreadyEnabled = true;
    }
    if (!this.alreadyEnabled)
      this.isEditable[rowIndex] = !this.isEditable[rowIndex];
    else{
      this.alreadyEnabled = false;
      this.toasterService.showErrorMessage(
        this.cingularMrktInfoHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE")
      );
    }
  }


private inputValueChanged(event, column, row, oldValue) {
        this.editedRow[column] = event.target.value;
        this.defaultEditedRow[column] = event.target.defaultValue;

}

//to update cingular mrkt info
public updateCingularMrktInfo(editData, rowIndex) {
    if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
        this.toasterService.showErrorMessage(
            this.cingularMrktInfoHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
        )
        return;
    }
    this.showLoadingScreen = true;
    let obj = { ...editData, ...this.editedRow }

    obj = this.wizardHelper.checkRequestObject(obj);
    obj.dbEnv = this.wizardHelper.dbEnv;
    obj.oldZip = this.defaultEditedRow.zip;
    delete obj.rowId;
    this.wizardService.updateCingularMrktInfo(obj).pipe(takeUntil(this.unsubscribe))
        .subscribe(
        (data: any) => {
            if (data[0] === null || data[0] === undefined) {
                this.showLoadingScreen = false;
                this.toasterService.showErrorMessage(
                    this.cingularMrktInfoHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_CINGULAR_MRKT_INFO_ERROR_MESSAGE")
                );
                return;
            }
            if (data[0] && data[0].ERR) {
                this.showLoadingScreen = false;
                const commaSeperatedArr = data[0].ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
                return;
            }
            for (let i = 0; i < this.tableRowsMainData.length; i++) {
                if (this.tableRowsMainData[i].rowId == this.defaultEditedRow.rowId) {
                    this.tableRowsMainData[i] = obj;
                }
            }
            this.isEditable[rowIndex] = !this.isEditable[rowIndex];
            this.showLoadingScreen = false;
            this.alreadyEnabled = true;
            this.editedRow = {};
            this.defaultEditedRow = {};
            this.tableRows = [...this.tableRowsMainData];
            this.searchForm();

            this.toasterService.showSuccessMessage(
                this.cingularMrktInfoHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_CINGULAR_MRKT_INFO_SUCCESS_MESSAGE")
            );

        },
        (err: any) => {
            this.showLoadingScreen = false;
            if (err.error === undefined || err.error === null)
                this.toasterService.showErrorMessage(
                    this.cingularMrktInfoHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                );
            else if (err.error && err.error.ERR) {
                const commaSeperatedArr = err.error.ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
            }
            else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                return;
            else this.toasterService.showErrorMessage(err.error);
        }
        );
}

//to cancel update
private cancelEditForm(rowData, rowIndex) {
    this.showLoadingScreen = true;
    this.isEditable[rowIndex] = !this.isEditable[rowIndex];
    this.tableColumns.forEach(e1 => {
        if (document.getElementById(e1.prop + rowIndex)) {
            (<HTMLInputElement>(
                document.getElementById(e1.prop + rowIndex)
            )).value = rowData[e1.prop] || '';
        }
    });

    this.editedRow = {};
    this.defaultEditedRow = {};
    this.showLoadingScreen = false;
    this.alreadyEnabled = true;
}

//to filter table
private updateSummaryTable(event) {
    let val: any;
        if (event.target)
            val = event.target.value.toLowerCase();
        else
            val = event.toLowerCase();

    const temp = this.tableRowsMainData.filter(function (d) {
        return (d.zip ? d.zip.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.mkt ? d.mkt.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.npa ? d.npa.indexOf(val) !== -1 : !val)
            || (d.nxx ? d.nxx.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.npanxx ? d.npanxx.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.rcNumber ? d.rcNumber.indexOf(val) !== -1 : !val)
            || (d.rcName ? d.rcName.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.rcState ? d.rcState.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.mktType ? d.mktType.indexOf(val) !== -1 : !val)
            || (d.accountNum ? d.accountNum.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.marketCode ? d.marketCode.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.dealerCode ? d.dealerCode.indexOf(val) !== -1 : !val)
            || (d.subMarketId ? d.subMarketId.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.template ? d.template.toLowerCase().indexOf(val) !== -1 : !val)
    });
    this.tableRows = temp;
}

// delete confirm
public showConfirm(esnData, rowIndex) {
    this.confirmationService.confirm({
      key: 'confirm-delete-cmi',
      message: "Are you sure you want to delete Cingular Mrkt Info ?",
      accept: () => {
        this.deleteCingularMrktInfo(esnData, rowIndex)
      }
    });
  }

  // to delete cingular mrkt info
  public deleteCingularMrktInfo(esnData, rowIndex) {
    this.showLoadingScreen = true;
    let obj:any = {};
    obj = esnData
    obj.dbEnv = this.wizardHelper.dbEnv;
    delete obj.rowId;
    this.wizardService.deleteCingularMrktInfo(obj).pipe(takeUntil(this.unsubscribe))
      .subscribe(
      (data: any) => {
        if (data[0] === null || data[0] === undefined) {
          this.showLoadingScreen = false;
          this.toasterService.showErrorMessage(
            this.cingularMrktInfoHelper.getTracfoneConstantMethod("TRACFONE_DELETE_CINGULAR_MRKT_INFO_ERROR_MESSAGE")
          );
          return;
        }
        if (data[0] && data[0].ERR) {
          this.showLoadingScreen = false;
          const commaSeperatedArr = data[0].ERR.split(",");
          for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
            if (commaSeperatedArr[i] != "")
              this.toasterService.showErrorMessage(
                commaSeperatedArr[i]
              );
          }
          return;
        }
        this.toasterService.showSuccessMessage(
          this.cingularMrktInfoHelper.getTracfoneConstantMethod("TRACFONE_DELETE_CINGULAR_MRKT_INFO_SUCCESS_MESSAGE")
        );
        this.showNoRecordsFoundMessage = false;
        this.searchForm();
      },
      (err: any) => {
        this.showLoadingScreen = false;
        if (err.error === undefined || err.error === null)
          this.toasterService.showErrorMessage(
            this.cingularMrktInfoHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
          );
        else if (err.error && err.error.ERR) {
          const commaSeperatedArr = err.error.ERR.split(",");
          for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
            if (commaSeperatedArr[i] != "")
              this.toasterService.showErrorMessage(
                commaSeperatedArr[i]
              );
          }
        }
        else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
          return;
        else this.toasterService.showErrorMessage(err.error);
      }
      );
  }
}