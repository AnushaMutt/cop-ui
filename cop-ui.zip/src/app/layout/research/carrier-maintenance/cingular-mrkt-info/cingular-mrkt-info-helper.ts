import { Injectable } from "@angular/core";
import { Subject } from "rxjs";

@Injectable({
    providedIn: "root"
})
export class CingularMrktInfoHelper {
    
    public breadcrumbListUpdate = new Subject<number>();
    public breadcrumbList = [];
    constructor() { }

    public CingularMrktInfoConstantObject = {
        "TRACFONE_DEFAULT_ERROR_MESSAGE": "Unable to process request",
        "TRACFONE_DONE_CREATING_CINGULAR_MRKT_INFO_CONFIRM_MESSAGE": "Are you done creating Cingular Mrkt Info ?",
        "TRACFONE_ADD_CINGULAR_MRKT_INFO_ERROR_MESSAGE": "Unable to add Cingular Mrkt Info",
        "TRACFONE_ADD_CINGULAR_MRKT_INFO_SUCCESS_MESSAGE": "Cingular Mrkt Info has been added successfully",  
        "TRACFONE_RETRIEVE_CINGULAR_MRKT_INFO_ERROR_MESSAGE" : "Unable to search Cingular Mrkt fvInfo",
        "TRACFONE_SEARCH_CINGULAR_MRKT_INFO_ERROR_MESSAGE" : "No Cingular Mrkt Info found",
        "TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE": "Please complete previous operation",  
        "TRACFONE_UPDATE_CINGULAR_MRKT_INFO_ERROR_MESSAGE" : "Unable to update Cingular Mrkt Info",
        "TRACFONE_UPDATE_CINGULAR_MRKT_INFO_SUCCESS_MESSAGE" : "Cingular Mrkt Info has been updated successfully",
        "TRACFONE_DELETE_CINGULAR_MRKT_INFO_SUCCESS_MESSAGE": "Cingular Mrkt Info has been deleted successfully",
        "TRACFONE_DELETE_CINGULAR_MRKT_INFO_ERROR_MESSAGE": "Unable to delete Cingular Mrkt Info",
        "TRACFONE_NO_SUMMARY_FOUND_ERROR_MESSAGE" : "No records found",
        "TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE" : "Please fix validation errors",
        "TRACFONE_DUPLICATE_CINGULAR_MRKT_INFO_ERROR_MESSAGE" : "Duplicate Cingular Mrkt Info found",
    }

    public getTracfoneConstantMethod(msg) {
        return this.CingularMrktInfoConstantObject[msg];
    }

}