import { Component, OnInit, ViewEncapsulation, ViewChildren, Output, EventEmitter } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { ConfirmationService } from 'primeng/primeng';
import { takeUntil } from 'rxjs/operators';
import { Subject } from "rxjs";
import { CarrierMaintenanceService } from '../../../../../Services/carrierMaintenance.service';
import { CarrierMaintenanceHelper } from "../../carrier-maintenance-helper";
import { ToasterService } from "../../../../../Services/toaster.service";
import { CingularMrktInfoHelper } from "../cingular-mrkt-info-helper";
import { CingularMrktInfoService } from "../cingular-mrkt-info-service";
import { MatDialog } from "@angular/material";
import { BulkInsertCingularMrktInfoComponent } from "../bulk-insert-cingular-mrkt-info/bulk-insert-cingular-mrkt-info";

@Component({
    selector: 'add-cingular-mrkt-info',
    templateUrl: './add-cingular-mrkt-info.html',
    styleUrls: ['./add-cingular-mrkt-info.scss',
        "../../../../components/ngxtable/material.scss",
        "../../../../components/ngxtable/datatable.component.scss",
        "../../../../components/ngxtable/icons.css",
        "../../../../components/ngxtable/app.css"],
    animations: [],
    encapsulation: ViewEncapsulation.None,
})

export class AddCingularMrktInfoComponent implements OnInit {
    
    @ViewChildren(DatatableComponent)
    table: any;
    private unsubscribe = new Subject<void>();
    public frmCingularMrktInfo: FormGroup;
    public showLoadingScreen: boolean;
    public displayTable = false;
    private checkedAnother = false;
    public tableRows: any = [];
    public tableRowsMainData: any = [];
    public errorMessage = "";
    public enteredZipCodes: any;
    isEditable = {};
    private editedRow: any = {};
    private defaultEditedRow: any = {};
    public tableColumns:any = [];
    public alerts = [];
    public bulkInsertData = [];
    public showMssg = false;
    @Output("returnedData") returnedData: any = new EventEmitter();
    public alreadyEnabled = true;

    constructor(
        private formBuilder: FormBuilder,
        private wizardService: CarrierMaintenanceService,
        private cingularMrktInfoHelper: CingularMrktInfoHelper,
        private toasterService: ToasterService,
        private wizardHelper: CarrierMaintenanceHelper,
        private confirmationService: ConfirmationService,
        private cingularMrktInfoService: CingularMrktInfoService,
        public dialog: MatDialog,
    ) {
        this.frmCingularMrktInfo = new FormGroup({});
    }

    ngOnInit() { 
        this.createForm();
        this.enteredZipCodes = "";
        this.errorMessage = "";
        this.tableColumns = [
            { name: 'NPA', prop: 'npa', width: "200" },
            { name: 'NXX', prop: 'nxx', width: "200" },
            { name: 'NPANXX', prop: 'npanxx', width: "200" },
            { name: 'Account Num', prop: 'accountNum', width: "250" },
            { name: 'Dealer Code', prop: 'dealerCode', width: "250" },
            { name: 'Market Code', prop: 'marketCode', width: "250" },
            { name: 'MKT', prop: 'mkt', width: "200" },
            { name: 'MKT Type', prop: 'mktType', width: "200" },
            { name: 'RC Name', prop: 'rcName', width: "200" },
            { name: 'RC Number', prop: 'rcNumber', width: "200" },
            { name: 'RC State', prop: 'rcState', width: "200" },
            { name: 'Sub Market Id', prop: 'subMarketId', width: "250" },
            { name: 'Template', prop: 'template', width: "200" },
            { name: 'Zip', prop: 'zip', width: "150" },
        ];
        this.showMssg = false;
        this.cingularMrktInfoService.setAddData([]);
    }

        //to create form
        private createForm() {
            this.frmCingularMrktInfo = this.formBuilder.group({
                rcNumber: ['', [Validators.required, Validators.maxLength(20)]],
                rcName: ['', [Validators.required, Validators.maxLength(20)]],
                zip: ['', [Validators.required, Validators.pattern("^[0-9\n ,]*$")]],
                subMarketId: ['', [Validators.required, Validators.maxLength(30)]],
                accountNum: ['', [Validators.required, Validators.maxLength(30)]],
                marketCode: ['', [Validators.required, Validators.maxLength(30)]],
                dealerCode: ['', [Validators.required, Validators.maxLength(30)]],
                mkt: ['', [Validators.required, Validators.maxLength(20)]],
                npa: ['', [Validators.maxLength(20)]],
                nxx: ['', [Validators.maxLength(20)]],
                npanxx: ['', [Validators.maxLength(20)]],
                rcState: ['', [Validators.required, Validators.maxLength(20)]],
                mktType: ['', [Validators.required, Validators.maxLength(20)]],
                template: ['', [Validators.required, Validators.maxLength(20)]],
            })
        }

    //to add cingular mrkt info
    private addCingularMrktInfo(f) {
        this.showLoadingScreen = true;
        this.alreadyEnabled = true;
        let obj = f.value;
        if (this.enteredZipCodes) {
            let zipCodes:any = [];
    zipCodes = [...this.enteredZipCodes.split(",")];
        let uniqueZips = zipCodes.filter((v, i) =>
        zipCodes.findIndex(item => item == v) === i);
            obj.zip = uniqueZips.toString();
        }
        obj = this.wizardHelper.checkRequestObject(obj);
        obj.dbEnv = this.wizardHelper.dbEnv;
        this.wizardService.addCingularMrktInfo(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.cingularMrktInfoHelper.getTracfoneConstantMethod("TRACFONE_ADD_CINGULAR_MRKT_INFO_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }

                const d = data[0].message;
                if(d==""){
                    this.toasterService.showErrorMessage(
                    this.cingularMrktInfoHelper.getTracfoneConstantMethod("TRACFONE_DUPLICATE_CINGULAR_MRKT_INFO_ERROR_MESSAGE")
                );
                }else{
                    let fullObject = [];
                    if (!this.cingularMrktInfoService.getAddData() || (this.cingularMrktInfoService.getAddData() && this.cingularMrktInfoService.getAddData().length == 0)) {
                        let zipValue = {...obj}
                        obj.zip.split(",").forEach(e1 => {
                            zipValue.zip = e1
                            obj = { ...obj, ...zipValue }
                            fullObject.push(obj);
                        });                    
                    } else if (this.cingularMrktInfoService.getAddData().length > 0) {
                        fullObject = this.cingularMrktInfoService.getAddData();
                       let zipValue = {...obj}
                        obj.zip.split(",").forEach(e1 => {
                            zipValue.zip = e1
                            obj = { ...obj, ...zipValue }
                            fullObject.push(obj);
                        }); 
                    }
                    this.cingularMrktInfoService.setAddData(fullObject);
                    this.tableRowsMainData = [];
                    this.tableRows = [];
                    for (let i = 0; i < this.cingularMrktInfoService.getAddData().length; i++) {
                        this.tableRowsMainData.push(this.cingularMrktInfoService.getAddData()[i]);
                    }
                    let rowId = 1;
                    this.tableRowsMainData.forEach(element => {
                        element.rowId = rowId;
                        rowId++;
                    });
                    this.tableRows = [...this.tableRowsMainData];
                    if (this.checkedAnother) {
                        this.displayTable = false;
                    } else {
                        this.displayTable = true;
                    }
                    this.frmCingularMrktInfo.reset();
                    this.toasterService.showSuccessMessage(
                        this.cingularMrktInfoHelper.getTracfoneConstantMethod("TRACFONE_ADD_CINGULAR_MRKT_INFO_SUCCESS_MESSAGE")
                    );
                }
                this.showLoadingScreen = false;
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.cingularMrktInfoHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }

    onChangeCheckbox(event) {
        if (event.checked) this.checkedAnother = true;
        else this.checkedAnother = false;
    }

    //show summary confirm
    public showSummaryConfirm(f, index) {
        this.confirmationService.confirm({
            key: 'confirm-add-show-summary',
            message: this.cingularMrktInfoHelper.getTracfoneConstantMethod("TRACFONE_DONE_CREATING_CINGULAR_MRKT_INFO_CONFIRM_MESSAGE"),
            accept: () => {
                this.displayTable = true;
                this.checkedAnother = false;
            }
        });
    }

    /*
     * Validate Zip Code text area
     * Validation Criteria- Limit -> 40,000 | Size -> 5 per zip code
     */
    zipCodeValidation(event) {
        this.errorMessage = "";
        //Splitting string based on the new line
        let zip = event.split("\n")
        let zipcodes: any = [];
        for (let i = 0; i < zip.length; i++) {
            //removing spaces
            zip[i] = zip[i].replace(/\s/g, "");
            //checking if any value with comma exists
            if (zip[i].indexOf(',') > -1) {
                //Sliting String based on the comma
                let commaSeperatedArr = zip[i].split(",");
                /*
                 * Validate Zip Code based on the length
                 * if Zip Codes are valid then pushing into 'zipcodes' array
                */
                for (let j = 0; j < commaSeperatedArr.length; j++) {
                    if (commaSeperatedArr[j].length != 0) {
                        if (commaSeperatedArr[j].length < 5) {
                            this.errorMessage = "Zip Code cannot have less than 5 digits."
                            break;
                        } else if (commaSeperatedArr[j].length > 5) {
                            this.errorMessage = "Zip Code cannot have more than 5 digits."
                            break;
                        } else {
                            zipcodes.push(commaSeperatedArr[j]);
                            //check if zip codes exceeds 40,000
                            if (zipcodes.length > 40000) {
                                this.errorMessage = "Zip Codes cannot exceed 40,000 limit"
                                break;
                            }
                        }
                    }
                }
            }//Validate Zip Code based on the length 
            else if (zip[i].length < 5) {
                if (zip[i].length != 0) {
                    this.errorMessage = "Zip Code cannot have less than 5 digits."
                    break;
                }
            }//Validate Zip Code based on the length 
            else if (zip[i].length > 5) {
                this.errorMessage = "Zip Code cannot have more than 5 digits."
                break;
            }//if Zip Codes are valid then pushing into 'zipcodes' array
            else {
                zipcodes.push(zip[i]);
                //check if zip codes exceeds 40,000
                if (zipcodes.length > 40000) {
                    this.errorMessage = "Zip Codes cannot exceed 40,000 limit"
                    break;
                }
            }
        }
        let returnedZip: any = [];
        this.enteredZipCodes = ""
        if (this.errorMessage == "") {
            zipcodes.forEach(element => {
                if (element.length != 0)
                    returnedZip.push(element);
            });
            this.enteredZipCodes = returnedZip.toString();
        } else {
            this.enteredZipCodes = null;
        }
    }

    // reset the form
    revert() {
        this.frmCingularMrktInfo.reset();
        this.enteredZipCodes = "";
        this.errorMessage = "";
        this.alerts = [];
        this.bulkInsertData = [];
        let filterKeys = Object.keys(this.frmCingularMrktInfo.controls);
        filterKeys.forEach(_e1 => {
            if(_e1 == 'subMarketId' || _e1 == 'accountNum' || _e1 == 'marketCode' || _e1 == 'dealerCode'){
                this.frmCingularMrktInfo.controls[`${_e1}`].setValidators([Validators.required, Validators.maxLength(30)]);
                this.frmCingularMrktInfo.controls[`${_e1}`].updateValueAndValidity();
                } else if(_e1 == 'zip'){
                    this.frmCingularMrktInfo.controls[`${_e1}`].setValidators([Validators.required, Validators.pattern("^[0-9\n ,]*$")]);
                    this.frmCingularMrktInfo.controls[`${_e1}`].updateValueAndValidity();  
                } else if(_e1 == 'npa' || _e1 == 'nxx' || _e1 == 'npanxx'){
                    this.frmCingularMrktInfo.controls[`${_e1}`].setValidators([Validators.maxLength(20)]);
                    this.frmCingularMrktInfo.controls[`${_e1}`].updateValueAndValidity();
                    }
                else{
                    this.frmCingularMrktInfo.controls[`${_e1}`].setValidators([Validators.required, Validators.maxLength(20)]);
                    this.frmCingularMrktInfo.controls[`${_e1}`].updateValueAndValidity();
                    }
        });
    }

    public  editButtonClicked(rowData,rowIndex) {
        this.alreadyEnabled = false;
        this.defaultEditedRow = { ...rowData }
        for (let i = 0; i < this.tableRowsMainData.length; i++) {
          if (this.isEditable[i])
            this.alreadyEnabled = true;
        }
        if (!this.alreadyEnabled)
          this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        else{
          this.alreadyEnabled = false;
          this.toasterService.showErrorMessage(
            this.cingularMrktInfoHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE")
          );
        }
      }
    
    private inputValueChanged(event, column, row, oldValue) {
            this.editedRow[column] = event.target.value;
            this.defaultEditedRow[column] = event.target.defaultValue;
    
    }
    
    //to update cingular mrkt info
    public updateCingularMrktInfo(editData, rowIndex) {
        if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
            this.toasterService.showErrorMessage(
                this.cingularMrktInfoHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            return;
        }
        this.showLoadingScreen = true;
        let obj = { ...editData, ...this.editedRow }
    
        obj = this.wizardHelper.checkRequestObject(obj);
        obj.dbEnv = this.wizardHelper.dbEnv;
        obj.oldZip = this.defaultEditedRow.zip;
        delete obj.rowId;
        this.wizardService.updateCingularMrktInfo(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.cingularMrktInfoHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_CINGULAR_MRKT_INFO_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                for (let i = 0; i < this.tableRowsMainData.length; i++) {
                    if (this.tableRowsMainData[i].rowId == this.defaultEditedRow.rowId) {
                        this.tableRowsMainData[i] = obj;
                    }
                }
                this.isEditable[rowIndex] = !this.isEditable[rowIndex];
                this.showLoadingScreen = false;
                this.editedRow = {};
                this.defaultEditedRow = {};
                this.tableRows = [...this.tableRowsMainData];
                this.alreadyEnabled = true;
    
                this.toasterService.showSuccessMessage(
                    this.cingularMrktInfoHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_CINGULAR_MRKT_INFO_SUCCESS_MESSAGE")
                );
    
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.cingularMrktInfoHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }
    
    //to cancel update
    private cancelEditForm(rowData, rowIndex) {
        this.showLoadingScreen = true;
        this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        this.tableColumns.forEach(e1 => {
            if (document.getElementById(e1.prop + rowIndex)) {
                (<HTMLInputElement>(
                    document.getElementById(e1.prop + rowIndex)
                )).value = rowData[e1.prop] || '';
            }
        });
    
        this.editedRow = {};
        this.defaultEditedRow = {};
        this.showLoadingScreen = false;
        this.alreadyEnabled = true;
    }
    
    //to filter table
    private updateSummaryTable(event) {
        const val = event.target.value.toLowerCase();
    
        const temp = this.tableRowsMainData.filter(function (d) {
            return (d.zip ? d.zip.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.mkt ? d.mkt.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.npa ? d.npa.indexOf(val) !== -1 : !val)
            || (d.nxx ? d.nxx.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.npanxx ? d.npanxx.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.rcNumber ? d.rcNumber.indexOf(val) !== -1 : !val)
            || (d.rcName ? d.rcName.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.rcState ? d.rcState.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.mktType ? d.mktType.indexOf(val) !== -1 : !val)
            || (d.accountNum ? d.accountNum.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.marketCode ? d.marketCode.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.dealerCode ? d.dealerCode.indexOf(val) !== -1 : !val)
            || (d.subMarketId ? d.subMarketId.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.template ? d.template.toLowerCase().indexOf(val) !== -1 : !val)
        });
        this.tableRows = temp;
    }


// delete confirm
public showConfirm(cmiData, rowIndex) {
    this.confirmationService.confirm({
      key: 'confirm-delete-cmi',
      message: "Are you sure you want to delete Cingular Mrkt Info ?",
      accept: () => {
        this.deleteCingularMrktInfo(cmiData, rowIndex)
      }
    });
  }

  // to delete cingular mrkt info
  public deleteCingularMrktInfo(cmiData, rowIndex) {
    this.showLoadingScreen = true;
    let obj:any = {};
    obj = cmiData
    obj.dbEnv = this.wizardHelper.dbEnv;
    delete obj.rowId;
    this.wizardService.deleteCingularMrktInfo(obj).pipe(takeUntil(this.unsubscribe))
      .subscribe(
      (data: any) => {
        if (data[0] === null || data[0] === undefined) {
          this.showLoadingScreen = false;
          this.toasterService.showErrorMessage(
            this.cingularMrktInfoHelper.getTracfoneConstantMethod("TRACFONE_DELETE_CINGULAR_MRKT_INFO_ERROR_MESSAGE")
          );
          return;
        }
        if (data[0] && data[0].ERR) {
          this.showLoadingScreen = false;
          const commaSeperatedArr = data[0].ERR.split(",");
          for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
            if (commaSeperatedArr[i] != "")
              this.toasterService.showErrorMessage(
                commaSeperatedArr[i]
              );
          }
          return;
        }
        this.toasterService.showSuccessMessage(
          this.cingularMrktInfoHelper.getTracfoneConstantMethod("TRACFONE_DELETE_CINGULAR_MRKT_INFO_SUCCESS_MESSAGE")
        );

        this.tableRows.forEach((rec: any, key) => {
            if (obj.zip == rec.zip && obj.nPANXX == rec.nPANXX && obj.accountNum == rec.accountNum) {
              this.tableRows.splice(key, 1);
              this.cingularMrktInfoService.getAddData().splice(key, 1);
            }
          });
          this.tableRows = [...this.tableRows];
          this.tableRowsMainData = [...this.tableRows];
          if (this.tableRows.length === 0) {
            this.displayTable = false;
            this.checkedAnother = false;
            this.tableRows = [];
            this.revert();
            this.cingularMrktInfoService.setAddData([]);
          }
        this.showLoadingScreen = false;
      },
      (err: any) => {
        this.showLoadingScreen = false;
        if (err.error === undefined || err.error === null)
          this.toasterService.showErrorMessage(
            this.cingularMrktInfoHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
          );
        else if (err.error && err.error.ERR) {
          const commaSeperatedArr = err.error.ERR.split(",");
          for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
            if (commaSeperatedArr[i] != "")
              this.toasterService.showErrorMessage(
                commaSeperatedArr[i]
              );
          }
        }
        else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
          return;
        else this.toasterService.showErrorMessage(err.error);
      }
      );
  }

// to open bulk insert pop up
  openUploadCSVDialog() {
    const dialogRef = this.dialog.open(BulkInsertCingularMrktInfoComponent, {
        width: "90%",
        height: "90%",
    });
    // Create subscription
    dialogRef.afterClosed().subscribe((bulkInsertData) => {
        if (bulkInsertData && bulkInsertData.length > 0) {
            this.warningAlert("Your upload is complete. Please click on Submit to begin database insertions.")
            this.bulkInsertData = [...bulkInsertData];
            let filterKeys = Object.keys(this.frmCingularMrktInfo.controls);
        filterKeys.forEach(_e1 => {
            this.frmCingularMrktInfo.controls[`${_e1}`].setValidators([]);
            this.frmCingularMrktInfo.controls[`${_e1}`].updateValueAndValidity();
        });
        }
    });
}

//to bulk insert cingular mrkt info
private bulkInsertCingularMrktInfo() {
    this.showLoadingScreen = true;
    let obj: any = [];
    this.alreadyEnabled = true;
    obj = [...this.bulkInsertData];
    obj.forEach(element => {
        element.dbEnv = this.wizardHelper.dbEnv;
    });
    obj = this.wizardHelper.checkRequestObject(obj);
    obj.dbEnv = this.wizardHelper.dbEnv;
    this.wizardService.bulkInsertCingularMrktInfo(obj).pipe(takeUntil(this.unsubscribe))
        .subscribe(
        (data: any) => {
            if (data[0] === null || data[0] === undefined) {
                this.showLoadingScreen = false;
                this.toasterService.showErrorMessage(
                    this.cingularMrktInfoHelper.getTracfoneConstantMethod("TRACFONE_ADD_CINGULAR_MRKT_INFO_ERROR_MESSAGE")
                );
                return;
            }
            if (data[0] && data[0].ERR) {
                this.showLoadingScreen = false;
                const commaSeperatedArr = data[0].ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
                return;
            }
            this.showLoadingScreen = false;
            this.showMssg = true;
            this.revert();
        },
        (err: any) => {
            this.showLoadingScreen = false;
            if (err.error === undefined || err.error === null)
                this.toasterService.showErrorMessage(
                    this.cingularMrktInfoHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                );
            else if (err.error && err.error.ERR) {
                const commaSeperatedArr = err.error.ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
            }
            else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                return;
            else this.toasterService.showErrorMessage(err.error);
        }
        );
}


private warningAlert(warningMsg: string) {
    window.scrollTo(0, 0);
    this.alerts = [];
    this.alerts.push({
        id: 3,
        type: 'warning',
        message: warningMsg
    });
  }

  public closeAlert(alert: any) {
    const index: number = this.alerts.indexOf(alert);
    this.alerts.splice(index, 1);
  }

  public showLastInsertedRecords() {
    this.returnedData.emit({ lastInsertedRecord: true });
  }

}
