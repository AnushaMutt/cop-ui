import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { ToasterService } from "../../../../../Services/toaster.service";
import { ExportToCsvService } from "../../../../../Services/export-to-csv.service";
import { ImportFromCsvService } from "../../../../../Services/import-from-csv.service";
import { MatDialogRef } from "@angular/material";

@Component({
    selector: 'bulk-insert-cingular-mrkt-info',
    templateUrl: './bulk-insert-cingular-mrkt-info.html',
    styleUrls: ['./bulk-insert-cingular-mrkt-info.scss',
        "../../../../components/ngxtable/material.scss",
        "../../../../components/ngxtable/datatable.component.scss",
        "../../../../components/ngxtable/icons.css",
        "../../../../components/ngxtable/app.css"],
    animations: [],
    encapsulation: ViewEncapsulation.None,
    providers: [ExportToCsvService, ImportFromCsvService]
})

export class BulkInsertCingularMrktInfoComponent implements OnInit {
    public multiColumnEditColumns = [];
    public fileContent: Boolean;
    public filename: string = null;
    public uploadedData: any = [];
    public uploadedMainData: any = [];
    public alerts: any = [];
    public exportColumns = [];
    public tableColmns = [];
    readonly EXPORT_FILE_NAME = "Insert_Cingular_Mrkt_Info_template";
    public showLoadingScreen: Boolean = false;
    public showMssg = false;

    constructor(
        private toasterService: ToasterService,
        private exportToCsvService: ExportToCsvService,
        private importFromCsvService: ImportFromCsvService,
        public dialogRef: MatDialogRef<BulkInsertCingularMrktInfoComponent>,
    ) { dialogRef.disableClose = true;  }

    ngOnInit() {
        this.fileContent = false;
        this.filename = "";
        this.uploadedData = [];
        this.uploadedMainData = [];
        this.alerts = [];
        this.exportColumns = ["MKT", "NPA", "NXX","NPANXX", "RC Number", "RC Name", "RC State", "Zip", "MKT Type", "Account Num", "Market Code", "Dealer Code", "Submarket Id", "Template"];
        this.tableColmns = [
            { name: 'Account Num', prop: 'accountNum', width: "250" },
            { name: 'Dealer Code', prop: 'dealerCode', width: "250" },
            { name: 'Market Code', prop: 'marketCode', width: "250" },
            { name: 'MKT', prop: 'mkt', width: "200" },
            { name: 'MKT Type', prop: 'mktType', width: "200" },
            { name: 'NPA', prop: 'npa', width: "200" },
            { name: 'NXX', prop: 'nxx', width: "200" },
            { name: 'NPANXX', prop: 'npanxx', width: "200" },
            { name: 'RC Name', prop: 'rcName', width: "200" },
            { name: 'RC Number', prop: 'rcNumber', width: "200" },
            { name: 'RC State', prop: 'rcState', width: "200" },
            { name: 'Sub Market Id', prop: 'subMarketId', width: "250" },
            { name: 'Template', prop: 'template', width: "200" },
            { name: 'Zip', prop: 'zip', width: "150" },
        ];
        this.showMssg = false;
    }

    //Used to Download Template
    exportToCSV() {
        this.exportToCsvService.downloadFile([], this.EXPORT_FILE_NAME, this.exportColumns);
    }

    saveUploadDialog() {
        if (document.getElementsByClassName("tableError") && document.getElementsByClassName("tableError").length > 0) {
            this.toasterService.showErrorMessage("Please fix validation errors.");
            return;
        }
        for(let i=0;i<this.uploadedMainData.length;i++){
            delete this.uploadedMainData[i].MKT;
            delete this.uploadedMainData[i].NPA;
            delete this.uploadedMainData[i].NXX;
            delete this.uploadedMainData[i].NPANXX;
            delete this.uploadedMainData[i]['RC Number'];
            delete this.uploadedMainData[i]['RC State'];
            delete this.uploadedMainData[i]["RC Name"];
            delete this.uploadedMainData[i].Zip;
            delete this.uploadedMainData[i]['MKT Type'];
            delete this.uploadedMainData[i]['Account Num'];
            delete this.uploadedMainData[i]['Market Code'];
            delete this.uploadedMainData[i]['Dealer Code'];
            delete this.uploadedMainData[i]["Submarket Id"];
            delete this.uploadedMainData[i].Template;
            delete this.uploadedMainData[i]['S.NO'];
        }
        let uploadData = [];
        
        uploadData = this.uploadedMainData.filter((v,i,a)=>a.findIndex(t=>(t.zip === v.zip))===i)
        this.dialogRef.close(uploadData);
    }

    //Read File and show data on the table
    public changeListener(files: FileList) {
        let invalidFile = "Please select a valid file to upload.";
        let noDataInFile = "There is no data to upload in this file.";
        let limitExceed = "You cannot insert more than 500 records at a time.";
        this.alerts = [];
        if (files && files.length > 0) { 
            this.fileContent = true;
            let file: File = files.item(0);
            let name = file.name;
            var ext = name.substring(name.lastIndexOf('.') + 1);
            if (ext.toLowerCase() == 'csv') {
                this.filename = name.substr(0, name.lastIndexOf("."));
                if (this.filename.split(" ")[0] != this.EXPORT_FILE_NAME) {
                    this.toasterService.showErrorMessage(invalidFile);
                    return;
                }
            } else {
                this.toasterService.showErrorMessage(invalidFile);
                return;
            }
            let reader: FileReader = new FileReader();
            reader.readAsText(file);
            reader.onload = (e) => {
                let uploadData = this.importFromCsvService.csvToArray(reader.result);
                if (uploadData.length == 0) {
                    this.toasterService.showErrorMessage(noDataInFile);
                } else if (uploadData.length > 500) {
                    this.toasterService.showErrorMessage(limitExceed);
                } else {
                    let keys = Object.keys(uploadData[0]);
                    for (let i = 1, j = 0; j < this.exportColumns.length; i++, j++) {
                        if (keys[i] != this.exportColumns[j]) {
                            this.toasterService.showErrorMessage(invalidFile);
                            return;
                        }
                    }
                    uploadData.forEach(_e1 => {
                        _e1.mkt = _e1.MKT;
                        _e1.npa = _e1.NPA;
                        _e1.nxx = _e1.NXX;
                        _e1.npanxx = _e1.NPANXX;
                        _e1.zip = _e1.Zip;
                        _e1.template = _e1.Template;
                        _e1.rcName = _e1["RC Name"];
                        _e1.rcNumber = _e1["RC Number"];
                        _e1.rcState = _e1["RC State"];
                        _e1.mktType = _e1["MKT Type"];
                        _e1.accountNum = _e1["Account Num"];
                        _e1.marketCode = _e1["Market Code"];
                        _e1.dealerCode = _e1["Dealer Code"];
                        _e1.subMarketId = _e1["Submarket Id"];
                    });
                    this.uploadedData = [...this.checkUploadedData(uploadData)];
                }
            }
        }
    }

    //Removes file and table from the screen
    public removeFile() {
        this.fileContent = false;
        this.filename = null;
        this.uploadedData = [];
        this.uploadedMainData = [];
        this.alerts = [];
    }

    public checkUploadedData(data) {
        let errorData = [];
        let successData = [];
        data.forEach(element => {
            element.rowNum = element['S.NO'];
        });
        data.forEach(element => {
            if (element.rowNum.length == 0 || element.Zip.length == 0 ||element.MKT.length == 0 ||element.Template.length == 0 || element["Account Num"].length == 0 || element["Dealer Code"].length == 0 
            || element["Market Code"].length == 0 || element["MKT Type"].length == 0 || element["RC Name"].length == 0 || element["RC Number"].length == 0 || element["RC State"].length == 0 || element["Submarket Id"].length == 0
            || element.MKT.length > 20 || element.Template.length > 20 || element.NPA.length > 20 || element.NXX.length > 20 || element.NPANXX.length > 30
            || element["Submarket Id"].length > 30 || element["Account Num"].length > 30 || element["Market Code"].length > 30 || element["Dealer Code"].length > 30
            || element["MKT Type"].length > 20 || element["RC Name"].length > 20 || element["RC Number"].length > 20 || element["RC State"].length > 20) {
                errorData.push(element);
            } else
            successData.push(element);
        });
        this.uploadedMainData = [...errorData, ...successData];
        return this.uploadedMainData;
    }

    //Removes Row from the table
    deleteRow(row) {
        this.uploadedMainData.forEach((data, key) => {
            if (row.rowNum == data.rowNum) {
                this.uploadedMainData.splice(key, 1);
            }
        });
        this.uploadedData = [...this.uploadedMainData];
    }

    //inline values changes
    public editValueChanged(event, column, row, oldValue) {
        for (let i = 0; i < this.uploadedMainData.length; i++) {
            if (this.uploadedMainData[i].rowNum == row.rowNum) {
                this.uploadedMainData[i][column] = event.target.value;
            }
        }
        this.uploadedData = [...this.uploadedMainData];
    }

    //Filter for result table
    public filterTableData(event) {
        const val = event.target.value.toLowerCase();
        // filter our data
        const temp = this.uploadedMainData.filter(function (d) {
            return (d.zip ? d.zip.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.mkt ? d.mkt.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.npa ? d.npa.indexOf(val) !== -1 : !val)
            || (d.nxx ? d.nxx.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.npanxx ? d.npanxx.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.rcNumber ? d.rcNumber.indexOf(val) !== -1 : !val)
            || (d.rcName ? d.rcName.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.rcState ? d.rcState.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.mktType ? d.mktType.indexOf(val) !== -1 : !val)
            || (d.accountNum ? d.accountNum.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.marketCode ? d.marketCode.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.dealerCode ? d.dealerCode.indexOf(val) !== -1 : !val)
            || (d.subMarketId ? d.subMarketId.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.template ? d.template.toLowerCase().indexOf(val) !== -1 : !val)
        });
        // update the rows
        this.uploadedData = temp;
    }

    cancelUploadDialog(): void {
        this.dialogRef.close();
    }

}