import { Injectable } from "@angular/core";
import { Subject } from "rxjs";

@Injectable({
    providedIn: "root"
})
export class Npanxx2CarrierZonesHelper {
    
    public breadcrumbListUpdate = new Subject<number>();
    public breadcrumbList = [];
    constructor() { }

    public Npanxx2CarrierZonesConstantObject = {
        "TRACFONE_DEFAULT_ERROR_MESSAGE": "Unable to process request",
        "TRACFONE_DONE_CREATING_NPANXX2CARRIERZONES_CONFIRM_MESSAGE": "Are you done creating NPANXX2 Carrier Zones ?",
        "TRACFONE_ADD_NPANXX2CARRIERZONES_ERROR_MESSAGE": "Unable to add NPANXX2 Carrier Zones",
        "TRACFONE_ADD_NPANXX2CARRIERZONES_SUCCESS_MESSAGE": "NPANXX2 Carrier Zones has been added successfully",  
        "TRACFONE_RETRIEVE_NPANXX2CARRIERZONES_ERROR_MESSAGE" : "Unable to search NPANXX2 Carrier Zones",
        "TRACFONE_SEARCH_NPANXX2CARRIERZONES_ERROR_MESSAGE" : "No NPANXX2 Carrier Zones found",
        "TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE": "Please complete previous operation",  
        "TRACFONE_UPDATE_NPANXX2CARRIERZONES_ERROR_MESSAGE" : "Unable to update NPANXX2 Carrier Zones",
        "TRACFONE_UPDATE_NPANXX2CARRIERZONES_SUCCESS_MESSAGE" : "NPANXX2 Carrier Zones has been updated successfully",
        "TRACFONE_DELETE_NPANXX2CARRIERZONES_SUCCESS_MESSAGE": "NPANXX2 Carrier Zones has been deleted successfully",
        "TRACFONE_DELETE_NPANXX2CARRIERZONES_ERROR_MESSAGE": "Unable to delete NPANXX2 Carrier Zones",
        "TRACFONE_NO_SUMMARY_FOUND_ERROR_MESSAGE" : "No records found",
        "TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE" : "Please fix validation errors",
        "TRACFONE_DUPLICATE_NPANXX2CARRIERZONES_ERROR_MESSAGE" : "Duplicate NPANXX2 Carrier Zones found",
    }

    public getTracfoneConstantMethod(msg) {
        return this.Npanxx2CarrierZonesConstantObject[msg];
    }

}