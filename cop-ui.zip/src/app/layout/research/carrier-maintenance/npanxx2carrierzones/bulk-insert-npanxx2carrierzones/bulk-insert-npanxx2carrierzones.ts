import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { ToasterService } from "../../../../../Services/toaster.service";
import { ExportToCsvService } from "../../../../../Services/export-to-csv.service";
import { ImportFromCsvService } from "../../../../../Services/import-from-csv.service";
import { MatDialogRef } from "@angular/material";

@Component({
    selector: 'bulk-insert-npanxx2carrierzones',
    templateUrl: './bulk-insert-npanxx2carrierzones.html',
    styleUrls: ['./bulk-insert-npanxx2carrierzones.scss',
        "../../../../components/ngxtable/material.scss",
        "../../../../components/ngxtable/datatable.component.scss",
        "../../../../components/ngxtable/icons.css",
        "../../../../components/ngxtable/app.css"],
    animations: [],
    encapsulation: ViewEncapsulation.None,
    providers: [ExportToCsvService, ImportFromCsvService]
})

export class BulkInsertNpanxx2carrierzonesComponent implements OnInit {
    public multiColumnEditColumns = [];
    public fileContent: Boolean;
    public filename: string = null;
    public uploadedData: any = [];
    public uploadedMainData: any = [];
    public alerts: any = [];
    public exportColumns = [];
    public tableColmns = [];
    readonly EXPORT_FILE_NAME = "Insert_Npanxx2carrierzones_template";
    public showLoadingScreen: Boolean = false;
    public showMssg = false;

    constructor(
        private toasterService: ToasterService,
        private exportToCsvService: ExportToCsvService,
        private importFromCsvService: ImportFromCsvService,
        public dialogRef: MatDialogRef<BulkInsertNpanxx2carrierzonesComponent>,
    ) { dialogRef.disableClose = true;  }

    ngOnInit() {
        this.fileContent = false;
        this.filename = "";
        this.uploadedData = [];
        this.uploadedMainData = [];
        this.alerts = [];
        this.exportColumns = ["NPA", "NXX", "Carrier ID", "Carrier Name", "Lead Time","Target Level",
                              "Rate Center","State","Carrier ID Description","Zone","County","Market ID", 
                              "MRKT Area","SID","Technology","Frequency1","Frequency2","BTA MKT Number",
                              "BTA MKT Name","GSM Tech","CDMA Tech","TDMA Tech","MNC"];
        this.tableColmns = [
            { name: 'NPA', prop: 'npa', width: "250" },
            { name: 'NXX', prop: 'nxx', width: "250" },
            { name: 'Carrier ID', prop: 'carrierId', width: "250" },
            { name: 'Carrier Name', prop: 'carrierName', width: "250" },
            { name: 'Lead Time', prop: 'leadTime', width: "250" },
            { name: 'Target Level', prop: 'targetLevel', width: "250" },
            { name: 'Rate Center', prop: 'rateCenter', width: "250" },
            { name: 'State', prop: 'state', width: "250" },
            { name: 'Carrier ID Description', prop: 'carrierIdDescription', width: "250" },
            { name: 'Zone', prop: 'zone', width: "250" },
            { name: 'County', prop: 'county', width: "250" },
            { name: 'Market ID', prop: 'marketId', width: "250" },
            { name: 'MRKT Area', prop: 'mrktArea', width: "250" },
            { name: 'SID', prop: 'sid', width: "250" },
            { name: 'Technology', prop: 'technology', width: "250" },
            { name: 'Frequency1', prop: 'frequency1', width: "250" },
            { name: 'Frequency2', prop: 'frequency2', width: "250" },
            { name: 'BTA MKT Number', prop: 'btaMktNumber', width: "250" },
            { name: 'BTA MKT Name', prop: 'btaMktName', width: "250" },
            { name: 'GSM Tech', prop: 'gsmTech', width: "250" },
            { name: 'CDMA Tech', prop: 'cdmaTech', width: "250" },
            { name: 'TDMA Tech', prop: 'tdmaTech', width: "250" },
            { name: 'MNC', prop: 'mnc', width: "250" },
        ];
        this.showMssg = false;
    }

    //Used to Download Template
    exportToCSV() {
        this.exportToCsvService.downloadFile([], this.EXPORT_FILE_NAME, this.exportColumns);
    }

    saveUploadDialog() {
        if (document.getElementsByClassName("tableError") && document.getElementsByClassName("tableError").length > 0) {
            this.toasterService.showErrorMessage("Please fix validation errors.");
            return;
        }
        for(let i=0;i<this.uploadedMainData.length;i++){
            delete this.uploadedMainData[i]['NPA'];
            delete this.uploadedMainData[i]['NXX'];
            delete this.uploadedMainData[i]['Carrier ID'];
            delete this.uploadedMainData[i]['Carrier Name'];
            delete this.uploadedMainData[i]['Lead Time'];
            delete this.uploadedMainData[i]['Target Level'];
            delete this.uploadedMainData[i]['Rate Center'];
            delete this.uploadedMainData[i]['State'];
            delete this.uploadedMainData[i]['Carrier ID Description'];
            delete this.uploadedMainData[i]['Zone'];
            delete this.uploadedMainData[i]['County'];
            delete this.uploadedMainData[i]['Market ID'];
            delete this.uploadedMainData[i]['MRKT Area'];
            delete this.uploadedMainData[i]['SID'];
            delete this.uploadedMainData[i]['Technology'];
            delete this.uploadedMainData[i]['Frequency1'];
            delete this.uploadedMainData[i]['Frequency2'];
            delete this.uploadedMainData[i]['BTA MKT Number'];
            delete this.uploadedMainData[i]['BTA MKT Name'];
            delete this.uploadedMainData[i]['GSM Tech'];
            delete this.uploadedMainData[i]['CDMA Tech'];
            delete this.uploadedMainData[i]['TDMA Tech'];
            delete this.uploadedMainData[i]['MNC'];
        }
        let uploadData = [];
        
        uploadData = this.uploadedMainData.filter((v,i,a)=>a.findIndex(t=>
            (t.npa == v.npa && t.nxx == v.nxx && t.carrierId == v.carrierId && t.rateCenter == v.rateCenter && t.state == v.state
                && t.zone == v.zone && t.sid == v.sid ))===i)
             
        this.dialogRef.close(uploadData);
    }

    //Read File and show data on the table
    public changeListener(files: FileList) {
        let invalidFile = "Please select a valid file to upload.";
        let noDataInFile = "There is no data to upload in this file.";
        let limitExceed = "You cannot insert more than 500 records at a time.";
        this.alerts = [];
        if (files && files.length > 0) { 
            this.fileContent = true;
            let file: File = files.item(0);
            let name = file.name;
            var ext = name.substring(name.lastIndexOf('.') + 1);
            if (ext.toLowerCase() == 'csv') {
                this.filename = name.substr(0, name.lastIndexOf("."));
                if (this.filename.split(" ")[0] != this.EXPORT_FILE_NAME) {
                    this.toasterService.showErrorMessage(invalidFile);
                    return;
                }
            } else {
                this.toasterService.showErrorMessage(invalidFile);
                return;
            }
            let reader: FileReader = new FileReader();
            reader.readAsText(file);
            reader.onload = (e) => {
                let uploadData = this.importFromCsvService.csvToArray(reader.result);
                if (uploadData.length == 0) {
                    this.toasterService.showErrorMessage(noDataInFile);
                } else if (uploadData.length > 500) {
                    this.toasterService.showErrorMessage(limitExceed);
                } else {
                    let keys = Object.keys(uploadData[0]);
                    for (let i = 1, j = 0; j < this.exportColumns.length; i++, j++) {
                        if (keys[i] != this.exportColumns[j]) {
                            this.toasterService.showErrorMessage(invalidFile);
                            return;
                        }
                    }
                    uploadData.forEach(_e1 => {
                        _e1.npa = _e1['NPA'];
                        _e1.nxx= _e1['NXX'];
                        _e1.carrierId = _e1['Carrier ID'];
                        _e1.carrierName = _e1['Carrier Name'];
                        _e1.leadTime= _e1['Lead Time'];
                        _e1.targetLevel = _e1['Target Level'];
                        _e1.rateCenter  = _e1['Rate Center']; 
                        _e1.state= _e1['State'];
                        _e1.carrierIdDescription = _e1['Carrier ID Description'];
                        _e1.zone = _e1['Zone'];
                        _e1.county  = _e1['County'];
                        _e1.marketId  = _e1['Market ID'];
                        _e1.mrktArea= _e1['MRKT Area'];
                        _e1.sid = _e1['SID'];
                        _e1.technology = _e1['Technology'];
                        _e1.frequency1= _e1['Frequency1'];
                        _e1.frequency2 = _e1['Frequency2'];
                        _e1.btaMktNumber= _e1['BTA MKT Number'];
                        _e1.btaMktName = _e1['BTA MKT Name'];
                        _e1.gsmTech = _e1['GSM Tech'];
                        _e1.cdmaTech= _e1['CDMA Tech'];
                        _e1.tdmaTech= _e1['TDMA Tech'];
                        _e1.mnc= _e1['MNC'];
                    });
                    this.uploadedData = [...this.checkUploadedData(uploadData)];
                }
            }
        }
    }

    //Removes file and table from the screen
    public removeFile() {
        this.fileContent = false;
        this.filename = null;
        this.uploadedData = [];
        this.uploadedMainData = [];
        this.alerts = [];
    }

    public checkUploadedData(data) {
        let errorData = [];
        let successData = [];
        data.forEach(element => {
            element.rowNum = element['S.NO'];
        });
        data.forEach(element => {
            if (element.rowNum.length == 0 || element["NPA"].length == 0 || element["NXX"].length == 0 || element["Carrier ID"].length == 0|| element["Rate Center"].length == 0 
            || element["State"].length == 0 || element["Zone"].length == 0|| element["SID"].length == 0
            || element["NPA"].length > 5 || element["NXX"].length > 5 || element["Carrier ID"].length > 126|| element["Carrier Name"].length > 255 
            || element["Lead Time"].length > 126 || element["Target Level"].length > 126
            || element["Rate Center"].length > 15 || element["State"].length > 4 || element["Carrier ID Description"].length > 255|| element["Zone"].length > 100 
            || element["County"].length > 50 || element["Market ID"].length > 126 || element["MRKT Area"].length > 33|| element["SID"].length > 10
            || element["Frequency1"].length > 38 || element["Frequency2"].length > 38
            || element["Technology"].length > 20|| element["BTA MKT Number"].length > 4 
             || element["BTA MKT Name"].length > 100 || element["GSM Tech"].length > 20 || element["CDMA Tech"].length > 20|| element["TDMA Tech"].length > 20 || element["MNC"].length > 5 ) {
                errorData.push(element);
            } else
            successData.push(element);
        });
        this.uploadedMainData = [...errorData, ...successData];
        return this.uploadedMainData;
    }

    //Removes Row from the table
    deleteRow(row) {
        this.uploadedMainData.forEach((data, key) => {
            if (row.rowNum == data.rowNum) {
                this.uploadedMainData.splice(key, 1);
            }
        });
        this.uploadedData = [...this.uploadedMainData];
    }

    //inline values changes
    public editValueChanged(event, column, row, oldValue) {
        for (let i = 0; i < this.uploadedMainData.length; i++) {
            if (this.uploadedMainData[i].rowNum == row.rowNum) {
                this.uploadedMainData[i][column] = event.target.value;
            }
        }
        this.uploadedData = [...this.uploadedMainData];
    }

    //Filter for result table
    public filterTableData(event) {
        const val = event.target.value.toLowerCase();
        // filter our data
        const temp = this.uploadedMainData.filter(function (d) {
            return (d.npa ? d.npa.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.nxx ? d.nxx.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.carrierId ? d.carrierId.indexOf(val) !== -1 : !val)
            || (d.carrierName ? d.carrierName.indexOf(val) !== -1 : !val)
            || (d.leadTime ? d.leadTime.indexOf(val) !== -1 : !val)
            || (d.targetLevel ? d.targetLevel.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.rateCenter ? d.rateCenter.indexOf(val) !== -1 : !val)
            || (d.state ? d.state.indexOf(val) !== -1 : !val)
            || (d.carrierIdDescription ? d.carrierIdDescription.indexOf(val) !== -1 : !val)
            || (d.zone ? d.zone.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.county ? d.county.indexOf(val) !== -1 : !val)
            || (d.marketId ? d.marketId.indexOf(val) !== -1 : !val)
            || (d.mrktArea ? d.mrktArea.indexOf(val) !== -1 : !val)
            || (d.sid ? d.sid.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.technology ? d.technology.indexOf(val) !== -1 : !val)
            || (d.frequency1 ? d.frequency1.indexOf(val) !== -1 : !val)
            || (d.frequency2 ? d.frequency2.indexOf(val) !== -1 : !val)
            || (d.btaMktNumber ? d.btaMktNumber.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.btaMktName ? d.btaMktName.indexOf(val) !== -1 : !val)
            || (d.gsmTech ? d.gsmTech.indexOf(val) !== -1 : !val)
            || (d.cdmaTech ? d.cdmaTech.indexOf(val) !== -1 : !val)
            || (d.tdmaTech ? d.tdmaTech.indexOf(val) !== -1 : !val)
            || (d.mnc ? d.mnc.indexOf(val) !== -1 : !val)
        });
        // update the rows
        this.uploadedData = temp;
    }

    cancelUploadDialog(): void {
        this.dialogRef.close();
    }

}