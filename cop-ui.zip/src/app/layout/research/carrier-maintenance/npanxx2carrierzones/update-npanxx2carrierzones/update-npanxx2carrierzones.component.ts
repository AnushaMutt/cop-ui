import { Component, OnInit, ViewEncapsulation, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ConfirmationService } from 'primeng/primeng';
import { takeUntil } from 'rxjs/operators';
import { Subject } from "rxjs";
import { CarrierMaintenanceService } from '../../../../../Services/carrierMaintenance.service';
import { CarrierMaintenanceHelper } from "../../carrier-maintenance-helper";
import { ToasterService } from "../../../../../Services/toaster.service";
import { Npanxx2CarrierZonesHelper } from "../npanxx2carrierzones-helper";
import { Npanxx2CarrierZonesService } from "../npanxx2carrierzones-service";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { ExportToCsvService } from "../../../../../Services/export-to-csv.service";
import { BulkDeleteNpaNxx2CarrrierZonesComponent } from "../bulk-delete-npanxx2-carrier-zones/bulk-delete-npanxx2-carrier-zones.component";
import { MatDialog } from "@angular/material";


@Component({
    selector: 'update-npanxx2carrierzones',
    templateUrl: './update-npanxx2carrierzones.component.html',
    styleUrls: ['./update-npanxx2carrierzones.component.scss',
        "../../../../components/ngxtable/material.scss",
        "../../../../components/ngxtable/datatable.component.scss",
        "../../../../components/ngxtable/icons.css",
        "../../../../components/ngxtable/app.css"],
    animations: [],
    encapsulation: ViewEncapsulation.None,
})

export class UpdateNpanxx2CarrierZonesComponent implements OnInit {
    private unsubscribe = new Subject<void>();
    public frmNpanxx2CarrierZones: FormGroup;
    public showLoadingScreen: boolean;
    public tableRows: any = [];
    public tableRowsMainData: any = [];
    isEditable = {};
    private editedRow: any = {};
    private defaultEditedRow: any = {};
    public tableColumns: any = [];
    public alreadyEnabled = true;
    public showNoRecordsFoundMessage: Boolean = true;
    public filteredValues: any = {};
    public selected: any = [];
    public multiColumnEditSection = false;
    public filteredRows: any;
    public tableFrmGroupMain: FormGroup;
    public showBulkUpdateButton = false;
    public selectedNpanxx2CarrierZones = [];
    public bulkEditBoolean: boolean;
    public otherColumn: boolean = false;
    public editAlreadyEnabled = false;
    public checkDuplicate = false;
    public bulkEditColumns = [];
    @ViewChild('multicolumnEditValue') multicolumnEditValue: any;
    public searchColumns: any = [];
    public searchColumnsMaindata = [];
    public selectedFields = [];
    public showOptionalFields = false;
    PAGINATION_AMOUNT = 200;
    public paginationStart: number;
    public paginationEnd: number;
    public paginationCount: number;
    public paginationOffSet: number;
    public pageindex: any = 1;
    public lastTransactionRequest: any = {};

    constructor(
        private formBuilder: FormBuilder,
        private wizardService: CarrierMaintenanceService,
        private npanxx2CarrierZonesHelper: Npanxx2CarrierZonesHelper,
        private toasterService: ToasterService,
        private wizardHelper: CarrierMaintenanceHelper,
        private confirmationService: ConfirmationService,
        private npanxx2CarrierZonesService: Npanxx2CarrierZonesService,
        private modalService: NgbModal,
        private exportToCsvService :ExportToCsvService,
        public dialog: MatDialog
    ) { }


    ngOnInit() {
        this.selectedFields = [];
        this.showOptionalFields = false;
        this.paginationOffSet = this.PAGINATION_AMOUNT;
        this.paginationEnd = this.PAGINATION_AMOUNT;
        this.paginationStart = 0;
        this.createForm();
        this.createTableForm();
        this.tableColumns = [
            { name: 'NPA', prop: 'npa', width: "250" },
            { name: 'NXX', prop: 'nxx', width: "250" },
            { name: 'Carrier ID', prop: 'carrierId', width: "250" },
            { name: 'Carrier Name', prop: 'carrierName', width: "250" },
            { name: 'Lead Time', prop: 'leadTime', width: "250" },
            { name: 'Target Level', prop: 'targetLevel', width: "250" },
            { name: 'Rate Center', prop: 'rateCenter', width: "250" },
            { name: 'State', prop: 'state', width: "250" },
            { name: 'Carrier ID Description', prop: 'carrierIdDescription', width: "250" },
            { name: 'Zone', prop: 'zone', width: "250" },
            { name: 'County', prop: 'county', width: "250" },
            { name: 'Market ID', prop: 'marketId', width: "250" },
            { name: 'MRKT Area', prop: 'mrktArea', width: "250" },
            { name: 'SID', prop: 'sid', width: "250" },
            { name: 'Technology', prop: 'technology', width: "250" },
            { name: 'Frequency1', prop: 'frequency1', width: "250" },
            { name: 'Frequency2', prop: 'frequency2', width: "250" },
            { name: 'BTA MKT Number', prop: 'btaMktNumber', width: "250" },
            { name: 'BTA MKT Name', prop: 'btaMktName', width: "250" },
            { name: 'GSM Tech', prop: 'gsmTech', width: "250" },
            { name: 'CDMA Tech', prop: 'cdmaTech', width: "250" },
            { name: 'TDMA Tech', prop: 'tdmaTech', width: "250" },
            { name: 'MNC', prop: 'mnc', width: "250" },
        ];
        this.searchColumns = [
            { name: 'NXX', prop: 'nxx', width: "250" },
            { name: 'Carrier Name', prop: 'carrierName', width: "250" },
            { name: 'Lead Time', prop: 'leadTime', width: "250" },
            { name: 'Target Level', prop: 'targetLevel', width: "250" },
            { name: 'Rate Center', prop: 'rateCenter', width: "250" },
            { name: 'State', prop: 'state', width: "250" },
            { name: 'Carrier ID Description', prop: 'carrierIdDescription', width: "250" },
            { name: 'Zone', prop: 'zone', width: "250" },
            { name: 'County', prop: 'county', width: "250" },
            { name: 'Market ID', prop: 'marketId', width: "250" },
            { name: 'MRKT Area', prop: 'mrktArea', width: "250" },
            { name: 'SID', prop: 'sid', width: "250" },
            { name: 'Technology', prop: 'technology', width: "250" },
            { name: 'Frequency1', prop: 'frequency1', width: "250" },
            { name: 'Frequency2', prop: 'frequency2', width: "250" },
            { name: 'BTA MKT Number', prop: 'btaMktNumber', width: "250" },
            { name: 'BTA MKT Name', prop: 'btaMktName', width: "250" },
            { name: 'GSM Tech', prop: 'gsmTech', width: "250" },
            { name: 'CDMA Tech', prop: 'cdmaTech', width: "250" },
            { name: 'TDMA Tech', prop: 'tdmaTech', width: "250" },
            { name: 'MNC', prop: 'mnc', width: "250" },

        ];
        this.searchColumnsMaindata = [...this.searchColumns];
        this.bulkEditColumns = [...this.tableColumns];
        this.filteredValues = {};
        this.multiColumnEditSection = false;
        this.showBulkUpdateButton = false
    }

    //to create form
    private createForm() {
        this.frmNpanxx2CarrierZones = this.formBuilder.group({
            npa: ['', [ Validators.maxLength(5)]],
                nxx: ['', [ Validators.maxLength(5)]],
                carrierId: ['', [Validators.maxLength(126),Validators.pattern("^([0-9]*[.])?[0-9]+")]],
                carrierName: ['', [Validators.maxLength(255)]],
                leadTime: ['', [Validators.maxLength(126),Validators.pattern("^([0-9]*[.])?[0-9]+")]],
                targetLevel: ['', [Validators.maxLength(126),Validators.pattern("^([0-9]*[.])?[0-9]+")]],
                rateCenter: ['', [ Validators.maxLength(15)]],
                state: ['', [ Validators.maxLength(4)]],
                carrierIdDescription: ['', [Validators.maxLength(255)]],
                zone: ['', [ Validators.maxLength(100)]],
                county: ['', [Validators.maxLength(50)]],
                marketId: ['',[Validators.maxLength(126),Validators.pattern("^([0-9]*[.])?[0-9]+")]],
                mrktArea: ['', [Validators.maxLength(33)]],
                sid: ['', [ Validators.maxLength(10)]],
                technology: ['', [Validators.maxLength(20)]],
                frequency1: ['', [Validators.pattern("^[0-9\n,]*$"),Validators.maxLength(38)]],
                frequency2: ['', [Validators.pattern("^[0-9\n,]*$"),Validators.maxLength(38)]],
                btaMktNumber: ['', [Validators.maxLength(4)]],
                btaMktName: ['', [Validators.maxLength(100)]],
                gsmTech: ['', [Validators.maxLength(20)]],
                cdmaTech: ['', [Validators.maxLength(20)]],
                tdmaTech: ['', [ Validators.maxLength(20)]],
                mnc: ['', [Validators.maxLength(5)]],
        })
    }

    //form for column level filter
    public createTableForm() {
        this.tableFrmGroupMain = this.formBuilder.group({
            npa: [''],
            nxx: [''],
            carrierId: [''],
            carrierName: [''],
            leadTime: [''],
            targetLevel: [''],
            rateCenter: [''],
            state: [''],
            carrierIdDescription: [''],
            zone: [''],
            county: [''],
            marketId: [''],
            mrktArea: [''],
            sid: [''],
            technology: [''],
            frequency1: [''],
            frequency2: [''],
            btaMktNumber: [''],
            btaMktName: [''],
            gsmTech: [''],
            cdmaTech: [''],
            tdmaTech: [''],
            mnc: [''],
        });
    }

    // reset the form
    revert() {
        this.pageindex = 1;
        this.PAGINATION_AMOUNT = 200;
        this.frmNpanxx2CarrierZones.reset();
        this.tableRows = [];
        this.tableRowsMainData = [];
        this.filteredValues = {};
        let filterKeys = Object.keys(this.tableFrmGroupMain.controls);
        filterKeys.forEach(_e1 => {
            this.tableFrmGroupMain.controls[`${_e1}`].patchValue([]);
        });
        this.selectedNpanxx2CarrierZones = [];
        this.alreadyEnabled = true;
        this.showBulkUpdateButton = false;
        this.selected = [];
        this.otherColumn = false;
        this.lastTransactionRequest = {};
    }

    // search NPANXX2 Carrier Zones
    public searchForm() {
        this.tableRowsMainData = [];
        this.tableRows = [];
        this.pageindex = 1;
        this.showLoadingScreen = true;
        let obj = this.frmNpanxx2CarrierZones.value;
        this.editedRow = {};
        this.defaultEditedRow = {};
        this.isEditable = {};
        this.selectedNpanxx2CarrierZones = [];
        this.selected = [];
        this.showBulkUpdateButton = false;
        this.otherColumn = false;
        this.checkDuplicate = false;
        this.npanxx2CarrierZonesService.setSearchData([]);
        let filterKeys = Object.keys(this.tableFrmGroupMain.controls);
        filterKeys.forEach(_e1 => {
            this.tableFrmGroupMain.controls[`${_e1}`].patchValue([]);
        });
        this.filteredValues = {};
        this.alreadyEnabled = true;
        obj = this.wizardHelper.checkRequestObject(obj);
        obj.dbEnv = this.wizardHelper.dbEnv;
        obj.paginationSearch = this.createPaginationRequest(0, 200);
        this.lastTransactionRequest = obj;
        this.paginationStart = 0;
        this.paginationOffSet = this.PAGINATION_AMOUNT;
        this.fireSubmitMethod(obj);
    }

public fireSubmitMethod(obj){
    this.showLoadingScreen = true;
    this.wizardService.searchNpanxx2CarrierZones(obj).pipe(takeUntil(this.unsubscribe))
    .subscribe(
        (data: any) => {
            if (data[0] === null || data[0] === undefined) {
                this.showLoadingScreen = false;
                this.toasterService.showErrorMessage(
                    this.npanxx2CarrierZonesHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_NPANXX2CARRIERZONES_ERROR_MESSAGE")
                );
                return;
            }
            if (data[0] && data[0].ERR) {
                this.showLoadingScreen = false;
                const commaSeperatedArr = data[0].ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
                return;
            }

            let response = data[0];
            let fullObject = [];
            this.npanxx2CarrierZonesService.setSearchData([]);
            if (!this.npanxx2CarrierZonesService.getSearchData() || (this.npanxx2CarrierZonesService.getSearchData() && this.npanxx2CarrierZonesService.getSearchData().length == 0)) {
                response.npanxx2Carrierzones.forEach(e1 => {
                    fullObject.push(e1)
                });
            } else if (this.npanxx2CarrierZonesService.getSearchData().length > 0) {
                fullObject = this.npanxx2CarrierZonesService.getSearchData();
                response.npanxx2Carrierzones.forEach(e1 => {
                    fullObject.push(e1)
                });
            }
            this.npanxx2CarrierZonesService.setSearchData(fullObject);
            this.tableRowsMainData = [];
            this.tableRows = [];
            for (let i = 0; i < this.npanxx2CarrierZonesService.getSearchData().length; i++) {
                this.tableRowsMainData.push(this.npanxx2CarrierZonesService.getSearchData()[i]);
            }
            let rowId = 1;
            this.tableRowsMainData.forEach(element => {
                element.rowId = rowId;
                rowId++;
            });

            this.tableRows = [...this.tableRowsMainData];
            let pag = data[0].paginationSearch;
            this.paginationCount = pag.total;
            this.showLoadingScreen = false;
            if (data[0].npanxx2Carrierzones && data[0].npanxx2Carrierzones.length == 0 && this.showNoRecordsFoundMessage)
                this.toasterService.showErrorMessage(
                    this.npanxx2CarrierZonesHelper.getTracfoneConstantMethod("TRACFONE_SEARCH_NPANXX2CARRIERZONES_ERROR_MESSAGE")
                );

            this.generateFilters();
            this.filterReportResults();
            this.multiColumnEditSection = false;
            this.showNoRecordsFoundMessage = true;
            if (this.filteredValues && this.filteredValues.mainTableFilter) {
                this.updateSummaryTable(this.filteredValues.mainTableFilter);
            }
        },
        (err: any) => {
            this.showLoadingScreen = false;
            if (err.error === undefined || err.error === null)
                this.toasterService.showErrorMessage(
                    this.npanxx2CarrierZonesHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                );
            else if (err.error && err.error.ERR) {
                const commaSeperatedArr = err.error.ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
            }
            else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                return;
            else this.toasterService.showErrorMessage(err.error);
        }
    );

}

    // to filter columns
    public filterReportResults(): void {
        const filterFormObject = this.tableFrmGroupMain.value;
        this.filteredValues.npa = filterFormObject.npa;
        this.filteredValues.nxx = filterFormObject.nxx;
        this.filteredValues.carrierId = filterFormObject.carrierId;
        this.filteredValues.carrierName = filterFormObject.carrierName;
        this.filteredValues.leadTime = filterFormObject.leadTime;
        this.filteredValues.targetLevel = filterFormObject.targetLevel;
        this.filteredValues.rateCenter = filterFormObject.rateCenter;
        this.filteredValues.state = filterFormObject.state;
        this.filteredValues.carrierIdDescription = filterFormObject.carrierIdDescription;
        this.filteredValues.zone = filterFormObject.zone;
        this.filteredValues.county = filterFormObject.county;
        this.filteredValues.marketId = filterFormObject.marketId;
        this.filteredValues.mrktArea = filterFormObject.mrktArea;
        this.filteredValues.sid = filterFormObject.sid;
        this.filteredValues.technology = filterFormObject.technology;
        this.filteredValues.frequency1 = filterFormObject.frequency1;
        this.filteredValues.frequency2 = filterFormObject.frequency2;
        this.filteredValues.btaMktNumber = filterFormObject.btaMktNumber;
        this.filteredValues.btaMktName = filterFormObject.btaMktName;
        this.filteredValues.gsmTech = filterFormObject.gsmTech;
        this.filteredValues.cdmaTech = filterFormObject.cdmaTech;
        this.filteredValues.tdmaTech = filterFormObject.tdmaTech;
        this.filteredValues.mnc = filterFormObject.mnc;
        const newRows = Object.keys(filterFormObject).reduce((acc, key) => {
            if (!filterFormObject[key].length) return acc;
            const filteredRows = acc.filter(val => filterFormObject[key].indexOf(val[key]) > -1);
            return filteredRows;
        }, this.tableRowsMainData);

        this.tableRows = newRows;
    }

    public generateFilters(): void {
        this.filteredRows = Object.keys(this.tableColumns)
            .map(i => this.tableColumns[i].prop)
            .reduce((filterObject, columnName) => {
                const uniqueValuesPerRow = this.tableRows.reduce((set, row) => set.add(row[columnName]), new Set());
                let val: any = Array.from(uniqueValuesPerRow);
                if (/^[0-9]*$/.test(val[0])) {
                    filterObject[columnName] = val.sort(function (a, b) { return a - b });
                } else {
                    filterObject[columnName] = val.sort((a, b) => {
                        a = a || '';
                        b = b || '';
                        return a.localeCompare(b);
                    });
                }
                return filterObject;
            }, {});
    }

    public onSelect(row) {
        this.multiColumnEditSection = true;
        this.selectedNpanxx2CarrierZones = [];
        if (row && row.selected) {
            for (let i = 0; i < row.selected.length; i++) {
                let obj = { ...row.selected[i] };
                this.selectedNpanxx2CarrierZones.push(obj);
            }
        }
        this.selectedNpanxx2CarrierZones = [...this.selectedNpanxx2CarrierZones]
        if (this.selectedNpanxx2CarrierZones.length == 0) {
            this.bulkEditBoolean = false;
            this.otherColumn = false;
            this.showBulkUpdateButton = false;
        }
    }
    public editButtonClicked(rowData, rowIndex) {
        this.alreadyEnabled = false;
        this.defaultEditedRow = { ...rowData }
        for (let i = 0; i < this.tableRowsMainData.length; i++) {
            if (this.isEditable[i])
                this.alreadyEnabled = true;
        }
        if (!this.alreadyEnabled)
            this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        else {
            this.alreadyEnabled = false;
            this.toasterService.showErrorMessage(
                this.npanxx2CarrierZonesHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE")
            );
        }
    }
    private inputValueChanged(event, column, row, oldValue) {
        this.editedRow[column] = event.target.value;
        this.defaultEditedRow[column] = event.target.defaultValue;

    }

    //to update Npanxx2 Carrier Zones
    public updateNpanxx2CarrierZones(editData, rowIndex) {
        if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
            this.toasterService.showErrorMessage(
                this.npanxx2CarrierZonesHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            return;
        }
        this.showLoadingScreen = true;
        let obj = { ...editData, ...this.editedRow }

        obj = this.wizardHelper.checkRequestObject(obj);
        obj.dbEnv = this.wizardHelper.dbEnv;
        obj.oldNpa = this.defaultEditedRow.npa;
        obj.oldNxx = this.defaultEditedRow.nxx;
        obj.oldCarrierId = this.defaultEditedRow.carrierId;
        obj.oldRateCenter = this.defaultEditedRow.rateCenter;
        obj.oldState = this.defaultEditedRow.state;
        obj.oldZone = this.defaultEditedRow.zone;
        obj.oldSid = this.defaultEditedRow.sid;
        if (obj.npa != this.defaultEditedRow.npa || obj.nxx != this.defaultEditedRow.nxx || obj.carrierId != this.defaultEditedRow.carrierId || obj.rateCenter != this.defaultEditedRow.rateCenter
            || obj.state != this.defaultEditedRow.state || obj.zone != this.defaultEditedRow.zone || obj.sid != this.defaultEditedRow.sid) {
            this.checkDuplicate = true;
        } else {
            this.checkDuplicate = false;
        }
        obj.checkDuplicate = this.checkDuplicate;
        delete obj.rowId;
        this.wizardService.updateNpanxx2CarrierZones(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.npanxx2CarrierZonesHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_NPANXX2CARRIERZONES_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    for (let i = 0; i < this.tableRowsMainData.length; i++) {
                        if (this.tableRowsMainData[i].rowId == this.defaultEditedRow.rowId) {
                            this.tableRowsMainData[i] = obj;
                        }
                    }
                    this.isEditable[rowIndex] = !this.isEditable[rowIndex];
                    this.showLoadingScreen = false;
                    this.alreadyEnabled = true;
                    this.editedRow = {};
                    this.defaultEditedRow = {};
                    this.tableRows = [...this.tableRowsMainData];
                    this.checkDuplicate = false;

                    this.toasterService.showSuccessMessage(
                        this.npanxx2CarrierZonesHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_NPANXX2CARRIERZONES_SUCCESS_MESSAGE")
                    );

                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.npanxx2CarrierZonesHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    //to cancel update
    private cancelEditForm(rowData, rowIndex) {
        this.showLoadingScreen = true;
        this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        this.tableColumns.forEach(e1 => {
            if (document.getElementById(e1.prop + rowIndex)) {
                (<HTMLInputElement>(
                    document.getElementById(e1.prop + rowIndex)
                )).value = rowData[e1.prop] || '';
            }
        });

        this.editedRow = {};
        this.defaultEditedRow = {};
        this.showLoadingScreen = false;
        this.checkDuplicate = false;
        this.alreadyEnabled = true;
    }

    //to filter table
    private updateSummaryTable(event) {
        let val: any;
        if (event.target)
            val = event.target.value.toLowerCase();
        else
            val = event.toLowerCase();

        const temp = this.tableRowsMainData.filter(function (d) {
            return (d.npa ? d.npa.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.nxx ? d.nxx.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.carrierId ? d.carrierId.indexOf(val) !== -1 : !val)
                || (d.carrierName ? d.carrierName.indexOf(val) !== -1 : !val)
                || (d.leadTime ? d.leadTime.indexOf(val) !== -1 : !val)
                || (d.targetLevel ? d.targetLevel.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.rateCenter ? d.rateCenter.indexOf(val) !== -1 : !val)
                || (d.state ? d.state.indexOf(val) !== -1 : !val)
                || (d.carrierIdDescription ? d.carrierIdDescription.indexOf(val) !== -1 : !val)
                || (d.zone ? d.zone.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.county ? d.county.indexOf(val) !== -1 : !val)
                || (d.marketId ? d.marketId.indexOf(val) !== -1 : !val)
                || (d.mrktArea ? d.mrktArea.indexOf(val) !== -1 : !val)
                || (d.sid ? d.sid.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.technology ? d.technology.indexOf(val) !== -1 : !val)
                || (d.frequency1 ? d.frequency1.indexOf(val) !== -1 : !val)
                || (d.frequency2 ? d.frequency2.indexOf(val) !== -1 : !val)
                || (d.btaMktNumber ? d.btaMktNumber.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.btaMktName ? d.btaMktName.indexOf(val) !== -1 : !val)
                || (d.gsmTech ? d.gsmTech.indexOf(val) !== -1 : !val)
                || (d.cdmaTech ? d.cdmaTech.indexOf(val) !== -1 : !val)
                || (d.tdmaTech ? d.tdmaTech.indexOf(val) !== -1 : !val)
                || (d.mnc ? d.mnc.indexOf(val) !== -1 : !val)
        });
        this.tableRows = temp;
    }

    // delete confirm
    public showConfirm(esnData, rowIndex) {
        this.confirmationService.confirm({
            key: 'confirm-delete-cmi',
            message: "Are you sure you want to delete NPANXX2 Carrier Zones ?",
            accept: () => {
                this.deleteNpanxx2CarrierZones(esnData, rowIndex)
            }
        });
    }

    // to delete Npanxx2 Carrier Zones
    public deleteNpanxx2CarrierZones(esnData, rowIndex) {
        this.showLoadingScreen = true;
        let obj: any = {};
        obj = esnData
        obj.dbEnv = this.wizardHelper.dbEnv;
        delete obj.rowId;
        this.wizardService.deleteNpanxx2CarrierZones(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.npanxx2CarrierZonesHelper.getTracfoneConstantMethod("TRACFONE_DELETE_NPANXX2CARRIERZONES_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    this.toasterService.showSuccessMessage(
                        this.npanxx2CarrierZonesHelper.getTracfoneConstantMethod("TRACFONE_DELETE_NPANXX2CARRIERZONES_SUCCESS_MESSAGE")
                    );
                    this.showNoRecordsFoundMessage = false;
                    this.searchForm();
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.npanxx2CarrierZonesHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    public assignmultiColumnName(column) {
        this.showBulkUpdateButton = false;
        this.otherColumn = true;
    }

    public showBulkUpdateButtonFun(event) {
        if (event)
            this.showBulkUpdateButton = true;
        else
            this.showBulkUpdateButton = false;
    }

    bulkUpdateColumn(column) {
        if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
            this.toasterService.showErrorMessage(
                this.npanxx2CarrierZonesHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            return;
        }
        this.showLoadingScreen = true;
        let requestObj = [];
        this.selectedNpanxx2CarrierZones.forEach(e => {
            let obj: any = {};
            obj.checkDuplicate = false;
            if (column == "NPA") {
                obj.npa = this.multicolumnEditValue.nativeElement.value;
                obj.checkDuplicate= true
            } else {
                obj.npa = e.npa;
            }
            if (column == "NXX") {
                obj.nxx = this.multicolumnEditValue.nativeElement.value;
                obj.checkDuplicate= true
            } else {
                obj.nxx = e.nxx;
            }
            if (column == "Carrier ID") {
                obj.carrierId = this.multicolumnEditValue.nativeElement.value;
                obj.checkDuplicate= true
            } else {
                obj.carrierId = e.carrierId;
            }
            if (column == "Carrier Name") {
                obj.carrierName = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.carrierName = e.carrierName;
            }
            if (column == "Lead Time") {
                obj.leadTime = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.leadTime = e.leadTime;

            }
            if (column == "Target Level") {
                obj.targetLevel = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.targetLevel = e.targetLevel;

            }
            if (column == "Rate Center") {
                obj.rateCenter = this.multicolumnEditValue.nativeElement.value;
                obj.checkDuplicate= true
            } else {
                obj.rateCenter = e.rateCenter;

            }
            if (column == "State") {
                obj.state = this.multicolumnEditValue.nativeElement.value;
                obj.checkDuplicate= true
            } else {
                obj.state = e.state;

            }
            if (column == "Carrier ID Description") {
                obj.carrierIdDescription = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.carrierIdDescription = e.carrierIdDescription;

            }
            if (column == "Zone") {
                obj.zone = this.multicolumnEditValue.nativeElement.value;
                obj.checkDuplicate= true
            } else {
                obj.zone = e.zone;

            }
            if (column == "County") {
                obj.county = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.county = e.county;

            }
            if (column == "Market ID") {
                obj.marketId = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.marketId = e.marketId;

            }
            if (column == "MRKT Area") {
                obj.mrktArea = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.mrktArea = e.mrktArea;

            }
            if (column == "SID") {
                obj.sid = this.multicolumnEditValue.nativeElement.value;
                obj.checkDuplicate= true
            } else {
                obj.sid = e.sid;

            }
            if (column == "Technology") {
                obj.technology = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.technology = e.technology;

            }
            if (column == "Frequency1") {
                obj.frequency1 = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.frequency1 = e.frequency1;

            }
            if (column == "Frequency2") {
                obj.frequency2 = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.frequency2 = e.frequency2;

            }
            if (column == "BTA MKT Number") {
                obj.btaMktNumber = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.btaMktNumber = e.btaMktNumber;

            }
            if (column == "BTA MKT Name") {
                obj.btaMktName = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.btaMktName = e.btaMktName;

            }
            if (column == "GSM Tech") {
                obj.gsmTech = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.gsmTech = e.gsmTech;

            }
            if (column == "CDMA Tech") {
                obj.cdmaTech = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.cdmaTech = e.cdmaTech;

            }
            if (column == "TDMA Tech") {
                obj.tdmaTech = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.tdmaTech = e.tdmaTech;

            }
            if (column == "MNC") {
                obj.mnc = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.mnc = e.mnc;

            }
            obj.oldNpa = e.npa;
            obj.oldNxx = e.nxx;
            obj.oldCarrierId = e.carrierId;
            obj.oldRateCenter = e.rateCenter;
            obj.oldState = e.state;
            obj.oldZone = e.zone;
            obj.oldSid = e.sid;
            obj.dbEnv = this.wizardHelper.dbEnv;
            requestObj.push(obj);
        });

        this.bulkUpdateNpanxx2CarrierZones(requestObj);
    }
    public bulkUpdateNpanxx2CarrierZones(request) {
        this.wizardService.bulkUpdateNpanxx2CarrierZones(request).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.npanxx2CarrierZonesHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_NPANXX2CARRIERZONES_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    this.showLoadingScreen = false;
                    this.alreadyEnabled = true;
                    this.editAlreadyEnabled = false;
                    this.bulkEditBoolean = false;
                    this.otherColumn = false;
                    this.showBulkUpdateButton = false;
                    this.selectedNpanxx2CarrierZones = [];
                    this.selected = [];
                    this.editedRow = {};
                    this.defaultEditedRow = {};
                    this.checkDuplicate = false;
                    this.searchForm();

                    this.toasterService.showSuccessMessage(
                        this.npanxx2CarrierZonesHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_NPANXX2CARRIERZONES_SUCCESS_MESSAGE")
                    );

                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.npanxx2CarrierZonesHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                });
    }

    /*opens the available columns popup*/
    openSml(content) {
        this.modalService.open(content, { size: 'lg' });
    }

        /*This method is used for filter in Available columns popup*/
        public updateOptionalColumns(event) {
            const val = event.target.value.toLowerCase();
            // filter our data
            const temp = this.searchColumnsMaindata.filter(function (d) {
                return d.name.toLowerCase().indexOf(val) !== -1 || !val;
            });
            // update the rows
            this.searchColumns = temp;
        }
    
        //reset the selected available columns 
        private resetOptionalFields() {
            this.searchColumns = this.searchColumnsMaindata;
        }

        private onSelectFields({ selected }) {
            this.selectedFields.splice(0, this.selectedFields.length);
            this.selectedFields.push(...selected);
        }

    /**
     * Sends request to retrieve the previous batch of transactions from the search parameter criteria.
     */     
   paginationNextBatch() {
        let viewTransactionPagination: any = {};
        if (this.paginationStart >= this.paginationCount || this.paginationOffSet >= this.paginationCount) {
            this.paginationOffSet = this.paginationCount;
        } else {
            this.paginationStart = this.paginationStart + this.paginationEnd;
            this.paginationOffSet = this.paginationOffSet + this.paginationEnd;
        }
        viewTransactionPagination.startIndex = this.paginationStart;
        viewTransactionPagination.endIndex = this.paginationOffSet;
        this.pageindex = this.pageindex + 1;
        this.lastTransactionRequest.paginationSearch = viewTransactionPagination;
        this.fireSubmitMethod(this.lastTransactionRequest);
    }

    /**
     * Sends request to retrieve the previous batch of transactions from the search parameter criteria.
     */
     paginationPreviousBatch() {
        let viewTransactionPagination: any = {};
        if (this.paginationStart <= 1) {
            this.paginationStart = 1;
            this.paginationOffSet = this.paginationEnd;
        } else {
            this.paginationStart = this.paginationStart - this.paginationEnd;
            this.paginationOffSet = this.paginationOffSet - this.paginationEnd;
        }
        viewTransactionPagination.startIndex = this.paginationStart;
        viewTransactionPagination.endIndex = this.paginationOffSet;
        this.pageindex = this.pageindex - 1;
        this.lastTransactionRequest.paginationSearch = viewTransactionPagination;
        this.fireSubmitMethod(this.lastTransactionRequest);
    }


    private resetPaginationCounters() {
        this.paginationStart = 0;
        this.paginationOffSet = Number(this.PAGINATION_AMOUNT);
    }

    private createPaginationRequest(startIndex, endIndex) {
        this.resetPaginationCounters();
        let viewTransactionPagination: any = {};
        viewTransactionPagination.startIndex = startIndex;
        viewTransactionPagination.endIndex = Number(endIndex);
        this.paginationEnd = Number(endIndex);
        this.paginationOffSet = Number(endIndex);
        return viewTransactionPagination;
    }

     //Used to Download Template
 exportToCSV() {
    let columns = [];
    this.tableColumns.forEach(x=>{
        columns.push(x.prop)            
    })
    this.exportToCsvService.downloadFile(this.selectedNpanxx2CarrierZones, "NpaNxx2CarrierZonesexport", columns);
}

       // to open bulk Delete pop up
       openUploadCSVDialog() {
        const dialogRef = this.dialog.open(BulkDeleteNpaNxx2CarrrierZonesComponent, {
            width: "90%",
            height: "90%",
        });
    }
}