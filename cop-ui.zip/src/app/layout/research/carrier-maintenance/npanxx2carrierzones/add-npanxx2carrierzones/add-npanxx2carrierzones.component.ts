import { Component, OnInit, ViewEncapsulation, ViewChildren, Output, EventEmitter } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { ConfirmationService } from 'primeng/primeng';
import { takeUntil } from 'rxjs/operators';
import { Subject } from "rxjs";
import { CarrierMaintenanceService } from '../../../../../Services/carrierMaintenance.service';
import { CarrierMaintenanceHelper } from "../../carrier-maintenance-helper";
import { ToasterService } from "../../../../../Services/toaster.service";
import { MatDialog } from "@angular/material";
import { Npanxx2CarrierZonesHelper } from "../npanxx2carrierzones-helper";
import { Npanxx2CarrierZonesService } from "../npanxx2carrierzones-service";
import { BulkInsertNpanxx2carrierzonesComponent } from "../bulk-insert-npanxx2carrierzones/bulk-insert-npanxx2carrierzones";

@Component({
    selector: 'add-npanxx2carrierzones',
    templateUrl: './add-npanxx2carrierzones.component.html',
    styleUrls: ['./add-npanxx2carrierzones.component.scss',
        "../../../../components/ngxtable/material.scss",
        "../../../../components/ngxtable/datatable.component.scss",
        "../../../../components/ngxtable/icons.css",
        "../../../../components/ngxtable/app.css"],
    animations: [],
    encapsulation: ViewEncapsulation.None,
})

export class AddNpanxx2CarrierZonesComponent implements OnInit {
    
    @ViewChildren(DatatableComponent)
    table: any;
    private unsubscribe = new Subject<void>();
    public frmNpanxx2CarrierZones: FormGroup;
    public showLoadingScreen: boolean;
    public displayTable = false;
    private checkedAnother = false;
    public tableRows: any = [];
    public tableRowsMainData: any = [];
    isEditable = {};
    private editedRow: any = {};
    private defaultEditedRow: any = {};
    public tableColumns:any = [];
    public alerts = [];
    public bulkInsertData = [];
    public showMssg = false;
    @Output("returnedData") returnedData: any = new EventEmitter();
    public alreadyEnabled = true;
    public filteredRows: any;
    public tableFrmGroupMain: FormGroup;
    public filteredValues: any = {};
    public checkDuplicate = false;
    


    constructor(
        private formBuilder: FormBuilder,
        private wizardService: CarrierMaintenanceService,
        private npanxx2carrierzonesHelper: Npanxx2CarrierZonesHelper,
        private toasterService: ToasterService,
        private wizardHelper: CarrierMaintenanceHelper,
        private confirmationService: ConfirmationService,
        private npanxx2carrierzonesService: Npanxx2CarrierZonesService,
        public dialog: MatDialog,
    ) {
        this.frmNpanxx2CarrierZones = new FormGroup({});
    }

    ngOnInit() { 
        this.createForm();
        this.createTableForm();
        this.tableColumns = [
            { name: 'NPA', prop: 'npa', width: "250" },
            { name: 'NXX', prop: 'nxx', width: "250" },
            { name: 'Carrier ID', prop: 'carrierId', width: "250" },
            { name: 'Carrier Name', prop: 'carrierName', width: "250" },
            { name: 'Lead Time', prop: 'leadTime', width: "250" },
            { name: 'Target Level', prop: 'targetLevel', width: "250" },
            { name: 'Rate Center', prop: 'rateCenter', width: "250" },
            { name: 'State', prop: 'state', width: "250" },
            { name: 'Carrier ID Description', prop: 'carrierIdDescription', width: "250" },
            { name: 'Zone', prop: 'zone', width: "250" },
            { name: 'County', prop: 'county', width: "250" },
            { name: 'Market ID', prop: 'marketId', width: "250" },
            { name: 'MRKT Area', prop: 'mrktArea', width: "250" },
            { name: 'SID', prop: 'sid', width: "250" },
            { name: 'Technology', prop: 'technology', width: "250" },
            { name: 'Frequency1', prop: 'frequency1', width: "250" },
            { name: 'Frequency2', prop: 'frequency2', width: "250" },
            { name: 'BTA MKT Number', prop: 'btaMktNumber', width: "250" },
            { name: 'BTA MKT Name', prop: 'btaMktName', width: "250" },
            { name: 'GSM Tech', prop: 'gsmTech', width: "250" },
            { name: 'CDMA Tech', prop: 'cdmaTech', width: "250" },
            { name: 'TDMA Tech', prop: 'tdmaTech', width: "250" },
            { name: 'MNC', prop: 'mnc', width: "250" },
        ];
        this.showMssg = false;
        this.npanxx2carrierzonesService.setAddData([]);
    }

        //to create form
        private createForm() {
            this.frmNpanxx2CarrierZones = this.formBuilder.group({
                npa: ['', [Validators.required, Validators.maxLength(5)]],
                nxx: ['', [Validators.required, Validators.maxLength(5)]],
                carrierId: ['', [Validators.required,Validators.maxLength(126),Validators.pattern("^([0-9]*[.])?[0-9]+")]],
                carrierName: ['', [Validators.maxLength(255)]],
                leadTime: ['', [Validators.maxLength(126),Validators.pattern("^([0-9]*[.])?[0-9]+")]],
                targetLevel: ['', [Validators.maxLength(126),Validators.pattern("^([0-9]*[.])?[0-9]+")]],
                rateCenter: ['', [Validators.required, Validators.maxLength(15)]],
                state: ['', [Validators.required, Validators.maxLength(4)]],
                carrierIdDescription: ['', [Validators.maxLength(255)]],
                zone: ['', [Validators.required, Validators.maxLength(100)]],
                county: ['', [Validators.maxLength(50)]],
                marketId: ['',[Validators.maxLength(126),Validators.pattern("^([0-9]*[.])?[0-9]+")]],
                mrktArea: ['', [Validators.maxLength(33)]],
                sid: ['', [Validators.required, Validators.maxLength(10)]],
                technology: ['', [Validators.maxLength(20)]],
                frequency1: ['', [Validators.pattern("^[0-9\n,]*$"),Validators.maxLength(38)]],
                frequency2: ['', [Validators.pattern("^[0-9\n,]*$"),Validators.maxLength(38)]],
                btaMktNumber: ['', [Validators.maxLength(4)]],
                btaMktName: ['', [Validators.maxLength(100)]],
                gsmTech: ['', [Validators.maxLength(20)]],
                cdmaTech: ['', [Validators.maxLength(20)]],
                tdmaTech: ['', [ Validators.maxLength(20)]],
                mnc: ['', [Validators.maxLength(5)]],
            })
        }

    //form for column level filter
    public createTableForm() {
        this.tableFrmGroupMain = this.formBuilder.group({
            npa: [''],
            nxx: [''],
            carrierId: [''],
            carrierName: [''],
            leadTime: [''],
            targetLevel: [''],
            rateCenter: [''],
            state: [''],
            carrierIdDescription: [''],
            zone: [''],
            county: [''],
            marketId: [''],
            mrktArea: [''],
            sid: [''],
            technology: [''],
            frequency1: [''],
            frequency2: [''],
            btaMktNumber: [''],
            btaMktName: [''],
            gsmTech: [''],
            cdmaTech: [''],
            tdmaTech: [''],
            mnc: [''],
        });
    }

    //to add Npanxx2 Carrier Zones
    private addNpanxx2CarrierZones(f) {
        this.showLoadingScreen = true;
        this.alreadyEnabled = true;
        let obj = f.value;
        obj = this.wizardHelper.checkRequestObject(obj);
        obj.dbEnv = this.wizardHelper.dbEnv;
        this.wizardService.addNpanxx2CarrierZones(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.npanxx2carrierzonesHelper.getTracfoneConstantMethod("TRACFONE_ADD_NPANXX2CARRIERZONES_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }

                const d = data[0].message;
                if(d==""){
                    this.toasterService.showErrorMessage(
                    this.npanxx2carrierzonesHelper.getTracfoneConstantMethod("TRACFONE_DUPLICATE_NPANXX2CARRIERZONES_ERROR_MESSAGE")
                );
                }else{
                    let fullObject = [];
                    if (!this.npanxx2carrierzonesService.getAddData() || (this.npanxx2carrierzonesService.getAddData() && this.npanxx2carrierzonesService.getAddData().length == 0)) {
                            fullObject.push(obj);
                    } else if (this.npanxx2carrierzonesService.getAddData().length > 0) {
                        fullObject = this.npanxx2carrierzonesService.getAddData();
                        fullObject.forEach((data, key) => {
                            if (data.npa == obj.npa && data.nxx == obj.nxx && data.carrierId == obj.carrierId && data.rateCenter == obj.rateCenter 
                                && data.state == obj.state  && data.zone == obj.zone && data.sid == obj.sid ) { 
                                fullObject.splice(key, 1);
                                fullObject = [...fullObject];
                            }
                        });
                            fullObject.push(obj);
                    }
                    this.npanxx2carrierzonesService.setAddData(fullObject);
                    this.tableRowsMainData = [];
                    this.tableRows = [];
                    for (let i = 0; i < this.npanxx2carrierzonesService.getAddData().length; i++) {
                        this.tableRowsMainData.push(this.npanxx2carrierzonesService.getAddData()[i]);
                    }
                    let rowId = 1;
                    this.tableRowsMainData.forEach(element => {
                        element.rowId = rowId;
                        rowId++;
                    });
                    this.tableRows = [...this.tableRowsMainData];
                    if (this.checkedAnother) {
                        this.displayTable = false;
                    } else {
                        this.displayTable = true;
                    }
                    this.generateFilters();
                    this.filterReportResults();
                    this.frmNpanxx2CarrierZones.reset();
                    this.toasterService.showSuccessMessage(
                        data[0].message
                    );
                }
                this.checkDuplicate = false;
                this.showLoadingScreen = false;
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.npanxx2carrierzonesHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }

    onChangeCheckbox(event) {
        if (event.checked) this.checkedAnother = true;
        else this.checkedAnother = false;
    }

    //show summary confirm
    public showSummaryConfirm(f, index) {
        this.confirmationService.confirm({
            key: 'confirm-add-show-summary',
            message: this.npanxx2carrierzonesHelper.getTracfoneConstantMethod("TRACFONE_DONE_CREATING_NPANXX2CARRIERZONES_CONFIRM_MESSAGE"),
            accept: () => {
                this.displayTable = true;
                this.checkedAnother = false;
            }
        });
    }
    
    // reset the form
    revert() {
        this.frmNpanxx2CarrierZones.reset();
        this.tableRows = [];
        this.tableRowsMainData = [];
        this.filteredValues = {};
        this.alerts = [];
        let filterKeys = Object.keys(this.tableFrmGroupMain.controls);
        filterKeys.forEach(_e1 => {
            this.tableFrmGroupMain.controls[`${_e1}`].patchValue([]);
        });
        this.alreadyEnabled = true;
    }

    public  editButtonClicked(rowData,rowIndex) {
        this.alreadyEnabled = false;
        this.defaultEditedRow = { ...rowData }
        for (let i = 0; i < this.tableRowsMainData.length; i++) {
          if (this.isEditable[i])
            this.alreadyEnabled = true;
        }
        if (!this.alreadyEnabled)
          this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        else{
          this.alreadyEnabled = false;
          this.toasterService.showErrorMessage(
            this.npanxx2carrierzonesHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE")
          );
        }
      }
    
    private inputValueChanged(event, column, row, oldValue) {
            this.editedRow[column] = event.target.value;
            this.defaultEditedRow[column] = event.target.defaultValue;
    
    }
    
    //to update Npanxx2 Carrier Zones
    public updateNpanxx2CarrierZones(editData, rowIndex) {
        if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
            this.toasterService.showErrorMessage(
                this.npanxx2carrierzonesHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            return;
        }
        this.showLoadingScreen = true;
        let obj = { ...editData, ...this.editedRow }

        obj = this.wizardHelper.checkRequestObject(obj);
        obj.dbEnv = this.wizardHelper.dbEnv;
        obj.oldNpa = this.defaultEditedRow.npa;
        obj.oldNxx = this.defaultEditedRow.nxx;
        obj.oldCarrierId = this.defaultEditedRow.carrierId;
        obj.oldRateCenter = this.defaultEditedRow.rateCenter;
        obj.oldState = this.defaultEditedRow.state;
        obj.oldZone = this.defaultEditedRow.zone;
        obj.oldSid = this.defaultEditedRow.sid;
        if (obj.npa != this.defaultEditedRow.npa || obj.nxx != this.defaultEditedRow.nxx || obj.carrierId != this.defaultEditedRow.carrierId || obj.rateCenter != this.defaultEditedRow.rateCenter
            || obj.state != this.defaultEditedRow.state || obj.zone != this.defaultEditedRow.zone || obj.sid != this.defaultEditedRow.sid) {
            this.checkDuplicate = true;
        } else {
            this.checkDuplicate = false;
        }
        obj.checkDuplicate = this.checkDuplicate;
        this.wizardService.updateNpanxx2CarrierZones(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.npanxx2carrierzonesHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_NPANXX2CARRIERZONES_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                for (let i = 0; i < this.tableRowsMainData.length; i++) {
                    if (this.tableRowsMainData[i].rowId == this.defaultEditedRow.rowId) {
                        this.tableRowsMainData[i] = obj;
                    }
                }
                this.isEditable[rowIndex] = !this.isEditable[rowIndex];
                this.showLoadingScreen = false;
                this.editedRow = {};
                this.defaultEditedRow = {};
                this.tableRows = [...this.tableRowsMainData];
                this.alreadyEnabled = true;
                this.generateFilters();
                this.filterReportResults();
    
                this.toasterService.showSuccessMessage(
                    this.npanxx2carrierzonesHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_NPANXX2CARRIERZONES_SUCCESS_MESSAGE")
                );
    
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.npanxx2carrierzonesHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }
    
    //to cancel update
    private cancelEditForm(rowData, rowIndex) {
        this.showLoadingScreen = true;
        this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        this.tableColumns.forEach(e1 => {
            if (document.getElementById(e1.prop + rowIndex)) {
                (<HTMLInputElement>(
                    document.getElementById(e1.prop + rowIndex)
                )).value = rowData[e1.prop] || '';
            }
        });
    
        this.editedRow = {};
        this.defaultEditedRow = {};
        this.showLoadingScreen = false;
        this.alreadyEnabled = true;
    }
    
    //to filter table
    private updateSummaryTable(event) {
        const val = event.target.value.toLowerCase();
    
        const temp = this.tableRowsMainData.filter(function (d) {
            return (d.npa ? d.npa.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.nxx ? d.nxx.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.carrierId ? d.carrierId.indexOf(val) !== -1 : !val)
            || (d.carrierName ? d.carrierName.indexOf(val) !== -1 : !val)
            || (d.leadTime ? d.leadTime.indexOf(val) !== -1 : !val)
            || (d.targetLevel ? d.targetLevel.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.rateCenter ? d.rateCenter.indexOf(val) !== -1 : !val)
            || (d.state ? d.state.indexOf(val) !== -1 : !val)
            || (d.carrierIdDescription ? d.carrierIdDescription.indexOf(val) !== -1 : !val)
            || (d.zone ? d.zone.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.county ? d.county.indexOf(val) !== -1 : !val)
            || (d.marketId ? d.marketId.indexOf(val) !== -1 : !val)
            || (d.mrktArea ? d.mrktArea.indexOf(val) !== -1 : !val)
            || (d.sid ? d.sid.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.technology ? d.technology.indexOf(val) !== -1 : !val)
            || (d.frequency1 ? d.frequency1.indexOf(val) !== -1 : !val)
            || (d.frequency2 ? d.frequency2.indexOf(val) !== -1 : !val)
            || (d.btaMktNumber ? d.btaMktNumber.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.btaMktName ? d.btaMktName.indexOf(val) !== -1 : !val)
            || (d.gsmTech ? d.gsmTech.indexOf(val) !== -1 : !val)
            || (d.cdmaTech ? d.cdmaTech.indexOf(val) !== -1 : !val)
            || (d.tdmaTech ? d.tdmaTech.indexOf(val) !== -1 : !val)
            || (d.mnc ? d.mnc.indexOf(val) !== -1 : !val)
        });
        this.tableRows = temp;
    }


// delete confirm
public showConfirm(cmiData, rowIndex) {
    this.confirmationService.confirm({
      key: 'confirm-delete-cmi',
      message: "Are you sure you want to delete NPANXX2 Carrier Zones ?",
      accept: () => {
        this.deleteNpanxx2CarrierZones(cmiData, rowIndex)
      }
    });
  }

  // to delete Npanxx2 Carrier Zones
  public deleteNpanxx2CarrierZones(cmiData, rowIndex) {
    this.showLoadingScreen = true;
    let obj:any = {};
    obj = cmiData
    obj.dbEnv = this.wizardHelper.dbEnv;
    delete obj.rowId;
    this.wizardService.deleteNpanxx2CarrierZones(obj).pipe(takeUntil(this.unsubscribe))
      .subscribe(
      (data: any) => {
        if (data[0] === null || data[0] === undefined) {
          this.showLoadingScreen = false;
          this.toasterService.showErrorMessage(
            this.npanxx2carrierzonesHelper.getTracfoneConstantMethod("TRACFONE_DELETE_NPANXX2CARRIERZONES_ERROR_MESSAGE")
          );
          return;
        }
        if (data[0] && data[0].ERR) {
          this.showLoadingScreen = false;
          const commaSeperatedArr = data[0].ERR.split(",");
          for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
            if (commaSeperatedArr[i] != "")
              this.toasterService.showErrorMessage(
                commaSeperatedArr[i]
              );
          }
          return;
        }
        this.toasterService.showSuccessMessage(
          this.npanxx2carrierzonesHelper.getTracfoneConstantMethod("TRACFONE_DELETE_NPANXX2CARRIERZONES_SUCCESS_MESSAGE")
        );

        this.tableRows.forEach((rec: any, key) => {
            if (obj.npa == rec.npa && obj.nxx == rec.nxx && obj.carrierId == rec.carrierId && obj.sid == rec.sid &&
                obj.rateCenter == rec.rateCenter && obj.state == rec.state && obj.zone == rec.zone ) {
              this.tableRows.splice(key, 1);
              this.npanxx2carrierzonesService.getAddData().splice(key, 1);
            }
          });
          this.tableRows = [...this.tableRows];
          this.tableRowsMainData = [...this.tableRows];
          if (this.tableRows.length === 0) {
            this.displayTable = false;
            this.checkedAnother = false;
            this.tableRows = [];
            this.revert();
            this.npanxx2carrierzonesService.setAddData([]);
          }
        this.showLoadingScreen = false;
      },
      (err: any) => {
        this.showLoadingScreen = false;
        if (err.error === undefined || err.error === null)
          this.toasterService.showErrorMessage(
            this.npanxx2carrierzonesHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
          );
        else if (err.error && err.error.ERR) {
          const commaSeperatedArr = err.error.ERR.split(",");
          for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
            if (commaSeperatedArr[i] != "")
              this.toasterService.showErrorMessage(
                commaSeperatedArr[i]
              );
          }
        }
        else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
          return;
        else this.toasterService.showErrorMessage(err.error);
      }
      );
  }

// to open bulk insert pop up
  openUploadCSVDialog() {
    const dialogRef = this.dialog.open(BulkInsertNpanxx2carrierzonesComponent, {
        width: "90%",
        height: "90%",
    });
    // Create subscription
    dialogRef.afterClosed().subscribe((bulkInsertData) => {
        if (bulkInsertData && bulkInsertData.length > 0) {
            this.warningAlert("Your upload is complete. Please click on Submit to begin database insertions.")
            this.bulkInsertData = [...bulkInsertData];
            let filterKeys = Object.keys(this.frmNpanxx2CarrierZones.controls);
        filterKeys.forEach(_e1 => {
            this.frmNpanxx2CarrierZones.controls[`${_e1}`].setValidators([]);
            this.frmNpanxx2CarrierZones.controls[`${_e1}`].updateValueAndValidity();
        });
        }
    });
}

//to bulk insert Npanxx2 Carrie rZones
private bulkInsertNpanxx2CarrierZones() {
    this.showLoadingScreen = true;
    let obj: any = [];
    this.alreadyEnabled = true;
    obj = [...this.bulkInsertData];
    obj.forEach(element => {
        element.dbEnv = this.wizardHelper.dbEnv;
    });
    obj = this.wizardHelper.checkRequestObject(obj);
    obj.dbEnv = this.wizardHelper.dbEnv;
    this.wizardService.bulkInsertNpanxx2CarrierZones(obj).pipe(takeUntil(this.unsubscribe))
        .subscribe(
        (data: any) => {
            if (data[0] === null || data[0] === undefined) {
                this.showLoadingScreen = false;
                this.toasterService.showErrorMessage(
                    this.npanxx2carrierzonesHelper.getTracfoneConstantMethod("TRACFONE_ADD_NPANXX2CARRIERZONES_ERROR_MESSAGE")
                );
                return;
            }
            if (data[0] && data[0].ERR) {
                this.showLoadingScreen = false;
                const commaSeperatedArr = data[0].ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
                return;
            }
            this.showLoadingScreen = false;
            this.showMssg = true;
            this.revert();
        },
        (err: any) => {
            this.showLoadingScreen = false;
            if (err.error === undefined || err.error === null)
                this.toasterService.showErrorMessage(
                    this.npanxx2carrierzonesHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                );
            else if (err.error && err.error.ERR) {
                const commaSeperatedArr = err.error.ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
            }
            else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                return;
            else this.toasterService.showErrorMessage(err.error);
        }
        );
}


private warningAlert(warningMsg: string) {
    window.scrollTo(0, 0);
    this.alerts = [];
    this.alerts.push({
        id: 3,
        type: 'warning',
        message: warningMsg
    });
  }

  public closeAlert(alert: any) {
    const index: number = this.alerts.indexOf(alert);
    this.alerts.splice(index, 1);
  }

  public showLastInsertedRecords() {
    this.returnedData.emit({ lastInsertedRecord: true });
  }

  // to filter columns
public filterReportResults(): void {
    const filterFormObject = this.tableFrmGroupMain.value;
    this.filteredValues.npa = filterFormObject.npa;
    this.filteredValues.nxx = filterFormObject.nxx;
    this.filteredValues.carrierId = filterFormObject.carrierId;
    this.filteredValues.carrierName = filterFormObject.carrierName;
    this.filteredValues.leadTime = filterFormObject.leadTime;
    this.filteredValues.targetLevel = filterFormObject.targetLevel;
    this.filteredValues.rateCenter = filterFormObject.rateCenter;
    this.filteredValues.state = filterFormObject.state;
    this.filteredValues.carrierIdDescription = filterFormObject.carrierIdDescription;
    this.filteredValues.zone = filterFormObject.zone;
    this.filteredValues.county = filterFormObject.county;
    this.filteredValues.marketId = filterFormObject.marketId;
    this.filteredValues.mrktArea = filterFormObject.mrktArea;
    this.filteredValues.sid = filterFormObject.sid;
    this.filteredValues.technology = filterFormObject.technology;
    this.filteredValues.frequency1 = filterFormObject.frequency1;
    this.filteredValues.frequency2 = filterFormObject.frequency2;
    this.filteredValues.btaMktNumber = filterFormObject.btaMktNumber;
    this.filteredValues.btaMktName = filterFormObject.btaMktName;
    this.filteredValues.gsmTech = filterFormObject.gsmTech;
    this.filteredValues.cdmaTech = filterFormObject.cdmaTech;
    this.filteredValues.tdmaTech = filterFormObject.tdmaTech;
    this.filteredValues.mnc = filterFormObject.mnc;
    const newRows = Object.keys(filterFormObject).reduce((acc, key) => {
        if (!filterFormObject[key].length) return acc;
        const filteredRows = acc.filter(val => filterFormObject[key].indexOf(val[key]) > -1);
        return filteredRows;
    }, this.tableRowsMainData);

    this.tableRows = newRows;
}

public generateFilters(): void {
    this.filteredRows = Object.keys(this.tableColumns)
        .map(i => this.tableColumns[i].prop)
        .reduce((filterObject, columnName) => {
            const uniqueValuesPerRow = this.tableRows.reduce((set, row) => set.add(row[columnName]), new Set());
            let val:any = Array.from(uniqueValuesPerRow);
          if( /^[0-9]*$/.test(val[0])){
               filterObject[columnName] = val.sort(function(a,b){return a - b});
          }else{
               filterObject[columnName] =val.sort((a, b) => {
                a = a || '';
                b = b || '';
                return a.localeCompare(b);
            });                   
          }
            return filterObject;
        }, {});
}

}
