import { Component, OnInit } from "@angular/core";


@Component({
    selector: 'step-carriers',
    templateUrl: './step-carriers.component.html',
    styleUrls: ['./step-carriers.component.scss'],

})
export class StepCarriersComponent implements OnInit {
    index = 0;
    constructor() { }

    ngOnInit() {

    }

    returnedData(data){
        this.index = data.index;
    }
    
    onChange(event) {
        if (event.index == 0) {
            this.index = 0;
        } else if (event.index == 1) {
            this.index = 1;
        }
    }
}


