import { Component, ViewEncapsulation, OnInit, Inject } from "@angular/core";
import { ConfirmationService } from "primeng/api";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { Subject } from "rxjs";
import { CarrierMaintenanceHelper } from "../../../../../carrier-maintenance-helper";
import { CarrierMaintenanceService } from "../../../../../../../../Services/carrierMaintenance.service";
import { ToasterService } from "../../../../../../../../Services/toaster.service";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { takeUntil } from "rxjs/operators";

@Component({
    selector: "carrier-rules-dialog",
    templateUrl: "./carrier-rules-dialog.component.html",
    styleUrls: [
        "./carrier-rules-dialog.component.scss"
    ],
    animations: [],
    encapsulation: ViewEncapsulation.None,
    providers: [ConfirmationService]
})
export class CarrierRulesDialogComponent implements OnInit {

    public frmGroupMain: FormGroup;
    public upadteFrmGroup: FormGroup;
    public unsubscribe = new Subject<void>();
    public addNew = false;
    public updateExisting = false;
    public selectExisting = false;
    public displayAddTable = false;
    public displaySelectTable = false;
    public showUpadteForm = false;
    public showForm = false;
    public addSummary = [];
    public addColumns: any;
    public selectSummary = [];
    public selectColumns: any;
    public updateSummary: any;
    public updateColumns: any;
    alreadyEnabled: any = { value: false };
    public techData: any;
    public showLoadingScreen = false;
    public carrierRulesObjId: any;
    public isEnabled = false;
    public firstAvailableColumnsFields = [];
    public secondAvilableColumnsFields = [];
    public thirdAvailableColumnsFields = [];
    public carrierRulesObjIdData: any;
    public selectExistingForm: FormGroup;
    public showSelectForm = false;
    public saveButtonBoolean = false;

    constructor(
        @Inject(MAT_DIALOG_DATA) public data: any,
        public dialogRef: MatDialogRef<CarrierRulesDialogComponent>,
        private _formBuilder: FormBuilder,
        private wizardHelper: CarrierMaintenanceHelper,
        private wizardService: CarrierMaintenanceService,
        private toasterService: ToasterService,
        private confirmationService: ConfirmationService,
    ) { }

    ngOnInit() {
        this.saveButtonBoolean = false;
        this.carrierRulesObjIdData = this.data.carrierRuleObjid;
        this.alreadyEnabled.value = false;
        this.alreadyEnabled = Object.assign({}, this.alreadyEnabled);
        this.addSummary = [];
        this.updateSummary = [];
        this.selectSummary = [];
        /** 
         * THESE COLUMNS ARE UESD TO SHOW A NEW ADDED CARRIER RULES IN THE TABLE 
         */
        this.addColumns = {
            parentCols: [
                { field: "objId", header: "ObjId", editable: false },
                { field: "coolingPeriod", header: "Cooling Period", editable: true, isOptional: true, isNumber: true, length: 38 },
                { field: "esnChangeDays", header: "ESN Change Days", editable: true, isOptional: true, isNumber: true, length: 38 },
                { field: "lineExpireDays", header: "Line Exchange Days", editable: true, isOptional: true, isNumber: true, length: 38 },
                { field: "lineReturnDays", header: "Line Return Days", editable: true, isOptional: true, isNumber: true, length: 38 },
                { field: "coolingAfterInsert", header: "Cooling After Insert", editable: true, isOptional: true, isNumber: true, length: 38 },
                { field: "npaNxxFlag", header: "NPA NXX Flag", editable: true, isOptional: true, isNumber: true, length: 38 },
                { field: "usedLineExpireDays", header: "Used Line Expire Days", editable: true, isOptional: true, isNumber: true, length: 38 },
                { field: "gsmGracePeriod", header: "GSM Grace Period", editable: true, isOptional: true, isNumber: true, length: 38 },
                { field: "technology", header: "Technology", editable: true, isOptional: false, length: 10 },
                { field: "reserveOnSuspend", header: "Reserve On Suspend", editable: true, isOptional: true, isNumber: true, length: 38 },
                { field: "reservePeriod", header: "Reserve Period", editable: true, isOptional: true, isNumber: true, length: 38 },
                { field: "deacAfterGrace", header: "Deac After Grace", editable: true, isOptional: true, isNumber: true, length: 38 },
                { field: "cancelSuspendDays", header: "Cancel Suspend Days", editable: true, isOptional: true, isNumber: true, length: 38 },
                { field: "cancelSuspend", header: "Cancel Suspend", editable: true, isOptional: true, isNumber: true, length: 38 },
                { field: "blockCreateActItem", header: "Block Create Act Item", editable: true, isOptional: true, isNumber: true, length: 22 },
                { field: "allow2gAct", header: "Allow 2G Act", editable: true, isOptional: true, length: 30 },
                { field: "allow2gReact", header: "Allow 2G React", editable: true, isOptional: true, length: 30 },
                { field: "allowNonHdActs", header: "Allow Non HD Acts", editable: true, isOptional: true, isNumber: true, length: 38 },
                { field: "allowNonHdReacts", header: "Allow Non HD Reacts", editable: true, isOptional: true, isNumber: true, length: 38 },
            ],
            parentDataId: "objId",
            defaultColumnSort: "objId",
            showFilterSection: true,
            hideDeleteIcon: true
        };

        /** 
         * THESE COLUMNS ARE UESD TO SHOW A FETCHED CARRIER RULES IN THE TABLE 
         */
        this.selectColumns = {
            parentCols: [
                { field: "check", editable: true, inputType: 'radio' },
                { field: "objId", header: "ObjId", editable: false },
                { field: "coolingPeriod", header: "Cooling Period", editable: false },
                { field: "esnChangeDays", header: "ESN Change Days", editable: false },
                { field: "lineExpireDays", header: "Line Exchange Days", editable: false },
                { field: "lineReturnDays", header: "Line Return Days", editable: false },
                { field: "coolingAfterInsert", header: "Cooling After Insert", editable: false },
                { field: "npaNxxFlag", header: "NPA NXX Flag", editable: false },
                { field: "usedLineExpireDays", header: "Used Line Expire Days", editable: false },
                { field: "gsmGracePeriod", header: "GSM Grace Period", editable: false },
                { field: "technology", header: "Technology", editable: false },
                { field: "reserveOnSuspend", header: "Reserve On Suspend", editable: false },
                { field: "reservePeriod", header: "Reserve Period", editable: false },
                { field: "deacAfterGrace", header: "Deac After Grace", editable: false },
                { field: "cancelSuspendDays", header: "Cancel Suspend Days", editable: false },
                { field: "cancelSuspend", header: "Cancel Suspend", editable: false },
                { field: "blockCreateActItem", header: "Block Create Act Item", editable: false },
                { field: "allow2gAct", header: "Allow 2G Act", editable: false },
                { field: "allow2gReact", header: "Allow 2G React", editable: false },
                { field: "allowNonHdActs", header: "Allow Non HD Acts", editable: false },
                { field: "allowNonHdReacts", header: "Allow Non HD Reacts", editable: false },
            ],
            parentDataId: "objId",
            defaultColumnSort: "objId",
            showFilterSection: true,
            isSearchResults: true
        };

        /** 
         * THESE COLUMNS ARE UESD TO CREATE A CARRIER RULES UPDATE FORM 
         */
        this.firstAvailableColumnsFields = [
            { name: 'OBJID', prop: 'objId' },
            { name: 'LINE EXPIRE DAYS', prop: 'lineExpireDays' },
            { name: 'NPA NXX FLAG', prop: 'npaNxxFlag' },
            { name: 'TECHNOLOGY', prop: 'technology' },
            { name: 'DEAC AFTER GRACE', prop: 'deacAfterGrace' },
            { name: 'BLOCK CREATE ACT ITEM', prop: 'blockCreateActItem' },
            { name: 'ALLOW NON HD ACTS', prop: 'allowNonHdActs' },
        ];

        this.secondAvilableColumnsFields = [
            { name: 'COOLING PERIOD', prop: 'coolingPeriod' },
            { name: 'LINE RETURN DAYS', prop: 'lineReturnDays' },
            { name: 'USED LINE EXPIRE DAYS', prop: 'usedLineExpireDays' },
            { name: 'RESERVE ON SUSPEND', prop: 'reserveOnSuspend' },
            { name: 'CANCEL SUSPEND DAYS', prop: 'cancelSuspendDays' },
            { name: 'ALLOW 2G ACT', prop: 'allow2gAct' },
            { name: 'ALLOW NON HD REACTS', prop: 'allowNonHdReacts' },
        ];

        this.thirdAvailableColumnsFields = [
            { name: 'ESN CHANGE DAYS', prop: 'esnChangeDays' },
            { name: 'COOLING AFTER INSERT', prop: 'coolingAfterInsert' },
            { name: 'GSM GRACE PERIOD', prop: 'gsmGracePeriod' },
            { name: 'RESERVE PERIOD', prop: 'reservePeriod' },
            { name: 'CANCEL SUSPEND', prop: 'cancelSuspend' },
            { name: 'ALLOW 2G REACT', prop: 'allow2gReact' },
        ];

        if (this.data.dataKey == 'carrier2Rule') {
            this.techData = "";
            this.isEnabled = false;
        } else if (this.data.dataKey == 'carrier2RulesCdma') {
            this.techData = "CDMA";
            this.isEnabled = true;
        } else if (this.data.dataKey == 'carrier2RulesGsm') {
            this.techData = "GSM";
            this.isEnabled = true;
        } else if (this.data.dataKey == 'carrier2RulesTdma') {
            this.techData = "TDMA";
            this.isEnabled = true;
        }
        this.upadteFrmGroup = this.createForm();
        this.frmGroupMain = this.createForm();
        this.selectExistingForm = this.createForm();
    }

    createForm() {
        return this._formBuilder.group({
            objId: ["", [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            coolingPeriod: ["", [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            esnChangeDays: ["", [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            lineExpireDays: ["", [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            lineReturnDays: ["", [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            coolingAfterInsert: ["", [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            npaNxxFlag: ["", [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            usedLineExpireDays: ["", [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            gsmGracePeriod: ["", [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            technology: [this.techData, [Validators.maxLength(10)]],
            reserveOnSuspend: ["", [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            reservePeriod: ["", [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            deacAfterGrace: ["", [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            cancelSuspendDays: ["", [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            cancelSuspend: ["", [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            blockCreateActItem: ["", [Validators.pattern("^[0-9]*$"), Validators.maxLength(22)]],
            allow2gAct: ["", [Validators.maxLength(30)]],
            allow2gReact: ["", [Validators.maxLength(30)]],
            allowNonHdActs: ["", [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            allowNonHdReacts: ["", [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            dbEnv:[""],
        });
    }

    public onSelect(event) {
        if (event.value == 'add') {
            this.addNew = true;
            this.updateExisting = false;
            this.selectExisting = false;
            this.displayAddTable = false;
            this.displaySelectTable = false;
            this.showForm = true;
            this.revert();
            this.showUpadteForm = false;
            this.showSelectForm = false;
            this.saveButtonBoolean = false;
        } else if (event.value == 'update') {
            this.addNew = false;
            this.updateExisting = true;
            this.selectExisting = false;
            this.displayAddTable = false;
            this.displaySelectTable = false;
            this.showForm = false;
            this.showSelectForm = false;
            this.saveButtonBoolean = false;
            this.getCarrierRules(this.carrierRulesObjIdData);
        } else if (event.value == 'select') {
            this.addNew = false;
            this.updateExisting = false;
            this.selectExisting = true;
            this.displayAddTable = false;
            this.displaySelectTable = false;
            this.showForm = false;
            this.revert();
            this.showUpadteForm = false
            this.showSelectForm = true;
            this.saveButtonBoolean = false;
        }
    }

    //this method will close the carrier rules dialog window
    cancelCarrierDialog(): void {
        this.dialogRef.close(false);
    }

    //show cancel confirm box
    showCancelConfirm() {
        this.confirmationService.confirm({
            key: 'confirm-cancel',
            message: this.wizardHelper.getTracfoneConstantMethod("TRACFONE_CANCEL_UPDATE_CARRIER_CONFIRM_MESSAGE"),
            accept: () => {
                this.cancelCarrierDialog();
            }
        });
    }

    // this is use to reset
    public revert() {
        let frmKeys = Object.keys(this.frmGroupMain.value);
        frmKeys.forEach(_e1 => {
            if ((this.data.dataKey == 'carrier2RulesCdma' || this.data.dataKey == 'carrier2RulesTdma'
                || this.data.dataKey == 'carrier2RulesGsm') && _e1 == "technology") {
                this.frmGroupMain.controls.technology.patchValue(this.techData);
            } else
                this.frmGroupMain.controls[`${_e1}`].reset();
        });
        frmKeys.forEach(_e1 => {
            if ((this.data.dataKey == 'carrier2RulesCdma' || this.data.dataKey == 'carrier2RulesTdma'
                || this.data.dataKey == 'carrier2RulesGsm') && _e1 == "technology") {
                this.selectExistingForm.controls.technology.patchValue(this.techData);
            } else
                this.selectExistingForm.controls[`${_e1}`].reset();
        });
        this.selectSummary = [];
        this.addSummary = [];
        this.saveButtonBoolean = false;
        this.displaySelectTable = false;
        this.displayAddTable = false;
    }

    //checking return data
    checkReturnData(returnedData) {
        if (returnedData.status == "save") {
            this.updateCarrierRules(returnedData.data);
        } else if (returnedData.status == "alreadyEditEnabled") {
            this.toasterService.showErrorMessage(
                this.wizardHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE")
            );
        } else if (returnedData.status == "validationfailed") {
            this.toasterService.showErrorMessage(
                this.wizardHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            );
        } else if (returnedData.status == "selectedData") {
            if (returnedData.data.length > 0) {
                this.carrierRulesObjId = { ...returnedData.data[0] }
                this.saveButtonBoolean = true;
                returnedData.data.splice(0, 1);
            }
        }
    }

    /** 
    * THIS METHOD IS CALLED WHEN USER CLICK ON SUBMIT OR SEARCH BUTTON
    */
    public onSubmit() {
        if (this.addNew) {
            this.addCarrierRules();
        } else if (this.selectExisting) {
            this.getCarrierRules("")
        }
    }

    //To Add New Carrier Rules
    public addCarrierRules() {
        this.showLoadingScreen = true;
        const obj: any = this.wizardHelper.checkRequestObjectSetToNull(
            this.frmGroupMain.value
        );
        obj.dbEnv = this.wizardHelper.dbEnv;
        this.wizardService
            .addCarrierRules(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_UNABLE_ADD_CARRIER_RULES_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    const d = data[0];
                    obj.objId = d.message;
                    this.showLoadingScreen = false;
                    this.displayAddTable = true;
                    this.showForm = false;
                    this.carrierRulesObjId = { ...obj };
                    this.saveButtonBoolean = true;
                    this.addSummary = [obj];
                    this.toasterService.showSuccessMessage(
                        this.wizardHelper.getTracfoneConstantMethod("TRACFONE_ADD_CARRIER_RULES_SUCCESS_MESSAGE")
                    );
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null) {
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    }
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    //To Fetch Carrier Rules
    public getCarrierRules(carrierRuleData) {
        this.selectSummary = [];
        this.saveButtonBoolean = false;
        this.displaySelectTable = false;
        this.showLoadingScreen = true;
        let obj: any = {};
        if (carrierRuleData != "") {
            obj.objId = carrierRuleData;
        } else {
            obj = this.wizardHelper.checkRequestObject(
                this.selectExistingForm.value
            );
        }
        obj.dbEnv = this.wizardHelper.dbEnv;
        this.wizardService
            .searchCarrierRules(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_UNABLE_SEARCH_ORDER_TYPES_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    this.showLoadingScreen = false;

                    if (this.updateExisting) {
                        this.updateSummary = data[0][0];
                        this.showUpadteForm = true;
                    } else {
                        this.selectSummary = data[0];
                        this.displaySelectTable = true;
                    }
                    if (data[0] && data[0].length == 0)
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("NO_CARRIER_RULES_FOUND")
                        );
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null) {
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    }
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    // To Upate Carrier Rules
    public updateCarrierRules(carrierRuleData) {
        this.showLoadingScreen = true;
        let obj = this.wizardHelper.checkRequestObjectSetToNull(
            { ...carrierRuleData }
        );
        obj.dbEnv = this.wizardHelper.dbEnv;
        this.wizardService
            .updateCarrierRules(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_UNABLE_UPDATE_CARRIER_RULES_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    this.showLoadingScreen = false;

                    if (this.updateExisting) {
                        this.dialogRef.close(this.carrierRulesObjIdData)
                    } else if (this.addNew) {
                        this.addSummary = [...this.addSummary];
                    }

                    this.alreadyEnabled.value = false;
                    carrierRuleData.isEditable = false;
                    this.alreadyEnabled = Object.assign({}, this.alreadyEnabled);
                    this.toasterService.showSuccessMessage(
                        this.wizardHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_CARRIER_RULES_SUCCESS_MESSAGE")
                    );
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null) {
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    }
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    // When Click on Save Button
    public saveCarrierRuleData() {
        if (this.carrierRulesObjId)
            this.dialogRef.close(this.carrierRulesObjId.objId);

    }
}