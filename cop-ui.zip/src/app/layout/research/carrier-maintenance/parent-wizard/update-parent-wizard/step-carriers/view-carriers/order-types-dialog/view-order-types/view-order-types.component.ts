import { Component, ViewEncapsulation, OnInit, Inject, Output, EventEmitter } from "@angular/core";
import { Subject } from "rxjs";
import { MAT_DIALOG_DATA } from "@angular/material";
import { ToasterService } from "../../../../../../../../../Services/toaster.service";
import { CarrierMaintenanceHelper } from "../../../../../../carrier-maintenance-helper";
import { CarrierMaintenanceService } from "../../../../../../../../../Services/carrierMaintenance.service";
import { takeUntil } from "rxjs/operators";

@Component({
    selector: 'view-order-types',
    templateUrl: './view-order-types.component.html',
    styleUrls: ['./view-order-types.component.scss',
        '../../../../../../../../components/ngxtable/material.scss',
        '../../../../../../../../components/ngxtable/datatable.component.scss',
        '../../../../../../../../components/ngxtable/icons.css',
        '../../../../../../../../components/ngxtable/app.css'],
    encapsulation: ViewEncapsulation.None
})

export class ViewOrderTypesComponent implements OnInit {

    @Output("returnedData") returnedData: any = new EventEmitter();
    public unsubscribe = new Subject<void>();
    public rowData: any;
    public orderTypesData = [];
    public orderTypesMainData = [];
    public showLoadingScreen = false;
    public orderTypesFields: any;
    public isEditable = {};
    public editedRow = {};
    public defaultEditedRow = {};
    public displayTable = false;
    alreadyEnabled: any = { value: false };
    public alerts: any = []

    constructor(
        @Inject(MAT_DIALOG_DATA) public data: any,
        private toasterService: ToasterService,
        private wizardHelper: CarrierMaintenanceHelper,
        private wizardService: CarrierMaintenanceService,
    ) { }

    ngOnInit() {
        this.alreadyEnabled.value = false;
        this.alreadyEnabled = Object.assign({}, this.alreadyEnabled);
        this.displayTable = false;
        this.orderTypesData = [];
        this.orderTypesMainData = [];
        this.showLoadingScreen = false;
        this.rowData = { ...this.data.dataKey };
        this.orderTypesFields = {
            parentCols: [
                { field: "objId", header: "ObjId", editable: false },
                { field: "orderType", header: "Order Type", editable: true, isOptional: false, length: 30 },
                { field: "npa", header: "NPA", editable: true, isOptional: true, length: 10 },
                { field: "nxx", header: "NXX", editable: true, isOptional: true, length: 10 },
                { field: "billCycle", header: "Bill Cycle", editable: true, isOptional: true, length: 10 },
                { field: "dealerCode", header: "Dealer Code", editable: true, isOptional: true, length: 30 },
                { field: "ldAccountNum", header: "LD Account Num", editable: true, isOptional: true, length: 30 },
                { field: "marketCode", header: "Market Code", editable: true, isOptional: true, length: 30 },
                { field: "orderType2xTransProfile", header: "Order Type2x Trans Profile", editable: true, isOptional: true, isNumber: true, length: 38 },
            ],
            parentDataId: "objId",
            defaultColumnSort: "objId",
            showFilterSection: true,
            hideDeleteIcon: false
        };
        this.getOrderType();
    }

    public getOrderType() {
        this.showLoadingScreen = true;
        this.orderTypesMainData = [];
        this.orderTypesData = [];
        let obj: any = {};
        obj.dbEnv = this.wizardHelper.dbEnv;
        obj.orderType2xCarrier = this.rowData.objId;
        this.wizardService
            .viewOrderTypes(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_UNABLE_SEARCH_ORDER_TYPES_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    this.showLoadingScreen = false;
                    this.displayTable = true;
                    this.orderTypesMainData = data[0];
                    this.orderTypesData = [...this.orderTypesMainData];

                    if (data[0] && data[0].length == 0) {
                        this.failedAlert(this.wizardHelper.getTracfoneConstantMethod("NO_ORDER_TYPE_FOUND"));
                    }
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null) {
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    }
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    checkReturnData(returnedData) {
        if (returnedData.status == "save") {
            this.editOrderTypes(returnedData.data);
        } else if (returnedData.status == "editEnableRow") {
            this.returnedData.emit({ status: "editEnableRow" });
        } else if (returnedData.status == "onRowEditCancel") {
            this.returnedData.emit({ status: "onRowEditCancel" });
        } else if (returnedData.status == "alreadyEditEnabled") {
            this.toasterService.showErrorMessage(
                this.wizardHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE")
            );
        } else if (returnedData.status == "validationfailed") {
            this.toasterService.showErrorMessage(
                this.wizardHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            );
        } else if(returnedData.status == "delete"){
            this.deleteOrderTypes(returnedData)
        }
    }

    private failedAlert(errorMsg: string) {
        this.alerts = [];
        this.alerts.push(
            {
                id: 4,
                type: 'danger',
                message: errorMsg
            }
        );
    }

    public editOrderTypes(orderTypeData) {
        this.showLoadingScreen = true;
        let obj: any = {}
        obj = this.wizardHelper.checkRequestObjectSetToNull(
            { ...orderTypeData }
        );
        obj.dbEnv = this.wizardHelper.dbEnv;
        delete obj.check;
        delete obj.children;
        delete obj.isEditable;
        this.wizardService
            .udpateOrderTypes(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_ORDER_TYPES_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    this.showLoadingScreen = false;
                    this.alreadyEnabled.value = false;
                    orderTypeData.isEditable = false;
                    this.alreadyEnabled = Object.assign({}, this.alreadyEnabled);
                    this.returnedData.emit({ status: "save" });
                    this.orderTypesData = [...this.orderTypesData];
                    this.toasterService.showSuccessMessage(
                        this.wizardHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_ORDER_TYPES_SUCCESS_MESSAGE")
                    );
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null) {
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    }
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    public deleteOrderTypes(reqData) {
        this.showLoadingScreen = true;
        this.alerts = [];
        let obj: any = {};
        obj.objId = reqData.data.objId;
        obj.dbEnv = this.wizardHelper.dbEnv;
        this.wizardService.deleteOrderType(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DELETE_ORDER_TYPES_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }

                    this.orderTypesData.splice(reqData.rowIndex, 1);
                    this.orderTypesData = [...this.orderTypesData];
                    this.showLoadingScreen = false;
                    this.toasterService.showSuccessMessage(
                        this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DELETE_ORDER_TYPES_SUCCESS_MESSAGE")
                    );
                    if (this.orderTypesData.length == 0) {
                        this.failedAlert(this.wizardHelper.getTracfoneConstantMethod("NO_ORDER_TYPE_FOUND"));
                    }
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            )
    }
}