import { Component, OnInit } from "@angular/core";
import { UpdateParentService } from "../services/update-parent-wizard.service";


@Component({
    selector: 'step-carrier-groups',
    templateUrl: './step-carrier-groups.component.html',
    styleUrls: ['./step-carrier-groups.component.scss'],

})
export class StepCarrierGroupsComponent implements OnInit {
    index = 0;
    constructor(
        private updateParentService: UpdateParentService,
    ) { }

    ngOnInit() {

    }

    returnedData(data){
        this.index = data.index;
    }

    onChange(event) {
        if (event.index == 0) {
            this.index = 0;
        } else if (event.index == 1) {
            this.index = 1;
            this.updateParentService.setCarrierGroupData([]);
            this.updateParentService.isAppCarrierGroupTableActivated(false);
        }
    }
}


