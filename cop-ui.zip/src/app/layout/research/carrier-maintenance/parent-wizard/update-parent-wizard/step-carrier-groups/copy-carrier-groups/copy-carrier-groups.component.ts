import { Component, ViewEncapsulation, OnInit, ViewChild, ViewChildren, Output, EventEmitter } from "@angular/core";
import { FormGroup, Validators, FormBuilder } from "@angular/forms";
import { UpdateParentService } from "../../services/update-parent-wizard.service";
import { CarrierMaintenanceHelper } from "../../../../carrier-maintenance-helper";
import { CarrierMaintenanceService } from "../../../../../../../Services/carrierMaintenance.service";
import { takeUntil } from "rxjs/operators";
import { Subject } from "rxjs";
import { ToasterService } from "../../../../../../../Services/toaster.service";
import { MatSelect } from "@angular/material";

@Component({
    selector: 'copy-carrier-groups',
    templateUrl: './copy-carrier-groups.component.html',
    styleUrls: ['./copy-carrier-groups.component.scss',
        '../../../../../../components/ngxtable/material.scss',
        '../../../../../../components/ngxtable/datatable.component.scss',
        '../../../../../../components/ngxtable/icons.css',
        '../../../../../../components/ngxtable/app.css'
    ],
    encapsulation: ViewEncapsulation.None
})

export class CopyCarrierGroupsComponent implements OnInit {

    public frmGroupMain: FormGroup;
    public displayTable = false;
    public carrierGroupMainData: any = [];
    public carrierGroupData: any = [];
    public selectedCarrierGroupData: any = [];
    public selectedCarrierGroupMainData: any = [];
    public selectedCG: any = [];
    public carrierGroupFields: any = [];
    public showLoadingScreen = false;
    public isEditable = {};
    public editedRow = {};
    public defaultEditedRow = {};
    public unsubscribe = new Subject<void>();
    public allAvailableCarrierGroupsColumns = []
    public isSearchResultsExpanded = false;
    public copyCGs = false;
    public copyCarrierGroupColumns = [];
    public copyselectedCarrierGroupssRows = [];
    private multiColumnEditSection = false;
    private multicolumnEditColumnName = '';
    @ViewChild('multicolumnEditColumnValue') multicolumnEditColumnValue: any;
    @ViewChild('multicolumnEditCheckbox') private multicolumnEditCheckbox: any;
    public flagColumn = false;
    public textColumns = false;
    public multiColumnEditColumns = [];
    @ViewChildren(MatSelect) matSelect: any;
    @Output("returnedData") returnedData: any = new EventEmitter();
    public parentData: any;
    constructor(
        private _formBuilder: FormBuilder,
        private updateParentService: UpdateParentService,
        private wizardHelper: CarrierMaintenanceHelper,
        private wizardService: CarrierMaintenanceService,
        private toasterService: ToasterService,
    ) { }

    ngOnInit() {
        this.parentData = this.updateParentService.getParentData();
        this.displayTable = false;
        this.showLoadingScreen = false;
        this.carrierGroupData = [];
        this.carrierGroupMainData = [];
        this.selectedCarrierGroupData = [];
        this.selectedCarrierGroupMainData = [];
        this.isSearchResultsExpanded = false;
        this.copyCGs = false;
        this.multiColumnEditColumns = [];

        this.allAvailableCarrierGroupsColumns = [
            { name: "ObjId", prop: "objId", width: "130" },
            { name: "Carrier Group Id", prop: "carrierGroupId", width: "150" },
            { name: "Carrier Name", prop: "carrierName", width: "300" },
            { name: "Status", prop: "status", width: "150" },
            { name: "Group2 Address", prop: "group2Address", width: "150" },
            { name: "No Auto Part", prop: "noAutoPart", width: "150" }
        ];
        this.copyCarrierGroupColumns = [...this.allAvailableCarrierGroupsColumns];
        this.multiColumnEditColumns = this.allAvailableCarrierGroupsColumns.filter((col) => { if (col.prop != "objId") return col; });
        this.createForm();
    }

    createForm() {
        this.frmGroupMain = this._formBuilder.group({
            carrierGroupId: ["", [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            carrierName: ["", [Validators.maxLength(30)]],
            status: [""]
        });
    }

    public onSubmit() {
        if (this.frmGroupMain.valid) {
            this.selectedCarrierGroupData = [];
            this.selectedCarrierGroupMainData = [];
            this.carrierGroupData = [];
            this.carrierGroupMainData = [];
            this.selectedCG = [];
            this.removeCopyCarrierGroupButton();
            this.showLoadingScreen = true;
            const obj: any = this.wizardHelper.checkRequestObject(
                this.frmGroupMain.value
            );
            obj.dbEnv = this.wizardHelper.dbEnv;
            this.wizardService
                .searchCarrierGroups(obj)
                .pipe(takeUntil(this.unsubscribe))
                .subscribe(
                    (data: any) => {
                        if (data[0] === null || data[0] === undefined) {
                            this.showLoadingScreen = false;
                            this.toasterService.showErrorMessage(
                                this.wizardHelper.getTracfoneConstantMethod("TRACFONE_UNABLE_SEARCH_CARRIER_GROUP_MESSAGE")
                            );
                            return;
                        }
                        if (data[0] && data[0].ERR) {
                            this.showLoadingScreen = false;
                            const commaSeperatedArr = data[0].ERR.split(",");
                            for (
                                let i = commaSeperatedArr.length - 1;
                                i >= 0;
                                i--
                            ) {
                                if (commaSeperatedArr[i] != "")
                                    this.toasterService.showErrorMessage(
                                        commaSeperatedArr[i]
                                    );
                            }
                            return;
                        }
                        this.showLoadingScreen = false;
                        this.carrierGroupMainData = data[0];
                        this.carrierGroupData = [...this.carrierGroupMainData];
                        if (data[0] && data[0].length == 0)
                            this.toasterService.showErrorMessage(
                                this.wizardHelper.getTracfoneConstantMethod("NO_CARRIER_GROUPS_FOUND")
                            );
                        else {
                            this.isSearchResultsExpanded = true;
                        }
                    },
                    (err: any) => {
                        this.showLoadingScreen = false;
                        if (err.error === undefined || err.error === null) {
                            this.toasterService.showErrorMessage(
                                this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                            );
                        }
                        else if (err.error && err.error.ERR) {
                            const commaSeperatedArr = err.error.ERR.split(",");
                            for (
                                let i = commaSeperatedArr.length - 1;
                                i >= 0;
                                i--
                            ) {
                                if (commaSeperatedArr[i] != "")
                                    this.toasterService.showErrorMessage(
                                        commaSeperatedArr[i]
                                    );
                            }
                        }
                        else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                            return;
                        else this.toasterService.showErrorMessage(err.error);
                    }
                );
        }
    }

    public copyCarrierGroupSubmit() {
        if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
            this.toasterService.showErrorMessage(
                this.wizardHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            return;
        }
        this.showLoadingScreen = true;
        let obj: any;
        obj = [...this.copyselectedCarrierGroupssRows];
        for (let i = 0; i < obj.length; i++) {
            obj[i].dbEnv = this.wizardHelper.dbEnv;
            obj[i].carrierGroup2Parent = this.parentData.objId;
        }
        this.wizardService
            .addCarrierGroups(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_COPY_CARRIER_GROUPS_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        if(data[0].ERR.indexOf('[') == -1){
                            const commaSeperatedArr = data[0].ERR.split(",");
                            for (
                                let i = commaSeperatedArr.length - 1;
                                i >= 0;
                                i--
                            ) {
                                if (commaSeperatedArr[i] != "")
                                    this.toasterService.showErrorMessage(
                                        commaSeperatedArr[i]
                                    );
                            }
                        } else{
                                    this.toasterService.showErrorMessage(
                                        data[0].ERR
                                    );                            
                        }
                            return;
                    }
                    this.showLoadingScreen = false;
                    this.revert();
                    this.returnedData.emit({ index: 0 });
                    this.toasterService.showSuccessMessage(
                        this.wizardHelper.getTracfoneConstantMethod("TRACFONE_COPY_CARRIER_GROUPS_SUCCESS_MESSAGE")
                    );
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null) {
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    }
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    // this is use to reset
    public revert() {
        this.frmGroupMain.reset();
        this.carrierGroupData = [];
        this.carrierGroupMainData = [];
        this.updateParentService.isAppCarrierGroupTableActivated(false);
        this.selectedCarrierGroupData = [];
        this.selectedCarrierGroupMainData = [];
        this.copyselectedCarrierGroupssRows = [];
        this.isSearchResultsExpanded = false;
        this.copyCGs = false;
    }

    public onSelect(row) {
        this.selectedCarrierGroupMainData = [];
        if (row && row.selected) {
            for (let i = 0; i < row.selected.length; i++) {
                let obj = { ...row.selected[i] };
                this.selectedCarrierGroupMainData.push(obj);
            }
        }
        this.selectedCarrierGroupData = [...this.selectedCarrierGroupMainData]
    }

    public copyCarrierGroupButton() {
        this.copyCGs = true;
        this.copyselectedCarrierGroupssRows = [...this.selectedCarrierGroupData];
        this.isSearchResultsExpanded = false;
    }

    public removeCopyCarrierGroupButton() {
        this.copyCGs = false;
        this.copyselectedCarrierGroupssRows = [];
        this.isSearchResultsExpanded = true;
        this.multiColumnEditSection = false;
        this.multicolumnEditColumnName = '';
        this.multicolumnEditColumnValue = '';
        this.multicolumnEditCheckbox = '';
        this.textColumns = false;
        this.flagColumn = false;
    }

    public updateCarrierGroupDataTable(event) {
        const val = event.target.value.toLowerCase();
        // filter our data
        const temp = this.carrierGroupMainData.filter(function (d) {
            return (d.carrierName ? d.carrierName.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.status ? d.status.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.objId ? d.objId.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.group2Address ? d.group2Address.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.parent2TempQueue ? d.parent2TempQueue.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.noAutoPart ? d.noAutoPart.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.carrierGroup2Parent ? d.carrierGroup2Parent.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.carrierGroupId ? d.carrierGroupId.toLowerCase().indexOf(val) !== -1 : !val) || !val
        });
        // update the rows
        this.carrierGroupData = temp;
    }

    public updateCopyCarrierGroupDataTable(event) {
        const val = event.target.value.toLowerCase();
        // filter our data
        const temp = this.selectedCarrierGroupData.filter(function (d) {
            return (d.carrierName ? d.carrierName.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.status ? d.status.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.objId ? d.objId.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.group2Address ? d.group2Address.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.parent2TempQueue ? d.parent2TempQueue.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.noAutoPart ? d.noAutoPart.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.carrierGroup2Parent ? d.carrierGroup2Parent.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.carrierGroupId ? d.carrierGroupId.toLowerCase().indexOf(val) !== -1 : !val) || !val
        });
        // update the rows
        this.copyselectedCarrierGroupssRows = temp;
    }

    public multiColumnEdit(isChecked) {
        if (isChecked.checked)
            this.multiColumnEditSection = true;
        else {
            this.multiColumnEditSection = false;
            this.multicolumnEditColumnName = '';
            this.multicolumnEditColumnValue = '';
        }
    }
    public assignmultiColumnName(column) {
        this.multicolumnEditColumnName = column;
        if (this.multicolumnEditColumnName == "status") {
            this.flagColumn = true;
            this.textColumns = false;
        } else {
            this.textColumns = true;
            this.flagColumn = false;
        }
    }

    public updatemultiColumnEdit() {
        if (this.textColumns) {
            for (let i = 0; i < this.copyselectedCarrierGroupssRows.length; i++) {
                this.copyselectedCarrierGroupssRows[i][this.multicolumnEditColumnName] = this.multicolumnEditColumnValue.nativeElement.value;
            }
            this.multicolumnEditColumnValue.nativeElement.value = '';
        } else if (this.flagColumn) {
            for (let i = 0; i < this.copyselectedCarrierGroupssRows.length; i++) {
                this.copyselectedCarrierGroupssRows[i][this.multicolumnEditColumnName] = this.multicolumnEditColumnValue.value;
            }
            this.multicolumnEditColumnValue.value = '';
        }
        this.copyselectedCarrierGroupssRows = [...this.copyselectedCarrierGroupssRows];
        this.multicolumnEditColumnName = '';
        this.multicolumnEditCheckbox.checked = false;
        this.multiColumnEditSection = false;
        this.textColumns = false;
        this.flagColumn = false;
    }

    public editValueChanged(event, column, row, oldValue) {
        for (let i = 0; i < this.copyselectedCarrierGroupssRows.length; i++) {
            if (this.copyselectedCarrierGroupssRows[i].objId == row.objId) {
                if (column != "status") {
                    this.copyselectedCarrierGroupssRows[i][column] = event.target.value;
                } else {
                    this.copyselectedCarrierGroupssRows[i][column] = event.value
                }
            }
        }
    }

    public deleteRow(data, rowIndex) {
        this.copyselectedCarrierGroupssRows.splice(rowIndex, 1);
        if (data) {
            for (let i = 0; i < this.selectedCarrierGroupData.length; i++) {
                if (data.objId == this.selectedCarrierGroupData[i].objId) {
                    this.selectedCarrierGroupData.splice(i, 1);
                }
            }
        }
        this.selectedCarrierGroupData = [...this.selectedCarrierGroupData];
        this.copyselectedCarrierGroupssRows = [...this.copyselectedCarrierGroupssRows];
    }

    public editCarrierGroup(row, rowIndex) {

    }
}