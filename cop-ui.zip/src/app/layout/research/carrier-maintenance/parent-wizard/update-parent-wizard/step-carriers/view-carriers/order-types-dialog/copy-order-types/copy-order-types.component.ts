import { Component, ViewEncapsulation, OnInit, ViewChild, Inject, Input, Output, EventEmitter } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { Subject } from "rxjs";
import { CarrierMaintenanceHelper } from "../../../../../../carrier-maintenance-helper";
import { CarrierMaintenanceService } from "../../../../../../../../../Services/carrierMaintenance.service";
import { ToasterService } from "../../../../../../../../../Services/toaster.service";
import { MAT_DIALOG_DATA } from "@angular/material";
import { takeUntil } from "rxjs/operators";

@Component({
    selector: 'copy-order-types',
    templateUrl: './copy-order-types.component.html',
    styleUrls: ['./copy-order-types.component.scss',
        '../../../../../../../../components/ngxtable/material.scss',
        '../../../../../../../../components/ngxtable/datatable.component.scss',
        '../../../../../../../../components/ngxtable/icons.css',
        '../../../../../../../../components/ngxtable/app.css'
    ],
    encapsulation: ViewEncapsulation.None
})

export class CopyOrderTypesComponent implements OnInit {
    @Input('workArea') workArea: any;
    @Output("returnedData") returnedData: any = new EventEmitter();
    public frmGroupMain: FormGroup;
    public unsubscribe = new Subject<void>();
    public rowData: any;
    public orderTypesData = [];
    public orderTypesMainData = [];
    public selectedOrderTypes = [];
    public copySelectedOrderTypesRows = [];
    public selectedOT = [];
    public copyOrderTypes = false;
    public showLoadingScreen = false;
    public orderTypesFields: any;
    public isEditable = {};
    public editedRow = {};
    public defaultEditedRow = {};
    public displayTable = false;
    public multiColumnEditSection = false;
    public multicolumnEditColumnName = '';
    @ViewChild('multicolumnEditColumnValue') multicolumnEditColumnValue: any;
    @ViewChild('multicolumnEditCheckbox') private multicolumnEditCheckbox: any;
    public multiColumnEditColumns = [];
    public allAvailableColumns: any;
    public copyColumns: any;
    public isSearchResultsExpanded = false;
    public summaryData = [];
    public summaryMainData = [];
    public textColumns = false;
    alreadyEnabled: any = { value: false };
    constructor(
        @Inject(MAT_DIALOG_DATA) public data: any,
        private _formBuilder: FormBuilder,
        private wizardHelper: CarrierMaintenanceHelper,
        private wizardService: CarrierMaintenanceService,
        private toasterService: ToasterService,
    ) { }

    ngOnInit() {
        this.alreadyEnabled.value = false;
        this.alreadyEnabled = Object.assign({}, this.alreadyEnabled);
        this.isSearchResultsExpanded = false;
        this.displayTable = false;
        this.orderTypesData = [];
        this.orderTypesMainData = [];
        this.showLoadingScreen = false;
        this.rowData = { ...this.data.dataKey };
        this.allAvailableColumns = {
            "parentCols": [
                { field: "check", editable: true, inputType: 'checkbox' },
                { field: "objId", header: "ObjId", editable: false },
                { field: "orderType", header: "Order Type", editable: false, isOptional: false, length: 30 },
                { field: "npa", header: "NPA", editable: false, isOptional: true, length: 10 },
                { field: "nxx", header: "NXX", editable: false, isOptional: true, length: 10 },
                { field: "billCycle", header: "Bill Cycle", editable: false, isOptional: true, length: 10 },
                { field: "dealerCode", header: "Dealer Code", editable: false, isOptional: true, length: 30 },
                { field: "ldAccountNum", header: "LD Account Num", editable: false, isOptional: true, length: 30 },
                { field: "marketCode", header: "Market Code", editable: false, isOptional: true, length: 30 },
                { field: "orderType2xTransProfile", header: "Order Type2x Trans Profile", editable: false, isOptional: true, isNumber: true, length: 38 },
            ],
            parentDataId: "objId",
            defaultColumnSort: "objId",
            isHeaderCheckBox: true,
            showFilterSection: true,
            isSearchResults: true
        }
        this.copyColumns = {
            "parentCols": [
                { field: "objId", header: "ObjId", editable: false },
                { field: "orderType", header: "Order Type", editable: true, isOptional: false, length: 30 },
                { field: "npa", header: "NPA", editable: true, isOptional: true, length: 10 },
                { field: "nxx", header: "NXX", editable: true, isOptional: true, length: 10 },
                { field: "billCycle", header: "Bill Cycle", editable: true, isOptional: true, length: 10 },
                { field: "dealerCode", header: "Dealer Code", editable: true, isOptional: true, length: 30 },
                { field: "ldAccountNum", header: "LD Account Num", editable: true, isOptional: true, length: 30 },
                { field: "marketCode", header: "Market Code", editable: true, isOptional: true, length: 30 },
                { field: "orderType2xTransProfile", header: "Order Type2x Trans Profile", editable: true, isOptional: true, isNumber: true, length: 38 },
            ],
            parentDataId: "objId",
            defaultColumnSort: "objId",
            showFilterSection: true,
            isWorkArea: true,

        }
        this.orderTypesFields = {
            "parentCols": [
                { field: "objId", header: "ObjId", editable: false },
                { field: "orderType", header: "Order Type", editable: true, isOptional: false, length: 30 },
                { field: "npa", header: "NPA", editable: true, isOptional: true, length: 10 },
                { field: "nxx", header: "NXX", editable: true, isOptional: true, length: 10 },
                { field: "billCycle", header: "Bill Cycle", editable: true, isOptional: true, length: 10 },
                { field: "dealerCode", header: "Dealer Code", editable: true, isOptional: true, length: 30 },
                { field: "ldAccountNum", header: "LD Account Num", editable: true, isOptional: true, length: 30 },
                { field: "marketCode", header: "Market Code", editable: true, isOptional: true, length: 30 },
                { field: "orderType2xTransProfile", header: "Order Type2x Trans Profile", editable: true, isOptional: true, isNumber: true, length: 38 },
            ],
            parentDataId: "objId",
            defaultColumnSort: "objId",
            showFilterSection: true,
            hideDeleteIcon: false
        }

        this.multiColumnEditColumns = [
            { field: "orderType", header: "Order Type", editable: true },
            { field: "npa", header: "NPA", editable: true, isOptional: true, length: 10 },
            { field: "nxx", header: "NXX", editable: true, isOptional: true, length: 10 },
            { field: "billCycle", header: "Bill Cycle", editable: true, isOptional: true, length: 10 },
            { field: "dealerCode", header: "Dealer Code", editable: true, isOptional: true, length: 30 },
            { field: "ldAccountNum", header: "LD Account Num", editable: true, isOptional: true, length: 30 },
            { field: "marketCode", header: "Market Code", editable: true, isOptional: true, length: 30 },
            { field: "orderType2xTransProfile", header: "Order Type2x Trans Profile", editable: true, isOptional: true, isNumber: true, length: 38 },

        ]
        this.createForm();
    }

    createForm() {
        this.frmGroupMain = this._formBuilder.group({
            orderType2xCarrier: ["", [Validators.pattern("^[0-9]*$"), Validators.maxLength(38), Validators.required]],
            orderType: ["", [Validators.maxLength(30)]]
        });
    }

    public onSubmit() {
        this.showLoadingScreen = true;
        this.orderTypesMainData = [];
        this.orderTypesData = [];
        this.selectedOrderTypes = [];
        this.copySelectedOrderTypesRows = [];
        this.isSearchResultsExpanded = false;
        this.copyOrderTypes = false;
        let data: any = [];
        data.data = [];
        this.returnedData.emit({ data: data, status: "selectedData" });
        const obj: any = this.wizardHelper.checkRequestObject(
            this.frmGroupMain.value
        );
        obj.dbEnv = this.wizardHelper.dbEnv;
        this.wizardService
            .viewOrderTypes(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_UNABLE_SEARCH_ORDER_TYPES_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    this.showLoadingScreen = false;
                    this.orderTypesMainData = data[0];
                    this.orderTypesData = [...this.orderTypesMainData];
                    if (data[0] && data[0].length == 0)
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("NO_ORDER_TYPE_FOUND")
                        );
                    else {
                        this.isSearchResultsExpanded = true;
                    }
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null) {
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    }
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }


    // this is use to reset
    public revert() {
        this.frmGroupMain.reset();
        this.orderTypesMainData = [];
        this.orderTypesData = [];
        this.selectedOrderTypes = [];
        this.copySelectedOrderTypesRows = [];
        this.isSearchResultsExpanded = false;
        this.copyOrderTypes = false;
        let data: any = [];
        data.data = [];
        this.returnedData.emit({ data: data, status: "selectedData" });
    }

    public copyOrderTypesButton() {
        this.copyOrderTypes = true;
        this.copySelectedOrderTypesRows = [...this.selectedOrderTypes];
        this.isSearchResultsExpanded = false;
    }

    public removeCopyButton() {
        this.copyOrderTypes = false;
        this.copySelectedOrderTypesRows = [];
        this.isSearchResultsExpanded = true;
        this.multiColumnEditSection = false;
        this.multicolumnEditColumnName = '';
        this.multicolumnEditColumnValue = '';
        this.multicolumnEditCheckbox = '';
    }

    public copyOrderTypesSubmit() {
        if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
            this.toasterService.showErrorMessage(
                this.wizardHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            return;
        }
        this.showLoadingScreen = true;
        this.summaryMainData = [];
        this.summaryData = [];
        let obj: any = [...this.copySelectedOrderTypesRows];
        for (let i = 0; i < obj.length; i++) {
            obj[i].dbEnv = this.wizardHelper.dbEnv;
            obj[i].orderType2xCarrier = this.rowData.objId;
        }
        this.wizardService
            .addOrderTypes(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (returnData: any) => {
                    if (returnData[0] === null || returnData[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_COPY_ORDER_TYPES_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (returnData[0] && returnData[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = returnData[0].ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    this.showLoadingScreen = false;
                    this.summaryMainData = [...returnData[0]];
                    this.summaryData = [...this.summaryMainData];
                    this.displayTable = true;
                    this.revert();
                    let data: any = []
                    data.data = []
                    this.returnedData.emit({ data: data, status: "selectedData" });
                    this.toasterService.showSuccessMessage(
                        this.wizardHelper.getTracfoneConstantMethod("TRACFONE_COPY_ORDER_TYPES_SUCCESS_MESSAGE")
                    );
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null) {
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    }
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    public checkReturnData(returnedData) {
        if (returnedData.status == "save") {
            this.editOrderTypes(returnedData.data);
        } else if (returnedData.status == "editEnableRow") {
            this.returnedData.emit({ status: "editEnableRow" });
        } else if (returnedData.status == "onRowEditCancel") {
            this.returnedData.emit({ status: "onRowEditCancel" });
        } else if (returnedData.status == "selectedData") {
            this.returnedData.emit({ data: returnedData, status: returnedData.status });
            this.selectedOrderTypes = [];
            for (let i = 0; i < returnedData.data.length; i++) {
                let data = { ...returnedData.data[i] }
                this.selectedOrderTypes.push(data);
            }
        } else if (returnedData.status == "alreadyEditEnabled") {
            this.toasterService.showErrorMessage(
                this.wizardHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE")
            )
        } else if (returnedData.status == "validationfailed") {
            this.toasterService.showErrorMessage(
                this.wizardHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
        } else if(returnedData.status == "delete"){
            this.deleteOrderTypes(returnedData)
        }
    }
    public multiColumnEdit(isChecked) {
        if (isChecked.checked)
            this.multiColumnEditSection = true;
        else {
            this.multiColumnEditSection = false;
            this.multicolumnEditColumnName = '';
            this.multicolumnEditColumnValue = '';
        }
    }
    public assignmultiColumnName(column) {
        this.multicolumnEditColumnName = column;
        this.textColumns = true;
    }

    public updatemultiColumnEdit() {
        if (this.textColumns) {
            for (let i = 0; i < this.copySelectedOrderTypesRows.length; i++) {
                this.copySelectedOrderTypesRows[i][this.multicolumnEditColumnName] = this.multicolumnEditColumnValue.nativeElement.value;
            }
            this.multicolumnEditColumnValue.nativeElement.value = '';
        }
        this.copySelectedOrderTypesRows = [...this.copySelectedOrderTypesRows];
        this.multicolumnEditColumnName = '';
        this.multicolumnEditCheckbox.checked = false;
        this.multiColumnEditSection = false;
        this.textColumns = false;
    }

    public editOrderTypes(orderTypeData) {
        this.showLoadingScreen = true;
        let obj: any = {}
        obj = this.wizardHelper.checkRequestObjectSetToNull(
            { ...orderTypeData }
        );
        obj.dbEnv = this.wizardHelper.dbEnv;
        delete obj.check;
        delete obj.children;
        delete obj.isEditable;
        this.wizardService
            .udpateOrderTypes(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_ORDER_TYPES_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    this.showLoadingScreen = false;
                    this.alreadyEnabled.value = false;
                    this.alreadyEnabled = Object.assign({}, this.alreadyEnabled);
                    this.returnedData.emit({ status: "save" });
                    this.summaryData = [...this.summaryData];
                    orderTypeData.isEditable = false;
                    this.toasterService.showSuccessMessage(
                        this.wizardHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_ORDER_TYPES_SUCCESS_MESSAGE")
                    );
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null) {
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    }
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }
    
    public deleteOrderTypes(reqData) {
        this.showLoadingScreen = true;
        let obj: any = {};
        obj.objId = reqData.data.objId;
        obj.dbEnv = this.wizardHelper.dbEnv;
        this.wizardService.deleteOrderType(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DELETE_ORDER_TYPES_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }

                    this.summaryData.splice(reqData.rowIndex, 1);
                    this.summaryData = [...this.summaryData];
                    this.showLoadingScreen = false;
                    this.toasterService.showSuccessMessage(
                        this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DELETE_ORDER_TYPES_SUCCESS_MESSAGE")
                    );
                    if (this.summaryData.length == 0) {
                        this.displayTable = false;
                        this.summaryMainData = [];
                    }
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            )
    }
}