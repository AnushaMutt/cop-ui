import { Component, ViewEncapsulation, OnInit, ChangeDetectorRef, ViewChildren } from "@angular/core";
import { ToasterService } from "../../../../../../../Services/toaster.service";
import { UpdateParentService } from "../../services/update-parent-wizard.service";
import { CarrierMaintenanceHelper } from "../../../../carrier-maintenance-helper";
import { CarrierMaintenanceService } from "../../../../../../../Services/carrierMaintenance.service";
import { takeUntil } from "rxjs/operators";
import { Subject } from "rxjs";
import { MatSelect } from "@angular/material";

@Component({
    selector: 'view-carrier-groups',
    templateUrl: './view-carrier-groups.component.html',
    styleUrls: ['./view-carrier-groups.component.scss',
        '../../../../../../components/ngxtable/material.scss',
        '../../../../../../components/ngxtable/datatable.component.scss',
        '../../../../../../components/ngxtable/icons.css',
        '../../../../../../components/ngxtable/app.css'],
    encapsulation: ViewEncapsulation.None
})

export class ViewCarrierGroupsComponent implements OnInit {

    public carrierGroupFields = [];
    public carrierGroupData = [];
    public carrierGroupMainData = [];
    public displayTable = false;
    public isEditable = {};
    public selectedCG = [];
    public selectedCarrierGroups = [];
    public showLoadingScreen = false;
    public editedRow = {};
    public defaultEditedRow = {};
    public parentData: any;
    public unsubscribe = new Subject<void>();
    @ViewChildren(MatSelect) matSelect: any;

    constructor(
        private toasterService: ToasterService,
        private updateParentService: UpdateParentService,
        private wizardHelper: CarrierMaintenanceHelper,
        private wizardService: CarrierMaintenanceService,
    ) { }

    ngOnInit() {
        this.parentData = this.updateParentService.getParentData();
        this.selectedCarrierGroups = [];
        this.carrierGroupData = [];
        this.carrierGroupMainData = [];
        this.showLoadingScreen = false;
        this.carrierGroupFields = [
            { name: "ObjId", prop: "objId", width: "100" },
            { name: "Carrier Group Id", prop: "carrierGroupId", width: "150" },
            { name: "Carrier Name", prop: "carrierName", width: "300" },
            { name: "Status", prop: "status", width: "150" },
            { name: "Group2 Address", prop: "group2Address", width: "150" },
            { name: "No Auto Part", prop: "noAutoPart", width: "150" }
        ];

        if (this.updateParentService.getCarrierGroupData() && this.updateParentService.getCarrierGroupData().length > 0) {
            this.displayTable = true;
            for (let i = 0; i < this.updateParentService.getCarrierGroupData().length; i++) {
                this.selectedCarrierGroups.push(this.updateParentService.getCarrierGroupData()[i]);
            }
            this.updateParentService.isAppCarrierGroupTableActivated(true);
        }
        this.getCarrierGroups();
    }

    public getCarrierGroups() {
        this.showLoadingScreen = true;
        this.carrierGroupMainData = [];
        this.carrierGroupData = [];
        this.displayTable = false;
        let obj: any = {};
        obj.dbEnv = this.wizardHelper.dbEnv;
        obj.carrierGroup2Parent = this.parentData.objId;
        this.wizardService
            .searchCarrierGroups(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_UNABLE_SEARCH_CARRIER_GROUPS_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    this.showLoadingScreen = false;
                    this.displayTable = true;
                    this.carrierGroupMainData = data[0];
                    this.carrierGroupData = [...this.carrierGroupMainData];
                    if (data[0] && data[0].length == 0)
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("NO_CARRIER_GROUPS_FOUND")
                        );
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null) {
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    }
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    public onSelect(row) {
        this.selectedCarrierGroups.splice(0, this.selectedCarrierGroups.length);
        this.selectedCarrierGroups.push(...row.selected);
        this.updateParentService.setCarrierGroupData(this.selectedCarrierGroups);
        if (this.selectedCarrierGroups.length > 0)
            this.updateParentService.isAppCarrierGroupTableActivated(true);
        else
            this.updateParentService.isAppCarrierGroupTableActivated(false);
    }

    public editButtonClicked(rowIndex) {
        let alreadyEnabled = false;
        for (let i = 0; i < this.carrierGroupData.length; i++) {
            if (this.isEditable[i])
                alreadyEnabled = true;
        }
        if (!alreadyEnabled)
            this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        else
            this.toasterService.showErrorMessage(
                this.wizardHelper.getTracfoneConstantMethod("COMPLETE_PREVIOUS_ACTION"),
            );
    }

    // cancel
    public cancelEditForm(rowData, rowIndex) {
        this.showLoadingScreen = true;
        this.isEditable[rowIndex] = !this.isEditable[rowIndex];

        this.carrierGroupFields.forEach(parent => {
            if (document.getElementById(parent.prop + rowIndex)) {
                (<HTMLInputElement>(
                    document.getElementById(parent.prop + rowIndex)
                )).value = rowData[parent.prop] || '';
            }
        });

        this.matSelect._results.forEach(matSelectData => {
            if (matSelectData.id.indexOf('status' + rowIndex) == 0)
                matSelectData.value = rowData['status'] || '';
        });

        this.editedRow = {};
        this.showLoadingScreen = false;
    }
    //check inline values
    public inputValueChanged(event, column, row, oldValue) {
        if (column != "status") {
            this.editedRow[column] = event.target.value;
            this.defaultEditedRow[column] = event.target.defaultValue;
        } else {
            this.editedRow[column] = event.value;
            this.defaultEditedRow[column] = oldValue;
        }
    }

    public editCarrierGroup(row, rowIndex) {
        if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
            this.toasterService.showErrorMessage(
                this.wizardHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            return;
        }
        this.showLoadingScreen = true;
        let obj: any = {};
        obj = { ...row, ...this.editedRow };
        obj.dbEnv = this.wizardHelper.dbEnv;
        this.wizardService
            .udpateCarrierGroups(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_CARRIER_GROUP_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    for (let i = 0; i < this.carrierGroupMainData.length; i++) {
                        if (this.carrierGroupMainData[i].objId == obj.objId) {
                            this.carrierGroupMainData[i] = { ...obj };
                        }
                    }
                    this.carrierGroupData = [...this.carrierGroupMainData];
                    this.isEditable[rowIndex] = !this.isEditable[rowIndex];
                    this.editedRow = {};
                    this.defaultEditedRow = {};
                    this.showLoadingScreen = false;
                    this.toasterService.showSuccessMessage(
                        this.wizardHelper.getTracfoneConstantMethod("TRACFONE_SUCCESS_UPDATE_CARRIER_GROUP_MESSAGE")
                    );

                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null) {
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    }
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    public updateCarrierGroupDataTable(event) {
        const val = event.target.value.toLowerCase();
        // filter our data
        const temp = this.carrierGroupMainData.filter(function (d) {
            return (d.carrierName ? d.carrierName.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.status ? d.status.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.objId ? d.objId.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.group2Address ? d.group2Address.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.parent2TempQueue ? d.parent2TempQueue.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.noAutoPart ? d.noAutoPart.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.carrierGroup2Parent ? d.carrierGroup2Parent.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.carrierGroupId ? d.carrierGroupId.toLowerCase().indexOf(val) !== -1 : !val) || !val
        });
        // update the rows
        this.carrierGroupData = temp;
    }

    rowIdentity = (row: any) => {
        return row.objId;
    }
}