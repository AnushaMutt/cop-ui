import { Component, OnInit } from "@angular/core";
import { UpdateParentService } from "../../services/update-parent-wizard.service";
import { CarrierMaintenanceHelper } from "../../../../carrier-maintenance-helper";
import { CarrierMaintenanceService } from "../../../../../../../Services/carrierMaintenance.service";
import { takeUntil } from "rxjs/operators";
import { ToasterService } from "../../../../../../../Services/toaster.service";
import { Subject } from "rxjs";
import { MatDialog } from "@angular/material";
import { UpdateCarrierDialogComponent } from "./update-carriers-dialog/update-carriers-dialog.component";
import { OrderTypesDialogComponent } from "./order-types-dialog/order-types-dialog.component";

@Component({
    selector: "view-carrier",
    templateUrl: "./view-carriers.component.html",
    styleUrls: ["./view-carriers.component.scss"]
})
export class ViewCarriersComponent implements OnInit {

    public firstAvailableColumnsFields = [];
    public secondAvilableColumnsFields = [];
    public thirdAvailableColumnsFields = [];
    public stepCarrierData: any;
    public showLoadingScreen = false;
    public carrierData = [];
    public carrierMainData = [];
    public unsubscribe = new Subject<void>();
    public showCarriers = false;

    constructor(
        private upadteParentService: UpdateParentService,
        private wizardHelper: CarrierMaintenanceHelper,
        private wizardService: CarrierMaintenanceService,
        private toasterService: ToasterService,
        public dialog: MatDialog
    ) { }

    ngOnInit() {
        this.carrierData = [];
        this.carrierMainData = [];
        this.showLoadingScreen = false;
        this.showCarriers = false;
        this.stepCarrierData = this.upadteParentService.getCarrierGroupData();

        this.firstAvailableColumnsFields = [
            { name: 'OBJID', prop: 'objId' },
            { name: 'ACT ANALOG', prop: 'actAnalog' },
            { name: 'ACT TECHNOLOGY', prop: 'actTechnology' },
            { name: 'ACTIVE LINE PERCENT', prop: 'activeLinePercent' },
            { name: 'AUTOMATED', prop: 'automated' },
            { name: 'BILL DATE', prop: 'billDate' },
            { name: 'CALL WAITING', prop: 'callWaiting' },
            { name: 'CARRIER ID', prop: 'carrierId' },
            { name: 'CARRIER2 ADDRESS', prop: 'carrier2Address' },
            { name: 'CARRIER2 CARR SCRIPT', prop: 'carrier2CarrScript' },
            { name: 'CARRIER2 PERSONALITY', prop: 'carrier2Personality' },
            { name: 'CARRIER2 PROVIDER', prop: 'carrier2Provider' },
            { name: 'CARRIER2 RULE', prop: 'carrier2Rule' },
            { name: 'CARRIER2 RULES CDMA', prop: 'carrier2RulesCdma' },
            { name: 'CARRIER2 RULES GSM', prop: 'carrier2RulesGsm' },
            { name: 'CARRIER2 RULES TDMA', prop: 'carrier2RulesTdma' },
            { name: 'CITY', prop: 'city' },
        ];

        this.secondAvilableColumnsFields = [
            { name: 'COUNTRY CODE', prop: 'countryCode' },
            { name: 'CW CODE', prop: 'cwCode' },
            { name: 'CW PACKAGE', prop: 'cwPackage' },
            { name: 'DATA SERVICE', prop: 'dataService' },
            { name: 'DIGITAL FEATURE', prop: 'digitalFeature' },
            { name: 'DIGITAL RATE PLAN', prop: 'digitalRatePlan' },
            { name: 'DUMMY ESN', prop: 'dummyEsn' },
            { name: 'ID CODE', prop: 'idCode' },
            { name: 'ID PACKAGE', prop: 'idPackage' },
            { name: 'LD ACCOUNT', prop: 'ldAccount' },
            { name: 'LD PIC CODE', prop: 'ldPicCode' },
            { name: 'LD PROVIDER', prop: 'ldProvider' },
            { name: 'NEW ANALOG PLAN', prop: 'newAnalogPlan' },
            { name: 'NEW DIGITAL PLAN', prop: 'newDigitalPlan' },
            { name: 'PRL PRE LOADED', prop: 'prlPreLoaded' },
            { name: 'RATE PLAN', prop: 'ratePlan' },
        ];

        this.thirdAvailableColumnsFields = [
            { name: 'REACT TECHNOLOGY', prop: 'reactTechnology' },
            { name: 'REACT ANALOG', prop: 'reactAnalog' },
            { name: 'SMS', prop: 'sms' },
            { name: 'SMS CODE', prop: 'smsCode' },
            { name: 'SMS PACKAGE', prop: 'smsPackage' },
            { name: 'SPECIAL MKT', prop: 'specialMkt' },
            { name: 'STATE', prop: 'state' },
            { name: 'STATUS', prop: 'status' },
            { name: 'SUB MARKET NAME', prop: 'submarketName' },
            { name: 'SUB MARKET OF', prop: 'submarketOf' },
            { name: 'TAPE RETURN ADDR2 ADDRESS', prop: 'tapeReturnAddr2Address' },
            { name: 'TAPE RETURN CHARGE', prop: 'tapeReturnCharge' },
            { name: 'VM CODE', prop: 'vmCode' },
            { name: 'VM PACKAGE', prop: 'vmPackage' },
            { name: 'VM SET UP LAND LINE', prop: 'vmSetUpLandLine' },
            { name: 'VOICE MAIL', prop: 'voiceMail' },
        ];

        this.getCarriers();
    }

    public getCarriers() {
        this.showLoadingScreen = true;
        this.carrierData = [];
        this.carrierMainData = [];
        let obj: any = {};
        obj.dbEnv = this.wizardHelper.dbEnv;
        obj.carrier2CarrierGroups = [];
        for(let i=0;i<this.stepCarrierData.length;i++){
            obj.carrier2CarrierGroups.push(this.stepCarrierData[i].objId);
        }
        this.wizardService
            .searchCarrier(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_UNABLE_SEARCH_CARRIER_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    this.showLoadingScreen = false;
                    this.showCarriers = true;
                    this.carrierMainData = data[0];
                    for (let i = 0; i < this.carrierMainData.length; i++) {
                        if(this.carrierMainData[i].billDate)
                            this.carrierMainData[i].billDate = this.carrierMainData[i].billDate.split(" ")[0];
                    }
                    this.carrierData = [...this.carrierMainData];
                    if (data[0] && data[0].length == 0)
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("NO_CARRIERS_FOUND")
                        );
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null) {
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    }
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    public updateCarrierTable(event) {
        const val = event.target.value.toLowerCase();


        const temp = this.carrierMainData.filter(function (d) {

            return (d.objId ? d.objId.indexOf(val) !== -1 : !val)
                || (d.carrierId ? d.carrierId.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.submarketName ? d.submarketName.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.submarketOf ? d.submarketOf.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.city ? d.city.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.state ? d.state.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.tapeReturnCharge ? d.tapeReturnCharge.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.activeLinePercent ? d.activeLinePercent.toLowerCase().indexOf(val) !== -1 : !val)

                || (d.status ? d.status.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.ldProvider ? d.ldProvider.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.ldAccount ? d.ldAccount.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.carrier2Personality ? d.carrier2Personality.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.carrier2Rule ? d.carrier2Rule.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.carrier2CarrScript ? d.carrier2CarrScript.toLowerCase().indexOf(val) !== -1 : !val)

                || (d.specialMkt ? d.specialMkt.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.newAnalogPlan ? d.newAnalogPlan.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.ldPicCode ? d.ldPicCode.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.ratePlan ? d.ratePlan.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.dummyEsn ? d.dummyEsn.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.billDate ? d.billDate.indexOf(val) !== -1 : !val)
                || (d.vmPackage ? d.vmPackage.toLowerCase().indexOf(val) !== -1 : !val)

                || (d.vmCode ? d.vmCode.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.voiceMail ? d.voiceMail.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.callerId ? d.callerId.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.idCode ? d.idCode.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.idPackage ? d.idPackage.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.callWaiting ? d.callWaiting.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.cwCode ? d.cwCode.toLowerCase().indexOf(val) !== -1 : !val)

                || (d.newDigitalPlan ? d.newDigitalPlan.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.sms ? d.sms.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.smsCode ? d.smsCode.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.smsPackage ? d.smsPackage.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.cwPackage ? d.cwPackage.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.reactTechnology ? d.reactTechnology.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.reactAnalog ? d.reactAnalog.toLowerCase().indexOf(val) !== -1 : !val) || !val

                || (d.actTechnology ? d.actTechnology.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.actAnalog ? d.actAnalog.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.digitalRatePlan ? d.digitalRatePlan.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.digitalFeature ? d.digitalFeature.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.prlPreLoaded ? d.prlPreLoaded.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.carrier2CarrierGroup ? d.carrier2CarrierGroup.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.tapeReturnAddr2Address ? d.tapeReturnAddr2Address.toLowerCase().indexOf(val) !== -1 : !val) || !val

                || (d.carrier2Provider ? d.carrier2Provider.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.carrier2Address ? d.carrier2Address.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.carrier2RulesCdma ? d.carrier2RulesCdma.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.carrier2RulesGsm ? d.carrier2RulesGsm.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.carrier2RulesTdma ? d.carrier2RulesTdma.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.dataService ? d.dataService.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.automated ? d.automated.toLowerCase().indexOf(val) !== -1 : !val) || !val;
        });

        this.carrierData = temp;
    }

    //opens the update carrier dialog window
    updateCarrierDialog(carrierValue) {
        const dialogRef = this.dialog.open(UpdateCarrierDialogComponent, {
            width: "90%",
            height: "90%",
            data: {
                dataKey: carrierValue,
            },
        });
        // Create subscription
        dialogRef.afterClosed().subscribe((isRefresh) => {
            // Do stuff after the dialog has closed
            if (isRefresh)
                this.getCarriers();
        });
    }

    //opens the order Types dialog window
    orderTypeDialog(carrierValue) {
        const dialogRef = this.dialog.open(OrderTypesDialogComponent, {
            width: "90%",
            height: "90%",
            data: {
                dataKey: carrierValue,
            },
        });
    }
}