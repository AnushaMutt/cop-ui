import { Component, OnInit, ViewEncapsulation, ViewChildren, SimpleChanges, Input } from "@angular/core";
import { FormGroup, Validators, FormBuilder } from "@angular/forms";
import { UpdateParentService } from "../services/update-parent-wizard.service";
import { ToasterService } from "../../../../../../Services/toaster.service";
import { CarrierMaintenanceHelper } from "../../../carrier-maintenance-helper";
import { takeUntil } from "rxjs/operators";
import { Subject } from "rxjs";
import { CarrierMaintenanceService } from "../../../../../../Services/carrierMaintenance.service";
import { MatSelect } from "@angular/material";

@Component({
    selector: 'step-parent',
    templateUrl: './step-parents.component.html',
    styleUrls: ['./step-parents.component.scss',
        "../../../../../components/ngxtable/material.scss",
        "../../../../../components/ngxtable/datatable.component.scss",
        "../../../../../components/ngxtable/icons.css",
        "../../../../../components/ngxtable/app.css"],
    animations: [],
    encapsulation: ViewEncapsulation.None,
})
export class StepParentComponent implements OnInit {

    @Input('clearData') clearData: any;
    @ViewChildren(MatSelect) matSelect: any;
    public frmGroupMain: FormGroup;
    public patrentTableData = [];
    public parentTableMainData = [];
    public selectedParents = [];
    public parentFields = [];
    public isEditable = {};
    public showLoadingScreen = false;
    public editedRow = {};
    public defaultEditedRow = {};
    public unsubscribe = new Subject<void>();

    constructor(
        private _formBuilder: FormBuilder,
        private updateParentService: UpdateParentService,
        private toasterService: ToasterService,
        private wizardHelper: CarrierMaintenanceHelper,
        private wizardService: CarrierMaintenanceService
    ) { }

    ngOnInit() {
        this.showLoadingScreen = false;
        this.createForm();
        this.patrentTableData = [];
        this.parentTableMainData = [];
        this.parentFields = [
            { name: "Parent Id", prop: "parentId", width: "150" },
            { name: "Parent Name", prop: "xParentName", width: "300" },
            { name: "Status", prop: "status", width: "150" },
            { name: "Parent Short Name", prop: "parentShortName", width: "150" },
            { name: "Hold Analog Deac", prop: "holdAnalogDeac", width: "150" },
            { name: "Hold Digital Deac", prop: "holdDigitalDeac", width: "150" },
            { name: "Parent2 Temp Queue", prop: "parent2TempQueue", width: "150" },
            { name: "No Invetory", prop: "noInventory", width: "150" },
            { name: "Vm Access Num", prop: "vmAccessNum", width: "150" },
            { name: "Auto Port In", prop: "autoPortIn", width: "150" },
            { name: "Auto Port Out", prop: "autoPortOut", width: "150" },
            { name: "No MSID", prop: "noMsid", width: "150" },
            { name: "OTA Carrier", prop: "otaCarrier", width: "200" },
            { name: "OTA Start Date", prop: "otaStartDate", width: "200" },
            { name: "OTA End Date", prop: "otaEndDate", width: "200" },
            { name: "OTA PSMS Address", prop: "otaPsmsAddress", width: "200" },
            { name: "Next Available", prop: "nextAvailable", width: "150" },
            { name: "Queue Name", prop: "queueName", width: "250" },
            { name: "Block Port In", prop: "blockPortIn", width: "150" },
            { name: "MEID Carrier", prop: "meidCarrier", width: "150" },
            { name: "OTA React", prop: "otaReact", width: "150" },
            { name: "AGG Carr Code", prop: "aggCarrCode", width: "150" },
            { name: "SUI Rule Obj Id", prop: "suiRuleObjId", width: "200" },
            { name: "Deact SIM EP Days", prop: "deactSimEpDays", width: "250" },
            { name: "Override SMS Address", prop: "overrideSmsAddress", width: "150" },
            { name: "Trigger Id", prop: "triggerId", width: "150" },
        ];
    }

    ngOnChanges(changes: SimpleChanges) {
        if (changes.clearData.currentValue) {
            this.revert();
        }
    }

    createForm() {
        this.frmGroupMain = this._formBuilder.group({
            parentName: ["", [Validators.maxLength(40)]],
            parentId: ["", [Validators.maxLength(30)]],
            status: ["", [Validators.maxLength(30)]],
        });
    }

    public onSubmit() {
        if (this.frmGroupMain.valid) {
            this.selectedParents = [];
            this.parentTableMainData = [];
            this.patrentTableData = [];
            this.isEditable = {};
            this.updateParentService.isAppStepParentTableActivated(false);
            this.showLoadingScreen = true;
            const obj: any = this.wizardHelper.checkRequestObject(
                this.frmGroupMain.value
            );
            obj.dbEnv = this.wizardHelper.dbEnv;
            this.wizardService
                .searchParent(obj)
                .pipe(takeUntil(this.unsubscribe))
                .subscribe(
                    (data: any) => {
                        if (data[0] === null || data[0] === undefined) {
                            this.showLoadingScreen = false;
                            this.toasterService.showErrorMessage(
                                this.wizardHelper.getTracfoneConstantMethod("TRACFONE_UNABLE_SEARCH_MESSAGE")
                            );
                            return;
                        }
                        if (data[0] && data[0].ERR) {
                            this.showLoadingScreen = false;
                            const commaSeperatedArr = data[0].ERR.split(",");
                            for (
                                let i = commaSeperatedArr.length - 1;
                                i >= 0;
                                i--
                            ) {
                                if (commaSeperatedArr[i] != "")
                                    this.toasterService.showErrorMessage(
                                        commaSeperatedArr[i]
                                    );
                            }
                            return;
                        }
                        this.showLoadingScreen = false;
                        this.parentTableMainData = data[0];
                        for (let i = 0; i < this.parentTableMainData.length; i++) {
                            if (this.parentTableMainData[i].otaEndDate != null)
                                this.parentTableMainData[i].otaEndDate = this.parentTableMainData[i].otaEndDate.split(" ")[0];
                            if (this.parentTableMainData[i].otaStartDate != null)
                                this.parentTableMainData[i].otaStartDate = this.parentTableMainData[i].otaStartDate.split(" ")[0];
                        }
                        this.patrentTableData = [...this.parentTableMainData];
                        if (data[0] && data[0].length == 0)
                            this.toasterService.showErrorMessage(
                                this.wizardHelper.getTracfoneConstantMethod("NO_PARENTS_FOUND")
                            );
                    },
                    (err: any) => {
                        this.showLoadingScreen = false;
                        if (err.error === undefined || err.error === null) {
                            this.toasterService.showErrorMessage(
                                this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                            );
                        }
                        else if (err.error && err.error.ERR) {
                            const commaSeperatedArr = err.error.ERR.split(",");
                            for (
                                let i = commaSeperatedArr.length - 1;
                                i >= 0;
                                i--
                            ) {
                                if (commaSeperatedArr[i] != "")
                                    this.toasterService.showErrorMessage(
                                        commaSeperatedArr[i]
                                    );
                            }
                        }
                        else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                            return;
                        else this.toasterService.showErrorMessage(err.error);
                    }
                );
        }
    }

    public onSelect(row) {
        this.selectedParents = [];
        this.selectedParents.push(row);
        this.updateParentService.setParentData(row);
        this.updateParentService.isAppStepParentTableActivated(true);
        this.wizardHelper.updateBreadcrumbList(row.xParentName, 2);
    }

    // this is use to reset
    public revert() {
        this.wizardHelper.deleteBreadcrumbList(2);
        if (this.frmGroupMain)
            this.frmGroupMain.reset();
        this.parentTableMainData = [];
        this.patrentTableData = [];
        this.updateParentService.isAppStepParentTableActivated(false);
    }

    editButtonClicked(rowIndex) {
        let alreadyEnabled = false;
        this.updateParentService.isAppStepParentTableActivated(false);
        for (let i = 0; i < this.patrentTableData.length; i++) {
            if (this.isEditable[i])
                alreadyEnabled = true;
        }
        if (!alreadyEnabled)
            this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        else
            this.toasterService.showErrorMessage(
                this.wizardHelper.getTracfoneConstantMethod("COMPLETE_PREVIOUS_ACTION"),
            );
    }

    // cancel
    public cancelEditForm(rowData, rowIndex) {
        this.showLoadingScreen = true;
        this.isEditable[rowIndex] = !this.isEditable[rowIndex];

        this.parentFields.forEach(parent => {
            if (document.getElementById(parent.prop + rowIndex)) {
                (<HTMLInputElement>(
                    document.getElementById(parent.prop + rowIndex)
                )).value = rowData[parent.prop] || '';
            }
        });

        this.matSelect._results.forEach(matSelectData => {
            if (matSelectData.id.indexOf('status' + rowIndex) == 0)
                matSelectData.value = rowData['status'] || '';
        });

        if (this.selectedParents.length > 0)
            this.updateParentService.isAppStepParentTableActivated(true);
        this.editedRow = {};
        this.showLoadingScreen = false;
    }
    //check inline values
    public inputValueChanged(event, column, row, oldValue) {
        if (column != "status" && column != "otaEndDate" && column != "otaStartDate") {
            this.editedRow[column] = event.target.value;
            this.defaultEditedRow[column] = event.target.defaultValue;
        } else if (column == "otaEndDate" || column == "otaStartDate") {
            this.editedRow[column] = this.controlDateToStringDate(event.target.value, "-");
            this.defaultEditedRow[column] = event.target.defaultValue;
        } else {
            this.editedRow[column] = event.value;
            this.defaultEditedRow[column] = oldValue;
        }
    }

    public updateParentDataTable(event) {
        const val = event.target.value.toLowerCase();
        // filter our data
        const temp = this.parentTableMainData.filter(function (d) {
            return (d.xParentName ? d.xParentName.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.parentShortName ? d.parentShortName.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.status ? d.status.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.parentId ? d.parentId.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.objId ? d.objId.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.holdAnalogDeac ? d.holdAnalogDeac.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.holdDigitalDeac ? d.holdDigitalDeac.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.parent2TempQueue ? d.parent2TempQueue.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.noInventory ? d.noInventory.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.vmAccessNum ? d.vmAccessNum.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.autoPortIn ? d.autoPortIn.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.autoPortOut ? d.autoPortOut.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.noMsid ? d.noMsid.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.otaCarrier ? d.otaCarrier.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.otaEndDate ? d.otaEndDate.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.otaPsmsAddress ? d.otaPsmsAddress.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.otaStartDate ? d.otaStartDate.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.nextAvailable ? d.nextAvailable.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.queueName ? d.queueName.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.blockPortIn ? d.blockPortIn.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.meidCarrier ? d.meidCarrier.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.otaReact ? d.otaReact.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.aggCarrCode ? d.aggCarrCode.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.suiRuleObjId ? d.suiRuleObjId.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.deactSimExpDays ? d.deactSimExpDays.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.overrideSmsAddress ? d.overrideSmsAddress.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.triggerId ? d.triggerId.toLowerCase().indexOf(val) !== -1 : !val) || !val

        });
        // update the rows
        this.patrentTableData = temp;
    }

    // Save row
    updateParentTable(row, rowIndex) {
        if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
            this.toasterService.showErrorMessage(
                this.wizardHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            return;
        }
        this.showLoadingScreen = true;
        let obj = { ...row, ...this.editedRow };
        obj = this.wizardHelper.checkRequestObjectSetToNull(obj);
        obj.parentName = obj.xParentName
        obj.dbEnv = this.wizardHelper.dbEnv;
        this.wizardService
            .udpateParent(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;

                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_UNABLE_UPDATE_PARENTS")
                        );

                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                            this.editedRow = [];
                        }
                        return;
                    }
                    for (let i = 0; i < this.parentTableMainData.length; i++) {
                        if (this.parentTableMainData[i].objId == obj.objId) {
                            this.parentTableMainData[i] = obj;
                        }
                    }
                    this.patrentTableData = [...this.parentTableMainData];
                    this.showLoadingScreen = false;
                    this.isEditable[rowIndex] = !this.isEditable[rowIndex];
                    this.editedRow = {};
                    this.defaultEditedRow = {};
                    if (this.selectedParents.length > 0)
                        this.updateParentService.isAppStepParentTableActivated(true);
                    this.toasterService.showSuccessMessage(
                        this.wizardHelper.getTracfoneConstantMethod("TRACFONE_PARENT_UPDATE_SUCCESS_MESSAGE")
                    );
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null) {
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    }
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    /**
    * Converts the java script object date from datepicker
    * to a string formatted date YYYY-MM-DD.
    */
    public controlDateToStringDate(controlDate: any, dateSeparator?: string): string {
        var formattedDate = '';

        if (dateSeparator == null) dateSeparator = '-';

        try {
            if (controlDate != null) {
                var year = controlDate.getUTCFullYear();
                var month = controlDate.getMonth() + 1;
                var day = controlDate.getDate();
            }
        } catch (Exception) {
            return '';
        }

        if (month < 10) {
            month = 0 + "" + month;
        }
        if (day < 10) {
            day = 0 + "" + day;
        }
        // Format YYYY-MM-DD.
        if (year != null && month != null && day != null) {
            formattedDate = year + dateSeparator + month + dateSeparator + day;
        }

        return formattedDate;
    }
}