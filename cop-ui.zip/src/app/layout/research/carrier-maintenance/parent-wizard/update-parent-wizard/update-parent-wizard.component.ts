import { Component, OnInit, ViewChild, Input, SimpleChanges } from "@angular/core";
import { MatDialog, MatStepper } from "@angular/material";
import { Router } from "@angular/router";
import { UpdateParentService } from "./services/update-parent-wizard.service";

@Component({
    selector: 'update-parent-wizard',
    templateUrl: './update-parent-wizard.component.html',
    styleUrls: ['./update-parent-wizard.component.scss']
})
export class UpdateParentWizardComponent implements OnInit {

    @Input("clearData") clearData: any;
    readonly STEP_PARENTS = 0;
    readonly STEP_CARRIER_GROUPS = 1;
    readonly STEP_CARRIERS = 2;
    @ViewChild('insertWizardStepper') insertWizardStepper: MatStepper;
    isAppParentStepActivated: boolean = false;
    isAppCarrierGroupStepActivated: boolean = false;
    isAppCarrierStepActivated: boolean = false;
    currentStep = 0;
    public isLinear = true;
    public showLoadingScreen = false;

    constructor(
        private router: Router,
        private dialog: MatDialog,
        private udpateParentService: UpdateParentService
    ) { }
    ngOnInit() {

        this.udpateParentService.isAppStepParentActive.subscribe(
            isActivated => {
                this.isAppParentStepActivated = isActivated;
            }
        );
        this.udpateParentService.isAppStepCarrierGroupActive.subscribe(
            isActivated => {
                this.isAppCarrierGroupStepActivated = isActivated;
            }
        );
        this.udpateParentService.isAppStepCarrierActive.subscribe(
            isActivated => {
                this.isAppCarrierStepActivated = isActivated;
            }
        );
        this.udpateParentService.currentStep.subscribe(currentStep => {
            this.currentStep = currentStep;
        });
    }

    ngOnChanges(changes: SimpleChanges){
        if(changes.clearData.currentValue){
            this.insertWizardStepper.selectedIndex = 0;
        }
    }

    public gotToNextStep(insertWizardStepper) {
        if (insertWizardStepper._selectedIndex == this.STEP_PARENTS) {
            this.currentStep = 1;
            insertWizardStepper.next();
        } else if (insertWizardStepper._selectedIndex == this.STEP_CARRIER_GROUPS) {
            this.currentStep = 2;
            insertWizardStepper.next();
        } else {
            return;
        }
    }

    /**
   * Previous step in the stepper.
   */
    public gotToPreviousStep(insertWizardStepper) {
        if (insertWizardStepper._selectedIndex == this.STEP_CARRIER_GROUPS) {
            this.currentStep = 0;
            insertWizardStepper.previous();
            this.udpateParentService.setCarrierGroupData([]);
            this.isAppCarrierGroupStepActivated = false;
        } else if (insertWizardStepper._selectedIndex == this.STEP_CARRIERS) {
            this.currentStep = 1;
            insertWizardStepper.previous();
        }
    }

    /**
       * Done step in the stepper.
       */
    public gotTodoneStep() {
        //this.router.navigate(['/dashboard']);
        window.location.reload();
    }
}

