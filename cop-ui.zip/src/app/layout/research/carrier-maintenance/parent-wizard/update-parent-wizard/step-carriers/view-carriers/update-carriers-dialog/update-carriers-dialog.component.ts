import { Component, ViewEncapsulation, OnInit, Inject } from "@angular/core";
import { ConfirmationService } from "primeng/api";
import { Subject } from "rxjs";
import { FormGroup, Validators, FormBuilder } from "@angular/forms";
import { MAT_DIALOG_DATA, MatDialogRef, MatDialog} from "@angular/material";
import { CarrierMaintenanceHelper } from "../../../../../carrier-maintenance-helper";
import { takeUntil } from "rxjs/operators";
import { ToasterService } from "../../../../../.././../../Services/toaster.service";
import { CarrierMaintenanceService } from "../../../../../.././../../Services/carrierMaintenance.service";
import { CarrierRulesDialogComponent } from "../carrier-rules-dialog/carrier-rules-dialog.component";


@Component({
    selector: "update-carrier-dialog",
    templateUrl: "./update-carriers-dialog.component.html",
    styleUrls: [
        "./update-carriers-dialog.component.scss"
    ],
    animations: [],
    encapsulation: ViewEncapsulation.None,
    providers: [ConfirmationService]
})
export class UpdateCarrierDialogComponent implements OnInit {

    public unsubscribe = new Subject<void>();
    public showLoadingScreen = false;
    public rowData: any
    public firstAvailableColumnsFields: any = [];
    public secondAvilableColumnsFields: any = [];
    public thirdAvailableColumnsFields: any = [];
    public availableColumnsFieldsTemp: any = [];
    public searchResultFetchedValue: any = {};
    public updateCarrierFormGroup: any;

    constructor(
        public dialogRef: MatDialogRef<UpdateCarrierDialogComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any,
        private _formBuilder: FormBuilder,
        private confirmationService: ConfirmationService,
        private wizardHelper: CarrierMaintenanceHelper,
        private toasterService: ToasterService,
        private wizardService: CarrierMaintenanceService,
        public dialog: MatDialog,
    ) { dialogRef.disableClose = true; this.updateCarrierFormGroup = new FormGroup({}); }

    ngOnInit() {
        //getting carrier values
        this.rowData = { ...this.data.dataKey };
        
        this.firstAvailableColumnsFields = [
            { name: 'OBJID', prop: 'objId' },
            { name: 'ACT ANALOG', prop: 'actAnalog' },
            { name: 'ACT TECHNOLOGY', prop: 'actTechnology' },
            { name: 'ACTIVE LINE PERCENT', prop: 'activeLinePercent' },
            { name: 'AUTOMATED', prop: 'automated' },
            { name: 'CALL WAITING', prop: 'callWaiting' },
            { name: 'CARRIER ID', prop: 'carrierId' },
            { name: 'CARRIER2 ADDRESS', prop: 'carrier2Address' },
            { name: 'CARRIER2 CARR SCRIPT', prop: 'carrier2CarrScript' },
            { name: 'CARRIER2 PERSONALITY', prop: 'carrier2Personality' },
            { name: 'CARRIER2 PROVIDER', prop: 'carrier2Provider' },
            { name: 'CARRIER2 RULE', prop: 'carrier2Rule' },
            { name: 'CARRIER2 RULES CDMA', prop: 'carrier2RulesCdma' },
            { name: 'CARRIER2 RULES GSM', prop: 'carrier2RulesGsm' },
            { name: 'CARRIER2 RULES TDMA', prop: 'carrier2RulesTdma' },
            { name: 'CITY', prop: 'city' },
            { name: 'BILL DATE', prop: 'billDate' },
        ];

        this.secondAvilableColumnsFields = [
            { name: 'COUNTRY CODE', prop: 'countryCode' },
            { name: 'CW CODE', prop: 'cwCode' },
            { name: 'CW PACKAGE', prop: 'cwPackage' },
            { name: 'DATA SERVICE', prop: 'dataService' },
            { name: 'DIGITAL FEATURE', prop: 'digitalFeature' },
            { name: 'DIGITAL RATE PLAN', prop: 'digitalRatePlan' },
            { name: 'DUMMY ESN', prop: 'dummyEsn' },
            { name: 'ID CODE', prop: 'idCode' },
            { name: 'ID PACKAGE', prop: 'idPackage' },
            { name: 'LD ACCOUNT', prop: 'ldAccount' },
            { name: 'LD PIC CODE', prop: 'ldPicCode' },
            { name: 'LD PROVIDER', prop: 'ldProvider' },
            { name: 'NEW ANALOG PLAN', prop: 'newAnalogPlan' },
            { name: 'NEW DIGITAL PLAN', prop: 'newDigitalPlan' },
            { name: 'PRL PRE LOADED', prop: 'prlPreLoaded' },
            { name: 'RATE PLAN', prop: 'ratePlan' },
        ];

        this.thirdAvailableColumnsFields = [
            { name: 'REACT TECHNOLOGY', prop: 'reactTechnology' },
            { name: 'REACT ANALOG', prop: 'reactAnalog' },
            { name: 'SMS', prop: 'sms' },
            { name: 'SMS CODE', prop: 'smsCode' },
            { name: 'SMS PACKAGE', prop: 'smsPackage' },
            { name: 'SPECIAL MKT', prop: 'specialMkt' },
            { name: 'STATE', prop: 'state' },
            { name: 'STATUS', prop: 'status' },
            { name: 'SUB MARKET NAME', prop: 'submarketName' },
            { name: 'SUB MARKET OF', prop: 'submarketOf' },
            { name: 'TAPE RETURN ADDR2 ADDRESS', prop: 'tapeReturnAddr2Address' },
            { name: 'TAPE RETURN CHARGE', prop: 'tapeReturnCharge' },
            { name: 'VM CODE', prop: 'vmCode' },
            { name: 'VM PACKAGE', prop: 'vmPackage' },
            { name: 'VM SET UP LAND LINE', prop: 'vmSetUpLandLine' },
            { name: 'VOICE MAIL', prop: 'voiceMail' },
        ];

        this.updateCarrierFormGroup = this.initCarrier();
    }

    //search form fields
    public initCarrier() {
        return this._formBuilder.group({
            objId: [''],
            carrierId: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            submarketName: ['', [Validators.maxLength(30)]],
            submarketOf: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            city: ['', [Validators.maxLength(30)]],
            state: ['', [Validators.maxLength(30)]],

            tapeReturnCharge: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(6)]],
            countryCode: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            activeLinePercent: ['', [Validators.pattern("[0-9]*\.?[0-9]*$"), Validators.maxLength(38)]],
            status: ['', [Validators.maxLength(20)]],
            ldProvider: ['', [Validators.maxLength(30)]],
            ldAccount: ['', [Validators.maxLength(50)]],

            carrier2Personality: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            carrier2Rule: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            carrier2CarrScript: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            specialMkt: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            newAnalogPlan: ['', [Validators.maxLength(30)]],
            ldPicCode: ['', [Validators.maxLength(50)]],
            ratePlan: ['', [Validators.maxLength(60)]],

            dummyEsn: ['', [Validators.maxLength(10)]],
            billDate: [''],
            voiceMail: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            vmCode: ['', [Validators.maxLength(30)]],
            vmPackage: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            callerId: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            idCode: ['', [Validators.maxLength(30)]],
            idPackage: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            callWaiting: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            cwCode: ['', [Validators.maxLength(30)]],

            newDigitalPlan: ['', [Validators.maxLength(30)]],
            sms: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            smsCode: ['', [Validators.maxLength(30)]],
            smsPackage: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            vmSetUpLandLine: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            cwPackage: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            reactTechnology: ['', [Validators.maxLength(30)]],
            reactAnalog: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            actTechnology: ['', [Validators.maxLength(20)]],

            actAnalog: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            digitalRatePlan: ['', [Validators.maxLength(60)]],
            digitalFeature: ['', [Validators.maxLength(30)]],
            prlPreLoaded: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            tapeReturnAddr2Address: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            carrier2Provider: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            carrier2Address: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],

            carrier2RulesCdma: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            carrier2RulesGsm: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            carrier2RulesTdma: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            dataService: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            automated: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],

        });
    }

    //this method will close the update carrier dialog window
    cancelUpdateCarrierDialog(): void {
        this.dialogRef.close(false);
    }

    //show cancel confirm box
    showCancelConfirm() {
        this.confirmationService.confirm({
            key: 'confirm-cancel',
            message: this.wizardHelper.getTracfoneConstantMethod("TRACFONE_CANCEL_UPDATE_CARRIER_CONFIRM_MESSAGE"),
            accept: () => {
                this.cancelUpdateCarrierDialog();
            }
        });
    }

    // update carrier confirm box
    showUpdateCarrierConfirm(rowData) {
        this.confirmationService.confirm({
            key: 'confirm-update-carrier',
            message: this.wizardHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_CARRIER_CONFIRM_MESSAGE"),
            accept: () => {
                this.updateCarrier(rowData);
            },
        });
    }

    public updateCarrier(rowData) {
        this.showLoadingScreen = true;
        rowData.carrier2CarrierGroups = [rowData.carrier2CarrierGroup];
        if (typeof (rowData.billDate) == 'object' && rowData.billDate != null && rowData.billDate != undefined) {
            rowData.billDate = this.controlDateToStringDate(rowData.billDate, "-");
        }
        const obj: any = this.wizardHelper.checkRequestObjectSetToNull(
            rowData
        );
        obj.dbEnv = this.wizardHelper.dbEnv;
        this.wizardService.udpateCarrier(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_CARRIER_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    this.showLoadingScreen = false;
                    this.toasterService.showSuccessMessage(
                        this.wizardHelper.getTracfoneConstantMethod("TRACFONE_SUCCESS_UPDATE_CARRIER_MESSAGE")
                    );
                    this.dialogRef.close(true);
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            )
    }

    /**
     * Converts the java script object date from datepicker
     * to a string formatted date YYYY-MM-DD.
     */
    public controlDateToStringDate(controlDate: any, dateSeparator?: string): string {
        var formattedDate = '';

        if (dateSeparator == null) dateSeparator = '-';

        try {
            if (controlDate != null) {
                var year = controlDate.getUTCFullYear();
                var month = controlDate.getMonth() + 1;
                var day = controlDate.getDate();
            }
        } catch (Exception) {
            return '';
        }

        if (month < 10) {
            month = 0 + "" + month;
        }
        if (day < 10) {
            day = 0 + "" + day;
        }
        // Format YYYY-MM-DD.
        if (year != null && month != null && day != null) {
            formattedDate = year + dateSeparator + month + dateSeparator + day;
        }

        return formattedDate;
    }

    public openCarrierRuleDialog(values, choice) {
        const dialogRef = this.dialog.open(CarrierRulesDialogComponent, {
            width: "90%",
            height: "90%",
            data: {carrierRuleObjid: values,dataKey : choice}
        });

        // Create subscription
        dialogRef.afterClosed().subscribe((returnValue) => {
            // Do stuff after the dialog has closed
            if (returnValue){
                if(choice == 'carrier2Rule'){
                    this.rowData.carrier2Rule = returnValue;
                } else if(choice == 'carrier2RulesCdma') {
                    this.rowData.carrier2RulesCdma = returnValue;
                } else if(choice == 'carrier2RulesGsm') {
                    this.rowData.carrier2RulesGsm = returnValue;
                } else if(choice == 'carrier2RulesTdma') {
                    this.rowData.carrier2RulesTdma = returnValue;
                } 
            }
        });
    }
}