import { Component, ViewEncapsulation, OnInit, Inject, ViewChild } from "@angular/core";
import { ConfirmationService } from "primeng/api";
import { MatDialogRef, MAT_DIALOG_DATA, MatTabGroup, MatTab, MatTabHeader, MatTabChangeEvent } from "@angular/material";
import { CarrierMaintenanceHelper } from "../../../../../carrier-maintenance-helper";
import { ToasterService } from "../../../../../../../../Services/toaster.service";

@Component({
    selector: "order-types-dialog",
    templateUrl: "./order-types-dialog.component.html",
    styleUrls: [
        "./order-types-dialog.component.scss"
    ],
    animations: [],
    encapsulation: ViewEncapsulation.None,
    providers: [ConfirmationService]
})
export class OrderTypesDialogComponent implements OnInit {

    @ViewChild('tabs') tabs: MatTabGroup;
    public showLoadingScreen = false;
    public firstTab = true;
    public secondTab = false;
    public editOpenRow = "";
    public returnedData: any;

    constructor(
        public dialogRef: MatDialogRef<OrderTypesDialogComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any,
        private confirmationService: ConfirmationService,
        private wizardHelper: CarrierMaintenanceHelper,
        private toasterService: ToasterService
    ) { dialogRef.disableClose = true; }

    ngOnInit() {
        this.tabs._handleClick = this.interceptTabChange.bind(this);

    }

    checkReturnData(returnedData) {
        this.editOpenRow = returnedData.status;
        this.returnedData = returnedData.data
    }

    interceptTabChange(tab: MatTab, tabHeader: MatTabHeader, idx: number) {
        let result = false;
        if ((this.editOpenRow == "editEnableRow") || (this.editOpenRow == "selectedData" && this.returnedData.data.length > 0)) {
            this.toasterService.showErrorMessage(
                this.wizardHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE")
            );
        } else if (this.editOpenRow == "onRowEditCancel" || this.editOpenRow == "save") {
            result = true;
            return result && MatTabGroup.prototype._handleClick.apply(this.tabs, arguments);
        } else {
            result = true;
            return result && MatTabGroup.prototype._handleClick.apply(this.tabs, arguments);
        }

    }

    public onTabClick(event: MatTabChangeEvent) {
        if (event.index == 1) {
            this.firstTab = false;
            this.secondTab = true;
        }
        else if (event.index == 0) {
            this.secondTab = false;
            this.firstTab = true;
        }
    }

    //show done confirm box
    showDoneConfirm() {
        this.confirmationService.confirm({
            key: 'confirm-done',
            message: this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DONE_ORDER_TYPES_CONFIRM_MESSAGE"),
            accept: () => {
                this.dialogRef.close();
            }
        });
    }
}