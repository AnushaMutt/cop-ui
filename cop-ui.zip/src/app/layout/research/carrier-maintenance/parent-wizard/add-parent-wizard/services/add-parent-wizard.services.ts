import { Injectable } from "@angular/core";
import { Subject } from "rxjs";

@Injectable({
    providedIn: "root"
})
export class AddParentService {

    stepParentData: any;
    stepCarrierGroupData: any;
    stepCarrierData: any;
    addOrderTypes: any;

    nextStepNumber = new Subject();
    isAppStepParentActive = new Subject<boolean>();
    isAppStepCarrierGroupActive = new Subject<boolean>();
    isAppStepCarrierActive = new Subject<boolean>();

    breadcrumbListUpdateForERP = new Subject<number>();
    breadcrumbListForERP = [];

    currentStep = new Subject<number>();;

    constructor() { }

    public updateCurrentStep(currentStep: number) {
        this.currentStep.next(currentStep);
    }

    public updateBreadcrumbListForUPW(breadcrumb: string, index: number) {
        this.breadcrumbListForERP[index] = breadcrumb;
        this.breadcrumbListUpdateForERP.next(Math.random());
    }

    public emptyBreadcrumbListForUPW() {
        this.breadcrumbListForERP = [];
        this.breadcrumbListUpdateForERP.next(Math.random());
    }

    public getBreadcrumbListForUPW() {
        return this.breadcrumbListForERP;
    }

    public setParentData(stepParentData) {
        this.stepParentData = stepParentData;
    }

    public getParentData() {
        return this.stepParentData;
    }

    public setCarrierGroupData(stepCarrierGroupData) {
        this.stepCarrierGroupData = stepCarrierGroupData;
    }

    public getCarrierGroupData() {
        return this.stepCarrierGroupData;
    }

    public setCarrierData(stepCarrierData) {
        this.stepCarrierData = stepCarrierData;
    }

    public getCarrierData() {
        return this.stepCarrierData;
    }

    public setAddOrderTypesData(addOrderTypes) {
        this.addOrderTypes = addOrderTypes;
    }

    public getAddOrderTypesData() {
        return this.addOrderTypes;
    }

    nextStepMove(step: Number) {
        this.nextStepNumber.next(step);
    }

    isAppStepParentTableActivated(isAppStepParentActive: boolean) {
        this.isAppStepParentActive.next(isAppStepParentActive);
    }

    isAppCarrierGroupTableActivated(isAppStepCarrierGroupActive: boolean) {
        this.isAppStepCarrierGroupActive.next(isAppStepCarrierGroupActive);
    }


    isAppStepCarrierTableActivated(isAppStepCarrierActive: boolean) {
        this.isAppStepCarrierActive.next(isAppStepCarrierActive);
    }

    public resetAll() {
        this.stepCarrierData = [];
        this.stepCarrierGroupData = [];
        this.stepParentData = [];
    }
}
