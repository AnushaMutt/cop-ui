import { Component, ViewEncapsulation, OnInit, ViewChild, Output, EventEmitter, ViewChildren } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { Subject } from "rxjs";
import { CarrierMaintenanceHelper } from "../../../carrier-maintenance-helper";
import { CarrierMaintenanceService } from "../../../../../../Services/carrierMaintenance.service";
import { ToasterService } from "../../../../../../Services/toaster.service";
import { takeUntil } from "rxjs/operators";
import { AddParentService } from "../services/add-parent-wizard.services";
import { MatDialog } from "@angular/material";
import { OrderTypesDialogComponent } from "../../update-parent-wizard/step-carriers/view-carriers/order-types-dialog/order-types-dialog.component";
import { UpdateCarrierDialogComponent } from "../../update-parent-wizard/step-carriers/view-carriers/update-carriers-dialog/update-carriers-dialog.component";

@Component({
    selector: 'step-copy-carriers',
    templateUrl: './step-copy-carriers.component.html',
    styleUrls: ['./step-copy-carriers.component.scss',
        '../../../../../components/ngxtable/material.scss',
        '../../../../../components/ngxtable/datatable.component.scss',
        '../../../../../components/ngxtable/icons.css',
        '../../../../../components/ngxtable/app.css'
    ],
    encapsulation: ViewEncapsulation.None
})

export class StepCopyCarriersComponent implements OnInit {

    @Output("returnedData") returnedData: any = new EventEmitter();
    public frmGroupMain: FormGroup;
    public unsubscribe = new Subject<void>();
    public isEditable = {};
    public editedRow = {};
    public defaultEditedRow = {};
    public displayTable = false;
    public multiColumnEditSection = false;
    public multicolumnEditColumnName = '';
    public multiColumnEditColumns = [];
    public allAvailableColumns = [];
    public copyColumns = [];
    public isSearchResultsExpanded = false;
    public summaryData = [];
    public summaryMainData = [];
    public textColumns = false;
    public dropDownColumns = false;
    public selectedCarriers = [];
    public selected = [];
    public copySelectedCarriersRow = [];
    public copyCarriers = false;
    public showLoadingScreen = false;
    public carrierData = [];
    public carrierMainData = []
    public summaryFields = [];
    public flagColumn = false;
    public carrier2CarrierGroupData = [];
    public carrier2CarrierGroupMainData = [];
    public searchResultColumns = [];
    public otherColumn = false;
    public objectId: any
    @ViewChild('multicolumnEditColumnValue') multicolumnEditColumnValue: any;
    @ViewChild('multicolumnEditCheckbox') private multicolumnEditCheckbox: any;
    public carrierGroupData = [];
    public firstAvailableColumnsFields = [];
    public secondAvilableColumnsFields = [];
    public thirdAvailableColumnsFields = [];
    public dateColumn = false;


    constructor(
        private _formBuilder: FormBuilder,
        private wizardHelper: CarrierMaintenanceHelper,
        private wizardService: CarrierMaintenanceService,
        private toasterService: ToasterService,
        private addParentService: AddParentService,
        public dialog: MatDialog
    ) { }

    ngOnInit() {
        this.carrierGroupData = this.addParentService.getCarrierGroupData();
        for (let i = 0; i < this.carrierGroupData.length; i++) {
            this.carrier2CarrierGroupMainData.push(this.carrierGroupData[i].objId);
        }
        this.carrier2CarrierGroupData = [...this.carrier2CarrierGroupMainData];
        if (this.carrier2CarrierGroupData.length == 1) {
            this.objectId = this.carrier2CarrierGroupData[0];
        }
        this.isSearchResultsExpanded = false;
        this.displayTable = false;
        this.carrierData = [];
        this.carrierMainData = [];
        this.showLoadingScreen = false;
        this.allAvailableColumns = [
            { name: 'OBJID', prop: 'objId', width: "200" },
            { name: 'CARRIER2 CARRIER GROUP', prop: 'carrier2CarrierGroup', width: "200" },
            { name: 'CARRIER ID', prop: 'carrierId', width: "200" },
            { name: 'STATUS', prop: 'status', width: "200" },
            { name: 'SUB MARKET NAME', prop: 'submarketName', width: "300" },
            { name: 'SUB MARKET OF', prop: 'submarketOf', width: "200" },
            { name: 'ACT ANALOG', prop: 'actAnalog', width: "200" },
            { name: 'ACT TECHNOLOGY', prop: 'actTechnology', width: "200" },
            { name: 'ACTIVE LINE PERCENT', prop: 'activeLinePercent', width: "200" },
            { name: 'AUTOMATED', prop: 'automated', width: "200" },
            { name: 'BILL DATE', prop: 'billDate', width: "200" },
            { name: 'CALL WAITING', prop: 'callWaiting', width: "200" },
            { name: 'CARRIER2 ADDRESS', prop: 'carrier2Address', width: "200" },
            { name: 'CARRIER2 CARR SCRIPT', prop: 'carrier2CarrScript', width: "200" },
            { name: 'CARRIER2 PERSONALITY', prop: 'carrier2Personality', width: "200" },
            { name: 'CARRIER2 PROVIDER', prop: 'carrier2Provider', width: "200" },
            { name: 'CARRIER2 RULE', prop: 'carrier2Rule', width: "200" },
            { name: 'CARRIER2 RULES CDMA', prop: 'carrier2RulesCdma', width: "200" },
            { name: 'CARRIER2 RULES GSM', prop: 'carrier2RulesGsm', width: "200" },
            { name: 'CARRIER2 RULES TDMA', prop: 'carrier2RulesTdma', width: "200" },
            { name: 'CITY', prop: 'city', width: "200" },
            { name: 'COUNTRY CODE', prop: 'countryCode', width: "200" },
            { name: 'CW CODE', prop: 'cwCode', width: "200" },
            { name: 'CW PACKAGE', prop: 'cwPackage', width: "200" },
            { name: 'DATA SERVICE', prop: 'dataService', width: "200" },
            { name: 'DIGITAL FEATURE', prop: 'digitalFeature', width: "200" },
            { name: 'DIGITAL RATE PLAN', prop: 'digitalRatePlan', width: "200" },
            { name: 'DUMMY ESN', prop: 'dummyEsn', width: "200" },
            { name: 'ID CODE', prop: 'idCode', width: "200" },
            { name: 'ID PACKAGE', prop: 'idPackage', width: "200" },
            { name: 'LD ACCOUNT', prop: 'ldAccount', width: "200" },
            { name: 'LD PIC CODE', prop: 'ldPicCode', width: "200" },
            { name: 'LD PROVIDER', prop: 'ldProvider', width: "200" },
            { name: 'NEW ANALOG PLAN', prop: 'newAnalogPlan', width: "200" },
            { name: 'NEW DIGITAL PLAN', prop: 'newDigitalPlan', width: "200" },
            { name: 'PRL PRE LOADED', prop: 'prlPreLoaded', width: "200" },
            { name: 'RATE PLAN', prop: 'ratePlan', width: "200" },
            { name: 'REACT TECHNOLOGY', prop: 'reactTechnology', width: "200" },
            { name: 'REACT ANALOG', prop: 'reactAnalog', width: "200" },
            { name: 'SMS', prop: 'sms', width: "200" },
            { name: 'SMS CODE', prop: 'smsCode', width: "200" },
            { name: 'SMS PACKAGE', prop: 'smsPackage', width: "200" },
            { name: 'SPECIAL MKT', prop: 'specialMkt', width: "200" },
            { name: 'STATE', prop: 'state', width: "200" },
            { name: 'TAPE RETURN ADDR2 ADDRESS', prop: 'tapeReturnAddr2Address', width: "200" },
            { name: 'TAPE RETURN CHARGE', prop: 'tapeReturnCharge', width: "200" },
            { name: 'VM CODE', prop: 'vmCode', width: "200" },
            { name: 'VM PACKAGE', prop: 'vmPackage', width: "200" },
            { name: 'VM SET UP LAND LINE', prop: 'vmSetUpLandLine', width: "200" },
            { name: 'VOICE MAIL', prop: 'voiceMail', width: "200" },
        ];

        this.firstAvailableColumnsFields = [
            { name: 'OBJID', prop: 'objId' },
            { name: 'ACT ANALOG', prop: 'actAnalog' },
            { name: 'ACT TECHNOLOGY', prop: 'actTechnology' },
            { name: 'ACTIVE LINE PERCENT', prop: 'activeLinePercent' },
            { name: 'AUTOMATED', prop: 'automated' },
            { name: 'BILL DATE', prop: 'billDate' },
            { name: 'CALL WAITING', prop: 'callWaiting' },
            { name: 'CARRIER ID', prop: 'carrierId' },
            { name: 'CARRIER2 ADDRESS', prop: 'carrier2Address' },
            { name: 'CARRIER2 CARR SCRIPT', prop: 'carrier2CarrScript' },
            { name: 'CARRIER2 PERSONALITY', prop: 'carrier2Personality' },
            { name: 'CARRIER2 PROVIDER', prop: 'carrier2Provider' },
            { name: 'CARRIER2 RULE', prop: 'carrier2Rule' },
            { name: 'CARRIER2 RULES CDMA', prop: 'carrier2RulesCdma' },
            { name: 'CARRIER2 RULES GSM', prop: 'carrier2RulesGsm' },
            { name: 'CARRIER2 RULES TDMA', prop: 'carrier2RulesTdma' },
            { name: 'CITY', prop: 'city' },
        ];

        this.secondAvilableColumnsFields = [
            { name: 'COUNTRY CODE', prop: 'countryCode' },
            { name: 'CW CODE', prop: 'cwCode' },
            { name: 'CW PACKAGE', prop: 'cwPackage' },
            { name: 'DATA SERVICE', prop: 'dataService' },
            { name: 'DIGITAL FEATURE', prop: 'digitalFeature' },
            { name: 'DIGITAL RATE PLAN', prop: 'digitalRatePlan' },
            { name: 'DUMMY ESN', prop: 'dummyEsn' },
            { name: 'ID CODE', prop: 'idCode' },
            { name: 'ID PACKAGE', prop: 'idPackage' },
            { name: 'LD ACCOUNT', prop: 'ldAccount' },
            { name: 'LD PIC CODE', prop: 'ldPicCode' },
            { name: 'LD PROVIDER', prop: 'ldProvider' },
            { name: 'NEW ANALOG PLAN', prop: 'newAnalogPlan' },
            { name: 'NEW DIGITAL PLAN', prop: 'newDigitalPlan' },
            { name: 'PRL PRE LOADED', prop: 'prlPreLoaded' },
            { name: 'RATE PLAN', prop: 'ratePlan' },
        ];

        this.thirdAvailableColumnsFields = [
            { name: 'REACT TECHNOLOGY', prop: 'reactTechnology' },
            { name: 'REACT ANALOG', prop: 'reactAnalog' },
            { name: 'SMS', prop: 'sms' },
            { name: 'SMS CODE', prop: 'smsCode' },
            { name: 'SMS PACKAGE', prop: 'smsPackage' },
            { name: 'SPECIAL MKT', prop: 'specialMkt' },
            { name: 'STATE', prop: 'state' },
            { name: 'STATUS', prop: 'status' },
            { name: 'SUB MARKET NAME', prop: 'submarketName' },
            { name: 'SUB MARKET OF', prop: 'submarketOf' },
            { name: 'TAPE RETURN ADDR2 ADDRESS', prop: 'tapeReturnAddr2Address' },
            { name: 'TAPE RETURN CHARGE', prop: 'tapeReturnCharge' },
            { name: 'VM CODE', prop: 'vmCode' },
            { name: 'VM PACKAGE', prop: 'vmPackage' },
            { name: 'VM SET UP LAND LINE', prop: 'vmSetUpLandLine' },
            { name: 'VOICE MAIL', prop: 'voiceMail' },
        ];

        this.searchResultColumns = this.allAvailableColumns.filter((col) => { if (col.prop != "carrier2CarrierGroup") return col; });
        this.copyColumns = [...this.allAvailableColumns];
        this.multiColumnEditColumns = this.allAvailableColumns.filter((col) => { if (col.prop != "objId") return col; });

        this.createForm();

        if (this.addParentService.getCarrierData() && this.addParentService.getCarrierData().length > 0) {
            for (let i = 0; i < this.addParentService.getCarrierData().length; i++) {
                let obj = this.addParentService.getCarrierData()[i]
                this.summaryMainData.push(obj);
            }
            this.summaryData = [...this.summaryMainData];
            this.displayTable = true;
        }
    }

    //Create Search form
    createForm() {
        this.frmGroupMain = this._formBuilder.group({
            carrierId: ["", [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            submarketName: ["", [Validators.maxLength(30)]],
            status: ['']
        });
    }

    //Search Submit
    public onSubmit() {
        this.showLoadingScreen = true;
        this.carrierMainData = [];
        this.carrierData = [];
        this.selectedCarriers = [];
        this.removeCopyButton();
        this.selected = [];
        this.copyCarriers = false;
        const obj: any = this.wizardHelper.checkRequestObject(
            this.frmGroupMain.value
        );
        obj.dbEnv = this.wizardHelper.dbEnv;
        this.wizardService
            .searchCarrier(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_UNABLE_SEARCH_CARRIER_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    this.showLoadingScreen = false;
                    this.carrierMainData = data[0];
                    for (let i = 0; i < this.carrierMainData.length; i++) {
                        this.carrierMainData[i].carrier2CarrierGroup = "";
                        if (this.carrierMainData[i].billDate)
                            this.carrierMainData[i].billDate = this.carrierMainData[i].billDate.split(" ")[0];
                    }
                    this.carrierData = [...this.carrierMainData];

                    if (data[0] && data[0].length == 0)
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("NO_CARRIERS_FOUND")
                        );
                    else {
                        this.isSearchResultsExpanded = true;
                    }
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null) {
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    }
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    //Copy final Submit
    public copyCarriersSubmit() {
        if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
            this.toasterService.showErrorMessage(
                this.wizardHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            return;
        }

        this.showLoadingScreen = true;
        let obj: any = [];
        this.copySelectedCarriersRow = this.wizardHelper.checkRequestObjectForArray(this.copySelectedCarriersRow);
        obj = [...this.copySelectedCarriersRow];
        for (let i = 0; i < obj.length; i++) {
            obj[i].dbEnv = this.wizardHelper.dbEnv;
            if (this.objectId)
                obj[i].carrier2CarrierGroups = [this.objectId];
            else
                obj[i].carrier2CarrierGroups = [obj[i].carrier2CarrierGroup];
        }
        this.wizardService
            .addCarriers(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_COPY_CARRIERS_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        if (data[0].ERR.indexOf('[') == -1) {
                            const commaSeperatedArr = data[0].ERR.split(",");
                            for (
                                let i = commaSeperatedArr.length - 1;
                                i >= 0;
                                i--
                            ) {
                                if (commaSeperatedArr[i] != "")
                                    this.toasterService.showErrorMessage(
                                        commaSeperatedArr[i]
                                    );
                            }
                        } else {
                            this.toasterService.showErrorMessage(
                                data[0].ERR
                            );
                        }
                        return;
                    }
                    this.showLoadingScreen = false;
                    this.getCarriers('first time');
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null) {
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    }
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    //If Copy success this method will be called
    public getCarriers(arg) {
        this.showLoadingScreen = true;
        this.summaryMainData = [];
        this.summaryData = [];
        let obj: any = {};
        obj.dbEnv = this.wizardHelper.dbEnv;
        obj.carrier2CarrierGroups = [];
        for (let i = 0; i < this.carrierGroupData.length; i++) {
            obj.carrier2CarrierGroups.push(this.carrierGroupData[i].objId);
        }
        this.wizardService
            .searchCarrier(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_UNABLE_SEARCH_CARRIER_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    this.showLoadingScreen = false;
                    this.revert();
                    this.summaryMainData = data[0];
                    this.displayTable = true;
                    for (let i = 0; i < this.summaryMainData.length; i++) {
                        if (this.summaryMainData[i].billDate)
                            this.summaryMainData[i].billDate = this.summaryMainData[i].billDate.split(" ")[0];
                    }
                    this.summaryData = [...this.summaryMainData];
                    this.addParentService.setCarrierData(this.summaryData);
		    this.addParentService.isAppStepCarrierTableActivated(true);
                    if (data[0] && data[0].length == 0)
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("NO_CARRIERS_FOUND")
                        );
                    else if(arg == 'first time')
                        this.toasterService.showSuccessMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_COPY_CARRIERS_SUCCESS_MESSAGE")
                        );
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null) {
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    }
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    // this is use to reset
    public revert() {
        this.frmGroupMain.reset();
        this.carrierMainData = [];
        this.carrierData = [];
        this.selectedCarriers = [];
        this.copySelectedCarriersRow = [];
        this.isSearchResultsExpanded = false;
        this.copyCarriers = false;
        this.selected = [];
    }

    //Row Selection
    public onSelect(row) {
        this.selectedCarriers = [];
        if (row && row.selected) {
            for (let i = 0; i < row.selected.length; i++) {
                let obj = { ...row.selected[i] };
                this.selectedCarriers.push(obj);
            }
        }
        this.selectedCarriers = [...this.selectedCarriers]
    }

    //Copy Button
    public copyCarrierButton() {
        this.copyCarriers = true;
        this.copySelectedCarriersRow = [...this.selectedCarriers];
        this.isSearchResultsExpanded = false;
    }

    //Remove Work Area
    public removeCopyButton() {
        this.copyCarriers = false;
        this.copySelectedCarriersRow = [];
        this.isSearchResultsExpanded = true;
        this.multiColumnEditSection = false;
        this.multicolumnEditColumnName = '';
        this.multicolumnEditColumnValue = '';
        this.multicolumnEditCheckbox = '';
        this.flagColumn = false;
        this.textColumns = false;
        this.dateColumn = false;
    }

    //Filter for Search table
    public updateCarrierTable(event) {
        const val = event.target.value.toLowerCase();
        const temp = this.carrierMainData.filter(function (d) {

            return (d.objId ? d.objId.indexOf(val) !== -1 : !val)
                || (d.carrierId ? d.carrierId.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.submarketName ? d.submarketName.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.submarketOf ? d.submarketOf.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.city ? d.city.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.state ? d.state.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.tapeReturnCharge ? d.tapeReturnCharge.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.activeLinePercent ? d.activeLinePercent.toLowerCase().indexOf(val) !== -1 : !val)

                || (d.status ? d.status.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.ldProvider ? d.ldProvider.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.ldAccount ? d.ldAccount.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.carrier2Personality ? d.carrier2Personality.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.carrier2Rule ? d.carrier2Rule.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.carrier2CarrScript ? d.carrier2CarrScript.toLowerCase().indexOf(val) !== -1 : !val)

                || (d.specialMkt ? d.specialMkt.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.newAnalogPlan ? d.newAnalogPlan.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.ldPicCode ? d.ldPicCode.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.ratePlan ? d.ratePlan.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.dummyEsn ? d.dummyEsn.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.billDate ? d.billDate.indexOf(val) !== -1 : !val)
                || (d.vmPackage ? d.vmPackage.toLowerCase().indexOf(val) !== -1 : !val)

                || (d.vmCode ? d.vmCode.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.voiceMail ? d.voiceMail.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.callerId ? d.callerId.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.idCode ? d.idCode.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.idPackage ? d.idPackage.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.callWaiting ? d.callWaiting.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.cwCode ? d.cwCode.toLowerCase().indexOf(val) !== -1 : !val)

                || (d.newDigitalPlan ? d.newDigitalPlan.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.sms ? d.sms.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.smsCode ? d.smsCode.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.smsPackage ? d.smsPackage.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.cwPackage ? d.cwPackage.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.reactTechnology ? d.reactTechnology.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.reactAnalog ? d.reactAnalog.toLowerCase().indexOf(val) !== -1 : !val) || !val

                || (d.actTechnology ? d.actTechnology.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.actAnalog ? d.actAnalog.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.digitalRatePlan ? d.digitalRatePlan.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.digitalFeature ? d.digitalFeature.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.prlPreLoaded ? d.prlPreLoaded.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.carrier2CarrierGroup ? d.carrier2CarrierGroup.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.tapeReturnAddr2Address ? d.tapeReturnAddr2Address.toLowerCase().indexOf(val) !== -1 : !val) || !val

                || (d.carrier2Provider ? d.carrier2Provider.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.carrier2Address ? d.carrier2Address.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.carrier2RulesCdma ? d.carrier2RulesCdma.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.carrier2RulesGsm ? d.carrier2RulesGsm.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.carrier2RulesTdma ? d.carrier2RulesTdma.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.dataService ? d.dataService.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.automated ? d.automated.toLowerCase().indexOf(val) !== -1 : !val) || !val;
        });

        this.carrierData = temp;
    }

    //Filter for work area
    public updateCopyCarriersDataTable(event) {
        const val = event.target.value.toLowerCase();
        const temp = this.selectedCarriers.filter(function (d) {

            return (d.objId ? d.objId.indexOf(val) !== -1 : !val)
                || (d.carrierId ? d.carrierId.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.submarketName ? d.submarketName.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.submarketOf ? d.submarketOf.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.city ? d.city.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.state ? d.state.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.tapeReturnCharge ? d.tapeReturnCharge.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.activeLinePercent ? d.activeLinePercent.toLowerCase().indexOf(val) !== -1 : !val)

                || (d.status ? d.status.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.ldProvider ? d.ldProvider.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.ldAccount ? d.ldAccount.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.carrier2Personality ? d.carrier2Personality.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.carrier2Rule ? d.carrier2Rule.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.carrier2CarrScript ? d.carrier2CarrScript.toLowerCase().indexOf(val) !== -1 : !val)

                || (d.specialMkt ? d.specialMkt.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.newAnalogPlan ? d.newAnalogPlan.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.ldPicCode ? d.ldPicCode.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.ratePlan ? d.ratePlan.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.dummyEsn ? d.dummyEsn.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.billDate ? d.billDate.indexOf(val) !== -1 : !val)
                || (d.vmPackage ? d.vmPackage.toLowerCase().indexOf(val) !== -1 : !val)

                || (d.vmCode ? d.vmCode.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.voiceMail ? d.voiceMail.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.callerId ? d.callerId.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.idCode ? d.idCode.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.idPackage ? d.idPackage.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.callWaiting ? d.callWaiting.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.cwCode ? d.cwCode.toLowerCase().indexOf(val) !== -1 : !val)

                || (d.newDigitalPlan ? d.newDigitalPlan.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.sms ? d.sms.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.smsCode ? d.smsCode.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.smsPackage ? d.smsPackage.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.cwPackage ? d.cwPackage.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.reactTechnology ? d.reactTechnology.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.reactAnalog ? d.reactAnalog.toLowerCase().indexOf(val) !== -1 : !val) || !val

                || (d.actTechnology ? d.actTechnology.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.actAnalog ? d.actAnalog.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.digitalRatePlan ? d.digitalRatePlan.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.digitalFeature ? d.digitalFeature.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.prlPreLoaded ? d.prlPreLoaded.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.carrier2CarrierGroup ? d.carrier2CarrierGroup.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.tapeReturnAddr2Address ? d.tapeReturnAddr2Address.toLowerCase().indexOf(val) !== -1 : !val) || !val

                || (d.carrier2Provider ? d.carrier2Provider.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.carrier2Address ? d.carrier2Address.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.carrier2RulesCdma ? d.carrier2RulesCdma.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.carrier2RulesGsm ? d.carrier2RulesGsm.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.carrier2RulesTdma ? d.carrier2RulesTdma.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.dataService ? d.dataService.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.automated ? d.automated.toLowerCase().indexOf(val) !== -1 : !val) || !val;
        });

        this.copySelectedCarriersRow = temp;
    }

    //Filter for Summary
    public updateSummaryCarrierTable(event) {
        const val = event.target.value.toLowerCase();


        const temp = this.summaryMainData.filter(function (d) {

            return (d.objId ? d.objId.indexOf(val) !== -1 : !val)
                || (d.carrierId ? d.carrierId.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.submarketName ? d.submarketName.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.submarketOf ? d.submarketOf.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.city ? d.city.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.state ? d.state.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.tapeReturnCharge ? d.tapeReturnCharge.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.activeLinePercent ? d.activeLinePercent.toLowerCase().indexOf(val) !== -1 : !val)

                || (d.status ? d.status.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.ldProvider ? d.ldProvider.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.ldAccount ? d.ldAccount.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.carrier2Personality ? d.carrier2Personality.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.carrier2Rule ? d.carrier2Rule.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.carrier2CarrScript ? d.carrier2CarrScript.toLowerCase().indexOf(val) !== -1 : !val)

                || (d.specialMkt ? d.specialMkt.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.newAnalogPlan ? d.newAnalogPlan.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.ldPicCode ? d.ldPicCode.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.ratePlan ? d.ratePlan.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.dummyEsn ? d.dummyEsn.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.billDate ? d.billDate.indexOf(val) !== -1 : !val)
                || (d.vmPackage ? d.vmPackage.toLowerCase().indexOf(val) !== -1 : !val)

                || (d.vmCode ? d.vmCode.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.voiceMail ? d.voiceMail.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.callerId ? d.callerId.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.idCode ? d.idCode.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.idPackage ? d.idPackage.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.callWaiting ? d.callWaiting.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.cwCode ? d.cwCode.toLowerCase().indexOf(val) !== -1 : !val)

                || (d.newDigitalPlan ? d.newDigitalPlan.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.sms ? d.sms.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.smsCode ? d.smsCode.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.smsPackage ? d.smsPackage.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.cwPackage ? d.cwPackage.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.reactTechnology ? d.reactTechnology.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.reactAnalog ? d.reactAnalog.toLowerCase().indexOf(val) !== -1 : !val) || !val

                || (d.actTechnology ? d.actTechnology.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.actAnalog ? d.actAnalog.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.digitalRatePlan ? d.digitalRatePlan.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.digitalFeature ? d.digitalFeature.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.prlPreLoaded ? d.prlPreLoaded.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.carrier2CarrierGroup ? d.carrier2CarrierGroup.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.tapeReturnAddr2Address ? d.tapeReturnAddr2Address.toLowerCase().indexOf(val) !== -1 : !val) || !val

                || (d.carrier2Provider ? d.carrier2Provider.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.carrier2Address ? d.carrier2Address.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.carrier2RulesCdma ? d.carrier2RulesCdma.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.carrier2RulesGsm ? d.carrier2RulesGsm.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.carrier2RulesTdma ? d.carrier2RulesTdma.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.dataService ? d.dataService.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.automated ? d.automated.toLowerCase().indexOf(val) !== -1 : !val) || !val;
        });

        this.summaryData = temp;
    }

    public multiColumnEdit(isChecked) {
        if (isChecked.checked)
            this.multiColumnEditSection = true;
        else {
            this.multiColumnEditSection = false;
            this.multicolumnEditColumnName = '';
            this.multicolumnEditColumnValue = '';
        }
    }

    //Choose Column to bulk edit
    public assignmultiColumnName(column) {
        this.multicolumnEditColumnName = column;
        if (this.multicolumnEditColumnName == "status") {
            this.flagColumn = true;
            this.textColumns = false;
            this.otherColumn = false;
            this.dateColumn = false;
        } else if (this.multicolumnEditColumnName == "carrier2CarrierGroup") {
            this.flagColumn = false;
            this.textColumns = false;
            this.otherColumn = true;
            this.dateColumn = false;
        } else if (this.multicolumnEditColumnName == "billDate") {
            this.flagColumn = false;
            this.textColumns = false;
            this.otherColumn = false;
            this.dateColumn = true;
        } else {
            this.textColumns = true;
            this.flagColumn = false;
            this.otherColumn = false;
            this.dateColumn = false;
        }
    }

    //Bulk edit 
    public updatemultiColumnEdit() {
        if (this.textColumns) {
            for (let i = 0; i < this.copySelectedCarriersRow.length; i++) {
                this.copySelectedCarriersRow[i][this.multicolumnEditColumnName] = this.multicolumnEditColumnValue.nativeElement.value;
            }
            this.multicolumnEditColumnValue.nativeElement.value = '';
        } else if (this.flagColumn) {
            for (let i = 0; i < this.copySelectedCarriersRow.length; i++) {
                this.copySelectedCarriersRow[i][this.multicolumnEditColumnName] = this.multicolumnEditColumnValue.value;
            }
            this.multicolumnEditColumnValue.value = '';
        } else if (this.otherColumn) {
            for (let i = 0; i < this.copySelectedCarriersRow.length; i++) {
                this.copySelectedCarriersRow[i][this.multicolumnEditColumnName] = this.multicolumnEditColumnValue.value;
            }
            this.multicolumnEditColumnValue.value = '';
        } else if(this.dateColumn) {
            for (let i = 0; i < this.copySelectedCarriersRow.length; i++) {
                this.copySelectedCarriersRow[i][this.multicolumnEditColumnName] = this.multicolumnEditColumnValue;
            }
            this.multicolumnEditColumnValue = '';
        }
        this.copySelectedCarriersRow = [...this.copySelectedCarriersRow];
        this.multicolumnEditColumnName = '';
        this.multicolumnEditCheckbox.checked = false;
        this.multiColumnEditSection = false;
        this.textColumns = false;
        this.flagColumn = false;
        this.otherColumn = false;
        this.dateColumn = false;
    }

    //Work Area inline value Changes
    public editValueChanged(event, column, row, oldValue) {
        for (let i = 0; i < this.copySelectedCarriersRow.length; i++) {
            if (this.copySelectedCarriersRow[i].objId == row.objId) {
                if (column != "status" && column != "carrier2CarrierGroup" && column != "billDate") {
                    this.copySelectedCarriersRow[i][column] = event.target.value;
                } else if (column == "billDate") {
                    this.copySelectedCarriersRow[i][column] = this.controlDateToStringDate(event.value, '-')
                } else {
                    this.copySelectedCarriersRow[i][column] = event.value
                }
            }
        }
    }

    //Remove row from work Area
    public deleteRow(data, rowIndex) {
        this.copySelectedCarriersRow.splice(rowIndex, 1);
        if (data) {
            for (let i = 0; i < this.selectedCarriers.length; i++) {
                if (data.objId == this.selectedCarriers[i].objId) {
                    this.selectedCarriers.splice(i, 1);
                }
            }
        }
        this.selectedCarriers = [...this.selectedCarriers];
        this.copySelectedCarriersRow = [...this.copySelectedCarriersRow];
    }

    private openedChange(rowData) {
        if (rowData == "objidInput")
            this.carrier2CarrierGroupData = [...this.carrier2CarrierGroupMainData];
    }

    private onKey(value, rowData) {
        if (rowData == "objidInput") {
            this.carrier2CarrierGroupData = [...this.carrier2CarrierGroupMainData];
            this.carrier2CarrierGroupData = this.search(value, 'objidInput');
        }
    }
    //Search from drop down
    private search(value: string, choice: string) {
        let filter = value.toLowerCase();
        if (choice == "objidInput")
            return this.carrier2CarrierGroupMainData.filter(option => option.toLowerCase().indexOf(filter) > -1);
    }

    //Bulk edit bill date change method
    changeDateForBulkEdit(event){
        this.multicolumnEditColumnValue = this.controlDateToStringDate(event.value, '-');
    }

    /**
     * Converts the java script object date from datepicker
     * to a string formatted date YYYY-MM-DD.
     */
    public controlDateToStringDate(controlDate: any, dateSeparator?: string): string {
        var formattedDate = '';

        if (dateSeparator == null) dateSeparator = '-';

        try {
            if (controlDate != null) {
                var year = controlDate.getUTCFullYear();
                var month = controlDate.getMonth() + 1;
                var day = controlDate.getDate();
            }
        } catch (Exception) {
            return '';
        }

        if (month < 10) {
            month = 0 + "" + month;
        }
        if (day < 10) {
            day = 0 + "" + day;
        }
        // Format YYYY-MM-DD.
        if (year != null && month != null && day != null) {
            formattedDate = year + dateSeparator + month + dateSeparator + day;
        }

        return formattedDate;
    }

    //opens the update carrier dialog window
    updateCarrierDialog(carrierValue) {
        const dialogRef = this.dialog.open(UpdateCarrierDialogComponent, {
            width: "90%",
            height: "90%",
            data: {
                dataKey: carrierValue,
            },
        });
        // Create subscription
        dialogRef.afterClosed().subscribe((isRefresh) => {
            // Do stuff after the dialog has closed
            if (isRefresh)
                this.getCarriers('after update');
        });
    }

    //opens the order Types dialog window
    orderTypeDialog(carrierValue) {
        const dialogRef = this.dialog.open(OrderTypesDialogComponent, {
            width: "90%",
            height: "90%",
            data: {
                dataKey: carrierValue,
            },
        });
    }
}