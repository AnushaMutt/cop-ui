import { Component, OnInit, Input, SimpleChanges,ViewChild } from "@angular/core";
import { NgbTabset } from "@ng-bootstrap/ng-bootstrap";

@Component({
    selector: 'parent-wizard',
    templateUrl: './parent-wizard.html',
})
export class ParentComponent implements OnInit {
@Input("clearData") clearData: any;

constructor() { }

ngOnInit() { }

}



