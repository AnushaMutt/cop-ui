import { Injectable } from "@angular/core";
import { Subject } from "rxjs";

@Injectable({
    providedIn: "root"
})
export class CarrierZoneHelper {
   
    public breadcrumbListUpdate = new Subject<number>();
    public breadcrumbList = [];
    constructor() { }

    public CarrierZonesConstantObject = {
        "TRACFONE_DEFAULT_ERROR_MESSAGE": "Unable to process request",
        "TRACFONE_DONE_CREATING_CARRIERZONES_CONFIRM_MESSAGE": "Are you done creating Carrier Zones ?",
        "TRACFONE_ADD_CARRIERZONES_ERROR_MESSAGE": "Unable to add Carrier Zones",
        "TRACFONE_ADD_CARRIERZONES_SUCCESS_MESSAGE": "Carrier Zones has been added successfully",  
        "TRACFONE_RETRIEVE_CARRIERZONES_ERROR_MESSAGE" : "Unable to search Carrier Zones",
        "TRACFONE_SEARCH_CARRIERZONES_ERROR_MESSAGE" : "No Carrier Zones found",
        "TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE": "Please complete previous operation",  
        "TRACFONE_UPDATE_CARRIERZONES_ERROR_MESSAGE" : "Unable to update Carrier Zones",
        "TRACFONE_UPDATE_CARRIERZONES_SUCCESS_MESSAGE" : "Carrier Zones has been updated successfully",
        "TRACFONE_DELETE_CARRIERZONES_SUCCESS_MESSAGE": "Carrier Zones has been deleted successfully",
        "TRACFONE_DELETE_CARRIERZONES_ERROR_MESSAGE": "Unable to delete Carrier Zones",
        "TRACFONE_NO_SUMMARY_FOUND_ERROR_MESSAGE" : "No records found",
        "TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE" : "Please fix validation errors",
        "TRACFONE_DUPLICATE_CARRIERZONES_ERROR_MESSAGE" : "Duplicate Carrier Zones found",
        "TRACFONE_BULK_ADD_CARRIERZONES_ERROR_MESSAGE" : "Unable to add Carrier Zones",
        "TRACFONE_BULK_DELETE_CARRIERZONES_ERROR_MESSAGE":"Unable to delete Carrier Zones",
        "TRACFONE_RETRIEVE_SUMMARY_ERROR_MESSAGE": "Unable to retrieve bulk insert Carrier Zones Summary",
        "TRACFONE_RETRIEVE_ERROR_DETAILS_ERROR_MESSAGE":"Unable to retrieve bulk insert Carrier Zones error details",
        "TRACFONE_NO_ERROR_DETAILS_FOUND_ERROR_MESSAGE":"No Details to display"
    }

    public getTracfoneConstantMethod(msg) {
        return this.CarrierZonesConstantObject[msg];
    }

}