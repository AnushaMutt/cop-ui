import { Component, OnInit, ViewEncapsulation, ViewChildren, Output, EventEmitter, SimpleChanges } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { ConfirmationService } from 'primeng/primeng';
import { takeUntil } from 'rxjs/operators';
import { Subject } from "rxjs";
import { CarrierMaintenanceService } from '../../../../../Services/carrierMaintenance.service';
import { CarrierMaintenanceHelper } from "../../carrier-maintenance-helper";
import { ToasterService } from "../../../../../Services/toaster.service";
import { MatDialog } from "@angular/material";
import { CarrierZoneService } from "../carrier-zones-service";
import { CarrierZoneHelper } from "../carrier-zones-helper";

@Component({
    selector: 'add-carrier-zones',
    templateUrl: './add-carrier-zones.component.html',
    styleUrls: ['./add-carrier-zones.component.scss',
        "../../../../components/ngxtable/material.scss",
        "../../../../components/ngxtable/datatable.component.scss",
        "../../../../components/ngxtable/icons.css",
        "../../../../components/ngxtable/app.css"],
    animations: [],
    encapsulation: ViewEncapsulation.None,
})

export class AddCarrierZonesComponent implements OnInit {

    @ViewChildren(DatatableComponent)
    table: any;
    private unsubscribe = new Subject<void>();
    public frmCarrierZones: FormGroup;
    public showLoadingScreen: boolean;
    public displayTable = false;
    private checkedAnother = false;
    public tableRows: any = [];
    public tableRowsMainData: any = [];
    isEditable = {};
    private editedRow: any = {};
    private defaultEditedRow: any = {};
    public tableColumns: any = [];
    public alerts = [];
    public bulkInsertData = [];
    public showMssg = false;
    @Output("returnedData") returnedData: any = new EventEmitter();
    public alreadyEnabled = true;
    public filteredRows: any;
    public tableFrmGroupMain: FormGroup;
    public filteredValues: any = {};
    public checkDuplicate = false;
    public errorMessage = "";
    public enteredZipCodes: any;
    
    constructor(
        private formBuilder: FormBuilder,
        private wizardService: CarrierMaintenanceService,
        private carrierzonesHelper: CarrierZoneHelper,
        private toasterService: ToasterService,
        private wizardHelper: CarrierMaintenanceHelper,
        private confirmationService: ConfirmationService,
        private carrierzonesService: CarrierZoneService,
        public dialog: MatDialog,
    ) {
        this.frmCarrierZones = new FormGroup({});
    }

    ngOnInit() {
        this.createForm();
        this.createTableForm();
        this.tableColumns = [
            { name: 'ZIP Code', prop: 'zipCode', width: "250" },
            { name: 'State', prop: 'state', width: "250" },
            { name: 'County', prop: 'county', width: "250" },
            { name: 'Zone', prop: 'zone', width: "250" },
            { name: 'Rate Center', prop: 'rateCente', width: "250" },
            { name: 'Market ID', prop: 'marketId', width: "250" },
            { name: 'Market Area', prop: 'marketArea', width: "250" },
            { name: 'City', prop: 'city', width: "250" },
            { name: 'BTA Market Number', prop: 'btaMarketNumber', width: "250" },
            { name: 'BTA Market Name', prop: 'btaMarketName', width: "250" },
            { name: 'Carrier ID', prop: 'carrierId', width: "250" },
            { name: 'Carrier Name', prop: 'carrierName', width: "250" },
            { name: 'ZIP Status', prop: 'zipStatus', width: "250" },
            { name: 'Sim Profile', prop: 'simProfile', width: "250" },
            { name: 'Sim Profile2', prop: 'simProfile2', width: "250" },
            { name: 'Plan Type', prop: 'planType', width: "250" },
        ];
        this.showMssg = false;
        this.carrierzonesService.setAddData([]);
    }

    //to create form
    private createForm() {
        this.frmCarrierZones = this.formBuilder.group({
            zipCode: ['', [Validators.required]],
            state: ['', [Validators.required, Validators.maxLength(2)]],
            county: ['', [Validators.required, Validators.maxLength(50)]],
            zone: ['', [Validators.required, Validators.maxLength(100)]],
            rateCente: ['', [Validators.maxLength(30)]],
            marketId: ['', [Validators.maxLength(126), Validators.pattern("^([0-9]*[.])?[0-9]+")]],
            marketArea: ['', [Validators.maxLength(33)]],
            city: ['', [Validators.maxLength(100)]],
            btaMarketNumber: ['', [Validators.maxLength(4)]],
            btaMarketName: ['', [Validators.maxLength(100)]],
            carrierId: ['', [Validators.maxLength(126), Validators.pattern("^([0-9]*[.])?[0-9]+")]],
            carrierName: ['', [Validators.required, Validators.maxLength(255)]],
            zipStatus: ['', [Validators.maxLength(15)]],
            simProfile: ['', [Validators.maxLength(30)]],
            simProfile2: ['', [Validators.maxLength(30)]],
            planType: ['', [Validators.maxLength(40)]],
        })
    }

    //form for column level filter
    public createTableForm() {
        this.tableFrmGroupMain = this.formBuilder.group({
            zipCode: [''],
            state: [''],
            county: [''],
            zone: [''],
            rateCente: [''],
            marketId: [''],
            marketArea: [''],
            city: [''],
            btaMarketNumber: [''],
            btaMarketName: [''],
            carrierId: [''],
            carrierName: [''],
            zipStatus: [''],
            simProfile: [''],
            simProfile2: [''],
            planType: [''],
        });
    }

    //to add Carrier Zones Details
    private addCarrierZones(f) {
        this.showLoadingScreen = true;
        this.alreadyEnabled = true;
        let obj = f.value;
        if (this.enteredZipCodes) {
            let zipCodes:any = [];
    zipCodes = [...this.enteredZipCodes.split(",")];
        let uniqueZips = zipCodes.filter((v, i) =>
        zipCodes.findIndex(item => item == v) === i);
            obj.zipCode = uniqueZips.toString();
        }
        obj = this.wizardHelper.checkRequestObject(obj);
        obj.dbEnv = this.wizardHelper.dbEnv;
        this.wizardService.addCarrierZones(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.carrierzonesHelper.getTracfoneConstantMethod("TRACFONE_ADD_CARRIERZONES_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }

                    const d = data[0].message;
                    if (d == "") {
                        this.toasterService.showErrorMessage(
                            this.carrierzonesHelper.getTracfoneConstantMethod("TRACFONE_DUPLICATE_CARRIERZONES_ERROR_MESSAGE")
                        );
                    } else {
                        let fullObject = [];
                        if (!this.carrierzonesService.getAddData() || (this.carrierzonesService.getAddData() && this.carrierzonesService.getAddData().length == 0)) {
                            let zipValue = {...obj}
                            obj.zipCode.split(",").forEach(e1 => {
                            zipValue.zipCode = e1
                            obj = { ...obj, ...zipValue }
                            fullObject.push(obj);
                        });
                        } else if (this.carrierzonesService.getAddData().length > 0) {
                            fullObject = this.carrierzonesService.getAddData();
                            let zipValue = {...obj}
                            obj.zipCode.split(",").forEach(e1 => {
                                zipValue.zipCode = e1
                                obj = { ...obj, ...zipValue }
                            }); 
                            fullObject.forEach((data, key) => {
                                if (data.zipCode == obj.zipCode && data.state == obj.state
                                    && data.county == obj.county && data.zone == obj.zone && data.carrierName == obj.carrierName
                                ) {
                                    fullObject.splice(key, 1);
                                    fullObject = [...fullObject];
                                }
                            });
                            fullObject.push(obj);
                        }
                        this.carrierzonesService.setAddData(fullObject);
                        this.tableRowsMainData = [];
                        this.tableRows = [];
                        for (let i = 0; i < this.carrierzonesService.getAddData().length; i++) {
                            this.tableRowsMainData.push(this.carrierzonesService.getAddData()[i]);
                        }
                        let rowId = 1;
                        this.tableRowsMainData.forEach(element => {
                            element.rowId = rowId;
                            rowId++;
                        });
                        this.tableRows = [...this.tableRowsMainData];
                        if (this.checkedAnother) {
                            this.displayTable = false;
                        } else {
                            this.displayTable = true;
                        }
                        this.generateFilters();
                        this.filterReportResults();
                        this.frmCarrierZones.reset();
                        this.toasterService.showSuccessMessage(
                            this.carrierzonesHelper.getTracfoneConstantMethod("TRACFONE_ADD_CARRIERZONES_SUCCESS_MESSAGE")
                        );
                    }
                    this.checkDuplicate = false;
                    this.showLoadingScreen = false;
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.carrierzonesHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    onChangeCheckbox(event) {
        if (event.checked) this.checkedAnother = true;
        else this.checkedAnother = false;
    }

    //show summary confirm
    public showSummaryConfirm(f, index) {
        this.confirmationService.confirm({
            key: 'confirm-add-show-summary',
            message: this.carrierzonesHelper.getTracfoneConstantMethod("TRACFONE_DONE_CREATING_CARRIERZONES_CONFIRM_MESSAGE"),
            accept: () => {
                this.displayTable = true;
                this.checkedAnother = false;
            }
        });
    }

    // reset the form
    revert() {
        this.frmCarrierZones.reset();
        this.tableRows = [];
        this.tableRowsMainData = [];
        this.filteredValues = {};
        this.alerts = [];
        let filterKeys = Object.keys(this.tableFrmGroupMain.controls);
        filterKeys.forEach(_e1 => {
            this.tableFrmGroupMain.controls[`${_e1}`].patchValue([]);
        });
        this.alreadyEnabled = true;
    }

    public editButtonClicked(rowData, rowIndex) {
        this.alreadyEnabled = false;
        this.defaultEditedRow = { ...rowData }
        for (let i = 0; i < this.tableRowsMainData.length; i++) {
            if (this.isEditable[i])
                this.alreadyEnabled = true;
        }
        if (!this.alreadyEnabled)
            this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        else {
            this.alreadyEnabled = false;
            this.toasterService.showErrorMessage(
                this.carrierzonesHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE")
            );
        }
    }

    private inputValueChanged(event, column, row, oldValue) {
        this.editedRow[column] = event.target.value;
        this.defaultEditedRow[column] = event.target.defaultValue;

    }

    //to update Carrier Zones Details
    public updateCarrierZones(editData, rowIndex) {
        if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
            this.toasterService.showErrorMessage(
                this.carrierzonesHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            return;
        }
        this.showLoadingScreen = true;
        let obj = { ...editData, ...this.editedRow }

        obj = this.wizardHelper.checkRequestObject(obj);
        obj.dbEnv = this.wizardHelper.dbEnv;
        obj.oldZipCode = this.defaultEditedRow.zipCode;
        obj.oldState = this.defaultEditedRow.state;
        obj.oldCounty = this.defaultEditedRow.county;
        obj.oldZone = this.defaultEditedRow.zone;
        obj.oldCarrierName = this.defaultEditedRow.carrierName;
        if (obj.zipCode != this.defaultEditedRow.zipCode || obj.state != this.defaultEditedRow.state || obj.county != this.defaultEditedRow.county
            || obj.zone != this.defaultEditedRow.zone || obj.carrierName != this.defaultEditedRow.carrierName) {
            this.checkDuplicate = true;
        } else {
            this.checkDuplicate = false;
        }
        obj.checkDuplicate = this.checkDuplicate;
        this.wizardService.updateCarrierZones(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.carrierzonesHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_CARRIERZONES_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    for (let i = 0; i < this.tableRowsMainData.length; i++) {
                        if (this.tableRowsMainData[i].rowId == this.defaultEditedRow.rowId) {
                            this.tableRowsMainData[i] = obj;
                        }
                    }
                    this.isEditable[rowIndex] = !this.isEditable[rowIndex];
                    this.showLoadingScreen = false;
                    this.editedRow = {};
                    this.defaultEditedRow = {};
                    this.tableRows = [...this.tableRowsMainData];
                    this.alreadyEnabled = true;
                    this.generateFilters();
                    // this.filterReportResults();

                    this.toasterService.showSuccessMessage(
                        this.carrierzonesHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_CARRIERZONES_SUCCESS_MESSAGE")
                    );

                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.carrierzonesHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    //to cancel update
    private cancelEditForm(rowData, rowIndex) {
        this.showLoadingScreen = true;
        this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        this.tableColumns.forEach(e1 => {
            if (document.getElementById(e1.prop + rowIndex)) {
                (<HTMLInputElement>(
                    document.getElementById(e1.prop + rowIndex)
                )).value = rowData[e1.prop] || '';
            }
        });

        this.editedRow = {};
        this.defaultEditedRow = {};
        this.showLoadingScreen = false;
        this.alreadyEnabled = true;
    }

    //to filter table
    private updateSummaryTable(event) {
        const val = event.target.value.toLowerCase();

        const temp = this.tableRowsMainData.filter(function (d) {
            return (d.zipCode ? d.zipCode.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.state ? d.state.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.county ? d.county.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.zone ? d.zone.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.rateCente ? d.rateCente.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.marketId ? d.marketId.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.marketArea ? d.marketArea.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.city ? d.city.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.btaMarketNumber ? d.btaMarketNumber.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.btaMarketName ? d.btaMarketName.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.carrierId ? d.carrierId.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.carrierName ? d.carrierName.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.zipStatus ? d.zipStatus.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.simProfile ? d.simProfile.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.simProfile2 ? d.simProfile2.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.planType ? d.planType.toLowerCase().indexOf(val) !== -1 : !val)
        });
        this.tableRows = temp;
    }


    // delete confirm
    public showConfirm(cmiData, rowIndex) {
        this.confirmationService.confirm({
            key: 'confirm-delete-cmi',
            message: "Are you sure you want to delete Carrier Zones ?",
            accept: () => {
                this.deleteCarrierZones(cmiData, rowIndex)
            }
        });
    }

    // to delete Ar Usa MarketDetails
    public deleteCarrierZones(cmiData, rowIndex) {
        this.showLoadingScreen = true;
        let obj: any = {};
        obj = cmiData
        obj.dbEnv = this.wizardHelper.dbEnv;
        delete obj.rowId;
        this.wizardService.deleteCarrierZones(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.carrierzonesHelper.getTracfoneConstantMethod("TRACFONE_DELETE_CARRIERZONES_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    this.toasterService.showSuccessMessage(
                        this.carrierzonesHelper.getTracfoneConstantMethod("TRACFONE_DELETE_CARRIERZONES_SUCCESS_MESSAGE")
                    );

                    this.tableRows.forEach((rec: any, key) => {
                        if (obj.zipCode == rec.zipCode && obj.state == rec.state && obj.county == rec.county && obj.zone == rec.zone && obj.carrierName == rec.carrierName) {
                            this.tableRows.splice(key, 1);
                            this.carrierzonesService.getAddData().splice(key, 1);
                        }
                    });
                    this.tableRows = [...this.tableRows];
                    this.tableRowsMainData = [...this.tableRows];
                    if (this.tableRows.length === 0) {
                        this.displayTable = false;
                        this.checkedAnother = false;
                        this.tableRows = [];
                        this.revert();
                        this.carrierzonesService.setAddData([]);
                    }
                    this.showLoadingScreen = false;
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.carrierzonesHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    ngOnChanges(changes: SimpleChanges) {
        if(changes.insertData){
            if (changes.insertData.currentValue) {
                if (changes.insertData.currentValue.zipCode) {
                    this.enteredZipCodes = changes.insertData.currentValue.zipCode;
                }
               
            }
        }
        }

      /*
     * Validate ZIP Code text area
     * Validation Criteria- Limit -> 40,000 | Size -> 5 per zip code
     */
      public zipCodeValidation(event) {
        this.errorMessage = "";
        let lengthError = "A ZIP Code must have exactly 5 digits.";
        let limitError = "ZIP Codes cannot exceed 40,000 limit";
        let stringError = "ZIP Code must be number";
        let zipcodes: any = [];
        if (/\d/.test(event)) {
            //Splitting string based on the new line
            let zip = event.split("\n")
            zip = zip.filter(el => el !== '')
            for (let i = 0; i < zip.length; i++) {
                //removing spaces
                zip[i] = zip[i].replace(/\s/g, "");
                //checking if any value with comma exists
                if (zip[i].indexOf(',') > -1) {
                    //Sliting String based on the comma
                    let commaSeperatedArr = zip[i].split(",");
                    /*
                     * Validate ZIP Code based on the length
                     * if ZIP Codes are valid then pushing into 'zipcodes' array
                    */
                    for (let j = 0; j < commaSeperatedArr.length; j++) {
                        //validate ZIP code if it is number or not
                        if (/^[0-9]*$/.test(commaSeperatedArr[j])) {
                            if (commaSeperatedArr[j].length != 0) {
                                if (commaSeperatedArr[j].length < 5) {
                                    this.errorMessage = lengthError;
                                    break;
                                } else if (commaSeperatedArr[j].length > 5) {
                                    this.errorMessage = lengthError;
                                    break;
                                } else {
                                    zipcodes.push(commaSeperatedArr[j]);
                                    //check if zip codes exceeds 40,000
                                    if (zipcodes.length > 40000) {
                                        this.errorMessage = limitError;
                                        break;
                                    }
                                }
                            }
                        } else {
                            this.errorMessage = stringError;
                            break;
                        }
                    }
                }//validate ZIP code if it is number or not
                else if (!/^[0-9]*$/.test(zip[i])) {
                    this.errorMessage = stringError;
                    break;
                }//Validate ZIP Code based on the length  
                else if (zip[i].length < 5) {
                    if (zip[i].length != 0) {
                        this.errorMessage = lengthError;
                        break;
                    }
                }//Validate ZIP Code based on the length 
                else if (zip[i].length > 5) {
                    this.errorMessage = lengthError;
                    break;
                }//if ZIP Codes are valid then pushing into 'zipcodes' array
                else {
                    zipcodes.push(zip[i]);
                    //check if zip codes exceeds 40,000
                    if (zipcodes.length > 40000) {
                        this.errorMessage = limitError;
                        break;
                    }
                }
            }
        } else {
            event = event.toUpperCase();
            if (event == "ALL")
                zipcodes.push(event);
            else if (event.length > 0)
                this.errorMessage = stringError;
        }

        let returnedZip: any = [];
        this.enteredZipCodes = "";
        if (this.errorMessage == "") {
            //filter duplicate zipcodes
            returnedZip = zipcodes.filter((val, index) => zipcodes.indexOf(val) == index);
            //removing empty elements
            returnedZip = returnedZip.filter(item => item);
            this.enteredZipCodes = returnedZip.toString();
        } else {
            this.enteredZipCodes = null;
        }
    }

    private warningAlert(warningMsg: string) {
        window.scrollTo(0, 0);
        this.alerts = [];
        this.alerts.push({
            id: 3,
            type: 'warning',
            message: warningMsg
        });
    }

    public closeAlert(alert: any) {
        const index: number = this.alerts.indexOf(alert);
        this.alerts.splice(index, 1);
    }

    public showLastInsertedRecords() {
        this.returnedData.emit({ lastInsertedRecord: true });
    }

    // to filter columns
    public filterReportResults(): void {
        const filterFormObject = this.tableFrmGroupMain.value;
        this.filteredValues.zipCode = filterFormObject.zipCode;
        this.filteredValues.state = filterFormObject.state;
        this.filteredValues.county = filterFormObject.county;
        this.filteredValues.zone = filterFormObject.zone;
        this.filteredValues.rateCente = filterFormObject.rateCente;
        this.filteredValues.marketId = filterFormObject.marketId;
        this.filteredValues.marketArea = filterFormObject.marketArea;
        this.filteredValues.city = filterFormObject.city;
        this.filteredValues.btaMarketNumber = filterFormObject.btaMarketNumber;
        this.filteredValues.btaMarketName = filterFormObject.btaMarketName;
        this.filteredValues.carrierId = filterFormObject.carrierId;
        this.filteredValues.carrierName = filterFormObject.carrierName;
        this.filteredValues.zipStatus = filterFormObject.zipStatus;
        this.filteredValues.simProfile = filterFormObject.simProfile;
        this.filteredValues.simProfile2 = filterFormObject.simProfile2;
        this.filteredValues.planType = filterFormObject.planType;
        const newRows = Object.keys(filterFormObject).reduce((acc, key) => {
            if (!filterFormObject[key].length) return acc;
            const filteredRows = acc.filter(val => filterFormObject[key].indexOf(val[key]) > -1);
            return filteredRows;
        }, this.tableRowsMainData);

        this.tableRows = newRows;
    }

    public generateFilters(): void {
        this.filteredRows = Object.keys(this.tableColumns)
            .map(i => this.tableColumns[i].prop)
            .reduce((filterObject, columnName) => {
                const uniqueValuesPerRow = this.tableRows.reduce((set, row) => set.add(row[columnName]), new Set());
                let val: any = Array.from(uniqueValuesPerRow);
                if (/^[0-9]*$/.test(val[0])) {
                    filterObject[columnName] = val.sort(function (a, b) { return a - b });
                } else {
                    filterObject[columnName] = val.sort((a, b) => {
                        a = a || '';
                        b = b || '';
                        return a.localeCompare(b);
                    });
                }
                return filterObject;
            }, {});
    }

}
