import { Component, OnInit, ViewChild } from "@angular/core";
import { NgbTabset} from '@ng-bootstrap/ng-bootstrap';


@Component({
    selector: 'carrier-zones',
    templateUrl: './carrier-zones.component.html',
})
export class CarrierZonesComponent implements OnInit {
    @ViewChild('tabs')
	private tabs: NgbTabset;
    readonly SUMMARY_TAB = "summaryTab";

    constructor() { }

    ngOnInit() { }


public returnedDatas(data) {
    if (data.lastInsertedRecord) {
        this.tabs.select(this.SUMMARY_TAB);
      }
}

}
