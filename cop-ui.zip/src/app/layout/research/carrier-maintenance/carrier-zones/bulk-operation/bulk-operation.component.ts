import { Component, OnInit, SimpleChanges, ViewEncapsulation } from "@angular/core";
import { Subject } from "rxjs";
import { takeUntil } from "rxjs/operators";
import { ToasterService } from "../../../../../Services/toaster.service";
import { ExportToCsvService } from "../../../../../Services/export-to-csv.service";
import { ImportFromCsvService } from "../../../../../Services/import-from-csv.service";
import { CarrierZoneHelper } from "../carrier-zones-helper";
import { CarrierMaintenanceService } from '../../../../../Services/carrierMaintenance.service';
import { CarrierMaintenanceHelper } from "../../carrier-maintenance-helper";


@Component({
    selector: 'bulk-operation-carrierzones',
    templateUrl: './bulk-operation.component.html',
    styleUrls: ['./bulk-operation.component.scss',
        '../../../../components/ngxtable/material.scss',
        '../../../../components/ngxtable/datatable.component.scss',
        '../../../../components/ngxtable/icons.css',
        '../../../../components/ngxtable/app.css'],
    encapsulation: ViewEncapsulation.None,
    providers: [ExportToCsvService, ImportFromCsvService],
})
export class BulkOperationCarrierZonesComponent implements OnInit {
    private unsubscribe = new Subject<void>();
    public flagColumn = false;
    public textColumns = false;
    public fileContent: Boolean;
    public fileContentDelete: Boolean;
    public filename: string = null;
    public filenameDelete: string = null;
    public uploadedData: any = [];
    public uploadedDataDelete: any = [];
    public uploadedMainData: any = [];
    public uploadedMainDataDelete: any = [];
    public alerts: any = [];
    public exportColumns = [];
    public exportColumnsDelete = [];
    public tableColmns = [];
    public tableColmnsDelete = [];
    readonly EXPORT_FILE_NAME = "Insert_CarrierZones_template";
    readonly EXPORT_FILE_NAME_DELETE = "Delete_CarrierZones_template";
    public showLoadingScreen: Boolean = false;
    public showMssg = false;
    public showAdd = false;
    public showDelete = true;
    public errorMessage = "";
    public enteredZipCodes: any;
    label = "Click here to bulk insert";

    constructor(
        private toasterService: ToasterService,
        private exportToCsvService: ExportToCsvService,
        private importFromCsvService: ImportFromCsvService,
        private wizardService: CarrierMaintenanceService,
        private wizardHelper: CarrierMaintenanceHelper,
        private carrierZoneHelper: CarrierZoneHelper,
    ) { }

    ngOnInit() {
        this.showAdd = false;
        this.showDelete = true;
        this.label = "Click here to bulk insert";
        this.fileContent = false;
        this.fileContentDelete = false;
        this.filename = "";
        this.filenameDelete = "";

        this.uploadedData = [];
        this.uploadedMainData = [];
        this.alerts = [];
        this.exportColumns = ["ZIP Code", "State", "County", "Zone", "Rate Center", "Market ID", "Market Area", "City", "BTA Market Number", "BTA Market Name",
            "Carrier ID", "Carrier Name", "ZIP Status", "Sim Profile", "Sim Profile2", "Plan Type"];
        this.exportColumnsDelete = ["ZIP Code", "State", "County", "Zone", "Carrier Name"];
        this.tableColmns = [
            { name: 'ZIP Code', prop: 'zipCode', width: "250" },
            { name: 'State', prop: 'state', width: "250" },
            { name: 'County', prop: 'county', width: "250" },
            { name: 'Zone', prop: 'zone', width: "250" },
            { name: 'Rate Center', prop: 'rateCente', width: "250" },
            { name: 'Market ID', prop: 'marketId', width: "250" },
            { name: 'Market Area', prop: 'marketArea', width: "250" },
            { name: 'City', prop: 'city', width: "250" },
            { name: 'BTA Market Number', prop: 'btaMarketNumber', width: "250" },
            { name: 'BTA Market Name', prop: 'btaMarketName', width: "250" },
            { name: 'Carrier ID', prop: 'carrierId', width: "250" },
            { name: 'Carrier Name', prop: 'carrierName', width: "250" },
            { name: 'ZIP Status', prop: 'zipStatus', width: "250" },
            { name: 'Sim Profile', prop: 'simProfile', width: "250" },
            { name: 'Sim Profile2', prop: 'simProfile2', width: "250" },
            { name: 'Plan Type', prop: 'planType', width: "250" },
        ];
        this.tableColmnsDelete = [
            { name: 'ZIP Code', prop: 'zipCode', width: "250" },
            { name: 'State', prop: 'state', width: "250" },
            { name: 'County', prop: 'county', width: "250" },
            { name: 'Zone', prop: 'zone', width: "250" },
            { name: 'Carrier Name', prop: 'carrierName', width: "250" },
        ];
        this.showMssg = false;
    }

    //Used to Download Template
    exportToCSV() {
        this.exportToCsvService.downloadFile([], this.EXPORT_FILE_NAME, this.exportColumns);
    }

    exportToCSVDelete() {
        this.exportToCsvService.downloadFile([], this.EXPORT_FILE_NAME_DELETE, this.exportColumnsDelete);
    }

    bulkInsertCarrierZones() {
        if (document.getElementsByClassName("tableError") && document.getElementsByClassName("tableError").length > 0) {
            this.toasterService.showErrorMessage("Please fix validation errors.");
            return;
        }
        for (let i = 0; i < this.uploadedMainData.length; i++) {
            this.uploadedMainData[i].dbEnv = this.wizardHelper.dbEnv;
            delete this.uploadedMainData[i]['S.NO'];
            delete this.uploadedMainData[i]['ZIP Code'];
            delete this.uploadedMainData[i]['State'];
            delete this.uploadedMainData[i]['County'];
            delete this.uploadedMainData[i]['Zone'];
            delete this.uploadedMainData[i]['Rate Center'];
            delete this.uploadedMainData[i]['Market ID'];
            delete this.uploadedMainData[i]['Market Area'];
            delete this.uploadedMainData[i]['City'];
            delete this.uploadedMainData[i]['BTA Market Number'];
            delete this.uploadedMainData[i]['BTA Market Name'];
            delete this.uploadedMainData[i]['Carrier ID'];
            delete this.uploadedMainData[i]['Carrier Name'];
            delete this.uploadedMainData[i]['ZIP Status'];
            delete this.uploadedMainData[i]['Sim Profile'];
            delete this.uploadedMainData[i]['Sim Profile2'];
            delete this.uploadedMainData[i]['Plan Type'];

        }
        let uploadData = [];

        uploadData = this.uploadedMainData.filter((v, i, a) => a.findIndex(t => (t.zipCode === v.zipCode && t.state === v.state && t.county === v.county
            && t.zone === v.zone && t.carrierName === v.carrierName)) === i);

        let callTimes: number = Math.ceil(uploadData.length / 500);
        for (let i = 0; i < callTimes; i++) {
            let obj = [];
            for (let j = 500 * i; j < uploadData.length; j++) {
                if (j < (i + 1) * 500)
                    obj.push(uploadData[j]);
                else
                    break;
            }
            this.bulkInsert(obj);
        }
    }

    private bulkInsert(obj) {
        this.showLoadingScreen = true;
        obj.zipCode = this.enteredZipCodes;
        this.wizardService.bulkInsertCarrierZones(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.carrierZoneHelper.getTracfoneConstantMethod("TRACFONE_BULK_ADD_CARRIERZONES_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    this.showLoadingScreen = false;
                    this.showMssg = true;
                    this.removeFile();
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.carrierZoneHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }


    bulkDeleteCarrierZones() {
        if (document.getElementsByClassName("tableError") && document.getElementsByClassName("tableError").length > 0) {
            this.toasterService.showErrorMessage("Please fix validation errors.");
            return;
        }
        for (let i = 0; i < this.uploadedMainDataDelete.length; i++) {
            this.uploadedMainDataDelete[i].dbEnv = this.wizardHelper.dbEnv;
            delete this.uploadedMainDataDelete[i]['S.NO'];
            delete this.uploadedMainDataDelete[i]['ZIP Code'];
            delete this.uploadedMainDataDelete[i]['State'];
            delete this.uploadedMainDataDelete[i]['County'];
            delete this.uploadedMainDataDelete[i]['Zone'];
            delete this.uploadedMainDataDelete[i]['Carrier Name'];
        }
        let uploadData = [];

        uploadData = this.uploadedMainDataDelete.filter((v, i, a) => a.findIndex(t => (t.zipCode === v.zipCode && t.state === v.state && t.county === v.county
            && t.zone === v.zone && t.carrierName === v.carrierName)) === i);

        let callTimes: number = Math.ceil(uploadData.length / 500);
        for (let i = 0; i < callTimes; i++) {
            let obj = [];
            for (let j = 500 * i; j < uploadData.length; j++) {
                if (j < (i + 1) * 500)
                    obj.push(uploadData[j]);
                else
                    break;
            }
            this.bulkDelete(obj);
        }
    }

    private bulkDelete(obj) {
        this.showLoadingScreen = true;
        this.wizardService.bulkDeleteCarrierZones(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.carrierZoneHelper.getTracfoneConstantMethod("TRACFONE_BULK_DELETE_CARRIERZONES_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    this.showLoadingScreen = false;
                    this.showMssg = true;
                    this.removeFile();
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.carrierZoneHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    //Read File and show data on the table
    public changeListenerDelete(files: FileList) {
        let invalidFile = "Please select a valid file to upload.";
        let noDataInFile = "There is no data to upload in this file.";
        this.alerts = [];
        if (files && files.length > 0) {
            this.fileContentDelete = true;
            let file: File = files.item(0);
            let name = file.name;
            var ext = name.substring(name.lastIndexOf('.') + 1);
            if (ext.toLowerCase() == 'csv') {
                this.filenameDelete = name.substr(0, name.lastIndexOf("."));
                if (this.filenameDelete.split(" ")[0] != this.EXPORT_FILE_NAME_DELETE) {
                    this.toasterService.showErrorMessage(invalidFile);
                    return;
                }
            } else {
                this.toasterService.showErrorMessage(invalidFile);
                return;
            }
            let reader: FileReader = new FileReader();
            reader.readAsText(file);
            reader.onload = (e) => {
                let uploadData = this.importFromCsvService.csvToArray(reader.result);
                if (uploadData.length == 0) {
                    this.toasterService.showErrorMessage(noDataInFile);
                } else {
                    let keys = Object.keys(uploadData[0]);
                    for (let i = 1, j = 0; j < this.exportColumnsDelete.length; i++, j++) {
                        if (keys[i] != this.exportColumnsDelete[j]) {
                            this.toasterService.showErrorMessage(invalidFile);
                            return;
                        }
                    }
                    uploadData.forEach(_e1 => {
                        _e1.zipCode = _e1['ZIP Code'];
                        _e1.state = _e1['State'];
                        _e1.county = _e1['County'];
                        _e1.zone = _e1['Zone'];
                        _e1.carrierName = _e1['Carrier Name'];
                    });
                    this.uploadedDataDelete = [...this.checkUploadedDataDelete(uploadData)];
                }
            }
        }
    }

    //Read File and show data on the table
    public changeListener(files: FileList) {
        let invalidFile = "Please select a valid file to upload.";
        let noDataInFile = "There is no data to upload in this file.";
        this.alerts = [];
        if (files && files.length > 0) {
            this.fileContent = true;
            let file: File = files.item(0);
            let name = file.name;
            var ext = name.substring(name.lastIndexOf('.') + 1);
            if (ext.toLowerCase() == 'csv') {
                this.filename = name.substr(0, name.lastIndexOf("."));
                if (this.filename.split(" ")[0] != this.EXPORT_FILE_NAME) {
                    this.toasterService.showErrorMessage(invalidFile);
                    return;
                }
            } else {
                this.toasterService.showErrorMessage(invalidFile);
                return;
            }
            let reader: FileReader = new FileReader();
            reader.readAsText(file);
            reader.onload = (e) => {
                let uploadData = this.importFromCsvService.csvToArray(reader.result);
                if (uploadData.length == 0) {
                    this.toasterService.showErrorMessage(noDataInFile);
                } else {
                    let keys = Object.keys(uploadData[0]);
                    for (let i = 1, j = 0; j < this.exportColumns.length; i++, j++) {
                        if (keys[i] != this.exportColumns[j]) {
                            this.toasterService.showErrorMessage(invalidFile);
                            return;
                        }
                    }
                    uploadData.forEach(_e1 => {
                        _e1.zipCode = _e1['ZIP Code'];
                        _e1.state = _e1['State'];
                        _e1.county = _e1['County'];
                        _e1.zone = _e1['Zone'];
                        _e1.rateCente = _e1['Rate Center'];
                        _e1.marketId = _e1['Market ID'];
                        _e1.marketArea = _e1['Market Area'];
                        _e1.city = _e1['City'];
                        _e1.btaMarketNumber = _e1['BTA Market Number'];
                        _e1.btaMarketName = _e1['BTA Market Name'];
                        _e1.carrierId = _e1['Carrier ID'];
                        _e1.carrierName = _e1['Carrier Name'];
                        _e1.zipStatus = _e1['ZIP Status'];
                        _e1.simProfile = _e1['Sim Profile'];
                        _e1.simProfile2 = _e1['Sim Profile2'];
                        _e1.planType = _e1['Plan Type'];
                    });
                    this.uploadedData = [...this.checkUploadedData(uploadData)];
                }
            }
        }
    }

    //Removes file and table from the screen
    public removeFile() {
        this.fileContent = false;
        this.fileContentDelete = false;
        this.filename = null;
        this.filenameDelete = null;

        this.uploadedData = [];
        this.uploadedMainData = [];
        this.uploadedDataDelete = [];
        this.uploadedMainDataDelete = [];
        this.alerts = [];
    }

    public checkUploadedDataDelete(data) {
        let errorData = [];
        let successData = [];
        data.forEach(element => {
            element.rowNum = element['S.NO'];
        });
        data.forEach(element => {
            if (element.rowNum.length == 0 || element["ZIP Code"].length == 0 || element["State"].length == 0 || element["County"].length == 0 || element["Zone"].length == 0 || element["Carrier Name"].length == 0 
            || element["ZIP Code"].length != 5 || element["State"].length > 2|| element["County"].length > 50 || element["Zone"].length > 100 || element["Carrier Name"].length > 255) {
             errorData.push(element);   
            } else
                successData.push(element);
        });
        this.uploadedMainDataDelete = [...errorData, ...successData];
        return this.uploadedMainDataDelete;
    }

    public checkUploadedData(data) {
        let errorData = [];
        let successData = [];
        data.forEach(element => {
            element.rowNum = element['S.NO'];
        });
        data.forEach(element => {

            if (element.rowNum.length == 0 || element["ZIP Code"].length == 0 || element["State"].length == 0 || element["County"].length == 0 || element["Zone"].length == 0
            || element["Carrier Name"].length == 0 || element["State"].length > 2
            || element["County"].length > 50 || element["Zone"].length > 100 || element["Rate Center"].length > 30 || element["Market ID"].length > 126
            || element["Market Area"].length > 33 || element["City"].length > 100 || element["BTA Market Number"].length > 4 || element["BTA Market Name"].length > 100
            || element["Carrier ID"].length > 126 || element["Carrier Name"].length > 255 || element["ZIP Status"].length > 15 || element["Sim Profile"].length > 30
            || element["Sim Profile2"].length > 30 || element["Plan Type"].length > 40) {
            errorData.push(element);
            } else
                successData.push(element);
        });
        this.uploadedMainData = [...errorData, ...successData];
        return this.uploadedMainData;
    }

    //Removes Row from the table
    deleteRow(row) {
        this.uploadedMainData.forEach((data, key) => {
            if (row.rowNum == data.rowNum) {
                this.uploadedMainData.splice(key, 1);
            }
        });
        this.uploadedData = [...this.uploadedMainData];
    }

    deleteRowDelete(row) {
        this.uploadedMainDataDelete.forEach((data, key) => {
            if (row.rowNum == data.rowNum) {
                this.uploadedMainDataDelete.splice(key, 1);
            }
        });
        this.uploadedDataDelete = [...this.uploadedMainDataDelete];
    }

    //inline values changes
    public editValueChanged(event, column, row, oldValue) {
        for (let i = 0; i < this.uploadedMainData.length; i++) {
            if (this.uploadedMainData[i].rowNum == row.rowNum) {
                this.uploadedMainData[i][column] = event.target.value;
            }
        }
        this.uploadedData = [...this.uploadedMainData];
    }

    public editValueChangedDelete(event, column, row, oldValue) {
        for (let i = 0; i < this.uploadedMainDataDelete.length; i++) {
            if (this.uploadedMainDataDelete[i].rowNum == row.rowNum) {
                this.uploadedMainDataDelete[i][column] = event.target.value;
            }
        }
        this.uploadedDataDelete = [...this.uploadedMainDataDelete];
    }

    //Filter for result table
    public filterTableData(event) {
        const val = event.target.value.toLowerCase();
        // filter our data
        const temp = this.uploadedMainData.filter(function (d) {
            return (d.zipCode ? d.zipCode.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.state ? d.state.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.county ? d.county.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.zone ? d.zone.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.rateCente ? d.rateCente.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.marketId ? d.marketId.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.marketArea ? d.marketArea.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.city ? d.city.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.btaMarketNumber ? d.btaMarketNumber.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.btaMarketName ? d.btaMarketName.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.carrierId ? d.carrierId.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.carrierName ? d.carrierName.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.zipStatus ? d.zipStatus.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.simProfile ? d.simProfile.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.simProfile2 ? d.simProfile2.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.planType ? d.planType.toLowerCase().indexOf(val) !== -1 : !val)
        });
        // update the rows
        this.uploadedData = temp;
    }

    //Filter for result table
    public filterTableDataDelete(event) {
        const val = event.target.value.toLowerCase();
        // filter our data
        const temp = this.uploadedMainDataDelete.filter(function (d) {
            return (d.zipCode ? d.zipCode.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.state ? d.state.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.county ? d.county.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.zone ? d.zone.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.carrierName ? d.carrierName.toLowerCase().indexOf(val) !== -1 : !val)
        });
        // update the rows
        this.uploadedDataDelete = temp;
    }

    ngOnChanges(changes: SimpleChanges) {
        if(changes.insertData){
            if (changes.insertData.currentValue) {
                if (changes.insertData.currentValue.zipCode) {
                    this.enteredZipCodes = changes.insertData.currentValue.zipCode;
                }
               
            }
        }
        }

      /*
     * Validate ZIP Code text area
     * Validation Criteria- Limit -> 40,000 | Size -> 5 per zip code
     */
      public zipCodeValidation(event) {
        this.errorMessage = "";
        let lengthError = "A ZIP Code must have exactly 5 digits.";
        let limitError = "ZIP Codes cannot exceed 40,000 limit";
        let stringError = "ZIP Code must be number";
        let zipcodes: any = [];
        if (/\d/.test(event)) {
            //Splitting string based on the new line
            let zip = event.split("\n")
            zip = zip.filter(el => el !== '')
            for (let i = 0; i < zip.length; i++) {
                //removing spaces
                zip[i] = zip[i].replace(/\s/g, "");
                //checking if any value with comma exists
                if (zip[i].indexOf(',') > -1) {
                    //Sliting String based on the comma
                    let commaSeperatedArr = zip[i].split(",");
                    /*
                     * Validate ZIP Code based on the length
                     * if ZIP Codes are valid then pushing into 'zipcodes' array
                    */
                    for (let j = 0; j < commaSeperatedArr.length; j++) {
                        //validate ZIP code if it is number or not
                        if (/^[0-9]*$/.test(commaSeperatedArr[j])) {
                            if (commaSeperatedArr[j].length != 0) {
                                if (commaSeperatedArr[j].length < 5) {
                                    this.errorMessage = lengthError;
                                    break;
                                } else if (commaSeperatedArr[j].length > 5) {
                                    this.errorMessage = lengthError;
                                    break;
                                } else {
                                    zipcodes.push(commaSeperatedArr[j]);
                                    //check if zip codes exceeds 40,000
                                    if (zipcodes.length > 40000) {
                                        this.errorMessage = limitError;
                                        break;
                                    }
                                }
                            }
                        } else {
                            this.errorMessage = stringError;
                            break;
                        }
                    }
                }//validate ZIP code if it is number or not
                else if (!/^[0-9]*$/.test(zip[i])) {
                    this.errorMessage = stringError;
                    break;
                }//Validate ZIP Code based on the length  
                else if (zip[i].length < 5) {
                    if (zip[i].length != 0) {
                        this.errorMessage = lengthError;
                        break;
                    }
                }//Validate ZIP Code based on the length 
                else if (zip[i].length > 5) {
                    this.errorMessage = lengthError;
                    break;
                }//if ZIP Codes are valid then pushing into 'zipcodes' array
                else {
                    zipcodes.push(zip[i]);
                    //check if zip codes exceeds 40,000
                    if (zipcodes.length > 40000) {
                        this.errorMessage = limitError;
                        break;
                    }
                }
            }
        } else {
            event = event.toUpperCase();
            if (event == "ALL")
                zipcodes.push(event);
            else if (event.length > 0)
                this.errorMessage = stringError;
        }

        let returnedZip: any = [];
        this.enteredZipCodes = "";
        if (this.errorMessage == "") {
            //filter duplicate zipcodes
            returnedZip = zipcodes.filter((val, index) => zipcodes.indexOf(val) == index);
            //removing empty elements
            returnedZip = returnedZip.filter(item => item);
            this.enteredZipCodes = returnedZip.toString();
        } else {
            this.enteredZipCodes = null;
        }
    }

    setLikeButton(event) {
        this.filename = "";
        this.filenameDelete = "";
        this.uploadedData = [];
        this.uploadedDataDelete = [];
        this.uploadedMainData = [];
        this.uploadedMainDataDelete = [];
        this.fileContent = false;
        this.fileContentDelete = false;
        if (event.checked) {
            this.showAdd = true
            this.showDelete = false
            this.label = "Click here to bulk delete";
        } else {
            this.showDelete = true
            this.showAdd = false
            this.label = "Click here to bulk insert";
        }
    }
}