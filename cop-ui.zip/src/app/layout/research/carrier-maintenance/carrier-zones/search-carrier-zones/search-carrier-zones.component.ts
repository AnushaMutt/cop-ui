import { Component, OnInit, ViewEncapsulation, ViewChild, SimpleChanges } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ConfirmationService } from 'primeng/primeng';
import { takeUntil } from 'rxjs/operators';
import { Subject } from "rxjs";
import { CarrierMaintenanceService } from '../../../../../Services/carrierMaintenance.service';
import { CarrierMaintenanceHelper } from "../../carrier-maintenance-helper";
import { ToasterService } from "../../../../../Services/toaster.service";
import { CarrierZoneHelper } from "../carrier-zones-helper";
import { CarrierZoneService } from "../carrier-zones-service";
import { ExportToCsvService } from "../../../../../Services/export-to-csv.service";


@Component({
    selector: 'search-carrier-zones',
    templateUrl: './search-carrier-zones.component.html',
    styleUrls: ['./search-carrier-zones.component.scss',
        "../../../../components/ngxtable/material.scss",
        "../../../../components/ngxtable/datatable.component.scss",
        "../../../../components/ngxtable/icons.css",
        "../../../../components/ngxtable/app.css"],
    animations: [],
    encapsulation: ViewEncapsulation.None,
})

export class SearchCarrierZonesComponent implements OnInit {
    private unsubscribe = new Subject<void>();
    public frmCarrierZones: FormGroup;
    public showLoadingScreen: boolean;
    public tableRows: any = [];
    public tableRowsMainData: any = [];
    isEditable = {};
    private editedRow: any = {};
    private defaultEditedRow: any = {};
    public tableColumns: any = [];
    public alreadyEnabled = true;
    public showNoRecordsFoundMessage: Boolean = true;
    public filteredValues: any = {};
    public selected: any = [];
    public multiColumnEditSection = false;
    public filteredRows: any;
    public tableFrmGroupMain: FormGroup;
    public showBulkUpdateButton = false;
    public selectedCarrierZones = [];
    public bulkEditBoolean: boolean;
    public otherColumn: boolean = false;
    public editAlreadyEnabled = false;
    public bulkEditColumns = [];
    @ViewChild('multicolumnEditValue') multicolumnEditValue: any;
    public checkDuplicate = false;
    public errorMessage = "";
    public enteredZipCodes: any;

    constructor(
        private formBuilder: FormBuilder,
        private wizardService: CarrierMaintenanceService,
        private carrierzoneHelper: CarrierZoneHelper,
        private toasterService: ToasterService,
        private wizardHelper: CarrierMaintenanceHelper,
        private confirmationService: ConfirmationService,
        private carrierzoneService: CarrierZoneService,
        private exportToCsvService :ExportToCsvService
    ) { 
        this.frmCarrierZones = new FormGroup({});
    }


    ngOnInit() {
        this.createForm();
        this.createTableForm();
        this.tableColumns = [
            { name: 'ZIP Code', prop: 'zipCode', width: "250" },
            { name: 'State', prop: 'state', width: "250" },
            { name: 'County', prop: 'county', width: "250" },
            { name: 'Zone', prop: 'zone', width: "250" },
            { name: 'Rate Center', prop: 'rateCente', width: "250" },
            { name: 'Market ID', prop: 'marketId', width: "250" },
            { name: 'Market Area', prop: 'marketArea', width: "250" },
            { name: 'City', prop: 'city', width: "250" },
            { name: 'BTA Market Number', prop: 'btaMarketNumber', width: "250" },
            { name: 'BTA Market Name', prop: 'btaMarketName', width: "250" },
            { name: 'Carrier ID', prop: 'carrierId', width: "250" },
            { name: 'Carrier Name', prop: 'carrierName', width: "250" },
            { name: 'ZIP Status', prop: 'zipStatus', width: "250" },
            { name: 'Sim Profile', prop: 'simProfile', width: "250" },
            { name: 'Sim Profile2', prop: 'simProfile2', width: "250" },
            { name: 'Plan Type', prop: 'planType', width: "250" },
        ];
        this.bulkEditColumns = [...this.tableColumns];
        this.filteredValues = {};
        this.multiColumnEditSection = false;
        this.showBulkUpdateButton = false
    }

    //to create form
    private createForm() {
        this.frmCarrierZones = this.formBuilder.group({
            zipCode: [''],
            state: ['', [ Validators.maxLength(2)]],
            county: ['', [ Validators.maxLength(50)]],
            zone: ['', [ Validators.maxLength(100)]],
            rateCente: ['', [Validators.maxLength(30)]],
            marketId: ['', [Validators.maxLength(126), Validators.pattern("^([0-9]*[.])?[0-9]+")]],
            marketArea: ['', [Validators.maxLength(33)]],
            city: ['', [Validators.maxLength(100)]],
            btaMarketNumber: ['', [Validators.maxLength(4)]],
            btaMarketName: ['', [Validators.maxLength(100)]],
            carrierId: ['', [Validators.maxLength(126), Validators.pattern("^([0-9]*[.])?[0-9]+")]],
            carrierName: ['', [ Validators.maxLength(255)]],
            zipStatus: ['', [Validators.maxLength(15)]],
            simProfile: ['', [Validators.maxLength(30)]],
            simProfile2: ['', [Validators.maxLength(30)]],
            planType: ['', [Validators.maxLength(40)]],
        })
    }

    //form for column level filter
    public createTableForm() {
        this.tableFrmGroupMain = this.formBuilder.group({
            zipCode: [''],
            state: [''],
            county: [''],
            zone: [''],
            rateCente: [''],
            marketId: [''],
            marketArea: [''],
            city: [''],
            btaMarketNumber: [''],
            btaMarketName: [''],
            carrierId: [''],
            carrierName: [''],
            zipStatus: [''],
            simProfile: [''],
            simProfile2: [''],
            planType: [''],
        });
    }

    // reset the form
    revert() {
        this.frmCarrierZones.reset();
        this.tableRows = [];
        this.tableRowsMainData = [];
        this.filteredValues = {};
        let filterKeys = Object.keys(this.tableFrmGroupMain.controls);
        filterKeys.forEach(_e1 => {
            this.tableFrmGroupMain.controls[`${_e1}`].patchValue([]);
        });
        this.selectedCarrierZones = [];
        this.alreadyEnabled = true;
        this.showBulkUpdateButton = false;
        this.selected = [];
        this.otherColumn = false;
    }

    // search carrier Zones
    public searchForm() {
        this.showLoadingScreen = true;
        let obj = this.frmCarrierZones.value;
        this.editedRow = {};
        this.defaultEditedRow = {};
        this.isEditable = {};
        this.selectedCarrierZones = [];
        this.selected = [];
        this.showBulkUpdateButton = false;
        this.otherColumn = false;
        this.carrierzoneService.setSearchData([]);
        let filterKeys = Object.keys(this.tableFrmGroupMain.controls);
        filterKeys.forEach(_e1 => {
            this.tableFrmGroupMain.controls[`${_e1}`].patchValue([]);
        });
        this.filteredValues = {};
        this.alreadyEnabled = true;
        obj = this.wizardHelper.checkRequestObject(obj);
        obj.dbEnv = this.wizardHelper.dbEnv;
        obj.zipCode = this.enteredZipCodes;
        this.wizardService.getCarrierZones(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.carrierzoneHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_CARRIERZONES_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }

                    let response = data[0];
                    let fullObject = [];
                    if (!this.carrierzoneService.getSearchData() || (this.carrierzoneService.getSearchData() && this.carrierzoneService.getSearchData().length == 0)) {
                        response.forEach(e1 => {
                            fullObject.push(e1)
                        });

                    } else if (this.carrierzoneService.getSearchData().length > 0) {
                        fullObject = this.carrierzoneService.getSearchData();
                        response.forEach(e1 => {
                            fullObject.push(e1)
                        });
                    }
                    this.carrierzoneService.setSearchData(fullObject);
                    this.tableRowsMainData = [];
                    this.tableRows = [];
                    for (let i = 0; i < this.carrierzoneService.getSearchData().length; i++) {
                        this.tableRowsMainData.push(this.carrierzoneService.getSearchData()[i]);
                    }
                    let rowId = 1;
                    this.tableRowsMainData.forEach(element => {
                        element.rowId = rowId;
                        rowId++;
                    });

                    this.tableRows = [...this.tableRowsMainData];
                    this.showLoadingScreen = false;
                    if (data[0] && data[0].length == 0 && this.showNoRecordsFoundMessage)
                        this.toasterService.showErrorMessage(
                            this.carrierzoneHelper.getTracfoneConstantMethod("TRACFONE_SEARCH_CARRIERZONES_ERROR_MESSAGE")
                        );

                    this.generateFilters();
                    this.filterReportResults();
                    this.multiColumnEditSection = false;
                    this.showNoRecordsFoundMessage = true;
                    if (this.filteredValues && this.filteredValues.mainTableFilter) {
                        this.updateSummaryTable(this.filteredValues.mainTableFilter);
                    }
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.carrierzoneHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    // to filter columns
    public filterReportResults(): void {
        const filterFormObject = this.tableFrmGroupMain.value;
        this.filteredValues.zipCode = filterFormObject.zipCode;
        this.filteredValues.state = filterFormObject.state;
        this.filteredValues.county = filterFormObject.county;
        this.filteredValues.zone = filterFormObject.zone;
        this.filteredValues.rateCente = filterFormObject.rateCente;
        this.filteredValues.marketId = filterFormObject.marketId;
        this.filteredValues.marketArea = filterFormObject.marketArea;
        this.filteredValues.city = filterFormObject.city;
        this.filteredValues.btaMarketNumber = filterFormObject.btaMarketNumber;
        this.filteredValues.btaMarketName = filterFormObject.btaMarketName;
        this.filteredValues.carrierId = filterFormObject.carrierId;
        this.filteredValues.carrierName = filterFormObject.carrierName;
        this.filteredValues.zipStatus = filterFormObject.zipStatus;
        this.filteredValues.simProfile = filterFormObject.simProfile;
        this.filteredValues.simProfile2 = filterFormObject.simProfile2;
        this.filteredValues.planType = filterFormObject.planType;
        const newRows = Object.keys(filterFormObject).reduce((acc, key) => {
            if (!filterFormObject[key].length) return acc;
            const filteredRows = acc.filter(val => filterFormObject[key].indexOf(val[key]) > -1);
            return filteredRows;
        }, this.tableRowsMainData);

        this.tableRows = newRows;
    }

    public generateFilters(): void {
        this.filteredRows = Object.keys(this.tableColumns)
            .map(i => this.tableColumns[i].prop)
            .reduce((filterObject, columnName) => {
                const uniqueValuesPerRow = this.tableRows.reduce((set, row) => set.add(row[columnName]), new Set());
                let val: any = Array.from(uniqueValuesPerRow);
                if (/^[0-9]*$/.test(val[0])) {
                    filterObject[columnName] = val.sort(function (a, b) { return a - b });
                } else {
                    filterObject[columnName] = val.sort((a, b) => {
                        a = a || '';
                        b = b || '';
                        return a.localeCompare(b);
                    });
                }
                return filterObject;
            }, {});
    }

    public onSelect(row) {
        this.multiColumnEditSection = true;
        this.selectedCarrierZones = [];
        if (row && row.selected) {
            for (let i = 0; i < row.selected.length; i++) {
                let obj = { ...row.selected[i] };
                this.selectedCarrierZones.push(obj);
            }
        }
        this.selectedCarrierZones = [...this.selectedCarrierZones]
        if (this.selectedCarrierZones.length == 0) {
            this.bulkEditBoolean = false;
            this.otherColumn = false;
            this.showBulkUpdateButton = false;
        }
    }


    public editButtonClicked(rowData, rowIndex) {
        this.alreadyEnabled = false;
        this.defaultEditedRow = { ...rowData }
        for (let i = 0; i < this.tableRowsMainData.length; i++) {
            if (this.isEditable[i])
                this.alreadyEnabled = true;
        }
        if (!this.alreadyEnabled)
            this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        else {
            this.alreadyEnabled = false;
            this.toasterService.showErrorMessage(
                this.carrierzoneHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE")
            );
        }
    }


    private inputValueChanged(event, column, row, oldValue) {
        this.editedRow[column] = event.target.value;
        this.defaultEditedRow[column] = event.target.defaultValue;

    }

    //to update carrier Zones
    public updateCarrierZones(editData, rowIndex) {
        if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
            this.toasterService.showErrorMessage(
                this.carrierzoneHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            return;
        }
        this.showLoadingScreen = true;
        let obj = { ...editData, ...this.editedRow }

        obj = this.wizardHelper.checkRequestObject(obj);
        obj.dbEnv = this.wizardHelper.dbEnv;
        obj.oldZipCode = this.defaultEditedRow.zipCode;
        obj.oldState = this.defaultEditedRow.state;
        obj.oldCounty = this.defaultEditedRow.county;
        obj.oldZone = this.defaultEditedRow.zone;
        obj.oldCarrierName = this.defaultEditedRow.carrierName;
        if (obj.zipCode != this.defaultEditedRow.zipCode || obj.state != this.defaultEditedRow.state || obj.county != this.defaultEditedRow.county
            || obj.zone != this.defaultEditedRow.zone || obj.carrierName != this.defaultEditedRow.carrierName) {
            this.checkDuplicate = true;
        } else {
            this.checkDuplicate = false;
        }
        obj.checkDuplicate = this.checkDuplicate;
        delete obj.rowId;
        this.wizardService.updateCarrierZones(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.carrierzoneHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_CARRIERZONES_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    for (let i = 0; i < this.tableRowsMainData.length; i++) {
                        if (this.tableRowsMainData[i].rowId == this.defaultEditedRow.rowId) {
                            this.tableRowsMainData[i] = obj;
                        }
                    }
                    this.isEditable[rowIndex] = !this.isEditable[rowIndex];
                    this.showLoadingScreen = false;
                    this.alreadyEnabled = true;
                    this.editedRow = {};
                    this.defaultEditedRow = {};
                    this.tableRows = [...this.tableRowsMainData];
                    this.searchForm();

                    this.toasterService.showSuccessMessage(
                        this.carrierzoneHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_CARRIERZONES_SUCCESS_MESSAGE")
                    );

                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.carrierzoneHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    //to cancel update
    private cancelEditForm(rowData, rowIndex) {
        this.showLoadingScreen = true;
        this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        this.tableColumns.forEach(e1 => {
            if (document.getElementById(e1.prop + rowIndex)) {
                (<HTMLInputElement>(
                    document.getElementById(e1.prop + rowIndex)
                )).value = rowData[e1.prop] || '';
            }
        });

        this.editedRow = {};
        this.defaultEditedRow = {};
        this.showLoadingScreen = false;
        this.alreadyEnabled = true;
    }

    //to filter table
    private updateSummaryTable(event) {
        let val: any;
        if (event.target)
            val = event.target.value.toLowerCase();
        else
            val = event.toLowerCase();

        const temp = this.tableRowsMainData.filter(function (d) {
            return (d.zipCode ? d.zipCode.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.state ? d.state.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.county ? d.county.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.zone ? d.zone.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.rateCente ? d.rateCente.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.marketId ? d.marketId.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.marketArea ? d.marketArea.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.city ? d.city.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.btaMarketNumber ? d.btaMarketNumber.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.btaMarketName ? d.btaMarketName.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.carrierId ? d.carrierId.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.carrierName ? d.carrierName.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.zipStatus ? d.zipStatus.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.simProfile ? d.simProfile.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.simProfile2 ? d.simProfile2.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.planType ? d.planType.toLowerCase().indexOf(val) !== -1 : !val)
        });
        this.tableRows = temp;
    }

    // delete confirm
    public showConfirm(esnData, rowIndex) {
        this.confirmationService.confirm({
            key: 'confirm-delete-cmi',
            message: "Are you sure you want to delete Carrier Zones ?",
            accept: () => {
                this.deleteCarrierZones(esnData, rowIndex)
            }
        });
    }

    // to delete carrier Zones
    public deleteCarrierZones(esnData, rowIndex) {
        this.showLoadingScreen = true;
        let obj: any = {};
        obj = esnData
        obj.dbEnv = this.wizardHelper.dbEnv;
        delete obj.rowId;
        this.wizardService.deleteCarrierZones(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.carrierzoneHelper.getTracfoneConstantMethod("TRACFONE_DELETE_CARRIERZONES_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    this.toasterService.showSuccessMessage(
                        this.carrierzoneHelper.getTracfoneConstantMethod("TRACFONE_DELETE_CARRIERZONES_SUCCESS_MESSAGE")
                    );
                    this.showNoRecordsFoundMessage = false;
                    this.searchForm();
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.carrierzoneHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    public assignmultiColumnName(column) {
        this.showBulkUpdateButton = false;
        this.otherColumn = true;
    }

    public showBulkUpdateButtonFun(event) {
        if (event)
            this.showBulkUpdateButton = true;
        else
            this.showBulkUpdateButton = false;
    }

    bulkUpdateColumn(column) {
        if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
            this.toasterService.showErrorMessage(
                this.carrierzoneHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            return;
        }
        this.showLoadingScreen = true;
        let requestObj = [];
        this.selectedCarrierZones.forEach(e => {
            let obj: any = {};
            obj.checkDuplicate = false
            if (column == "ZIP Code") {
                obj.zipCode = this.multicolumnEditValue.nativeElement.value;
                obj.checkDuplicate = true
            } else {
                obj.zipCode = e.zipCode;
            }
            if (column == "State") {
                obj.state = this.multicolumnEditValue.nativeElement.value;
                obj.checkDuplicate = true
            } else {
                obj.state = e.state;
            }
            if (column == "County") {
                obj.county = this.multicolumnEditValue.nativeElement.value;
                obj.checkDuplicate = true
            } else {
                obj.county = e.county;
            }
            if (column == "Zone") {
                obj.zone = this.multicolumnEditValue.nativeElement.value;
                obj.checkDuplicate = true
            } else {
                obj.zone = e.zone;
            }
            if (column == "Rate Center") {
                obj.rateCente = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.rateCente = e.rateCente;
            }
            if (column == "Market ID") {
                obj.marketId = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.marketId = e.marketId;
            }
            if (column == "Market Area") {
                obj.marketArea = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.marketArea = e.marketArea;
            }
            if (column == "City") {
                obj.city = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.city = e.city;
            }
            if (column == "BTA Market Number") {
                obj.btaMarketNumber = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.btaMarketNumber = e.btaMarketNumber;
            }
            if (column == "BTA Market Name") {
                obj.btaMarketName = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.btaMarketName = e.btaMarketName;
            }
            if (column == "Carrier ID") {
                obj.carrierId = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.carrierId = e.carrierId;
            }
            if (column == "Carrier Name") {
                obj.carrierName = this.multicolumnEditValue.nativeElement.value;
                obj.checkDuplicate = true
            } else {
                obj.carrierName = e.carrierName;
            }
            if (column == "ZIP Status") {
                obj.zipStatus = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.zipStatus = e.zipStatus;
            }
            if (column == "Sim Profile") {
                obj.simProfile = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.simProfile = e.simProfile;
            }
            if (column == "Sim Profile2") {
                obj.simProfile2 = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.simProfile2 = e.simProfile2;
            }
            if (column == "Plan Type") {
                obj.planType = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.planType = e.planType;
            }
            obj.dbEnv = this.wizardHelper.dbEnv;
            obj.oldZipCode = e.zipCode;
            obj.oldState = e.state;
            obj.oldCounty = e.county;
            obj.oldZone = e.zone;
            obj.oldCarrierName = e.carrierName;
            requestObj.push(obj);
        });

        this.bulkUpdateCarrierZones(requestObj);
    }

    public bulkUpdateCarrierZones(request) {
        this.wizardService.bulkUpdateCarrierZones(request).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.carrierzoneHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_CARRIERZONES_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    this.showLoadingScreen = false;
                    this.alreadyEnabled = true;
                    this.editAlreadyEnabled = false;
                    this.bulkEditBoolean = false;
                    this.otherColumn = false;
                    this.showBulkUpdateButton = false;
                    this.selectedCarrierZones = [];
                    this.selected = [];
                    this.editedRow = {};
                    this.defaultEditedRow = {};
                    this.searchForm();

                    this.toasterService.showSuccessMessage(
                        this.carrierzoneHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_CARRIERZONES_SUCCESS_MESSAGE")
                    );

                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.carrierzoneHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    ngOnChanges(changes: SimpleChanges) {
        if(changes.insertData){
            if (changes.insertData.currentValue) {
                if (changes.insertData.currentValue.zipCode) {
                    this.enteredZipCodes = changes.insertData.currentValue.zipCode;
                }
               
            }
        }
        }

      /*
     * Validate ZIP Code text area
     * Validation Criteria- Limit -> 40,000 | Size -> 5 per zip code
     */
      public zipCodeValidation(event) {
        this.errorMessage = "";
        let lengthError = "A ZIP Code must have exactly 5 digits.";
        let limitError = "ZIP Codes cannot exceed 40,000 limit";
        let stringError = "ZIP Code must be number";
        let zipcodes: any = [];
        if (/\d/.test(event)) {
            //Splitting string based on the new line
            let zip = event.split("\n")
            zip = zip.filter(el => el !== '')
            for (let i = 0; i < zip.length; i++) {
                //removing spaces
                zip[i] = zip[i].replace(/\s/g, "");
                //checking if any value with comma exists
                if (zip[i].indexOf(',') > -1) {
                    //Sliting String based on the comma
                    let commaSeperatedArr = zip[i].split(",");
                    /*
                     * Validate ZIP Code based on the length
                     * if ZIP Codes are valid then pushing into 'zipcodes' array
                    */
                    for (let j = 0; j < commaSeperatedArr.length; j++) {
                        //validate ZIP code if it is number or not
                        if (/^[0-9]*$/.test(commaSeperatedArr[j])) {
                            if (commaSeperatedArr[j].length != 0) {
                                if (commaSeperatedArr[j].length < 5) {
                                    this.errorMessage = lengthError;
                                    break;
                                } else if (commaSeperatedArr[j].length > 5) {
                                    this.errorMessage = lengthError;
                                    break;
                                } else {
                                    zipcodes.push(commaSeperatedArr[j]);
                                    //check if zip codes exceeds 40,000
                                    if (zipcodes.length > 40000) {
                                        this.errorMessage = limitError;
                                        break;
                                    }
                                }
                            }
                        } else {
                            this.errorMessage = stringError;
                            break;
                        }
                    }
                }//validate ZIP code if it is number or not
                else if (!/^[0-9]*$/.test(zip[i])) {
                    this.errorMessage = stringError;
                    break;
                }//Validate ZIP Code based on the length  
                else if (zip[i].length < 5) {
                    if (zip[i].length != 0) {
                        this.errorMessage = lengthError;
                        break;
                    }
                }//Validate ZIP Code based on the length 
                else if (zip[i].length > 5) {
                    this.errorMessage = lengthError;
                    break;
                }//if ZIP Codes are valid then pushing into 'zipcodes' array
                else {
                    zipcodes.push(zip[i]);
                    //check if zip codes exceeds 40,000
                    if (zipcodes.length > 40000) {
                        this.errorMessage = limitError;
                        break;
                    }
                }
            }
        } else {
            event = event.toUpperCase();
            if (event == "ALL")
                zipcodes.push(event);
            else if (event.length > 0)
                this.errorMessage = stringError;
        }

        let returnedZip: any = [];
        this.enteredZipCodes = "";
        if (this.errorMessage == "") {
            //filter duplicate zipcodes
            returnedZip = zipcodes.filter((val, index) => zipcodes.indexOf(val) == index);
            //removing empty elements
            returnedZip = returnedZip.filter(item => item);
            this.enteredZipCodes = returnedZip.toString();
        } else {
            this.enteredZipCodes = null;
        }
    }

 //Used to Download Template
 exportToCSV() {
    let columns = [];
    this.tableColumns.forEach(x=>{
        columns.push(x.prop)            
    })
    this.exportToCsvService.downloadFile(this.selectedCarrierZones, "CarrierZonesexport", columns);
}

}