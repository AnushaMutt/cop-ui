import { Component, OnInit, ViewEncapsulation, ViewChild, ChangeDetectorRef } from "@angular/core";
import { ConfirmationService, MenuItem } from "primeng/primeng";
import { routerTransition } from "../../../../app/router.animations";
import { MatTabGroup, MatTab, MatTabHeader } from "@angular/material";
import { Subject } from "rxjs";
import { DatabaseEnvService } from "../../../Services/dbenv.service";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { takeUntil } from "rxjs/operators";
import { ToasterService } from "../../../Services/toaster.service";
import { UpdateParentService } from "./parent-wizard/update-parent-wizard/services/update-parent-wizard.service";
import { CarrierMaintenanceHelper } from "./carrier-maintenance-helper";
import { DataConfigMappingService } from "./data-config-mapping-wizard/data-config-mapping-wizard.service";
import { AddParentService } from "./parent-wizard/add-parent-wizard/services/add-parent-wizard.services";
import { OrderTypesService } from "./order-types-wizard/order-types-wizard.service";
import { EditThrottleService } from "./throttle-wizard/edit-throttle/edit-throttle-service";
import { VerizonZipNPANXXService } from "./verizon-zip-npanxx-wizard/verizon-zip-npanxx-wizard-service";
import { TmoZipNgpService } from "./tmo-zip-ngp-wizard/tmo-zip-ngp-wizard-service";
import { CingularMrktInfoService } from "./cingular-mrkt-info/cingular-mrkt-info-service";
import { NotCertifyModelService } from "./not-certify-model/not-certify-model-service";

@Component({
    selector: "carrier-maintenance",
    templateUrl: "./carrier-maintenance.component.html",
    styleUrls: ["./carrier-maintenance.component.scss"],
    encapsulation: ViewEncapsulation.None,
    providers: [ConfirmationService],
    animations: [routerTransition()],
})

export class CarrierMaintenanceComponent implements OnInit {
    @ViewChild('tabs') tabs: MatTabGroup;
    public showLoadingScreen = false;
    private unsubscribe = new Subject<void>();
    public dbEnvironments = [];
    public dbEnvironmentsMainData = [];
    public tableName = [];
    public tableNameMainData = [];
    public frmGroupMain: FormGroup;
    public breadCrumbIndex = 0;
    public index = 0
    items: MenuItem[];
    home: MenuItem;
    public showTabs: boolean = false;
    public operationStarted = false;
    public clearData:any = 0;
    constructor(
        public cdRef: ChangeDetectorRef,
        private confirmationService: ConfirmationService,
        private dbenvService: DatabaseEnvService,
        private toasterService: ToasterService,
        private _formBuilder: FormBuilder,
        private updateParentService: UpdateParentService,
        private carrierMaintenanceHelper: CarrierMaintenanceHelper,
        private dataConfigMappingService: DataConfigMappingService,
        private addParentService: AddParentService,
        private orderTypesService: OrderTypesService,
        private editThrottleService: EditThrottleService,
        private verizonZipNPANXXService: VerizonZipNPANXXService,
        private tmoZipNgpService: TmoZipNgpService,
        private cingularMrktInfoService: CingularMrktInfoService,
        private notCertifyModelService: NotCertifyModelService,
    ) { }

    ngOnInit() {
        this.tableName = [{'description':'Parent', 'index':0},
        {'description':'Data Config Mapping', 'index':1},
        {'description':'IG Order Types', 'index':2},
        {'description':'Throttle Policy', 'index':3},
        {'description':'Verizon Zip NPANXX', 'index':4},
        {'description':'TMO Zip NGP', 'index':5},
        {'description':'Cingular Mrkt Info', 'index':6},
        {'description':'Not Certify Model', 'index':7},
        {'description':'Carrier SIM Preferences', 'index':8},
        {'description':'NPANXX2 Carrier Zones', 'index':9},
        {'description':'Postal Zips', 'index':10},
        {'description':'AR USA MARKET', 'index':11},
        {'description':'Geo Loc', 'index':12},
        {'description':'Carrier Zones', 'index':13}];
        this.tableNameMainData = [...this.tableName];
        this.showTabs = false;
        this.frmGroupMain = new FormGroup({});
        this.createForm();
        this.retrieveDBEnv();
        this.carrierMaintenanceHelper.breadcrumbListUpdate.subscribe(menus => {
            this.items = [];
            this.carrierMaintenanceHelper.breadcrumbList.forEach(bc => {
                bc && this.items.push({ "label": bc });
            });
        });
        this.home = {
            icon: "pi pi-home",
            command: _e => {
                this.clearData = this.clearData + Math.random();
                this.index = 0;
                this.tabs.selectedIndex = 0;
                this.operationStarted = false;
                this.updateParentService.resetAll();
                this.addParentService.resetAll();
                this.carrierMaintenanceHelper.deleteBreadcrumbList(2);
                this.dataConfigMappingService.resetDataConfigMapping();
                this.orderTypesService.resetAll();
                this.editThrottleService.resetAll();
                this.notCertifyModelService.resetAll();
            }
        };
        this.tabs._handleClick = this.interceptTabChange.bind(this);
    }

    createForm() {
        this.frmGroupMain = this._formBuilder.group({
            dbEnv: ["", Validators.required],
        });
        this.frmGroupMain.get("dbEnv").valueChanges.subscribe(val => {
            const dbEnvironemnt = this.dbEnvironments.find(
                db => db.name === val
            );
            if (dbEnvironemnt) {
                this.carrierMaintenanceHelper.updateBreadcrumbList(
                    dbEnvironemnt.description,
                    1
                );
            }
        });
    }

    interceptTabChange(tab: MatTab, tabHeader: MatTabHeader, idx: number) {
        let result = false;
        /*this.confirmationService.confirm({
            key: "confirm-parentTab-changed",
            message: 'Are you sure you want to navigate from current tab ?',
            accept: () => {*/
                result = true;
                this.updateParentService.resetAll();
                this.addParentService.resetAll();
                this.carrierMaintenanceHelper.deleteBreadcrumbList(2);
                this.dataConfigMappingService.resetDataConfigMapping();
                this.orderTypesService.resetAll();
                this.editThrottleService.resetAll();
                return result && MatTabGroup.prototype._handleClick.apply(this.tabs, [tab, tabHeader, idx]);
            /*}
        });*/
    }

    ngAfterViewInit() {
        this.cdRef.detectChanges();
    }

    onChange(event) {
        if (event.index == 0) {
            this.index = 0;
        } else if (event.index == 1) {
            this.index = 1;
        } else if (event.index == 2) {
            this.index = 2;
        } else if (event.index == 3) {
            this.index = 3;
        } else if (event.index == 4) {
            this.index = 4;
        }  else if (event.index == 5) {
            this.index = 5;
        }  else if (event.index == 6) {
            this.index = 6;
        } else if (event.index == 7) {
            this.index = 7;
        } else if (event.index == 8) {
            this.index = 8;
        } else if (event.index == 9) {
            this.index = 9;
        } else if (event.index == 10) {
            this.index = 10;
        } else if (event.index == 11) {
            this.index = 11;
        }else if (event.index == 12) {
            this.index = 12;
        }else if (event.index == 13) {
            this.index = 13;
        }
    }

    public retrieveDBEnv() {
        this.showLoadingScreen = true;
        this.carrierMaintenanceHelper.emptyBreadcrumbList();
        // If envs were previously retrieved, get it from internal storage.
        if (this.dbenvService.isDBEnvsInStorage()) {
            this.dbEnvironments = this.dbenvService.getDbEnvsFromStorage();
            this.dbEnvironmentsMainData = this.dbEnvironments;
            // making database as default selected if one database is available
            if (this.dbEnvironments.length == 1) {
                this.frmGroupMain
                    .get("dbEnv")
                    .setValue(this.dbEnvironments[0].name);
                this.dbSelect(this.dbEnvironments[0].name);
            }
            this.showLoadingScreen = false;
        } else {
            // Get envs from service request.
            this.dbenvService
                .getDbEnvsFromService()
                .pipe(takeUntil(this.unsubscribe))
                .subscribe(
                    data => {
                        if (data[0] === null || data[0] === undefined) {
                            this.toasterService.showErrorMessage(
                                this.carrierMaintenanceHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_DATABASE_ERROR_MESSAGE")
                            );
                            this.showLoadingScreen = false;
                            return;
                        }

                        this.dbEnvironments = data[0];
                        this.dbEnvironmentsMainData = this.dbEnvironments;
                        this.dbenvService.storeDbEnvs(this.dbEnvironments);
                        // making database as default selected if one database is available
                        if (this.dbEnvironments.length == 1) {
                            this.frmGroupMain
                                .get("dbEnv")
                                .setValue(this.dbEnvironments[0].name);
                            this.dbSelect(this.dbEnvironments[0].name);
                        }
                        this.showLoadingScreen = false;
                    },
                    (err: any) => {
                        this.showLoadingScreen = false;
                        if (err.error === undefined || err.error === null) {
                            this.toasterService.showErrorMessage(
                                this.carrierMaintenanceHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                            );
                        }
                        else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                            return;
                        else this.toasterService.showErrorMessage(err.error);
                    }
                );
        }
    }

    public getDbEnvironments() {
        return this.dbEnvironments;
    }

    openedChange(option) {
        if (option == "database") {
            this.dbEnvironments = [...this.dbEnvironmentsMainData];
        }
        if (option == "tab") {
            this.tableName = [...this.tableNameMainData];
        }
    }

    onKey(value, option) {
        if (option == "database") {
            this.dbEnvironments = [...this.dbEnvironmentsMainData];
            this.dbEnvironments = this.search(value, this.dbEnvironments);
        }
        if (option == "tab") {
            this.tableName = [...this.tableNameMainData];
            this.tableName = this.search(value, this.tableName);
        }
    }

    search(value: string, searchArray: any) {
        let filter = value.toLowerCase();
        return searchArray.filter(
            option =>
                (option.description &&
                    option.description.toLowerCase().indexOf(filter) > -1)
        );
    }

    public dbSelect(dbEnv) {
        this.carrierMaintenanceHelper.setDbEnv(dbEnv);
        this.showTabs = true;
        this.operationStarted = true;
        this.updateParentService.resetAll();
        this.dataConfigMappingService.resetConfigData();
        this.dataConfigMappingService.resetDataConfigMapping();
        this.orderTypesService.resetAll();
        this.editThrottleService.resetAll();
        this.verizonZipNPANXXService.resetAll();
        this.tmoZipNgpService.resetAll();
        this.cingularMrktInfoService.resetAll();
    }

    public tabSelect(value){
        this.index = Number(value);        
    }
}
