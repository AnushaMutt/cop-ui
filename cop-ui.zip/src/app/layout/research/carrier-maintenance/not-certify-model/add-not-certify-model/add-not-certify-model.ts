import { Component, OnInit, ViewEncapsulation, ViewChildren, Output, EventEmitter } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { ConfirmationService } from 'primeng/primeng';
import { takeUntil } from 'rxjs/operators';
import { Subject } from "rxjs";
import { CarrierMaintenanceService } from '../../../../../Services/carrierMaintenance.service';
import { CarrierMaintenanceHelper } from "../../carrier-maintenance-helper";
import { ToasterService } from "../../../../../Services/toaster.service";
import { NotCertifyModelHelper } from "../not-certify-model-helper";
import { NotCertifyModelService } from "../not-certify-model-service";
import { MatDialog } from "@angular/material";
import { BulkInsertNotCertifyModelComponent } from "../bulk-insert-not-certify-model/bulk-insert-not-certify-model";
import { MatSelect } from "@angular/material";

@Component({
    selector: 'add-not-certify-model',
    templateUrl: './add-not-certify-model.html',
    styleUrls: ['./add-not-certify-model.scss',
        "../../../../components/ngxtable/material.scss",
        "../../../../components/ngxtable/datatable.component.scss",
        "../../../../components/ngxtable/icons.css",
        "../../../../components/ngxtable/app.css"],
    animations: [],
    encapsulation: ViewEncapsulation.None,
})

export class AddNotCertifyModelComponent implements OnInit {
    
    @ViewChildren(DatatableComponent)
    table: any;
    private unsubscribe = new Subject<void>();
    public frmNotCertifyModel: FormGroup;
    public showLoadingScreen: boolean;
    public displayTable = false;
    private checkedAnother = false;
    public tableRows: any = [];
    public tableRowsMainData: any = [];
    isEditable = {};
    private editedRow: any = {};
    private defaultEditedRow: any = {};
    public tableColumns:any = [];
    public alerts = [];
    public bulkInsertData = [];
    public showMssg = false;
    @Output("returnedData") returnedData: any = new EventEmitter();
    public alreadyEnabled = true;
    public parentName: any = [];
    public parentNameMainData: any = [];
    public partClassData: any = [];
    public partClassMainData: any = [];
    @ViewChildren(MatSelect) matSelect: any;
    public tableFrmGroupMain: FormGroup;
    public filteredValues: any = {};
    public filteredRows: any;

    constructor(
        private formBuilder: FormBuilder,
        private wizardService: CarrierMaintenanceService,
        private notCertifyModelHelper: NotCertifyModelHelper,
        private toasterService: ToasterService,
        private wizardHelper: CarrierMaintenanceHelper,
        private confirmationService: ConfirmationService,
        private notCertifyModelService: NotCertifyModelService,
        public dialog: MatDialog,
    ) {
        this.frmNotCertifyModel = new FormGroup({});
    }

    ngOnInit() { 
        this.createForm();
        this.createTableForm();
        this.tableColumns = [
            { name: 'Dev', prop: 'dev', width: "200" },
            { name: 'Parent Id', prop: 'parentId', width: "250" },
            { name: 'Part Class Obj Id', prop: 'partClassObjId', width: "250" },
        ];
        this.showMssg = false;
        this.notCertifyModelService.setAddData([]);
        if (this.notCertifyModelService.getParentId() && this.notCertifyModelService.getParentId().length > 0) {
            this.notCertifyModelService.getParentId().forEach(e2 => {
                this.parentName.push(e2)
            });
            this.parentNameMainData = [...this.parentName];
            this.notCertifyModelService.getPartClass().forEach(e3 => {
                this.partClassMainData.push(e3)
            });
            this.partClassData = [...this.partClassMainData];
        }else{
            this.retrieveParentId();
        }
    }

        //to create form
        private createForm() {
            this.frmNotCertifyModel = this.formBuilder.group({
                dev: ['', [Validators.pattern("^[0-9\n ,]*$"), Validators.maxLength(38)]],
                parentId: ['', [Validators.required]],
                partClassObjId: ['', [Validators.required]],
            })
        }

           //form for column level filter
    public createTableForm() {
        this.tableFrmGroupMain = this.formBuilder.group({
            objId: [""],
            dev: [""],
            parentId: [""],
            partClassObjId: [""],
        });
    }

    //to add not certify model
    private addNotCertifyModel(f) {
        this.showLoadingScreen = true;
        this.alreadyEnabled = true;
        let obj = f.value;
        obj = this.wizardHelper.checkRequestObject(obj);
        obj.dbEnv = this.wizardHelper.dbEnv;
        let filterKeys = Object.keys(this.tableFrmGroupMain.controls);
        filterKeys.forEach(_e1 => {
            this.tableFrmGroupMain.controls[`${_e1}`].patchValue([]);
        });
        this.filteredValues ={};
        this.wizardService.addNotCertifyModel(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_ADD_NOT_CERTIFY_MODEL_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }

                const d = data[0].message;
                obj.objId = d;
                if(d==""){
                    this.toasterService.showErrorMessage(
                    this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_DUPLICATE_NOT_CERTIFY_MODEL_ERROR_MESSAGE")
                );
                }else{
                    let fullObject = [];
                    if (!this.notCertifyModelService.getAddData() || (this.notCertifyModelService.getAddData() && this.notCertifyModelService.getAddData().length == 0)) {
                            fullObject.push(obj);
                    } else if (this.notCertifyModelService.getAddData().length > 0) {
                        fullObject = this.notCertifyModelService.getAddData();
                            fullObject.push(obj);
                    }
                    this.notCertifyModelService.setAddData(fullObject);
                    this.tableRowsMainData = [];
                    this.tableRows = [];
                    for (let i = 0; i < this.notCertifyModelService.getAddData().length; i++) {
                        this.tableRowsMainData.push(this.notCertifyModelService.getAddData()[i]);
                    }
                    let rowId = 1;
                    this.tableRowsMainData.forEach(element => {
                        element.rowId = rowId;
                        rowId++;
                    });
                    this.tableRows = [...this.tableRowsMainData];
                    if (this.checkedAnother) {
                        this.displayTable = false;
                    } else {
                        this.displayTable = true;
                    }
                    this.generateFilters();
                    this.filterReportResults();
                    this.frmNotCertifyModel.reset();
                    this.toasterService.showSuccessMessage(
                        this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_ADD_NOT_CERTIFY_MODEL_SUCCESS_MESSAGE")
                    );
                }
                this.showLoadingScreen = false;
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }

    onChangeCheckbox(event) {
        if (event.checked) this.checkedAnother = true;
        else this.checkedAnother = false;
    }

    //show summary confirm
    public showSummaryConfirm(f, index) {
        this.confirmationService.confirm({
            key: 'confirm-add-show-summary',
            message: this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_DONE_CREATING_NOT_CERTIFY_MODEL_CONFIRM_MESSAGE"),
            accept: () => {
                this.displayTable = true;
                this.checkedAnother = false;
            }
        });
    }

    // reset the form
    revert() {
        this.frmNotCertifyModel.reset();
        this.alerts = [];
        this.bulkInsertData = [];
        let formKeys = Object.keys(this.frmNotCertifyModel.controls);
        formKeys.forEach(_e1 => {
            if(_e1!='dev'){
                this.frmNotCertifyModel.controls[`${_e1}`].setValidators([Validators.required]);
                this.frmNotCertifyModel.controls[`${_e1}`].updateValueAndValidity();
            }else{
                this.frmNotCertifyModel.controls[`${_e1}`].setValidators([Validators.maxLength(38)]);
                this.frmNotCertifyModel.controls[`${_e1}`].updateValueAndValidity();
            }
        });
        let filterKeys = Object.keys(this.tableFrmGroupMain.controls);
        filterKeys.forEach(_e1 => {
            this.tableFrmGroupMain.controls[`${_e1}`].patchValue([]);
        });
    }

    public  editButtonClicked(rowData,rowIndex) {
        this.alreadyEnabled = false;
        this.defaultEditedRow = { ...rowData }
        for (let i = 0; i < this.tableRowsMainData.length; i++) {
          if (this.isEditable[i])
            this.alreadyEnabled = true;
        }
        if (!this.alreadyEnabled)
          this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        else{
          this.alreadyEnabled = false;
          this.toasterService.showErrorMessage(
            this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE")
          );
        }
      }
    
    private inputValueChanged(event, column, row, oldValue) {
        if (column != "parentId" && column != "partClassObjId") {
            this.editedRow[column] = event.target.value;
            this.defaultEditedRow[column] = event.target.defaultValue;
        }
        else {
            this.editedRow[column] = event.value;
            this.defaultEditedRow[column] = oldValue;
        }    
    }
    
    //to update not certify model
    public updateNotCertifyModel(editData, rowIndex) {
        if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
            this.toasterService.showErrorMessage(
                this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            return;
        }
        this.showLoadingScreen = true;
        let obj = { ...editData, ...this.editedRow }
        obj = this.wizardHelper.checkRequestObject(obj);
        obj.dbEnv = this.wizardHelper.dbEnv;
        delete obj.rowId;
        this.wizardService.updateNotCertifyModel(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_NOT_CERTIFY_MODEL_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                for (let i = 0; i < this.tableRowsMainData.length; i++) {
                    if (this.tableRowsMainData[i].rowId == this.defaultEditedRow.rowId) {
                        this.tableRowsMainData[i] = obj;
                    }
                }
                this.isEditable[rowIndex] = !this.isEditable[rowIndex];
                this.showLoadingScreen = false;
                this.editedRow = {};
                this.defaultEditedRow = {};
                this.tableRows = [...this.tableRowsMainData];
                this.alreadyEnabled = true;
                let filterKeys = Object.keys(this.tableFrmGroupMain.controls);
                filterKeys.forEach(_e1 => {
                    this.tableFrmGroupMain.controls[`${_e1}`].patchValue([]);
                });
                this.filteredValues ={};
                this.generateFilters();
                this.filterReportResults();
    
                this.toasterService.showSuccessMessage(
                    this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_NOT_CERTIFY_MODEL_SUCCESS_MESSAGE")
                );
    
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }
    
    //to cancel update
    private cancelEditForm(rowData, rowIndex) {
        this.showLoadingScreen = true;
    this.isEditable[rowIndex] = !this.isEditable[rowIndex];
    this.tableColumns.forEach(e1 => {
        if (document.getElementById(e1.prop + rowIndex)) {
            (<HTMLInputElement>(
                document.getElementById(e1.prop + rowIndex)
            )).value = rowData[e1.prop] || '';
        }
    });

    this.matSelect._results.forEach(matSelectData => {
        if (matSelectData.id.indexOf('parentId' + rowIndex) == 0)
            matSelectData.value = rowData['parentId'] || '';
        else if (matSelectData.id.indexOf('partClassObjId' + rowIndex) == 0)
            matSelectData.value = rowData['partClassObjId'] || '';
    });
    this.editedRow = {};
    this.defaultEditedRow = {};
    this.showLoadingScreen = false;
    this.alreadyEnabled = true;
    }
    
    //to filter table
    private updateSummaryTable(event) {
        const val = event.target.value.toLowerCase();
    
        const temp = this.tableRowsMainData.filter(function (d) {
            return (d.objId ? d.objId.indexOf(val) !== -1 : !val)
                || (d.dev ? d.dev.indexOf(val) !== -1 : !val)
                || (d.parentId ? d.parentId.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.partClassObjId ? d.partClassObjId.toLowerCase().indexOf(val) !== -1 : !val)
        });
        this.tableRows = temp;
    }


// delete confirm
public showConfirm(ncmData, rowIndex) {
    this.confirmationService.confirm({
      key: 'confirm-delete-cmi',
      message: "Are you sure you want to delete Not Certify Model ?",
      accept: () => {
        this.deleteNotCertifyModel(ncmData, rowIndex)
      }
    });
  }

  // to delete not certify model
  public deleteNotCertifyModel(ncmData, rowIndex) {
    this.showLoadingScreen = true;
    let obj:any = {};
    obj = ncmData
    obj.dbEnv = this.wizardHelper.dbEnv;
    delete obj.rowId;
    this.wizardService.deleteNotCertifyModel(obj).pipe(takeUntil(this.unsubscribe))
      .subscribe(
      (data: any) => {
        if (data[0] === null || data[0] === undefined) {
          this.showLoadingScreen = false;
          this.toasterService.showErrorMessage(
            this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_DELETE_NOT_CERTIFY_MODEL_ERROR_MESSAGE")
          );
          return;
        }
        if (data[0] && data[0].ERR) {
          this.showLoadingScreen = false;
          const commaSeperatedArr = data[0].ERR.split(",");
          for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
            if (commaSeperatedArr[i] != "")
              this.toasterService.showErrorMessage(
                commaSeperatedArr[i]
              );
          }
          return;
        }
        this.toasterService.showSuccessMessage(
          this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_DELETE_NOT_CERTIFY_MODEL_SUCCESS_MESSAGE")
        );

        this.tableRowsMainData.forEach((rec: any, key) => {
            if (obj.objId == rec.objId) {
              this.tableRowsMainData.splice(key, 1);
              this.notCertifyModelService.getAddData().splice(key, 1);
            }
          });
          this.tableRowsMainData = [...this.tableRowsMainData];
          this.tableRows = [...this.tableRowsMainData];
          if (this.tableRows.length === 0) {
            this.displayTable = false;
            this.checkedAnother = false;
            this.tableRows = [];
            this.revert();
            this.notCertifyModelService.setAddData([]);
          }
        this.showLoadingScreen = false;
      },
      (err: any) => {
        this.showLoadingScreen = false;
        if (err.error === undefined || err.error === null)
          this.toasterService.showErrorMessage(
            this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
          );
        else if (err.error && err.error.ERR) {
          const commaSeperatedArr = err.error.ERR.split(",");
          for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
            if (commaSeperatedArr[i] != "")
              this.toasterService.showErrorMessage(
                commaSeperatedArr[i]
              );
          }
        }
        else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
          return;
        else this.toasterService.showErrorMessage(err.error);
      }
      );
  }

// to open bulk insert pop up
  openUploadCSVDialog() {
    const dialogRef = this.dialog.open(BulkInsertNotCertifyModelComponent, {
        width: "90%",
        height: "90%",
    });
    // Create subscription
    dialogRef.afterClosed().subscribe((bulkInsertData) => {
        if (bulkInsertData && bulkInsertData.length > 0) {
            this.warningAlert("Your upload is complete. Please click on Submit to begin database insertions.")
            this.bulkInsertData = [...bulkInsertData];
            let filterKeys = Object.keys(this.frmNotCertifyModel.controls);
        filterKeys.forEach(_e1 => {
            this.frmNotCertifyModel.controls[`${_e1}`].setValidators([]);
            this.frmNotCertifyModel.controls[`${_e1}`].updateValueAndValidity();
        });
        }
    });
}

//to bulk insert not certify model
private bulkInsertNotCertifyModel() {
    this.showLoadingScreen = true;
    let obj: any = [];
    this.alreadyEnabled = true;
    obj = [...this.bulkInsertData];
    obj.forEach(element => {
        element.dbEnv = this.wizardHelper.dbEnv;
    });
    obj = this.wizardHelper.checkRequestObject(obj);
    obj.dbEnv = this.wizardHelper.dbEnv;
    this.wizardService.bulkInsertNotCertifyModel(obj).pipe(takeUntil(this.unsubscribe))
        .subscribe(
        (data: any) => {
            if (data[0] === null || data[0] === undefined) {
                this.showLoadingScreen = false;
                this.toasterService.showErrorMessage(
                    this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_ADD_NOT_CERTIFY_MODEL_ERROR_MESSAGE")
                );
                return;
            }
            if (data[0] && data[0].ERR) {
                this.showLoadingScreen = false;
                const commaSeperatedArr = data[0].ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
                return;
            }
            this.showLoadingScreen = false;
            this.showMssg = true;
            this.revert();
        },
        (err: any) => {
            this.showLoadingScreen = false;
            if (err.error === undefined || err.error === null)
                this.toasterService.showErrorMessage(
                    this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                );
            else if (err.error && err.error.ERR) {
                const commaSeperatedArr = err.error.ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
            }
            else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                return;
            else this.toasterService.showErrorMessage(err.error);
        }
        );
}


private warningAlert(warningMsg: string) {
    window.scrollTo(0, 0);
    this.alerts = [];
    this.alerts.push({
        id: 3,
        type: 'warning',
        message: warningMsg
    });
  }

  public closeAlert(alert: any) {
    const index: number = this.alerts.indexOf(alert);
    this.alerts.splice(index, 1);
  }

  public showLastInsertedRecords() {
    this.returnedData.emit({ lastInsertedRecord: true });
  }

  public openedChange(rowData) {
    if (rowData == "searchParentInput")
        this.parentName = [...this.parentNameMainData];
    else if (rowData == "searchPartClass")
        this.partClassData = [...this.partClassMainData];
}

public onKey(value, rowData) {
    if (rowData == "searchParentInput") {
        this.parentName = [...this.parentNameMainData];
        this.parentName = this.search(value, "parentId");
    }  else if (rowData == "searchPartClass") {
        this.partClassData = [...this.partClassMainData];
        this.partClassData = this.search(value, "partClass");
    }
}

//filter for dropdown
public search(value: string, choice: string) {
    let filter = value.toLowerCase();
    if (choice == "parentId")
        return this.parentNameMainData.filter(option => (option.parentId &&option.parentId.toLowerCase().indexOf(filter) > -1) ||
        (option.xParentName && option.xParentName.toLowerCase().indexOf(filter) > -1));
    else if (choice == "partClass")
        return this.partClassMainData.filter(option => (option.name &&option.name.toLowerCase().indexOf(filter) > -1) ||
            (option.objId && option.objId.indexOf(filter) > -1));
}

// to retrieve parent ids
private retrieveParentId() {
    this.showLoadingScreen = true;
    var obj: any = {}
    this.wizardService
        .getParentName(this.wizardHelper.dbEnv, '')
        .pipe(takeUntil(this.unsubscribe))
        .subscribe(
        (data: any) => {
            if (data[0] === null || data[0] === undefined) {
                this.toasterService.showErrorMessage(
                    this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_PARENT_ID_ERROR_MESSAGE")
                );
                return;
            }
            if (data[0] && data[0].ERR) {
                this.showLoadingScreen = false;
                const commaSeperatedArr = data[0].ERR.split(",");
                for (
                    let i = commaSeperatedArr.length - 1;
                    i >= 0;
                    i--
                ) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
                return;
            }
            this.showLoadingScreen = false;
            this.parentNameMainData = data[0];
           
            let uniqueValue = this.parentNameMainData.filter((v, i) => 
            this.parentNameMainData.findIndex(item => item.parentId == v.parentId) === i);
            this.parentNameMainData = [...uniqueValue];
            this.parentName = [...this.parentNameMainData];
            this.notCertifyModelService.setParentId(this.parentName);                
            this.retrievePartClassObjId();
        },
        (err: any) => {
            this.showLoadingScreen = false;
            if (err.error === undefined || err.error === null)
                this.toasterService.showErrorMessage(
                    this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                );
            else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                return;
            else this.toasterService.showErrorMessage(err.error);
        }
        );
}

// to retrieve part class objid
public retrievePartClassObjId() {
    this.showLoadingScreen = true;
    let obj: any = {};
    this.partClassData = [];
    this.partClassMainData = [];
    obj.dbEnv = this.wizardHelper.dbEnv;
    this.wizardService
        .retrievePartClassObjId(obj)
        .pipe(takeUntil(this.unsubscribe))
        .subscribe(
        (data: any) => {
            if (data[0] === null || data[0] === undefined) {

                this.toasterService.showErrorMessage(
                    this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_UNABLE_RETRIEVE_PART_CLASS_OBJID")
                );
                this.showLoadingScreen = false;
                return;
            }
            if (data[0] && data[0].ERR) {
                this.showLoadingScreen = false;
                const commaSeperatedArr = data[0].ERR.split(",");
                for (
                    let i = commaSeperatedArr.length - 1;
                    i >= 0;
                    i--
                ) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
                return;
            }
            if (data[0].length == 0)
                this.toasterService.showErrorMessage("No Part Class Obj Id found");
            this.partClassData = data[0];
            this.partClassMainData = data[0];
            this.notCertifyModelService.setPartClass(this.partClassMainData);
            this.showLoadingScreen = false;
        },
        (err: any) => {
            this.showLoadingScreen = false;
            if (err.error === undefined || err.error === null) {
                this.toasterService.showErrorMessage(
                    this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                );
            }
            else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                return;
            else this.toasterService.showErrorMessage(err.error);
        }
        );
}

// to filter columns
public filterReportResults(): void {
    const filterFormObject = this.tableFrmGroupMain.value;
    this.filteredValues.objId = filterFormObject.objId;
    this.filteredValues.dev = filterFormObject.dev;
    this.filteredValues.parentId = filterFormObject.parentId;
    this.filteredValues.partClassObjId = filterFormObject.partClassObjId;
    const newRows = Object.keys(filterFormObject).reduce((acc, key) => {
        if (!filterFormObject[key].length) return acc;
        const filteredRows = acc.filter(val => filterFormObject[key].indexOf(val[key]) > -1);
        return filteredRows;
    }, this.tableRowsMainData);

    this.tableRows = newRows;
}

public generateFilters(): void {
    this.filteredRows = Object.keys(this.tableColumns)
        .map(i => this.tableColumns[i].prop)
        .reduce((filterObject, columnName) => {
            const uniqueValuesPerRow = this.tableRows.reduce((set, row) => set.add(row[columnName]), new Set());
            let val:any = Array.from(uniqueValuesPerRow);
          if( /^[0-9]*$/.test(val[0])){
               filterObject[columnName] = val.sort(function(a,b){return a - b});
          }else{
               filterObject[columnName] =val.sort((a, b) => {
                a = a || '';
                b = b || '';
                return a.localeCompare(b);
            });                   
          }
            return filterObject;
        }, {});
}


}
