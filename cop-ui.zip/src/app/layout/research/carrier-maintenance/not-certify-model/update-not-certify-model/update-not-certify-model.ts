import { Component, OnInit, ViewEncapsulation, ViewChildren, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ConfirmationService } from 'primeng/primeng';
import { takeUntil } from 'rxjs/operators';
import { Subject } from "rxjs";
import { CarrierMaintenanceService } from '../../../../../Services/carrierMaintenance.service';
import { CarrierMaintenanceHelper } from "../../carrier-maintenance-helper";
import { ToasterService } from "../../../../../Services/toaster.service";
import { NotCertifyModelHelper } from "../not-certify-model-helper";
import { NotCertifyModelService } from "../not-certify-model-service";
import { MatSelect } from "@angular/material";

@Component({
    selector: 'update-not-certify-model',
    templateUrl: './update-not-certify-model.html',
    styleUrls: ['./update-not-certify-model.scss',
        "../../../../components/ngxtable/material.scss",
        "../../../../components/ngxtable/datatable.component.scss",
        "../../../../components/ngxtable/icons.css",
        "../../../../components/ngxtable/app.css"],
    animations: [],
    encapsulation: ViewEncapsulation.None,
})

export class UpdateNotCertifyModelComponent implements OnInit {
    private unsubscribe = new Subject<void>();
    public frmNotCertifyModel: FormGroup;
    public showLoadingScreen: boolean;
    public tableRows: any = [];
    public tableRowsMainData: any = [];
    isEditable = {};
    private editedRow: any = {};
    private defaultEditedRow: any = {};
    public tableColumns:any = [];
    public alreadyEnabled = true;
    public showNoRecordsFoundMessage : Boolean = true;
    public parentName: any = [];
    public parentNameMainData: any = [];
    public partClassData: any = [];
    public partClassMainData: any = [];
    @ViewChildren(MatSelect) matSelect: any;
    public selected: any = [];
    public multiColumnEditSection = false;
    public multicolumnEditColumnName = '';
    @ViewChild('multicolumnEditColumnValue') multicolumnEditColumnValue: any;
    @ViewChild('multicolumnEditCheckbox') private multicolumnEditCheckbox: any;
    public partClassObjIdColumn = false;
    public textColumns = false;
    public parentColumn = false;
    public parentIdData: any = [];
    public parentIdMainData: any = [];
    public filteredValues: any = {};
    public filteredRows: any;
    public tableFrmGroupMain: FormGroup;
    public selectedModels:any = [];
    public showBulkUpdateButton = false;

    constructor(
        private formBuilder: FormBuilder,
        private wizardService: CarrierMaintenanceService,
        private notCertifyModelHelper: NotCertifyModelHelper,
        private toasterService: ToasterService,
        private wizardHelper: CarrierMaintenanceHelper,
        private confirmationService: ConfirmationService,
        private notCertifyModelService: NotCertifyModelService
    ) { }
    

    ngOnInit() { 
        this.createForm();
        this.createTableForm();
        this.tableColumns = [
            { name: 'Dev', prop: 'dev', width: "200" },
            { name: 'Parent Id', prop: 'parentId', width: "250" },
            { name: 'Part Class Obj Id', prop: 'partClassObjId', width: "250" },
        ];
        this.filteredValues = {};
        if (this.notCertifyModelService.getParentId() && this.notCertifyModelService.getParentId().length > 0) {
            this.notCertifyModelService.getParentId().forEach(e2 => {
                this.parentName.push(e2)
            });
            this.parentNameMainData = [...this.parentName];
            this.notCertifyModelService.getPartClass().forEach(e3 => {
                this.partClassMainData.push(e3)
            });
            this.partClassData = [...this.partClassMainData];
        }else{
            this.retrieveParentId();
        }

        this.multiColumnEditSection = false;
        this.multicolumnEditColumnName = '';
        this.multicolumnEditColumnValue = '';
        this.multicolumnEditCheckbox = '';
        this.showBulkUpdateButton = false
    }

        //to create form
        private createForm() {
            this.frmNotCertifyModel = this.formBuilder.group({
                objId: ['', [Validators.pattern("^[0-9\n ,]*$"), Validators.maxLength(38)]],
                dev: ['', [Validators.pattern("^[0-9\n ,]*$"), Validators.maxLength(38)]],
                parentId: ['', []],
                partClassObjId: ['', []],
            })
        }

        //form for column level filter
    public createTableForm() {
        this.tableFrmGroupMain = this.formBuilder.group({
            objId: [""],
            dev: [""],
            parentId: [""],
            partClassObjId: [""],
        });
    }

    // reset the form
    revert() {
        this.frmNotCertifyModel.reset();
        this.tableRows = [];
        this.tableRowsMainData = [];
        this.filteredValues = {};
        let filterKeys = Object.keys(this.tableFrmGroupMain.controls);
        filterKeys.forEach(_e1 => {
            this.tableFrmGroupMain.controls[`${_e1}`].patchValue([]);
        });
        this.selectedModels = [];
        this.alreadyEnabled = true;
        this.showBulkUpdateButton = false;
        this.selected = [];
    }

   // search not certify model
   public searchForm() {
    this.showLoadingScreen = true;
    let obj = this.frmNotCertifyModel.value;
        this.editedRow = {};
        this.defaultEditedRow = {};
        this.isEditable = {};
        this.selectedModels = [];
        this.selected = [];
        this.showBulkUpdateButton = false;
        this.notCertifyModelService.setSearchData([]);
        let filterKeys = Object.keys(this.tableFrmGroupMain.controls);
        filterKeys.forEach(_e1 => {
            this.tableFrmGroupMain.controls[`${_e1}`].patchValue([]);
        });
        this.filteredValues ={};
      this.alreadyEnabled = true;
    obj = this.wizardHelper.checkRequestObject(obj);
    obj.dbEnv = this.wizardHelper.dbEnv;
    this.wizardService.searchNotCertifyModel(obj).pipe(takeUntil(this.unsubscribe))
        .subscribe(
        (data: any) => {
            if (data[0] === null || data[0] === undefined) {
                this.showLoadingScreen = false;
                this.toasterService.showErrorMessage(
                    this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_NOT_CERTIFY_MODEL_ERROR_MESSAGE")
                );
                return;
            }
            if (data[0] && data[0].ERR) {
                this.showLoadingScreen = false;
                const commaSeperatedArr = data[0].ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
                return;
            }

            let response = data[0];
            let fullObject = [];
                if (!this.notCertifyModelService.getSearchData() || (this.notCertifyModelService.getSearchData() && this.notCertifyModelService.getSearchData().length == 0)) {
                    response.forEach(e1 => {
                        fullObject.push(e1)
                    });
                    
                } else if (this.notCertifyModelService.getSearchData().length > 0) {
                    fullObject = this.notCertifyModelService.getSearchData();
                    response.forEach(e1 => {
                        fullObject.push(e1)
                    });
                }
                this.notCertifyModelService.setSearchData(fullObject);
                this.tableRowsMainData = [];
                this.tableRows = [];
                for (let i = 0; i < this.notCertifyModelService.getSearchData().length; i++) {
                    this.tableRowsMainData.push(this.notCertifyModelService.getSearchData()[i]);
                }
                let rowId = 1;
                this.tableRowsMainData.forEach(element => {
                    element.rowId = rowId;
                    rowId++;
                });
                this.tableRows = [...this.tableRowsMainData];
            this.showLoadingScreen = false;
            if (data[0] && data[0].length == 0  && this.showNoRecordsFoundMessage)
            this.toasterService.showErrorMessage(
            this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_SEARCH_NOT_CERTIFY_MODEL_ERROR_MESSAGE")
            );

            this.generateFilters();
            this.filterReportResults();
            this.multiColumnEditSection = false;
                this.partClassObjIdColumn = false;
                this.textColumns = false;
                this.parentColumn = false;
            this.showNoRecordsFoundMessage = true;
            if (this.filteredValues && this.filteredValues.mainTableFilter) {
                this.updateSummaryTable(this.filteredValues.mainTableFilter);
            }
        },
        (err: any) => {
            this.showLoadingScreen = false;
            if (err.error === undefined || err.error === null)
                this.toasterService.showErrorMessage(
                    this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                );
            else if (err.error && err.error.ERR) {
                const commaSeperatedArr = err.error.ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
            }
            else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                return;
            else this.toasterService.showErrorMessage(err.error);
        }
        );
}

public  editButtonClicked(rowData,rowIndex) {
    this.alreadyEnabled = false;
    this.defaultEditedRow = { ...rowData }
    for (let i = 0; i < this.tableRowsMainData.length; i++) {
      if (this.isEditable[i])
        this.alreadyEnabled = true;
    }
    if (!this.alreadyEnabled)
      this.isEditable[rowIndex] = !this.isEditable[rowIndex];
    else{
      this.alreadyEnabled = false;
      this.toasterService.showErrorMessage(
        this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE")
      );
    }
  }


private inputValueChanged(event, column, row, oldValue) {
    if (column != "parentId" && column != "partClassObjId") {
        this.editedRow[column] = event.target.value;
        this.defaultEditedRow[column] = event.target.defaultValue;
    }
    else {
        this.editedRow[column] = event.value;
        this.defaultEditedRow[column] = oldValue;
    }

}

//to update not certify model
public updateNotCertifyModel(editData, rowIndex) {
    if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
        this.toasterService.showErrorMessage(
            this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
        )
        return;
    }
    this.showLoadingScreen = true;
    let obj = { ...editData, ...this.editedRow }

    obj = this.wizardHelper.checkRequestObject(obj);
    obj.dbEnv = this.wizardHelper.dbEnv;
    delete obj.rowId;
    this.wizardService.updateNotCertifyModel(obj).pipe(takeUntil(this.unsubscribe))
        .subscribe(
        (data: any) => {
            if (data[0] === null || data[0] === undefined) {
                this.showLoadingScreen = false;
                this.toasterService.showErrorMessage(
                    this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_NOT_CERTIFY_MODEL_ERROR_MESSAGE")
                );
                return;
            }
            if (data[0] && data[0].ERR) {
                this.showLoadingScreen = false;
                const commaSeperatedArr = data[0].ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
                return;
            }
            for (let i = 0; i < this.tableRowsMainData.length; i++) {
                if (this.tableRowsMainData[i].rowId == this.defaultEditedRow.rowId) {
                    this.tableRowsMainData[i] = obj;
                }
            }
            this.isEditable[rowIndex] = !this.isEditable[rowIndex];
            this.showLoadingScreen = false;
            this.alreadyEnabled = true;
            this.editedRow = {};
            this.defaultEditedRow = {};
            this.tableRows = [...this.tableRowsMainData];
            this.searchForm();

            this.toasterService.showSuccessMessage(
                this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_NOT_CERTIFY_MODEL_SUCCESS_MESSAGE")
            );

        },
        (err: any) => {
            this.showLoadingScreen = false;
            if (err.error === undefined || err.error === null)
                this.toasterService.showErrorMessage(
                    this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                );
            else if (err.error && err.error.ERR) {
                const commaSeperatedArr = err.error.ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
            }
            else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                return;
            else this.toasterService.showErrorMessage(err.error);
        }
        );
}

//to cancel update
private cancelEditForm(rowData, rowIndex) {
    this.showLoadingScreen = true;
    this.isEditable[rowIndex] = !this.isEditable[rowIndex];
    this.tableColumns.forEach(e1 => {
        if (document.getElementById(e1.prop + rowIndex)) {
            (<HTMLInputElement>(
                document.getElementById(e1.prop + rowIndex)
            )).value = rowData[e1.prop] || '';
        }
    });

    this.matSelect._results.forEach(matSelectData => {
        if (matSelectData.id.indexOf('parentId' + rowIndex) == 0)
            matSelectData.value = rowData['parentId'] || '';
        else if (matSelectData.id.indexOf('partClassObjId' + rowIndex) == 0)
            matSelectData.value = rowData['partClassObjId'] || '';
    });
    this.editedRow = {};
    this.defaultEditedRow = {};
    this.showLoadingScreen = false;
    this.alreadyEnabled = true;
}

//to filter table
private updateSummaryTable(event) {
    let val: any;
        if (event.target)
            val = event.target.value.toLowerCase();
        else
            val = event.toLowerCase();

    const temp = this.tableRowsMainData.filter(function (d) {
        return (d.objId ? d.objId.indexOf(val) !== -1 : !val)
            || (d.dev ? d.dev.indexOf(val) !== -1 : !val)
            || (d.parentId ? d.parentId.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.partClassObjId ? d.partClassObjId.toLowerCase().indexOf(val) !== -1 : !val)
    });
    this.tableRows = temp;
}

// delete confirm
public showConfirm(esnData, rowIndex) {
    this.confirmationService.confirm({
      key: 'confirm-delete-cmi',
      message: "Are you sure you want to delete not certify model ?",
      accept: () => {
        this.deleteNotCertifyModel(esnData, rowIndex)
      }
    });
  }

  // to delete not certify model
  public deleteNotCertifyModel(esnData, rowIndex) {
    this.showLoadingScreen = true;
    let obj:any = {};
    obj = esnData
    obj.dbEnv = this.wizardHelper.dbEnv;
    delete obj.rowId;
    this.wizardService.deleteNotCertifyModel(obj).pipe(takeUntil(this.unsubscribe))
      .subscribe(
      (data: any) => {
        if (data[0] === null || data[0] === undefined) {
          this.showLoadingScreen = false;
          this.toasterService.showErrorMessage(
            this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_DELETE_NOT_CERTIFY_MODEL_ERROR_MESSAGE")
          );
          return;
        }
        if (data[0] && data[0].ERR) {
          this.showLoadingScreen = false;
          const commaSeperatedArr = data[0].ERR.split(",");
          for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
            if (commaSeperatedArr[i] != "")
              this.toasterService.showErrorMessage(
                commaSeperatedArr[i]
              );
          }
          return;
        }
        this.toasterService.showSuccessMessage(
          this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_DELETE_NOT_CERTIFY_MODEL_SUCCESS_MESSAGE")
        );
        this.showNoRecordsFoundMessage = false;
        this.searchForm();
      },
      (err: any) => {
        this.showLoadingScreen = false;
        if (err.error === undefined || err.error === null)
          this.toasterService.showErrorMessage(
            this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
          );
        else if (err.error && err.error.ERR) {
          const commaSeperatedArr = err.error.ERR.split(",");
          for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
            if (commaSeperatedArr[i] != "")
              this.toasterService.showErrorMessage(
                commaSeperatedArr[i]
              );
          }
        }
        else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
          return;
        else this.toasterService.showErrorMessage(err.error);
      }
      );
  }

  // to retrieve parent ids
private retrieveParentId() {
    this.showLoadingScreen = true;
    var obj: any = {}
    this.wizardService
        .getParentName(this.wizardHelper.dbEnv, '')
        .pipe(takeUntil(this.unsubscribe))
        .subscribe(
        (data: any) => {
            if (data[0] === null || data[0] === undefined) {
                this.toasterService.showErrorMessage(
                    this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_PARENT_ID_ERROR_MESSAGE")
                );
                return;
            }
            if (data[0] && data[0].ERR) {
                this.showLoadingScreen = false;
                const commaSeperatedArr = data[0].ERR.split(",");
                for (
                    let i = commaSeperatedArr.length - 1;
                    i >= 0;
                    i--
                ) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
                return;
            }
            this.showLoadingScreen = false;
            this.parentNameMainData = data[0];
           
            let uniqueValue = this.parentNameMainData.filter((v, i) => 
            this.parentNameMainData.findIndex(item => item.parentId == v.parentId) === i);
            this.parentNameMainData = [...uniqueValue];
            this.parentName = [...this.parentNameMainData];
            this.notCertifyModelService.setParentId(this.parentName);                
            this.retrievePartClassObjId();
        },
        (err: any) => {
            this.showLoadingScreen = false;
            if (err.error === undefined || err.error === null)
                this.toasterService.showErrorMessage(
                    this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                );
            else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                return;
            else this.toasterService.showErrorMessage(err.error);
        }
        );
}

// to retrieve part class objid
public retrievePartClassObjId() {
    this.showLoadingScreen = true;
    let obj: any = {};
    this.partClassData = [];
    this.partClassMainData = [];
    obj.dbEnv = this.wizardHelper.dbEnv;
    this.wizardService
        .retrievePartClassObjId(obj)
        .pipe(takeUntil(this.unsubscribe))
        .subscribe(
        (data: any) => {
            if (data[0] === null || data[0] === undefined) {

                this.toasterService.showErrorMessage(
                    this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_UNABLE_RETRIEVE_PART_CLASS_OBJID")
                );
                this.showLoadingScreen = false;
                return;
            }
            if (data[0] && data[0].ERR) {
                this.showLoadingScreen = false;
                const commaSeperatedArr = data[0].ERR.split(",");
                for (
                    let i = commaSeperatedArr.length - 1;
                    i >= 0;
                    i--
                ) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
                return;
            }
            if (data[0].length == 0)
                this.toasterService.showErrorMessage("No Part Class Obj Id found");
            this.partClassData = data[0];
            this.partClassMainData = data[0];
            this.notCertifyModelService.setPartClass(this.partClassMainData);
            this.showLoadingScreen = false;
        },
        (err: any) => {
            this.showLoadingScreen = false;
            if (err.error === undefined || err.error === null) {
                this.toasterService.showErrorMessage(
                    this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                );
            }
            else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                return;
            else this.toasterService.showErrorMessage(err.error);
        }
        );
}

public openedChange(rowData) {
    if (rowData == "searchParentInput")
        this.parentName = [...this.parentNameMainData];
    else if (rowData == "searchPartClass")
        this.partClassData = [...this.partClassMainData];
}

public onKey(value, rowData) {
    if (rowData == "searchParentInput") {
        this.parentName = [...this.parentNameMainData];
        this.parentName = this.search(value, "parentId");
    }  else if (rowData == "searchPartClass") {
        this.partClassData = [...this.partClassMainData];
        this.partClassData = this.search(value, "partClass");
    }
}

//filter for dropdown
public search(value: string, choice: string) {
    let filter = value.toLowerCase();
    if (choice == "parentId")
        return this.parentNameMainData.filter(option => (option.parentId && option.parentId.indexOf(filter) > -1) ||
        (option.xParentName && option.xParentName.toLowerCase().indexOf(filter) > -1));
    else if (choice == "partClass")
        return this.partClassMainData.filter(option => (option.name &&option.name.toLowerCase().indexOf(filter) > -1) ||
            (option.objId && option.objId.indexOf(filter) > -1));
}

// to filter columns
public filterReportResults(): void {
    const filterFormObject = this.tableFrmGroupMain.value;
    this.filteredValues.objId = filterFormObject.objId;
    this.filteredValues.dev = filterFormObject.dev;
    this.filteredValues.parentId = filterFormObject.parentId;
    this.filteredValues.partClassObjId = filterFormObject.partClassObjId;
    const newRows = Object.keys(filterFormObject).reduce((acc, key) => {
        if (!filterFormObject[key].length) return acc;
        const filteredRows = acc.filter(val => filterFormObject[key].indexOf(val[key]) > -1);
        return filteredRows;
    }, this.tableRowsMainData);

    this.tableRows = newRows;
}

public generateFilters(): void {
    this.filteredRows = Object.keys(this.tableColumns)
        .map(i => this.tableColumns[i].prop)
        .reduce((filterObject, columnName) => {
            const uniqueValuesPerRow = this.tableRows.reduce((set, row) => set.add(row[columnName]), new Set());
            let val:any = Array.from(uniqueValuesPerRow);
          if( /^[0-9]*$/.test(val[0])){
               filterObject[columnName] = val.sort(function(a,b){return a - b});
          }else{
               filterObject[columnName] =val.sort((a, b) => {
                a = a || '';
                b = b || '';
                return a.localeCompare(b);
            });                   
          }
            return filterObject;
        }, {});
}

public onSelect(row) {
    this.selectedModels = [];
    this.multiColumnEditSection = false;
    this.textColumns = false;
    this.parentColumn = false;
    this.partClassObjIdColumn = false;
    if (row && row.selected) {
        for (let i = 0; i < row.selected.length; i++) {
            let obj = { ...row.selected[i] };
            this.selectedModels.push(obj);
        }
    }
    this.selectedModels = [...this.selectedModels];
    this.alreadyEnabled = true;
    this.showBulkUpdateButton = false;
}

private multiColumnEdit(isChecked) {
    if (isChecked.checked)
        this.multiColumnEditSection = true;
    else {
        this.multiColumnEditSection = false;
        this.multicolumnEditColumnName = '';
        this.multicolumnEditColumnValue = '';
        this.showBulkUpdateButton = false;
        this.textColumns = false;
        this.parentColumn = false;
        this.partClassObjIdColumn = false;
    }
}

public assignmultiColumnName(column) {
    this.multicolumnEditColumnName = column;
    this.showBulkUpdateButton = false;
   if (this.multicolumnEditColumnName == "partClassObjId") {
        this.partClassObjIdColumn = true;
        this.textColumns = false;
        this.parentColumn = false;
    }else if (this.multicolumnEditColumnName == "parentId") {
        this.partClassObjIdColumn = false;
        this.textColumns = false;
        this.parentColumn = true;            
    } else {
        this.textColumns = true;
        this.partClassObjIdColumn = false;
        this.parentColumn = false;            
    }
}

public updatemultiColumnEdit() {
    if (this.textColumns) {
        for (let i = 0; i < this.selectedModels.length; i++) {
            this.selectedModels[i][this.multicolumnEditColumnName] = this.multicolumnEditColumnValue.nativeElement.value;
        }
        this.multicolumnEditColumnValue.nativeElement.value = '';
    } else if (this.partClassObjIdColumn) {
        for (let i = 0; i < this.selectedModels.length; i++) {
            this.selectedModels[i][this.multicolumnEditColumnName] = this.multicolumnEditColumnValue.value;
        }
        this.multicolumnEditColumnValue.value = '';
    } else if (this.parentColumn) {
        for (let i = 0; i < this.selectedModels.length; i++) {
            this.selectedModels[i][this.multicolumnEditColumnName] = this.multicolumnEditColumnValue.value;
        }
        this.multicolumnEditColumnValue.value = '';
    }
    this.selectedModels = [...this.selectedModels];
    this.multicolumnEditColumnName = '';
    this.multicolumnEditCheckbox.checked = false;
    this.multiColumnEditSection = false;
    this.textColumns = false;
    this.partClassObjIdColumn = false;
    this.bulkUpdateNotCertifyModel();
}

//to bulk update not certify model
public bulkUpdateNotCertifyModel() {
    if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
        this.toasterService.showErrorMessage(
            this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
        )
        return;
    }
    this.showLoadingScreen = true;
    let obj:any = [...this.selectedModels];
    obj.forEach(e => {
        e.dbEnv = this.wizardHelper.dbEnv
    });
    this.alreadyEnabled = false;
    obj = this.wizardHelper.checkRequestObject(obj);
    this.wizardService.bulkUpdateNotCertifyModel(obj).pipe(takeUntil(this.unsubscribe))
        .subscribe(
        (data: any) => {
            if (data[0] === null || data[0] === undefined) {
                this.showLoadingScreen = false;
                this.toasterService.showErrorMessage(
                    this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_NOT_CERTIFY_MODEL_ERROR_MESSAGE")
                );
                return;
            }
            if (data[0] && data[0].ERR) {
                this.showLoadingScreen = false;
                const commaSeperatedArr = data[0].ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
                return;
            }
            this.showLoadingScreen = false;
            this.alreadyEnabled = true;
            this.searchForm();

            this.toasterService.showSuccessMessage(
                this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_NOT_CERTIFY_MODEL_SUCCESS_MESSAGE")
            );

        },
        (err: any) => {
            this.showLoadingScreen = false;
            if (err.error === undefined || err.error === null)
                this.toasterService.showErrorMessage(
                    this.notCertifyModelHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                );
            else if (err.error && err.error.ERR) {
                const commaSeperatedArr = err.error.ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
            }
            else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                return;
            else this.toasterService.showErrorMessage(err.error);
        }
        );
}

public showUpdate(val){
    if(val){
        this.showBulkUpdateButton = true;
    } else {
        this.showBulkUpdateButton = false;
    }
}


}