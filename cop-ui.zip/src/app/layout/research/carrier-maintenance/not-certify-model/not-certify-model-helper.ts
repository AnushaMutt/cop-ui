import { Injectable } from "@angular/core";
import { Subject } from "rxjs";

@Injectable({
    providedIn: "root"
})
export class NotCertifyModelHelper {
    
    public breadcrumbListUpdate = new Subject<number>();
    public breadcrumbList = [];
    constructor() { }

    public NotCertifyModelConstantObject = {
        "TRACFONE_DEFAULT_ERROR_MESSAGE": "Unable to process request",
        "TRACFONE_DONE_CREATING_NOT_CERTIFY_MODEL_CONFIRM_MESSAGE": "Are you done creating Not Certify Model ?",
        "TRACFONE_ADD_NOT_CERTIFY_MODEL_ERROR_MESSAGE": "Unable to add Not Certify Model",
        "TRACFONE_ADD_NOT_CERTIFY_MODEL_SUCCESS_MESSAGE": "Not Certify Model has been added successfully",  
        "TRACFONE_RETRIEVE_NOT_CERTIFY_MODEL_ERROR_MESSAGE" : "Unable to search Not Certify Model",
        "TRACFONE_SEARCH_NOT_CERTIFY_MODEL_ERROR_MESSAGE" : "No Not Certify Model found",
        "TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE": "Please complete previous operation",  
        "TRACFONE_UPDATE_NOT_CERTIFY_MODEL_ERROR_MESSAGE" : "Unable to update Not Certify Model",
        "TRACFONE_UPDATE_NOT_CERTIFY_MODEL_SUCCESS_MESSAGE" : "Not Certify Model has been updated successfully",
        "TRACFONE_DELETE_NOT_CERTIFY_MODEL_SUCCESS_MESSAGE": "Not Certify Model has been deleted successfully",
        "TRACFONE_DELETE_NOT_CERTIFY_MODEL_ERROR_MESSAGE": "Unable to delete Not Certify Model",
        "TRACFONE_NO_SUMMARY_FOUND_ERROR_MESSAGE" : "No records found",
        "TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE" : "Please fix validation errors",
        "TRACFONE_DUPLICATE_NOT_CERTIFY_MODEL_ERROR_MESSAGE" : "Duplicate Not Certify Model found",
        "TRACFONE_UNABLE_RETRIEVE_PART_CLASS_OBJID": "Unable to retrieve part Class Obj Id",
        "TRACFONE_RETRIEVE_PARENT_ID_ERROR_MESSAGE": "Unable to retrieve Parent Id"
    }

    public getTracfoneConstantMethod(msg) {
        return this.NotCertifyModelConstantObject[msg];
    }

}