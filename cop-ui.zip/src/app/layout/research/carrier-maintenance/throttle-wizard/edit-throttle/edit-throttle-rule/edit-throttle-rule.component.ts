import { Component, OnInit } from "@angular/core";

@Component({
    selector: 'edit-throttle-rule',
    templateUrl: './edit-throttle-rule.component.html',
    styleUrls: ['./edit-throttle-rule.component.scss']
})
export class EditThrottleRuleComponent implements OnInit {
    index = 0;

    constructor() { }

    ngOnInit() { }

    returnedData(data){
        this.index = data.index;
    }

    onChange(event) {
        if (event.index == 0) {
            this.index = 0;
        } else if (event.index == 1) {
            this.index = 1;
        } else if (event.index == 2) {
            this.index = 2;
        }
    }
}


