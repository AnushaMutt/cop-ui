import { Injectable } from "@angular/core";
import { Subject } from "rxjs";

@Injectable({
    providedIn: "root"
})
export class EditThrottleService {
    step1Data:any = [];
    parentId:any = [];

    nextStepNumber = new Subject();
    isAppThrottlePolicyActive = new Subject<boolean>();
    isAppThrottleRuleActive = new Subject<boolean>();
    currentStep = new Subject<number>();
    isBackButton = new Subject<boolean>(); 

    constructor() { }


    nextStepMove(step: Number) {
        this.nextStepNumber.next(step);
    }

    isAppThrottlePolicyActivated(isAppThrottlePolicyActive: boolean) {
        this.isAppThrottlePolicyActive.next(isAppThrottlePolicyActive);
    }

    isAppThrottleRuleActivated(isAppThrottleRuleActive: boolean) {
        this.isAppThrottleRuleActive.next(isAppThrottleRuleActive);
    }

    public setStep1Data(step1Data) {
        this.step1Data = step1Data;
    }

    public getStep1Data() {
        return this.step1Data;
    }

    public setParentId(parentId) {
        this.parentId = parentId;
    }

    public getParentId() {
        return this.parentId;
    }

    public isBackButtonActive(isBackButton: boolean) {
        this.isBackButton.next(isBackButton);
    }

    public resetAll(){
        this.step1Data = [];
        this.parentId = [];
    }
   

}