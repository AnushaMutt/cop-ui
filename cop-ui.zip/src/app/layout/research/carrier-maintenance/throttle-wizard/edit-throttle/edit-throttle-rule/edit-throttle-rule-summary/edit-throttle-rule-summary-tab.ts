import { Subject } from "rxjs";
import { Component, ViewEncapsulation, OnInit, ViewChildren } from '@angular/core';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { ConfirmationService } from 'primeng/primeng';
import { takeUntil } from 'rxjs/operators';
import { MatSelect, MatDialog } from "@angular/material";
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CarrierMaintenanceService } from '../../../../../../../Services/carrierMaintenance.service';
import { CarrierMaintenanceHelper } from "../../../../carrier-maintenance-helper";
import { ToasterService } from "../../../../../../../Services/toaster.service";
import { EditThrottleWizardHelper } from "../../edit-throttle-helper";
import { EditThrottleService } from "../../edit-throttle-service";
import { EditThrottleFeatureComponent } from "../../edit-throttle-feature/edit-throttle-feature.component";

@Component({
    selector: 'edit-throttle-rule-summary',
    templateUrl: './edit-throttle-rule-summary-tab.html',
    styleUrls: ['./edit-throttle-rule-summary-tab.scss',
        "../../../../../../components/ngxtable/material.scss",
        "../../../../../../components/ngxtable/datatable.component.scss",
        "../../../../../../components/ngxtable/icons.css",
        "../../../../../../components/ngxtable/app.css"],
})

export class EditThrottleRuleSummaryTab implements OnInit {
    @ViewChildren(DatatableComponent)
    table: any;
    @ViewChildren(MatSelect) matSelect: any;
    private unsubscribe = new Subject<void>();
    public showLoadingScreen: boolean;
    public throttleRuleFields: any = [];
    public throttleRuleCols: any = [];
    public throttleRuleData: any = [];
    public throttleRuleMainData: any = [];
    public isEditable: any = {}
    public editedRow: any = {};
    public defaultEditedRow: any = {};
    public selected: any = [];
    public parentIdData: any = [];
    public parentIdMainData: any = [];

    constructor(
        private wizardService: CarrierMaintenanceService,
        private toasterService: ToasterService,
        private wizardHelper: CarrierMaintenanceHelper,
        private modalService: NgbModal,
        private confirmationService: ConfirmationService,
        private editThrottleWizardHelper: EditThrottleWizardHelper,
        private editThrottleService: EditThrottleService,
        public dialog: MatDialog,
    ) { }

    ngOnInit() {
        this.throttleRuleMainData = [];
        this.throttleRuleData = [];
        this.throttleRuleFields = [
            { name: "Rule Description", prop: "ruleDesc", width: '150' },
        ];
        this.throttleRuleCols = [
            { name: "Parent Id", prop: "parentId", width: '280' },
            { name: "Rule Description", prop: "ruleDesc", width: '150' },
            { name: "Status", prop: "status", width: '50' },
        ];
        if (this.editThrottleService.getParentId() && this.editThrottleService.getParentId().length > 0) {
            this.editThrottleService.getParentId().forEach(e1 => {
                this.parentIdMainData.push(e1)
            });
            this.parentIdData = [...this.parentIdMainData];
            this.retrieveThrottleRules();
        } else {
            this.retrieveParentId();
        }
    }

    // to retrieve parent ids
    private retrieveParentId() {
        this.showLoadingScreen = true;
        var obj: any = {}
        this.wizardService
            .getParentName(this.wizardHelper.dbEnv, '')
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.toasterService.showErrorMessage(
                        this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_PARENT_ID_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (
                        let i = commaSeperatedArr.length - 1;
                        i >= 0;
                        i--
                    ) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                this.showLoadingScreen = false;
                this.parentIdMainData = data[0];
                this.parentIdData = [...this.parentIdMainData];
                this.editThrottleService.setParentId(this.parentIdData);
                this.retrieveThrottleRules();

            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }

    //to retrieve throttle rules
    public retrieveThrottleRules() {
        this.showLoadingScreen = true;
        this.defaultEditedRow = {};
        this.throttleRuleData = [];
        this.throttleRuleMainData = [];
        let obj: any = {};
        let policyData: any = this.editThrottleService.getStep1Data();
        obj.policyId = policyData[0].objId;
        obj = this.wizardHelper.checkRequestObject(
            obj
        );
        obj.dbEnv = this.wizardHelper.dbEnv;
        this.wizardService.retrieveThrottleRules(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_THROTTLE_RULE_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (
                        let i = commaSeperatedArr.length - 1;
                        i >= 0;
                        i--
                    ) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                this.showLoadingScreen = false;

                this.throttleRuleData = data[0];
                for(let i=0; i<this.throttleRuleData.length; i++){
                    let parentName = this.parentIdData.filter(e => {
                            return e.objId == this.throttleRuleData[i].parentId;
                    });
                    if(parentName && parentName[0] && parentName[0].xParentName)
                        this.throttleRuleData[i].parentId = this.throttleRuleData[i].parentId + " - " + parentName[0].xParentName;
                    else
                        this.throttleRuleData[i].parentId = this.throttleRuleData[i].parentId;
                    if(this.throttleRuleData[i].status == 'A'){
                        this.throttleRuleData[i].status =  'ACTIVE'
                    } else if(this.throttleRuleData[i].status == 'S'){
                        this.throttleRuleData[i].status =  'SUSPEND'
                    }
                     }
                    this.throttleRuleData = [...this.throttleRuleData];
                this.throttleRuleMainData = [...this.throttleRuleData];

                if (data[0] && data[0].length == 0)
                    this.toasterService.showErrorMessage(
                        this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_SEARCH_THROTTLE_RULE_ERROR_MESSAGE")
                    );
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != " ")
                            this.toasterService.showMultiple(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }

    //to filter table
    public updateThrottleRule(event) {
        const val = event.target.value.toLowerCase();

        const temp = this.throttleRuleMainData.filter(function (d) {
            return (d.objId ? d.objId.indexOf(val) !== -1 : !val) || !val
                || (d.parentId ? d.parentId.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.ruleDesc ? d.ruleDesc.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.status ? d.status.toLowerCase().indexOf(val) !== -1 : !val) || !val;
        });
        // update the rows
        this.throttleRuleData = temp;
        this.throttleRuleData.offset = 0;
    }

    public openedChange(rowData) {
        if (rowData == "searchParentInput")
            this.parentIdData = [...this.parentIdMainData];
    }

    public onKey(value, rowData) {
        if (rowData == "searchParentInput") {
            this.parentIdData = [...this.parentIdMainData];
            this.parentIdData = this.search(value, this.parentIdData);
        } 
    }

    search(value: string, searchArray: any) {
        let filter = value.toLowerCase();
        return searchArray.filter(
            option =>
                (option.xParentName &&
                    option.xParentName.toLowerCase().indexOf(filter) > -1) ||
                (option.objId &&
                    option.objId.indexOf(filter) > -1) ||
                (typeof option == "string"
                    ? option.toLowerCase().indexOf(filter) > -1
                    : !filter)
        );
    }

    public editButtonClicked(rowData, rowIndex) {
        let alreadyEnabled = false;
        this.defaultEditedRow = { ...rowData }
        for (let i = 0; i < this.throttleRuleData.length; i++) {
            if (this.isEditable[i])
                alreadyEnabled = true;
        }
        if (!alreadyEnabled)
            this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        else
            this.toasterService.showErrorMessage(
                this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE")
            );
    }

    // to cancel edit
    public cancelEditForm(rowData, rowIndex) {
        this.showLoadingScreen = true;
        this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        this.throttleRuleCols.forEach(e1 => {
            if (document.getElementById(e1.prop + rowIndex)) {
                (<HTMLInputElement>(
                    document.getElementById(e1.prop + rowIndex)
                )).value = rowData[e1.prop] || '';
            }
        });

        this.matSelect._results.forEach(matSelectData => {
            if (matSelectData.id.indexOf('status' + rowIndex) == 0)
                matSelectData.value = rowData['status'] || '';
            else if (matSelectData.id.indexOf('parentId' + rowIndex) == 0)
                matSelectData.value = rowData['parentId'] || '';
        });
        this.editedRow = {};
        this.defaultEditedRow = {};
        this.showLoadingScreen = false;
    }

    public inputValueChanged(event, column, row, oldValue) {
        if (column != "status" && column != "parentId") {

            this.editedRow[column] = event.target.value;
            this.defaultEditedRow[column] = event.target.defaultValue;
        }
        else {
            this.editedRow[column] = event.value;
            this.defaultEditedRow[column] = oldValue;
        }
    }

    public editConfirm(configdata, rowIndex){
        let obj = { ...configdata, ...this.editedRow }
        if(this.defaultEditedRow.status == 'ACTIVE' && obj.status ==  'SUSPEND'){
            this.showSuspendConfirm(configdata, rowIndex);
        } else {
            this.editThrottleRuleData(configdata, rowIndex)
        }
    }

    // delete confirm
    public showSuspendConfirm(throttleRuleData, rowIndex) {
        this.confirmationService.confirm({
            key: 'confirm-delete-rule',
            message: this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_DELETE_THROTTLE_RULE_CONFIRM_MESSAGE"),
            accept: () => {
                this.editThrottleRuleData(throttleRuleData, rowIndex)
            }
        });
    }

    //to update throttle rule
    public editThrottleRuleData(configdata, rowIndex) {
        if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
            this.toasterService.showErrorMessage(
                this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            return;
        }
        this.showLoadingScreen = true;
        let obj = { ...configdata, ...this.editedRow }

        obj = this.wizardHelper.checkRequestObject(obj);
        obj.dbEnv = this.wizardHelper.dbEnv; 
        if(obj.status == 'ACTIVE'){
                obj.status =  'A'
        } else if(obj.status == 'SUSPEND'){
                obj.status =  'S'
        }   
        obj.parentId = obj.parentId.split(" - ")[0];
        this.wizardService.updateThrottleRule(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_THROTTLE_RULE_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                this.isEditable[rowIndex] = !this.isEditable[rowIndex];
                this.showLoadingScreen = false;
                this.editedRow = {};
                this.defaultEditedRow = {};
                this.retrieveThrottleRules();

                this.toasterService.showSuccessMessage(
                    this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_THROTTLE_RULE_SUCCESS_MESSAGE")
                );

            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }

    // to open pop up
    featuresDialog(rowData) {
        const dialogRef = this.dialog.open(EditThrottleFeatureComponent, {
            width: "90%",
            height: "90%",
            data: {
                dataKey: rowData,
            },
        });
    }

}


