import { Subject } from "rxjs";
import { Component, ViewEncapsulation, OnInit, ViewChildren } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { ConfirmationService } from 'primeng/primeng';
import { takeUntil } from 'rxjs/operators';
import { MatSelect } from "@angular/material";
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CarrierMaintenanceService } from '../../../../../../Services/carrierMaintenance.service';
import { CarrierMaintenanceHelper } from "../../../carrier-maintenance-helper";
import { ToasterService } from "../../../../../../Services/toaster.service";
import { EditThrottleWizardHelper } from "../edit-throttle-helper";
import { EditThrottleService } from "../edit-throttle-service";

@Component({
    selector: 'edit-throttle-policy',
    templateUrl: './edit-throttle-policy.component.html',
    styleUrls: ['./edit-throttle-policy.component.scss',
        "./../../../../../components/ngxtable/material.scss",
        "./../../../../../components/ngxtable/datatable.component.scss",
        "./../../../../../components/ngxtable/icons.css",
        "./../../../../../components/ngxtable/app.css"],
})
export class EditThrottlePolicyComponent implements OnInit {
    @ViewChildren(DatatableComponent)
    table: any;
    @ViewChildren(MatSelect) matSelect: any;
    private unsubscribe = new Subject<void>();
    public frmGroupThrottle: FormGroup;
    public showLoadingScreen: boolean;
    public throttlePolicyFields: any = [];
    public throttlePolicyData: any = [];
    public throttlePolicyMainData: any = [];
    public isEditable: any = {}
    public editedRow: any = {};
    public defaultEditedRow: any = {};
    public selected = [];   
    public selectedPolicy:any = []; 

    constructor(
        private _formBuilder: FormBuilder,
        private wizardService: CarrierMaintenanceService,
        private toasterService: ToasterService,
        private wizardHelper: CarrierMaintenanceHelper,
        private modalService: NgbModal,
        private confirmationService: ConfirmationService,
        private editThrottleWizardHelper: EditThrottleWizardHelper,
        private editThrottleService: EditThrottleService,
    ) { 
        this.frmGroupThrottle = new FormGroup({});
    }

    ngOnInit() { 
        this.throttlePolicyMainData = [];
        this.throttlePolicyData = [];
        this.throttlePolicyFields = [
            {name: "Policy Name", prop: "policyName",  width: '150' },
            {name: "Policy Description", prop: "policyDesc",  width: '250' },
            {name: "Bypass Trans Queue", prop: "bypassTransQueue",  width: '150' },
            {name: "Data Suspended Flag", prop: "dataSuspendedFlag",  width: '150' },
        ];
        this.createSearchForm();
    }

        //to create search form
    public createSearchForm() {
    this.frmGroupThrottle = this._formBuilder.group({
            objId: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            policyName: ['', [Validators.maxLength(20)]],
            policyDesc: ['', [Validators.maxLength(40)]],
        });
    }

    //to search throttle policy
    public onSearchForm(isUpdate) {
      this.showLoadingScreen = true;
      this.isEditable = {};         
      this.editedRow = {};         
      this.defaultEditedRow = {};
      if(!isUpdate){
      this.editThrottleService.isAppThrottlePolicyActivated(false);
      this.selected = [];
      this.selectedPolicy = [];
      }        
      this.throttlePolicyData = [];
      this.throttlePolicyMainData = [];
      let obj: any = {};
      obj = this.wizardHelper.checkRequestObject(
        this.frmGroupThrottle.value
      );
      obj.dbEnv = this.wizardHelper.dbEnv;
      this.wizardService.searchThrottlePolicy(obj).pipe(takeUntil(this.unsubscribe))
        .subscribe(
        (data: any) => {
          if (data[0] === null || data[0] === undefined) {
            this.showLoadingScreen = false;
            this.toasterService.showErrorMessage(
              this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_THROTTLE_POLICY_ERROR_MESSAGE")
            );
            return;
          }
          if (data[0] && data[0].ERR) {
            this.showLoadingScreen = false;
            const commaSeperatedArr = data[0].ERR.split(",");
            for (
              let i = commaSeperatedArr.length - 1;
              i >= 0;
              i--
            ) {
              if (commaSeperatedArr[i] != "")
                this.toasterService.showErrorMessage(
                  commaSeperatedArr[i]
                );
            }
            return;
          }
          this.showLoadingScreen = false;
         
          this.throttlePolicyData = data[0];
          this.throttlePolicyMainData = [...this.throttlePolicyData];
         
          if (data[0] && data[0].length == 0)
            this.toasterService.showErrorMessage(
              this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_SEARCH_THROTTLE_POLICY_ERROR_MESSAGE")
            );
        },
        (err: any) => {
          this.showLoadingScreen = false;
          if (err.error === undefined || err.error === null)
            this.toasterService.showErrorMessage(
              this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
            );
          else if (err.error && err.error.ERR) {
            const commaSeperatedArr = err.error.ERR.split(",");
            for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
              if (commaSeperatedArr[i] != " ")
                this.toasterService.showMultiple(
                  commaSeperatedArr[i]
                );
            }
          } 
          else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
          return;
          else this.toasterService.showErrorMessage(err.error);
        }
        );
  }

  public editButtonClicked(rowData, rowIndex) {
        let alreadyEnabled = false;
        this.defaultEditedRow = { ...rowData }
        for (let i = 0; i < this.throttlePolicyData.length; i++) {
            if (this.isEditable[i])
                alreadyEnabled = true;
        }
        if (!alreadyEnabled)
            this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        else
            this.toasterService.showErrorMessage(
                this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE")
            );
    }

    // to cancel edit
    public cancelEditForm(rowData, rowIndex) {
        this.showLoadingScreen = true;
        this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        this.throttlePolicyFields.forEach(e1 => {
            if (document.getElementById(e1.prop + rowIndex)) {
                (<HTMLInputElement>(
                    document.getElementById(e1.prop + rowIndex)
                )).value = rowData[e1.prop] || '';
            }
        });

        this.matSelect._results.forEach(matSelectData => {
            if (matSelectData.id.indexOf('dataSuspendedFlag' + rowIndex) == 0)
                matSelectData.value = rowData['dataSuspendedFlag'] || '';
            else if (matSelectData.id.indexOf('bypassTransQueue' + rowIndex) == 0)
                matSelectData.value = rowData['bypassTransQueue'] || '';
        });
        this.editedRow = {};
        this.defaultEditedRow = {};
        this.showLoadingScreen = false;
    }

    public inputValueChanged(event, column, row, oldValue) {
        if (column != "dataSuspendedFlag" && column != "bypassTransQueue") {

            this.editedRow[column] = event.target.value;
            this.defaultEditedRow[column] = event.target.defaultValue;
        }
        else {
            this.editedRow[column] = event.value;
            this.defaultEditedRow[column] = oldValue;
        }
    }

    //to filter table
    public updateDataConfig(event) {
    const val = event.target.value.toLowerCase();

    const temp = this.throttlePolicyMainData.filter(function (d) {
      return (d.objId ? d.objId.indexOf(val) !== -1 : !val) || !val
        || (d.policyName ? d.policyName.toLowerCase().indexOf(val) !== -1 : !val) || !val
        || (d.policyDesc ? d.policyDesc.toLowerCase().indexOf(val) !== -1 : !val) || !val
        || (d.bypassTransQueue ? d.bypassTransQueue.toLowerCase().indexOf(val) !== -1 : !val) || !val
        || (d.dataSuspendedFlag ? d.dataSuspendedFlag.toLowerCase().indexOf(val) !== -1 : !val) || !val;        
    });
    // update the rows
    this.throttlePolicyData = temp;
    this.throttlePolicyData.offset = 0;
  }
  
    //to reset the form
    public revert() {
    this.wizardHelper.deleteBreadcrumbList(2);
    this.frmGroupThrottle.reset(); 
    this.throttlePolicyMainData = [];
    this.throttlePolicyData = [];
    this.selected = [];
    this.selectedPolicy = [];
    this.defaultEditedRow = {};
    this.editThrottleService.isAppThrottlePolicyActivated(false)  
    this.isEditable = {};         
    this.editedRow = {};         
    this.defaultEditedRow = {};           
    }

  //to update throttle policy
  public editThrottlePolicyData(configdata, rowIndex) {
        if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
            this.toasterService.showErrorMessage(
                this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            return;
        }
        this.showLoadingScreen = true;
        let obj = { ...configdata, ...this.editedRow }

        obj = this.wizardHelper.checkRequestObject(obj);
        obj.dbEnv = this.wizardHelper.dbEnv;
        this.wizardService.updateThrottlePolicy(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_THROTTLE_POLICY_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                if (this.selectedPolicy.length > 0){
                    this.editThrottleService.isAppThrottlePolicyActivated(true);
                 }
                this.isEditable[rowIndex] = !this.isEditable[rowIndex];
                this.showLoadingScreen = false;
                this.editedRow = {};
                this.defaultEditedRow = {};
                this.wizardHelper.updateBreadcrumbList(obj.policyName, 2);
                let isUpdate = true;
                this.onSearchForm(isUpdate);
               
                this.toasterService.showSuccessMessage(
                    this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_THROTTLE_POLICY_SUCCESS_MESSAGE")
                );

            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }
    
    //Row Selection
    public onSelect(row) {
    this.editThrottleService.setStep1Data("");
    this.selectedPolicy = [];
    this.selectedPolicy.push(row);
    this.editThrottleService.setStep1Data(this.selectedPolicy);
    this.editThrottleService.isAppThrottlePolicyActivated(true);
    this.wizardHelper.updateBreadcrumbList(row.policyName, 2); 
}

}


