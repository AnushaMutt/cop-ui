import { FormBuilder, FormGroup, FormArray, Validators } from "@angular/forms";
import { Subject } from "rxjs";
import { Component, ViewEncapsulation, OnInit, ViewChildren, Inject, ViewChild, EventEmitter, Output, Input } from '@angular/core';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { ConfirmationService } from 'primeng/primeng';
import { takeUntil } from 'rxjs/operators';
import { MatSelect } from "@angular/material";
import { CarrierMaintenanceService } from '../../../../../../../Services/carrierMaintenance.service';
import { CarrierMaintenanceHelper } from "../../../../carrier-maintenance-helper";
import { ToasterService } from "../../../../../../../Services/toaster.service";
import { EditThrottleWizardHelper } from "../../edit-throttle-helper";
import { EditThrottleService } from "../../edit-throttle-service";
import { EditThrottleFeatureComponent } from "../../edit-throttle-feature/edit-throttle-feature.component";
import { MAT_DIALOG_DATA } from "@angular/material";

@Component({
    selector: 'edit-throttle-feature-copy',
    templateUrl: './edit-throttle-feature-copy-tab.html',
    styleUrls: ['./edit-throttle-feature-copy-tab.scss',
        "../../../../../../components/ngxtable/material.scss",
        "../../../../../../components/ngxtable/datatable.component.scss",
        "../../../../../../components/ngxtable/icons.css",
        "../../../../../../components/ngxtable/app.css"],
})
export class EditThrottleFeatureCopyTab implements OnInit {
    @Input('workArea') workArea: any;
    @Output("returnedData") returnedData: any = new EventEmitter();
    public unsubscribe = new Subject<void>();
    public frmGroupThrottle: FormGroup;
    public rowData: any;
    public throttleFeatureData = [];
    public throttleFeatureMainData = [];
    public selectedFeatures = [];
    public copySelectedThrottleFeatures = [];
    public selectedOT = [];
    public copyThrottleFeatures = false;
    public showLoadingScreen = false;
    public throttleFeatureFields: any;
    public isEditable = {};
    public editedRow = {};
    public defaultEditedRow = {};
    public displayTable = false;
    public multiColumnEditSection = false;
    public multicolumnEditColumnName = '';
    @ViewChild('multicolumnEditColumnValue') multicolumnEditColumnValue: any;
    @ViewChild('multicolumnEditCheckbox') private multicolumnEditCheckbox: any;
    public multiColumnEditColumns = [];
    public allAvailableColumns: any;
    public copyColumns: any;
    public isSearchResultsExpanded = false;
    public textColumns = false;
    alreadyEnabled: any = { value: false };
    public statusDynamicselect: any = [];
    public statusColumn = false;
    public flagColumn = false;
    @Output("summaryData") summaryData: any = new EventEmitter();
    public featureFlagValueDynamicselect: any = [];

    constructor(
        private _formBuilder: FormBuilder,
        @Inject(MAT_DIALOG_DATA) public data: any,
        private wizardService: CarrierMaintenanceService,
        private toasterService: ToasterService,
        private wizardHelper: CarrierMaintenanceHelper,
        private confirmationService: ConfirmationService,
        private editThrottleWizardHelper: EditThrottleWizardHelper,
        private editThrottleService: EditThrottleService,

    ) {
        this.frmGroupThrottle = new FormGroup({});
    }

    ngOnInit() {
        this.showLoadingScreen = false;
        this.copySelectedThrottleFeatures = [];
        this.isSearchResultsExpanded = false;
        this.multiColumnEditSection = false;
        this.multicolumnEditColumnName = '';
        this.multicolumnEditColumnValue = '';
        this.multicolumnEditCheckbox = '';
        this.alreadyEnabled.value = false;
        this.statusDynamicselect = [
            { id: 'ACTIVE', name: 'ACTIVE' },
            { id: 'SUSPEND', name: 'SUSPEND' },
        ];
       this.featureFlagValueDynamicselect = [
            { id: 'YES', name: 'YES' },
            { id: 'NO', name: 'NO' },
            { id: '', name: 'NONE' },
        ]
        this.alreadyEnabled = Object.assign({}, this.alreadyEnabled);
        this.isSearchResultsExpanded = false;
        this.displayTable = false;
        this.throttleFeatureData = [];
        this.throttleFeatureMainData = [];
        this.rowData = { ...this.data.dataKey };
        this.allAvailableColumns = {
            "parentCols": [
                { field: "check", editable: true, inputType: 'checkbox' },
                { header: "Obj Id", field: "objId", editable: false },
                { header: "Feature Flag Name", field: "featureFlagName", editable: true, isOptional: false, length: 40 },
                { header: "Feature Flag Value", field: "featureFlagValue", editable: true, isOptional: true, length: 1, type: "dynamicselect" },
                { header: "Feature Name", field: "featureName", editable: true, isOptional: false, length: 30 },
                { header: "Feature Value", field: "featureValue", editable: true, isOptional: true, length: 30 },
                { header: "Status", field: "status", editable: true, isOptional: false, length: 1, type: "dynamicselect" },
            ],
            parentDataId: "objId",
            defaultColumnSort: "objId",
            isHeaderCheckBox: true,
            showFilterSection: true,
            isSearchResults: true
        }
        this.copyColumns = {
            "parentCols": [
                { header: "Obj Id", field: "objId", editable: false },
                { header: "Feature Flag Name", field: "featureFlagName", editable: true, isOptional: false, length: 40 },
                { header: "Feature Flag Value", field: "featureFlagValue", editable: true, isOptional: true, length: 1, type: "dynamicselect" },
                { header: "Feature Name", field: "featureName", editable: true, isOptional: false, length: 30 },
                { header: "Feature Value", field: "featureValue", editable: true, isOptional: true, length: 30 },
                { header: "Status", field: "status", editable: true, isOptional: false, length: 1, type: "dynamicselect", width: '125%' }
            ],
            parentDataId: "objId",
            defaultColumnSort: "objId",
            isWorkArea: true,

        }
        this.throttleFeatureFields = {
            "parentCols": [
                { header: "Obj Id", field: "objId", editable: false },
                { header: "Feature Flag Name", field: "featureFlagName", editable: true, isOptional: false, length: 40 },
                { header: "Feature Flag Value", field: "featureFlagValue", editable: true, isOptional: true, length: 1, type: "dynamicselect" },
                { header: "Feature Name", field: "featureName", editable: true, isOptional: false, length: 30 },
                { header: "Feature Value", field: "featureValue", editable: true, isOptional: true, length: 30 },
                { header: "Status", field: "status", editable: true, isOptional: false, length: 1, type: "dynamicselect" },
            ],
            parentDataId: "objId",
            defaultColumnSort: "objId",
            showFilterSection: true,
            hideDeleteIcon: false
        }

        this.multiColumnEditColumns = [
            { header: "Feature Flag Name", field: "featureFlagName", editable: true, isOptional: false, length: 40 },
            { header: "Feature Flag Value", field: "featureFlagValue", editable: true, isOptional: true, length: 1, type: "dynamicselect" },
            { header: "Feature Name", field: "featureName", editable: true, isOptional: false, length: 30 },
            { header: "Feature Value", field: "featureValue", editable: true, isOptional: true, length: 30 },
            { header: "Status", field: "status", editable: true, isOptional: false, length: 1, type: "dynamicselect" },
        ]
        this.createForm();
    }

    createForm() {
        this.frmGroupThrottle = this._formBuilder.group({
            featureFlagName: ['', [Validators.maxLength(40)]],
            featureName: ['', [Validators.maxLength(30)]],
            ruleId: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
        });
    }

    // to search throttle feature
    public onSearchForm() {
        this.showLoadingScreen = true;
        this.throttleFeatureMainData = [];
        this.throttleFeatureData = [];
        this.selectedFeatures = [];
        this.copySelectedThrottleFeatures = [];
        this.isSearchResultsExpanded = false;
        this.copyThrottleFeatures = false;
        let data: any = [];
        data.data = [];
        this.returnedData.emit({ data: data, status: "selectedData" });
        const obj: any = this.wizardHelper.checkRequestObject(
            this.frmGroupThrottle.value
        );
        obj.dbEnv = this.wizardHelper.dbEnv;
        this.wizardService
            .retrieveThrottleFeatures(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_THROTTLE_FEATURE_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (
                        let i = commaSeperatedArr.length - 1;
                        i >= 0;
                        i--
                    ) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                this.showLoadingScreen = false;
	this.multiColumnEditSection = false;
        this.flagColumn = false;
        this.textColumns = false;
        this.statusColumn = false;
                this.throttleFeatureMainData = data[0];
                for (let i = 0; i < this.throttleFeatureMainData.length; i++) {
                    this.throttleFeatureMainData[i].statusdynamicselect = this.statusDynamicselect;
                    this.throttleFeatureMainData[i].featureFlagValuedynamicselect = this.featureFlagValueDynamicselect;
                    if (this.throttleFeatureMainData[i].status == 'A') {
                        this.throttleFeatureMainData[i].status = 'ACTIVE'
                    } else if (this.throttleFeatureMainData[i].status == 'S') {
                        this.throttleFeatureMainData[i].status = 'SUSPEND'
                    }
                    if (this.throttleFeatureMainData[i].featureFlagValue == 'Y') {
                        this.throttleFeatureMainData[i].featureFlagValue = 'YES'
                    } else if (this.throttleFeatureMainData[i].featureFlagValue == 'N') {
                        this.throttleFeatureMainData[i].featureFlagValue = 'NO'
                    }
                }
                this.throttleFeatureData = [...this.throttleFeatureMainData];
                if (data[0] && data[0].length == 0)
                    this.toasterService.showErrorMessage(
                        this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_SEARCH_THROTTLE_FEATURE_ERROR_MESSAGE")
                    );
                else {
                    this.isSearchResultsExpanded = true;
                }
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null) {
                    this.toasterService.showErrorMessage(
                        this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                }
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (
                        let i = commaSeperatedArr.length - 1;
                        i >= 0;
                        i--
                    ) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }

    public checkReturnData(returnedData) {
        if (returnedData.status == "editEnableRow") {
            this.returnedData.emit({ status: "editEnableRow" });
        } else if (returnedData.status == "onRowEditCancel") {
            this.returnedData.emit({ status: "onRowEditCancel" });
        } else if (returnedData.status == "selectedData") {
            this.returnedData.emit({ data: returnedData, status: returnedData.status });
            this.selectedFeatures = [];
            for (let i = 0; i < returnedData.data.length; i++) {
                let data = { ...returnedData.data[i] }
                this.selectedFeatures.push(data);
            }
        } else if (returnedData.status == "alreadyEditEnabled") {
            this.toasterService.showErrorMessage(
                this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE")
            )
        } else if (returnedData.status == "validationfailed") {
            this.toasterService.showErrorMessage(
                this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
        }
    }

    public copyFeaturesButton() {
        this.copyThrottleFeatures = true;
        this.copySelectedThrottleFeatures = [...this.selectedFeatures];
        this.isSearchResultsExpanded = false;
    }

    public removeCopyButton() {
        this.copyThrottleFeatures = false;
        this.copySelectedThrottleFeatures = [];
        this.isSearchResultsExpanded = true;
        this.multiColumnEditSection = false;
        this.multicolumnEditColumnName = '';
        this.multicolumnEditColumnValue = '';
        this.multicolumnEditCheckbox = '';
	this.multiColumnEditSection = false;
        this.flagColumn = false;
        this.textColumns = false;
        this.statusColumn = false;
    }

    // to copy throttle features
    public copyThrottlesFeatures() {
        if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
            this.toasterService.showErrorMessage(
                this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            return;
        }
        this.showLoadingScreen = true;
        let obj: any = [...this.copySelectedThrottleFeatures];
        for (let i = 0; i < obj.length; i++) {
            obj[i].dbEnv = this.wizardHelper.dbEnv;
            obj[i].ruleId = this.rowData.objId;
            if (obj[i].status == 'ACTIVE') {
                obj[i].status = 'A'
            } else if (obj[i].status == 'SUSPEND') {
                obj[i].status = 'S'
            }
	   if (obj[i].featureFlagValue == 'YES') {
                obj[i].featureFlagValue = 'Y'
            } else if (obj[i].featureFlagValue == 'NO') {
                obj[i].featureFlagValue = 'N'
            }
        }
        this.wizardService
            .addThrottleFeature(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (returnData: any) => {
                if (returnData[0] === null || returnData[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_COPY_THROTTLE_FEATURE_ERROR_MESSAGE")
                    );
                    return;
                }
                if (returnData[0] && returnData[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = returnData[0].ERR.split(",");
                    for (
                        let i = commaSeperatedArr.length - 1;
                        i >= 0;
                        i--
                    ) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                this.showLoadingScreen = false;
                this.displayTable = true;
                this.revert();
                let data: any = []
                data.data = []
                this.returnedData.emit({ data: data, status: "selectedData" });
                this.summaryData.emit({ index: 0 });
                this.toasterService.showSuccessMessage(
                    this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_COPY_THROTTLE_FEATURE_SUCCESS_MESSAGE")
                );
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null) {
                    this.toasterService.showErrorMessage(
                        this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                }
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (
                        let i = commaSeperatedArr.length - 1;
                        i >= 0;
                        i--
                    ) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }

    private multiColumnEdit(isChecked) {
        if (isChecked.checked)
            this.multiColumnEditSection = true;
        else {
            this.multiColumnEditSection = false;
            this.multicolumnEditColumnName = '';
            this.multicolumnEditColumnValue = '';
        }
    }

    public assignmultiColumnName(column) {
        this.multicolumnEditColumnName = column;
        if (this.multicolumnEditColumnName == "status") {
            this.statusColumn = true;
            this.textColumns = false;
            this.flagColumn = false;
        } else if (this.multicolumnEditColumnName == "featureFlagValue") {
            this.statusColumn = false;
            this.textColumns = false;
            this.flagColumn = true;
        } else {
            this.statusColumn = false;
            this.textColumns = true;
            this.flagColumn = false;
        }
    }

    public updatemultiColumnEdit() {
        if (this.textColumns) {
            for (let i = 0; i < this.copySelectedThrottleFeatures.length; i++) {
                this.copySelectedThrottleFeatures[i][this.multicolumnEditColumnName] = this.multicolumnEditColumnValue.nativeElement.value;
            }
            this.multicolumnEditColumnValue.nativeElement.value = '';
        } else if (this.statusColumn || this.flagColumn) {
            for (let i = 0; i < this.copySelectedThrottleFeatures.length; i++) {
                this.copySelectedThrottleFeatures[i][this.multicolumnEditColumnName] = this.multicolumnEditColumnValue.value;
            }
            this.multicolumnEditColumnValue.value = '';
        }
        this.copySelectedThrottleFeatures = [...this.copySelectedThrottleFeatures];
        this.multicolumnEditColumnName = '';
        this.multicolumnEditCheckbox.checked = false;
        this.multiColumnEditSection = false;
        this.textColumns = false;
        this.statusColumn = false;
        this.flagColumn = false;
    }

    // to reset the form
    public revert() {
        this.frmGroupThrottle.reset();
        this.throttleFeatureMainData = [];
        this.throttleFeatureData = [];
        this.selectedFeatures = [];
        this.copySelectedThrottleFeatures = [];
        this.isSearchResultsExpanded = false;
        this.copyThrottleFeatures = false;
        let data: any = [];
        data.data = [];
        this.returnedData.emit({ data: data, status: "selectedData" });
	this.multiColumnEditSection = false;
        this.flagColumn = false;
        this.textColumns = false;
        this.statusColumn = false;
    }

}