import { Subject } from "rxjs";
import { Component, ViewEncapsulation, OnInit, ViewChildren, Inject, EventEmitter, Output } from '@angular/core';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { ConfirmationService } from 'primeng/primeng';
import { takeUntil } from 'rxjs/operators';
import { MatSelect, MatDialog } from "@angular/material";
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CarrierMaintenanceService } from '../../../../../../../Services/carrierMaintenance.service';
import { CarrierMaintenanceHelper } from "../../../../carrier-maintenance-helper";
import { ToasterService } from "../../../../../../../Services/toaster.service";
import { EditThrottleWizardHelper } from "../../edit-throttle-helper";
import { EditThrottleService } from "../../edit-throttle-service";
import { EditThrottleFeatureComponent } from "../../edit-throttle-feature/edit-throttle-feature.component";
import { MAT_DIALOG_DATA } from "@angular/material";

@Component({
    selector: 'edit-throttle-feature-summary',
    templateUrl: './edit-throttle-feature-summary-tab.html',
    styleUrls: ['./edit-throttle-feature-summary-tab.scss',
        "../../../../../../components/ngxtable/material.scss",
        "../../../../../../components/ngxtable/datatable.component.scss",
        "../../../../../../components/ngxtable/icons.css",
        "../../../../../../components/ngxtable/app.css"],
})

export class EditThrottleFeatureSummaryTab implements OnInit {
    @Output("returnedData") returnedData: any = new EventEmitter();
    public unsubscribe = new Subject<void>();
    public rowData: any;
    public throttleFeatureData = [];
    public throttleFeatureMainData = [];
    public showLoadingScreen = false;
    public throttleFeatureFields: any;
    public isEditable = {};
    public editedRow = {};
    public defaultEditedRow = {};
    public displayTable = false;
    alreadyEnabled: any = { value: false };
    public alerts: any = [];
    public statusDynamicselect: any = [];
    public oldStatus: any;
    public featureFlagValueDynamicselect: any = [];

    constructor(
        @Inject(MAT_DIALOG_DATA) public data: any,
        private wizardService: CarrierMaintenanceService,
        private toasterService: ToasterService,
        private wizardHelper: CarrierMaintenanceHelper,
        private modalService: NgbModal,
        private confirmationService: ConfirmationService,
        private editThrottleWizardHelper: EditThrottleWizardHelper,
        private editThrottleService: EditThrottleService,
        public dialog: MatDialog,
    ) { }

    ngOnInit() {
        this.alreadyEnabled.value = false;
        this.statusDynamicselect = [
            { id: 'ACTIVE', name: 'ACTIVE' },
            { id: 'SUSPEND', name: 'SUSPEND' },
        ];
        this.featureFlagValueDynamicselect = [
            { id: 'YES', name: 'YES' },
            { id: 'NO', name: 'NO' },
            { id: '', name: 'NONE' },
        ]
        this.alreadyEnabled = Object.assign({}, this.alreadyEnabled);
        this.displayTable = false;
        this.throttleFeatureData = [];
        this.throttleFeatureMainData = [];
        this.showLoadingScreen = false;
        this.rowData = { ...this.data.dataKey };
        this.throttleFeatureFields = {
            parentCols: [
                { header: "Obj Id", field: "objId", editable: false },
                { header: "Feature Flag Name", field: "featureFlagName", editable: true, isOptional: false, length: 40 },
                { header: "Feature Flag Value", field: "featureFlagValue", editable: true, isOptional: true, length: 1, type: "dynamicselect" },
                { header: "Feature Name", field: "featureName", editable: true, isOptional: false, length: 30 },
                { header: "Feature Value", field: "featureValue", editable: true, isOptional: true, length: 30 },
                { header: "Status", field: "status", editable: true, isOptional: false, length: 1, type: "dynamicselect" },
            ],
            parentDataId: "objId",
            defaultColumnSort: "objId",
            showFilterSection: true,
            hideDeleteIcon: true
        };
        this.retrieveThrottleFeatures();
    }

    public retrieveThrottleFeatures() {
        this.showLoadingScreen = true;
        this.throttleFeatureMainData = [];
        this.throttleFeatureData = [];
        let obj: any = {};
        obj.dbEnv = this.wizardHelper.dbEnv;
        obj.ruleId = this.data.dataKey.objId;
        this.wizardService
            .retrieveThrottleFeatures(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_THROTTLE_FEATURE_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (
                        let i = commaSeperatedArr.length - 1;
                        i >= 0;
                        i--
                    ) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                this.showLoadingScreen = false;
                this.displayTable = true;
                this.throttleFeatureMainData = data[0];
                for (let i = 0; i < this.throttleFeatureMainData.length; i++) {
                    this.throttleFeatureMainData[i].statusdynamicselect = this.statusDynamicselect;
                    this.throttleFeatureMainData[i].featureFlagValuedynamicselect = this.featureFlagValueDynamicselect;
                    if (this.throttleFeatureMainData[i].status == 'A') {
                        this.throttleFeatureMainData[i].status = 'ACTIVE'
                    } else if (this.throttleFeatureMainData[i].status == 'S') {
                        this.throttleFeatureMainData[i].status = 'SUSPEND'
                    }
                    if (this.throttleFeatureMainData[i].featureFlagValue == 'Y') {
                        this.throttleFeatureMainData[i].featureFlagValue = 'YES'
                    } else if (this.throttleFeatureMainData[i].featureFlagValue == 'N') {
                        this.throttleFeatureMainData[i].featureFlagValue = 'NO'
                    }
                }
                this.throttleFeatureData = [...this.throttleFeatureMainData];


                if (data[0] && data[0].length == 0) {
                    this.failedAlert(this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_SEARCH_THROTTLE_FEATURE_ERROR_MESSAGE"));
                }
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null) {
                    this.toasterService.showErrorMessage(
                        this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                }
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (
                        let i = commaSeperatedArr.length - 1;
                        i >= 0;
                        i--
                    ) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }

    private failedAlert(errorMsg: string) {
        this.alerts = [];
        this.alerts.push(
            {
                id: 4,
                type: 'danger',
                message: errorMsg
            }
        );
    }

    // delete confirm
    public showConfirm(throttleRuleData) {
        this.confirmationService.confirm({
            key: 'confirm-delete-rule',
            message: this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_DELETE_THROTTLE_FEATURE_CONFIRM_MESSAGE"),
            accept: () => {
                this.editThrottleFeatureData(throttleRuleData)
            }
        });
    }

    public editConfirm(featureData) {
        if (this.oldStatus == 'ACTIVE' && featureData.status == 'SUSPEND') {
            this.showConfirm(featureData);
        } else {
            this.editThrottleFeatureData(featureData)
        }
    }

    public editThrottleFeatureData(featureData) {
        this.showLoadingScreen = true;
        let obj: any = {}
        obj = this.wizardHelper.checkRequestObjectSetToNull(
            { ...featureData }
        );
        obj.dbEnv = this.wizardHelper.dbEnv;
        if (featureData.status == 'ACTIVE') {
            obj.status = 'A'
        } else if (featureData.status == 'SUSPEND') {
            obj.status = 'S'
        }
        if (featureData.featureFlagValue == 'YES') {
            obj.featureFlagValue = 'Y'
        } else if (featureData.featureFlagValue == 'NO') {
            obj.featureFlagValue = 'N'
        }
        delete obj.check;
        delete obj.children;
        delete obj.isEditable;
        this.wizardService
            .updateThrottleFeature(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_THROTTLE_FEATURE_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (
                        let i = commaSeperatedArr.length - 1;
                        i >= 0;
                        i--
                    ) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                this.showLoadingScreen = false;
                this.alreadyEnabled.value = false;
                featureData.isEditable = false;
                this.alreadyEnabled = Object.assign({}, this.alreadyEnabled);
                this.returnedData.emit({ status: "save" });
                this.throttleFeatureData = [...this.throttleFeatureData];
                this.toasterService.showSuccessMessage(
                    this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_THROTTLE_FEATURE_SUCCESS_MESSAGE")
                );
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null) {
                    this.toasterService.showErrorMessage(
                        this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                }
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (
                        let i = commaSeperatedArr.length - 1;
                        i >= 0;
                        i--
                    ) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }

    checkReturnData(returnedData) {
        if (returnedData.status == "save") {
            this.editConfirm(returnedData.data);
        } else if (returnedData.status == "editEnableRow") {
            this.returnedData.emit({ status: "editEnableRow" });
            this.oldStatus = returnedData.oldData.status;
        } else if (returnedData.status == "onRowEditCancel") {
            this.returnedData.emit({ status: "onRowEditCancel" });
        } else if (returnedData.status == "alreadyEditEnabled") {
            this.toasterService.showErrorMessage(
                this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE")
            );
        } else if (returnedData.status == "validationfailed") {
            this.toasterService.showErrorMessage(
                this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            );
        } 
    }

}


