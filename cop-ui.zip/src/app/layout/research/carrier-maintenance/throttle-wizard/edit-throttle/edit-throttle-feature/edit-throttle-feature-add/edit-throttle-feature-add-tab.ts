import { Subject } from "rxjs";
import { Component, ViewEncapsulation, OnInit, ViewChildren, ViewChild, Output, EventEmitter, Inject } from '@angular/core';
import { ConfirmationService } from 'primeng/primeng';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { takeUntil } from 'rxjs/operators';
import { CarrierMaintenanceService } from '../../../../../../../Services/carrierMaintenance.service';
import { CarrierMaintenanceHelper } from "../../../../carrier-maintenance-helper";
import { ToasterService } from "../../../../../../../Services/toaster.service";
import { EditThrottleWizardHelper } from "../../edit-throttle-helper";
import { EditThrottleService } from "../../edit-throttle-service";
import { MAT_DIALOG_DATA } from "@angular/material";

@Component({
    selector: 'edit-throttle-feature-add',
    templateUrl: './edit-throttle-feature-add-tab.html',
    styleUrls: ['./edit-throttle-feature-add-tab.scss',
        "../../../../../../components/ngxtable/material.scss",
        "../../../../../../components/ngxtable/datatable.component.scss",
        "../../../../../../components/ngxtable/icons.css",
        "../../../../../../components/ngxtable/app.css"],
})

export class EditThrottleFeatureAddTab implements OnInit {
    private unsubscribe = new Subject<void>();
    public showLoadingScreen: boolean;
    public frmGroupThrottle: FormGroup;
    private checkedAnother = false;
    public tableRows: any = [];
    @Output("summaryData") summaryData: any = new EventEmitter();

    constructor(
        @Inject(MAT_DIALOG_DATA) public data: any,
        private _formBuilder: FormBuilder,
        private wizardService: CarrierMaintenanceService,
        private toasterService: ToasterService,
        private wizardHelper: CarrierMaintenanceHelper,
        private confirmationService: ConfirmationService,
        private editThrottleWizardHelper: EditThrottleWizardHelper,
        private editThrottleService: EditThrottleService,
    ) {
        this.frmGroupThrottle = new FormGroup({});
    }

    ngOnInit() {
        this.createSearchForm();
    }

    //to create search form
    public createSearchForm() {
        this.frmGroupThrottle = this._formBuilder.group({
            featureFlagName: ['', [Validators.required, Validators.maxLength(40)]],
            featureFlagValue: ['', [Validators.maxLength(1)]],
            featureName: ['', [Validators.required, Validators.maxLength(30)]],
            featureValue: ['', [Validators.maxLength(30)]],
            status: ['', [Validators.required, Validators.maxLength(1)]],
        });
    }

    onChangeCheckbox(event) {
        if (event.checked) this.checkedAnother = true;
        else this.checkedAnother = false;
    }

    //show summary confirm
    public showSummaryConfirm(f, index) {
        this.confirmationService.confirm({
            key: 'confirm-add-show-summary',
            message: this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_DONE_CREATING_THROTTLE_FEATURE_CONFIRM_MESSAGE"),
            accept: () => {
                this.checkedAnother = false;
                this.summaryData.emit({ index: 0 });
            }
        });
    }

    //to add throttle feature
    public addThrottleFeature() {
        this.showLoadingScreen = true;
        let obj = this.frmGroupThrottle.value;
        obj = this.wizardHelper.checkRequestObject(obj);
        obj.ruleId = this.data.dataKey.objId;
        obj.dbEnv = this.wizardHelper.dbEnv;
        this.wizardService.addThrottleFeature([obj]).pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_ADD_THROTTLE_FEATURE_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                const d = data[0].message;
                if(d==""){
                    this.toasterService.showErrorMessage(
                    this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_DUPLICATE_THROTTLE_FEATURE_ERROR_MESSAGE")
                );
                } else {
                this.tableRows.push(obj);
                if (this.checkedAnother) {
                } else {
                    this.summaryData.emit({ index: 0 });
                }
                this.frmGroupThrottle.reset();
                this.toasterService.showSuccessMessage(
                    this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_ADD_THROTTLE_FEATURE_SUCCESS_MESSAGE")
                );
                }
                this.showLoadingScreen = false;
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.editThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }

}


