import { Injectable } from "@angular/core";
import { Subject } from "rxjs";

@Injectable({
    providedIn: "root"
})
export class AddThrottleWizardHelper {
    
    public breadcrumbListUpdate = new Subject<number>();
    public breadcrumbList = [];
    constructor() { }

    public editThrottleConstantObject = {
        "TRACFONE_DEFAULT_ERROR_MESSAGE": "Unable to process request",
		"TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE" : "Please complete previous operation",
		"TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE": "Please fix validation errors",

        // throttle policy
        "TRACFONE_RETRIEVE_THROTTLE_POLICY_ERROR_MESSAGE": "Unable to retrieve Throttle Policy",        
        "TRACFONE_SEARCH_THROTTLE_POLICY_ERROR_MESSAGE": "No Throttle Policy Found",
        "TRACFONE_UPDATE_THROTTLE_POLICY_ERROR_MESSAGE": "Unable to update Throttle Policy",
        "TRACFONE_UPDATE_THROTTLE_POLICY_SUCCESS_MESSAGE": "Throttle Policy has been updated successfully",
        "TRACFONE_ADD_THROTTLE_POLICY_ERROR_MESSAGE" : "Unable to add Throttle Policy",
        "TRACFONE_ADD_THROTTLE_POLICY_SUCCESS_MESSAGE": "Throttle Policy has been added successfully",
        "TRACFONE_COPY_THROTTLE_POLICY_ERROR_MESSAGE" : "Unable to copy Throttle Policy",
        "TRACFONE_COPY_THROTTLE_POLICY_SUCCESS_MESSAGE": "Throttle Policy has been copied successfully",
        "TRACFONE_DUPLICATE_THROTTLE_POLICY_ERROR_MESSAGE": "Duplicate Throttle Policy Found",
        
        // throttle rule
        "TRACFONE_RETRIEVE_THROTTLE_RULE_ERROR_MESSAGE": "Unable to retrieve Throttle Rule",        
        "TRACFONE_SEARCH_THROTTLE_RULE_ERROR_MESSAGE": "No Throttle Rule Found",
        "TRACFONE_UPDATE_THROTTLE_RULE_ERROR_MESSAGE": "Unable to update Throttle Rule",
        "TRACFONE_UPDATE_THROTTLE_RULE_SUCCESS_MESSAGE": "Throttle Rule has been updated successfully",
        "TRACFONE_DELETE_THROTTLE_RULE_ERROR_MESSAGE": "Unable to delete Throttle Rule",
        "TRACFONE_DELETE_THROTTLE_RULE_SUCCESS_MESSAGE": "Throttle Rule has been deleted successfully",
        "TRACFONE_DELETE_THROTTLE_RULE_CONFIRM_MESSAGE": "Are you sure you want to suspend Throttle Rule ?",
        "TRACFONE_DONE_CREATING_THROTTLE_RULE_CONFIRM_MESSAGE": "Are you done creating Throttle Rule ?", 
        "TRACFONE_ADD_THROTTLE_RULE_ERROR_MESSAGE" : "Unable to add Throttle Rule",
        "TRACFONE_ADD_THROTTLE_RULE_SUCCESS_MESSAGE": "Throttle Rule has been added successfully",
        "TRACFONE_RETRIEVE_PARENT_ID_ERROR_MESSAGE": "Unable to retrieve Parent Id",
        "TRACFONE_COPY_THROTTLE_RULE_ERROR_MESSAGE" : "Unable to copy Throttle Rules",
        "TRACFONE_COPY_THROTTLE_RULE_SUCCESS_MESSAGE": "Throttle Rules have been copied successfully",
        "TRACFONE_DUPLICATE_THROTTLE_RULE_ERROR_MESSAGE": "Duplicate Throttle Rule Found",
        
        // throttle feature
		"TRACFONE_CANCEL_THROTTLE_FEATURE_CONFIRM_MESSAGE" : "Are you done creating Throttle Features ?", 
        "TRACFONE_DONE_CREATING_THROTTLE_FEATURE_CONFIRM_MESSAGE": "Are you done creating Throttle Feature ?", 
        "TRACFONE_ADD_THROTTLE_FEATURE_ERROR_MESSAGE" : "Unable to add Throttle Feature",
        "TRACFONE_ADD_THROTTLE_FEATURE_SUCCESS_MESSAGE": "Throttle Feature has been added successfully",
        "TRACFONE_RETRIEVE_THROTTLE_FEATURE_ERROR_MESSAGE": "Unable to retrieve Throttle Feature",        
        "TRACFONE_SEARCH_THROTTLE_FEATURE_ERROR_MESSAGE": "No Throttle Features Found",
        "TRACFONE_UPDATE_THROTTLE_FEATURE_ERROR_MESSAGE": "Unable to update Throttle Feature",
        "TRACFONE_UPDATE_THROTTLE_FEATURE_SUCCESS_MESSAGE": "Throttle Feature has been updated successfully",
        "TRACFONE_DELETE_THROTTLE_FEATURE_ERROR_MESSAGE": "Unable to delete Throttle Feature",
        "TRACFONE_DELETE_THROTTLE_FEATURE_SUCCESS_MESSAGE": "Throttle Feature has been deleted successfully",
        "TRACFONE_DELETE_THROTTLE_FEATURE_CONFIRM_MESSAGE": "Are you sure you want to suspend Throttle Feature ?",
        "TRACFONE_COPY_THROTTLE_FEATURE_ERROR_MESSAGE" : "Unable to copy Throttle Features",
        "TRACFONE_COPY_THROTTLE_FEATURE_SUCCESS_MESSAGE": "Throttle Features have been copied successfully",
        "TRACFONE_DUPLICATE_THROTTLE_FEATURE_ERROR_MESSAGE": "Duplicate Throttle Feature Found",
       
    }

    public getTracfoneConstantMethod(msg) {
        return this.editThrottleConstantObject[msg];
    }

}