import { Subject, Observable } from "rxjs";
import { Component, ViewEncapsulation, OnInit, ViewChildren, ViewChild, Output, EventEmitter } from '@angular/core';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { ConfirmationService } from 'primeng/primeng';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { takeUntil, startWith, map } from 'rxjs/operators';
import { MatSelect } from "@angular/material";
import { CarrierMaintenanceService } from '../../../../../../../Services/carrierMaintenance.service';
import { CarrierMaintenanceHelper } from "../../../../carrier-maintenance-helper";
import { ToasterService } from "../../../../../../../Services/toaster.service";
import { AddThrottleWizardHelper } from "../../add-throttle-helper";
import { AddThrottleService } from "../../add-throttle-service";

@Component({
    selector: 'add-throttle-rule-add',
    templateUrl: './add-throttle-rule-add-tab.html',
    styleUrls: ['./add-throttle-rule-add-tab.scss',
        "../../../../../../components/ngxtable/material.scss",
        "../../../../../../components/ngxtable/datatable.component.scss",
        "../../../../../../components/ngxtable/icons.css",
        "../../../../../../components/ngxtable/app.css"],
})
export class AddThrottleRuleAddTab implements OnInit {
private unsubscribe = new Subject<void>();
    public showLoadingScreen: boolean;
    public frmGroupThrottle: FormGroup;
    public parentIdData: any = [];
    public parentIdMainData: any = [];
    public tableRows: any = [];
    public alerts: Array<any> = [];
    filteredParentIdOptions: Observable<any[]>;

    constructor(
        private _formBuilder: FormBuilder,
        private wizardService: CarrierMaintenanceService,
        private toasterService: ToasterService,
        private wizardHelper: CarrierMaintenanceHelper,
        private confirmationService: ConfirmationService,
        private addThrottleWizardHelper: AddThrottleWizardHelper,
        private addThrottleService: AddThrottleService,
    ) {
        this.frmGroupThrottle = new FormGroup({});
    }

    ngOnInit() { 
        this.alerts = [];
        this.parentIdData = [];
        this.parentIdMainData = [];
        this.createSearchForm();
        let serviceData:any = [];
        if (this.addThrottleService.getParentId() && this.addThrottleService.getParentId().length > 0) {
            this.addThrottleService.getParentId().forEach(e1 => {
            serviceData.push(e1)
            });
                this.parentIdData = [];
                this.parentIdMainData = [];
                this.parentIdMainData = serviceData;
                this.filteredParentIdOptions = this.frmGroupThrottle.controls.parentIdSearch.valueChanges
                        .pipe(
                            startWith<string>(''),
                            map((name: any) => this._filter(name, 'parentIdInput'))
                );
            } else {
        this.retrieveParentId();
        }
    }

    //to create search form
    public createSearchForm() {
        this.frmGroupThrottle = this._formBuilder.group({
            parentId: ['', [Validators.required]],
            ruleDesc: ['', [Validators.required, Validators.maxLength(40)]],
            status: ['', [Validators.required, Validators.maxLength(1)]],
            parentIdSearch: [''],            
        });
    }

    // to retrieve parent ids
    private retrieveParentId() {
        this.showLoadingScreen = true;
        var obj: any = {}
        this.wizardService
            .getParentName(this.wizardHelper.dbEnv, '')
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.toasterService.showErrorMessage(
                        this.addThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_PARENT_ID_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (
                        let i = commaSeperatedArr.length - 1;
                        i >= 0;
                        i--
                    ) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                this.showLoadingScreen = false;
                let parentData = data[0];
                this.addThrottleService.setParentId(parentData);
                this.parentIdData = [];
                this.parentIdMainData = [];
                this.parentIdMainData = data[0];
                this.filteredParentIdOptions = this.frmGroupThrottle.controls.parentIdSearch.valueChanges
                        .pipe(
                            startWith<string>(''),
                            map((name: any) => this._filter(name, 'parentIdInput'))
                );
                if (data[0].length == 0){
                    this.frmGroupThrottle.controls.parentId.patchValue("");
                }
               
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.addThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }

    //to add throttle rule
    public addThrottleRule() {
        this.showLoadingScreen = true;
        this.alerts = [];
        let obj = this.frmGroupThrottle.value;
        obj = this.wizardHelper.checkRequestObject(obj);
        let policyData: any = this.addThrottleService.getStep1Data();
        obj.policyId = policyData[0].objId;
        if(this.frmGroupThrottle.value.parentId){
            obj.parentId = this.frmGroupThrottle.value.parentId.toString();
        }
        obj.dbEnv = this.wizardHelper.dbEnv;
        this.wizardService.addThrottleRule([obj]).pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.addThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_ADD_THROTTLE_RULE_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                const d = data[0].message;
                if(d=="[]"){
                    this.toasterService.showErrorMessage(
                    this.addThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_DUPLICATE_THROTTLE_RULE_ERROR_MESSAGE")
                );
                }else{
                this.revert();
                this.addThrottleService.isSummaryTableActive(true);
                this.successAlert("Throttle Rule has been added successfully. Please go to summary tab to add Throttle Features")
                this.addThrottleService.isBackButtonActive(false);
                }
                this.showLoadingScreen = false;
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.addThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }

    public closeAlert(alert: any) {
	    const index: number = this.alerts.indexOf(alert);
	    this.alerts.splice(index, 1);
	}
	
	private successAlert(successMsg:string){
		this.alerts = [];
		this.alerts.push(
            {
                id: 1,
                type: 'success',
                message: successMsg
            }
        );
	}

     // selection change to clear selected values
    selectionMultipleChange(event, choice) {
        if (event.isUserInput && event.source.selected == false) {
            if (choice == "parentIdInput") {
                let index = this.parentIdData.indexOf(event.source.value);
                if(index > -1)
                this.parentIdData.splice(index, 1)
            }
        }
    }

    // resetting text field to show all dropdown values
    openedMultiChange(e, data) {
         this.frmGroupThrottle.controls.parentIdSearch.patchValue('');  
    }

     checkReturnData(returnedData) {
        if (returnedData.status == "selected") {
            this.parentIdData = [...returnedData.data];
        }
    }

    // filter for multiple dropdown search
    private _filter(arg: string, choice) {
        let name = arg;
        if (name)
            name = name.toLowerCase();
        const filterValue = name;
        // Set selected values to retain the selected checkbox 
        this.setSelectedValues(choice);
        let filteredList;

         if (choice == "parentIdInput") {
            this.frmGroupThrottle.controls.parentId.patchValue(this.parentIdData);
            filteredList = this.parentIdMainData.filter((option: any) =>
                option.objId.toLowerCase().indexOf(filterValue) > -1 ||
                option.xParentName.toLowerCase().indexOf(filterValue) > -1
            );
        }
        return filteredList;
    }

    // setting selected values
    setSelectedValues(choice) {
        if (choice == "parentIdInput") {
            if (this.frmGroupThrottle.controls.parentId.value && this.frmGroupThrottle.controls.parentId.value.length > 0) {
                this.frmGroupThrottle.controls.parentId.value.forEach((e) => {
                    if (this.parentIdData.indexOf(e) == -1) {
                        this.parentIdData.push(e);
                    }
                });
            }
        }
    }

    //to reset form
    public revert() {
        let keys = Object.keys(this.frmGroupThrottle.controls)
        keys.forEach(e1 =>{
            if(e1 != "parentIdSearch"){
                this.frmGroupThrottle.controls[`${e1}`].reset();
            }
        })
        this.parentIdData = [];
    }

}


