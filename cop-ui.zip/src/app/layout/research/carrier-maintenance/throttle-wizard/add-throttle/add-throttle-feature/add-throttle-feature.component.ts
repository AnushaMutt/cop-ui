import { ViewEncapsulation, Component, OnInit, Inject, ViewChild } from "@angular/core";
import { Subject } from "rxjs";
import { MatDialogRef, MatTabChangeEvent, MatTabGroup, MatTab, MatTabHeader } from "@angular/material";
import { MAT_DIALOG_DATA } from '@angular/material';
import { ConfirmationService } from "primeng/api";
import { AddThrottleWizardHelper } from "../add-throttle-helper";
import { AddThrottleService } from "../add-throttle-service"; 

@Component({
    selector: 'add-throttle-feature',
    templateUrl: './add-throttle-feature.component.html',
    styleUrls: ['./add-throttle-feature.component.scss']
})
export class AddThrottleFeatureComponent implements OnInit {
    @ViewChild('tabs') tabs: MatTabGroup;
    public showLoadingScreen = false;
    index = 0;
    featureSummaryActive: boolean = false;

    constructor(
        public dialogRef: MatDialogRef<AddThrottleFeatureComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any,
        private confirmationService: ConfirmationService,
        private addThrottleWizardHelper: AddThrottleWizardHelper,
        private addThrottleService: AddThrottleService
    )
    { dialogRef.disableClose = true; }

    ngOnInit() {
        this.addThrottleService.featureSummaryActive.subscribe(
            isActivated => {
                this.featureSummaryActive = isActivated;
            }
        );
    }

    summaryData(data) {
        this.index = data.index;
    }

    public onTabClick(event: MatTabChangeEvent) {
        if (event.index == 0) {
            this.index = 0;
        } else if (event.index == 1) {
            this.index = 1;
        } else if (event.index == 2) {
            this.index = 2;
        }
    }

    closeFeatureDialog(): void {
        this.dialogRef.close();
    }

    showCloseConfirm() {
        this.confirmationService.confirm({
            key: 'confirm-close',
            message: this.addThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_CANCEL_THROTTLE_FEATURE_CONFIRM_MESSAGE"),
            accept: () => {
                this.closeFeatureDialog()
            }
        });
    }
}



