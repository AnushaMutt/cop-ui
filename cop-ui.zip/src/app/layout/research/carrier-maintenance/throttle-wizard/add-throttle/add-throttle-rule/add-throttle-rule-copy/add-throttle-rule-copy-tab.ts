import { Subject } from "rxjs";
import { Component, ViewEncapsulation, OnInit, ViewChildren, ViewChild, EventEmitter, Output, Inject } from '@angular/core';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { ConfirmationService } from 'primeng/primeng';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { takeUntil } from 'rxjs/operators';
import { MatSelect } from "@angular/material";
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CarrierMaintenanceService } from '../../../../../../../Services/carrierMaintenance.service';
import { CarrierMaintenanceHelper } from "../../../../carrier-maintenance-helper";
import { ToasterService } from "../../../../../../../Services/toaster.service";
import { AddThrottleWizardHelper } from "../../add-throttle-helper";
import { AddThrottleService } from "../../add-throttle-service";

@Component({
    selector: 'throttle-rule-copy',
    templateUrl: './add-throttle-rule-copy-tab.html',
    styleUrls: ['./add-throttle-rule-copy-tab.scss',
        "../../../../../../components/ngxtable/material.scss",
        "../../../../../../components/ngxtable/datatable.component.scss",
        "../../../../../../components/ngxtable/icons.css",
        "../../../../../../components/ngxtable/app.css"],
})
export class AddThrottleRuleCopyTab implements OnInit {
@ViewChildren(DatatableComponent)
    table: any;
    @ViewChildren(MatSelect) matSelect: any;
    private unsubscribe = new Subject<void>();
    public showLoadingScreen: boolean;
    public frmGroupThrottle: FormGroup;
    public throttleRuleFields: any = [];
    public throttleRuleData: any = [];
    public throttleRuleMainData: any = [];
    public selected: any = [];
    public selectedProfileFeatures: any = [];
    public copyAllFeaturestoProfileBoolean = false;
    public copyselectedProfileFeaturesRows: any = [];
    public isSearchResultsExpanded = false;
    public multiColumnEditSection = false;
    public multicolumnEditColumnName = '';
    @ViewChild('multicolumnEditColumnValue') multicolumnEditColumnValue: any;
    @ViewChild('multicolumnEditCheckbox') private multicolumnEditCheckbox: any;
    public flagColumn = false;
    public textColumns = false;
    public parentColumn = false;
    public parentIdData: any = [];
    public parentIdMainData: any = [];
    public alerts: Array<any> = [];

    constructor(
        private _formBuilder: FormBuilder,
        private wizardService: CarrierMaintenanceService,
        private toasterService: ToasterService,
        private wizardHelper: CarrierMaintenanceHelper,
        private modalService: NgbModal,
        private confirmationService: ConfirmationService,
        private addThrottleWizardHelper: AddThrottleWizardHelper,
        private addThrottleService: AddThrottleService,
    ) {
        this.frmGroupThrottle = new FormGroup({});
    }

    ngOnInit() {
        this.alerts = [];
        this.throttleRuleMainData = [];
        this.throttleRuleData = [];
        this.throttleRuleFields = [
            { name: "Parent Id", prop: "parentId", width: '370' },
            { name: "Rule Description", prop: "ruleDesc", width: '300' },
            { name: "Status", prop: "status", width: '150' },
        ];
        this.copyAllFeaturestoProfileBoolean = false;
        this.copyselectedProfileFeaturesRows = [];
        this.isSearchResultsExpanded = false;
        this.multiColumnEditSection = false;
        this.multicolumnEditColumnName = '';
        this.multicolumnEditColumnValue = '';
        this.multicolumnEditCheckbox = '';
        this.parentIdData = [];
        this.parentIdMainData = [];
        this.createSearchForm();
        if (this.addThrottleService.getParentId() && this.addThrottleService.getParentId().length > 0) {
            this.addThrottleService.getParentId().forEach(e1 => {
            this.parentIdMainData.push(e1)
            });
            this.parentIdData = [...this.parentIdMainData];     
            } else {
        this.retrieveParentId();
        }
    }

    //to create search form
    public createSearchForm() {
        this.frmGroupThrottle = this._formBuilder.group({
            policyId: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            parentId: [''],
            policyName: ['',Validators.maxLength(20)]
        });
    }

    // to retrieve parent ids
    private retrieveParentId() {
        this.showLoadingScreen = true;
        var obj: any = {}
        this.wizardService
            .getParentName(this.wizardHelper.dbEnv, '')
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.toasterService.showErrorMessage(
                        this.addThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_PARENT_ID_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (
                        let i = commaSeperatedArr.length - 1;
                        i >= 0;
                        i--
                    ) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                this.showLoadingScreen = false;
                this.parentIdMainData = data[0];
                this.parentIdData = [...this.parentIdMainData];
                this.addThrottleService.setParentId(this.parentIdData);
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.addThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }

    public openedChange(rowData) {
        if (rowData == "searchParentInput")
            this.parentIdData = [...this.parentIdMainData];
    }

    public onKey(value, rowData) {
        if (rowData == "searchParentInput") {
            this.parentIdData = [...this.parentIdMainData];
            this.parentIdData = this.search(value, this.parentIdData);
        } 
    }

    search(value: string, searchArray: any) {
        let filter = value.toLowerCase();
        return searchArray.filter(
            option =>
                (option.xParentName &&
                    option.xParentName.toLowerCase().indexOf(filter) > -1) ||
                (option.objId &&
                    option.objId.indexOf(filter) > -1) ||
                (typeof option == "string"
                    ? option.toLowerCase().indexOf(filter) > -1
                    : !filter)
        );
    }

    //to retrieve throttle rules
    public onSearchForm() {
        this.showLoadingScreen = true;
        this.throttleRuleData = [];
        this.throttleRuleMainData = [];
        this.alerts = [];
        let obj: any = {};
        obj = this.frmGroupThrottle.value;
        obj = this.wizardHelper.checkRequestObject(
            obj
        );
        obj.dbEnv = this.wizardHelper.dbEnv;
        if(obj.parentId) {
        obj.parentId = obj.parentId.split("-")[0];
        }
        this.wizardService.retrieveThrottleRules(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.addThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_THROTTLE_RULE_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (
                        let i = commaSeperatedArr.length - 1;
                        i >= 0;
                        i--
                    ) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                this.showLoadingScreen = false;
                this.selectedProfileFeatures = [];
                this.selected = [];
                this.copyselectedProfileFeaturesRows = [];
                this.copyAllFeaturestoProfileBoolean = false;
                this.isSearchResultsExpanded = true;
                this.multiColumnEditSection = false;
                this.flagColumn = false;
                this.textColumns = false;
                this.parentColumn = false;

                this.throttleRuleData = data[0];
                for(let i=0; i<this.throttleRuleData.length; i++){
                    let parentName = this.parentIdData.filter(e => {
                        return e.objId == this.throttleRuleData[i].parentId;
                    });
                    if(parentName && parentName[0] && parentName[0].xParentName)
                        this.throttleRuleData[i].parentId = this.throttleRuleData[i].parentId + " - " + parentName[0].xParentName;
                    else
                        this.throttleRuleData[i].parentId = this.throttleRuleData[i].parentId;
                    if(this.throttleRuleData[i].status == 'A'){
                        this.throttleRuleData[i].status =  'ACTIVE'
                    } else if(this.throttleRuleData[i].status == 'S'){
                        this.throttleRuleData[i].status =  'SUSPEND'
                    }
                     }
                this.throttleRuleMainData = [...this.throttleRuleData];

                if (data[0] && data[0].length == 0)
                    this.toasterService.showErrorMessage(
                        this.addThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_SEARCH_THROTTLE_RULE_ERROR_MESSAGE")
                    );
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.addThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != " ")
                            this.toasterService.showMultiple(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }

    private onSelect(row) {
        this.selectedProfileFeatures = [];
        if (row && row.selected) {
            for (let i = 0; i < row.selected.length; i++) {
                let obj = { ...row.selected[i] };
                this.selectedProfileFeatures.push(obj);
            }
        }
        if (this.selectedProfileFeatures.length == 0)
            this.copyAllFeaturestoProfileBoolean = false;
    }

    private removeCopyAllFeaturestoProfile() {
        this.copyAllFeaturestoProfileBoolean = false;
        this.copyselectedProfileFeaturesRows = [];
        this.isSearchResultsExpanded = true;
        this.selected = [];
        this.selectedProfileFeatures = [];
        this.multiColumnEditSection = false;
        this.flagColumn = false;
        this.textColumns = false;
        this.parentColumn = false;
    }

    public copyAllFeaturestoProfile() {
        this.copyAllFeaturestoProfileBoolean = true;
        this.copyselectedProfileFeaturesRows = [...this.selectedProfileFeatures];
        this.isSearchResultsExpanded = false;
    }

    //to filter table
    public updateThrottleRule(event) {
        const val = event.target.value.toLowerCase();

        const temp = this.throttleRuleMainData.filter(function (d) {
            return (d.objId ? d.objId.indexOf(val) !== -1 : !val) || !val
                || (d.parentId ? d.parentId.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.ruleDesc ? d.ruleDesc.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.status ? d.status.toLowerCase().indexOf(val) !== -1 : !val) || !val;
        });
        // update the rows
        this.throttleRuleData = temp;
        this.throttleRuleData.offset = 0;
    }

    private multiColumnEdit(isChecked) {
        if (isChecked.checked)
            this.multiColumnEditSection = true;
        else {
            this.multiColumnEditSection = false;
            this.multicolumnEditColumnName = '';
            this.multicolumnEditColumnValue = '';
        }
    }

    public assignmultiColumnName(column) {
        this.multicolumnEditColumnName = column;
       if (this.multicolumnEditColumnName == "status") {
            this.flagColumn = true;
            this.textColumns = false;
            this.parentColumn = false;
        }else if (this.multicolumnEditColumnName == "parentId") {
            this.flagColumn = false;
            this.textColumns = false;
            this.parentColumn = true;            
        } else {
            this.textColumns = true;
            this.flagColumn = false;
            this.parentColumn = false;            
        }
    }

    public updatemultiColumnEdit() {
        if (this.textColumns) {
            for (let i = 0; i < this.copyselectedProfileFeaturesRows.length; i++) {
                this.copyselectedProfileFeaturesRows[i][this.multicolumnEditColumnName] = this.multicolumnEditColumnValue.nativeElement.value;
            }
            this.multicolumnEditColumnValue.nativeElement.value = '';
        } else if (this.flagColumn  || this.parentColumn) {
            for (let i = 0; i < this.copyselectedProfileFeaturesRows.length; i++) {
                this.copyselectedProfileFeaturesRows[i][this.multicolumnEditColumnName] = this.multicolumnEditColumnValue.value;
            }
            this.multicolumnEditColumnValue.value = '';
        }
        this.copyselectedProfileFeaturesRows = [...this.copyselectedProfileFeaturesRows];
        this.multicolumnEditColumnName = '';
        this.multicolumnEditCheckbox.checked = false;
        this.multiColumnEditSection = false;
        this.textColumns = false;
        this.flagColumn = false;
        this.parentColumn = false;
    }
   
    private editValueChanged(event, column, row, oldValue) {
        for (let i = 0; i < this.copyselectedProfileFeaturesRows.length; i++) {
            if (this.copyselectedProfileFeaturesRows[i].objId == row.objId) {

                if (column != "status" && column != "parentId") {
                    this.copyselectedProfileFeaturesRows[i][column] = event.target.value;
                }
                else {
                    this.copyselectedProfileFeaturesRows[i][column] = event.value
                }
            }
        }
    }

    private deleteRow(rowData, rowIndex) {
        this.copyselectedProfileFeaturesRows.splice(rowIndex, 1);
        this.copyselectedProfileFeaturesRows = [...this.copyselectedProfileFeaturesRows];
    }

    public revert() {
        this.frmGroupThrottle.reset();
        this.throttleRuleData = [];
        this.throttleRuleMainData = [];
        this.selectedProfileFeatures = [];
        this.selected = [];
        this.copyselectedProfileFeaturesRows = [];
        this.copyAllFeaturestoProfileBoolean = false;
        this.multiColumnEditSection = false;
        this.flagColumn = false;
        this.textColumns = false;
        this.parentColumn = false;
    }

    // to copy throttle rules
    private copyThrottleRules() {
        if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
            this.toasterService.showErrorMessage(
                this.addThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            return;
        }
        this.showLoadingScreen = true;
        let obj: any;
        let policyData: any = this.addThrottleService.getStep1Data();
        obj = [...this.copyselectedProfileFeaturesRows];
        for (let i = 0; i < obj.length; i++) {
            obj[i].parentId = obj[i].parentId.split(" - ")[0];
            obj[i].dbEnv = this.wizardHelper.dbEnv;
            obj[i].policyId = policyData[0].objId;
            if(obj[i].status == 'ACTIVE'){
                obj[i].status =  'A'
            } else if(obj[i].status == 'SUSPEND'){
                obj[i].status =  'S'
        }
        }
        this.wizardService.addThrottleRule(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.addThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_COPY_THROTTLE_RULE_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                this.showLoadingScreen = false;
                this.revert();
                this.addThrottleService.isSummaryTableActive(true);
                this.successAlert("Throttle Rules have been copied successfully. Please go to summary tab to add Throttle Features")
                this.addThrottleService.isBackButtonActive(false);
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.addThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }

    public closeAlert(alert: any) {
	    const index: number = this.alerts.indexOf(alert);
	    this.alerts.splice(index, 1);
	}
	
	private successAlert(successMsg:string){
		this.alerts = [];
		this.alerts.push(
            {
                id: 1,
                type: 'success',
                message: successMsg
            }
        );
	}

}