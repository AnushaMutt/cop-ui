import { Subject } from "rxjs";
import { Component, ViewEncapsulation, OnInit, ViewChildren } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { ConfirmationService } from 'primeng/primeng';
import { takeUntil } from 'rxjs/operators';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CarrierMaintenanceService } from '../../../../../../Services/carrierMaintenance.service';
import { CarrierMaintenanceHelper } from "../../../carrier-maintenance-helper";
import { ToasterService } from "../../../../../../Services/toaster.service";
import { AddThrottleWizardHelper } from "../add-throttle-helper";
import { AddThrottleService } from "../add-throttle-service";
import { MatSelect } from "@angular/material";

@Component({
    selector: 'add-throttle-policy',
    templateUrl: './add-throttle-policy.component.html',
    styleUrls: ['./add-throttle-policy.component.scss',
        "./../../../../../components/ngxtable/material.scss",
        "./../../../../../components/ngxtable/datatable.component.scss",
        "./../../../../../components/ngxtable/icons.css",
        "./../../../../../components/ngxtable/app.css"],
})
export class AddThrottlePolicyComponent implements OnInit {
    private unsubscribe = new Subject<void>();
    public showLoadingScreen: boolean;
    public frmAddPolicy: FormGroup;
    public frmGroupThrottle: FormGroup;

    private checkedAnother = false;
    public tableRows: any = [];

    public throttlePolicyFields: any = [];
    public throttlePolicyData: any = [];
    public throttlePolicyMainData: any = [];
    public isEditable: any = {}
    public editedRow: any = {};
    public defaultEditedRow: any = {};
    public selected = [];
    public selectedPolicy: any = [];

    @ViewChildren(MatSelect) matSelect: any;
    public showAdd = false;
    public showCopy = true;
    label = "Click here to add a new Throttle Policy";
    public isSearchResultsExpanded = false;
    public copyPolicyBoolean = false;
    public copySelectedRow = [];
    public copyColumns = [];
    public summaryTableData = [];
    public summaryTableMainData = [];
    public displayTable = false;

    constructor(
        private _formBuilder: FormBuilder,
        private wizardService: CarrierMaintenanceService,
        private toasterService: ToasterService,
        private wizardHelper: CarrierMaintenanceHelper,
        private confirmationService: ConfirmationService,
        private addThrottleWizardHelper: AddThrottleWizardHelper,
        private addThrottleService: AddThrottleService,
    ) {
        this.frmAddPolicy = new FormGroup({});
        this.frmGroupThrottle = new FormGroup({});
    }

    ngOnInit() {
        this.showAdd = false;
        this.showCopy = true;
        this.displayTable = false;
        this.label = "Click here to add a new Throttle Policy";
        this.isSearchResultsExpanded = false;
        this.throttlePolicyMainData = [];
        this.throttlePolicyData = [];
        this.throttlePolicyFields = [
            {
                prop: 'selected',
                name: '',
                sortable: false,
                canAutoResize: false,
                draggable: false,
                resizable: false,
                headerCheckboxable: false,
                checkboxable: true,
                width: 30
            },
            { name: "Policy Name", prop: "policyName", width: '150' },
            { name: "Policy Description", prop: "policyDesc", width: '250' },
            { name: "Bypass Trans Queue", prop: "bypassTransQueue", width: '130' },
            { name: "Data Suspended Flag", prop: "dataSuspendedFlag", width: '130' },
        ];
        this.copyColumns = [
            { name: "Policy Name", prop: "policyName", width: '150' },
            { name: "Policy Description", prop: "policyDesc", width: '250' },
            { name: "Bypass Trans Queue", prop: "bypassTransQueue", width: '140' },
            { name: "Data Suspended Flag", prop: "dataSuspendedFlag", width: '140' },
        ];
        this.createAddForm();
        this.createSearchForm();
    }

    //to create search form
    public createAddForm() {
        this.frmAddPolicy = this._formBuilder.group({
            policyName: ['', [Validators.required, Validators.maxLength(20)]],
            policyDesc: ['', [Validators.required, Validators.maxLength(40)]],
            bypassTransQueue: ['', [Validators.maxLength(30)]],
            dataSuspendedFlag: ['', [Validators.maxLength(1)]]
        });
    }

    //to create search form
    public createSearchForm() {
        this.frmGroupThrottle = this._formBuilder.group({
            objId: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            policyName: ['', [Validators.maxLength(20)]],
            policyDesc: ['', [Validators.maxLength(40)]],
        });
    }

    setLikeButton(event) {
        if (event.checked) {
            this.showAdd = true
            this.showCopy = false
            this.label = "Click here to copy from an existing Throttle Policy";
            this.revert();
        } else {
            this.showCopy = true
            this.showAdd = false
            this.label = "Click here to add a new Throttle Policy";
            this.frmAddPolicy.reset();
        }
    }

    //to search throttle policy
    public onSearchForm(isUpdate) {
        this.showLoadingScreen = true;
        this.isEditable = {};         
        this.editedRow = {};         
        this.defaultEditedRow = {};
        if (!isUpdate) {
            this.addThrottleService.isAppThrottlePolicyActivated(false);
            this.selected = [];
            this.selectedPolicy = [];
        }
        this.throttlePolicyData = [];
        this.throttlePolicyMainData = [];
        this.copyPolicyBoolean = false;
        this.copySelectedRow = [];
        this.isSearchResultsExpanded = true;
        
        let obj: any = {};
        obj = this.wizardHelper.checkRequestObject(
            this.frmGroupThrottle.value
        );
        obj.dbEnv = this.wizardHelper.dbEnv;
        this.wizardService.searchThrottlePolicy(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.addThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_THROTTLE_POLICY_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (
                        let i = commaSeperatedArr.length - 1;
                        i >= 0;
                        i--
                    ) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                this.showLoadingScreen = false;

                this.throttlePolicyData = data[0];
                this.throttlePolicyData = [...this.throttlePolicyData];
                for (let i = 0; i < this.throttlePolicyData.length; i++) {
                    if (this.throttlePolicyData[i].dataSuspendedFlag == 'Y') {
                        this.throttlePolicyData[i].dataSuspendedFlag = 'YES'
                    } else if (this.throttlePolicyData[i].dataSuspendedFlag == 'N') {
                        this.throttlePolicyData[i].dataSuspendedFlag = 'NO'
                    }
                }

                this.throttlePolicyMainData = [...this.throttlePolicyData];

                if (data[0] && data[0].length == 0) {
                    this.toasterService.showErrorMessage(
                        this.addThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_SEARCH_THROTTLE_POLICY_ERROR_MESSAGE")
                    );
                } else {
                    this.isSearchResultsExpanded = true;
                }
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.addThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != " ")
                            this.toasterService.showMultiple(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }

    //to add throttle policy
    public addThrottlePolicy() {
        this.showLoadingScreen = true;
        this.summaryTableData = [];
        this.summaryTableMainData = [];
        let obj = this.frmAddPolicy.value;
        obj = this.wizardHelper.checkRequestObject(obj);
        obj.dbEnv = this.wizardHelper.dbEnv;
        this.wizardService.addThrottlePolicy(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.addThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_ADD_THROTTLE_POLICY_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                this.showLoadingScreen = false;
                const d = data[0].message;
                if(d==""){
                    this.toasterService.showErrorMessage(
                    this.addThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_DUPLICATE_THROTTLE_POLICY_ERROR_MESSAGE")
                );
                }else{
                this.summaryTableMainData.push(obj);
                this.summaryTableMainData.forEach(_e => {
                    _e.objId = d;
                });
                this.summaryTableData = [...this.summaryTableMainData];
                this.displayTable = true;
                this.addThrottleService.setStep1Data(this.summaryTableData);
                this.revert();
                this.wizardHelper.updateBreadcrumbList(obj.policyName, 2)
                this.addThrottleService.isAppThrottlePolicyActivated(true);
                this.toasterService.showSuccessMessage(
                    this.addThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_ADD_THROTTLE_POLICY_SUCCESS_MESSAGE")
                );
                }
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.addThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }

    //to copy throttle policy
    public copyThrottlePolicy() {
        if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
            this.toasterService.showErrorMessage(
                this.addThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            return;
        }
        this.showLoadingScreen = true;
        this.summaryTableData = [];
        this.summaryTableMainData = [];
        let obj: any = {};
        obj = { ...this.copySelectedRow[0] };
        obj = this.wizardHelper.checkRequestObject(obj);
        obj.dbEnv = this.wizardHelper.dbEnv;
        this.wizardService.addThrottlePolicy(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.addThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_COPY_THROTTLE_POLICY_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                this.showLoadingScreen = false;
                const d = data[0].message;
                if(d==""){
                    this.toasterService.showErrorMessage(
                    this.addThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_DUPLICATE_THROTTLE_POLICY_ERROR_MESSAGE")
                );
                } else {
                this.summaryTableMainData = [...this.copySelectedRow];
                this.summaryTableMainData.forEach(_e => {
                    _e.objId = d;
                });
                this.summaryTableData = [...this.summaryTableMainData];
                this.displayTable = true;
                this.addThrottleService.setStep1Data(this.summaryTableData);
                this.revert();
                this.wizardHelper.updateBreadcrumbList(obj.policyName, 2)
                this.addThrottleService.isAppThrottlePolicyActivated(true);
                this.toasterService.showSuccessMessage(
                    this.addThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_COPY_THROTTLE_POLICY_SUCCESS_MESSAGE")
                );
                }
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.addThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }


    //Row Selection
    public onSelect(row) {
        if (row && row.selected) {
            for (let i = 0; i < row.selected.length; i++) {
                let obj = { ...row.selected[i] };
                if (this.selectedPolicy[0] && this.selectedPolicy[0].objId && obj.objId == this.selectedPolicy[0].objId) {
                    this.selectedPolicy = [];
                    this.selected = [];
                } else {
                    this.selectedPolicy = [];
                    this.selectedPolicy.push(obj);
                }
            }
        }
    }

    //Copy Button
    public copyPolicyButton() {
        this.copyPolicyBoolean = true;
        this.copySelectedRow = [...this.selectedPolicy];

        if (this.copySelectedRow[0].dataSuspendedFlag == 'YES') {
            this.copySelectedRow[0].dataSuspendedFlag = 'Y'
        } else if (this.copySelectedRow[0].dataSuspendedFlag == 'NO') {
            this.copySelectedRow[0].dataSuspendedFlag = 'N'
        }

        this.isSearchResultsExpanded = false;
    }

    //Remove Work area
    public removeCopyButton() {
        this.copyPolicyBoolean = false;
        this.copySelectedRow = [];
        this.isSearchResultsExpanded = true;
        this.selected = [];
        this.selectedPolicy = [];
    }

    //Search Result table filter
    public updatePolicyTable(event) {
        const val = event.target.value.toLowerCase();
        // filter our data
        const temp = this.throttlePolicyMainData.filter(function (d) {
            return (d.policyName ? d.policyName.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.policyDesc ? d.policyDesc.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.dataSuspendedFlag ? d.dataSuspendedFlag.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.bypassTransQueue ? d.bypassTransQueue.toLowerCase().indexOf(val) !== -1 : !val) || !val
        });
        // update the rows
        this.throttlePolicyData = temp;
    }

    // this is use to reset
    public revert() {
        this.wizardHelper.deleteBreadcrumbList(2);
        if (this.frmGroupThrottle)
            this.frmGroupThrottle.reset();
        this.throttlePolicyData = [];
        this.throttlePolicyMainData = [];
        this.addThrottleService.isAppThrottlePolicyActivated(false);
        this.removeCopyButton();
        this.isEditable = {};         
        this.editedRow = {};         
        this.defaultEditedRow = {};
    }

    public editButtonClicked(rowData, rowIndex) {
        let alreadyEnabled = false;
        this.defaultEditedRow = { ...rowData }
        for (let i = 0; i < this.throttlePolicyData.length; i++) {
            if (this.isEditable[i])
                alreadyEnabled = true;
        }
        if (!alreadyEnabled)
            this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        else
            this.toasterService.showErrorMessage(
                this.addThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE")
            );
    }

    // to cancel edit
    public cancelEditForm(rowData, rowIndex) {
        this.showLoadingScreen = true;
        this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        this.throttlePolicyFields.forEach(e1 => {
            if (document.getElementById(e1.prop + rowIndex)) {
                (<HTMLInputElement>(
                    document.getElementById(e1.prop + rowIndex)
                )).value = rowData[e1.prop] || '';
            }
        });

        this.matSelect._results.forEach(matSelectData => {
            if (matSelectData.id.indexOf('dataSuspendedFlag' + rowIndex) == 0)
                matSelectData.value = rowData['dataSuspendedFlag'] || '';
            else if (matSelectData.id.indexOf('bypassTransQueue' + rowIndex) == 0)
                matSelectData.value = rowData['bypassTransQueue'] || '';
        });
        this.editedRow = {};
        this.defaultEditedRow = {};
        this.showLoadingScreen = false;
    }

    public inputValueChanged(event, column, row, oldValue) {
        if (column != "dataSuspendedFlag" && column != "bypassTransQueue") {

            this.editedRow[column] = event.target.value;
            this.defaultEditedRow[column] = event.target.defaultValue;
        }
        else {
            this.editedRow[column] = event.value;
            this.defaultEditedRow[column] = oldValue;
        }
    }

    //Work area inline value changes
    public editValueChanged(event, column, row, oldValue) {
        for (let i = 0; i < this.copySelectedRow.length; i++) {
            if (this.copySelectedRow[i].objId == row.objId) {
                if (column != "bypassTransQueue" && column != "dataSuspendedFlag") {
                    this.copySelectedRow[i][column] = event.target.value;
                } else {
                    this.copySelectedRow[i][column] = event.value
                }
            }
        }
    }

    //to update throttle policy
    public editThrottlePolicyData(configdata, rowIndex) {
        if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
            this.toasterService.showErrorMessage(
                this.addThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            return;
        }
        this.showLoadingScreen = true;
        let obj = { ...configdata, ...this.editedRow }

        obj = this.wizardHelper.checkRequestObject(obj);
        obj.dbEnv = this.wizardHelper.dbEnv;
        this.wizardService.updateThrottlePolicy(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.addThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_THROTTLE_POLICY_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                if (this.selectedPolicy.length > 0) {
                    this.addThrottleService.isAppThrottlePolicyActivated(true);
                }
                this.summaryTableMainData[0] = obj;
                this.summaryTableData = [...this.summaryTableMainData];
                this.showLoadingScreen = false;
                this.isEditable[rowIndex] = !this.isEditable[rowIndex];
                this.editedRow = {};
                this.defaultEditedRow = {};
                this.wizardHelper.updateBreadcrumbList(obj.policyName, 2)
                this.addThrottleService.isAppThrottleRuleActivated(true);
                this.toasterService.showSuccessMessage(
                    this.addThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_THROTTLE_POLICY_SUCCESS_MESSAGE")
                );

            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.addThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }

}