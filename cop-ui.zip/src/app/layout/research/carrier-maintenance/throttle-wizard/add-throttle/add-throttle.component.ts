import { Component, OnInit, ViewChild, ViewEncapsulation, Input, Output, EventEmitter } from '@angular/core';
import { ConfirmationService } from 'primeng/api';
import { AddThrottleService } from './add-throttle-service';
import { Subject } from "rxjs";
import { MatDialog } from "@angular/material";
import { Router } from "@angular/router";

@Component({
    selector: 'add-throttle',
    templateUrl: './add-throttle.component.html',
})
export class AddThrottleWizardComponent implements OnInit {
    readonly STEP_THROTTLE_POLICY = 0;
    readonly STEP_THROTTLE_RULE = 1;
    @ViewChild('insertWizardStepper') insertWizardStepper;
    isAppThrottlePolicyActive: boolean = false;
    isAppThrottleRuleActive: boolean = true;
    isBackButton: boolean = true;
    currentStep = 0;
    private unsubscribe = new Subject<void>();
    public showLoadingScreen = false;
    public index = 0;

    constructor(
        private router: Router,
        public dialog: MatDialog,
        private addThrottleService: AddThrottleService,
    ) { }


    ngOnInit() {
         this.addThrottleService.currentStep.subscribe(
            isActivated => {
                this.currentStep = isActivated;
            }
        );
        this.addThrottleService.isAppThrottlePolicyActive.subscribe(
            isActivated => {
                this.isAppThrottlePolicyActive = isActivated;
            }
        );
        this.addThrottleService.isAppThrottleRuleActive.subscribe(
            isActivated => {
                this.isAppThrottleRuleActive = isActivated;
            }
        );
        this.addThrottleService.isBackButton.subscribe(
            isActivated => {
                this.isBackButton = isActivated;
            }
        );
  
    }

    public gotToNextStep(insertWizardStepper) {
        if (insertWizardStepper._selectedIndex == this.STEP_THROTTLE_POLICY) {
            this.currentStep = 1;
            insertWizardStepper.next();
        } else {
            return;
        }
    }

    /**
   * Previous step in the stepper.
   */
    public gotToPreviousStep(insertWizardStepper) {
        if (insertWizardStepper._selectedIndex == this.STEP_THROTTLE_RULE) {
            this.currentStep = 0;
            insertWizardStepper.previous();
        } 
    }

    public gotTodoneStep() {
        window.location.reload();
    }


}


