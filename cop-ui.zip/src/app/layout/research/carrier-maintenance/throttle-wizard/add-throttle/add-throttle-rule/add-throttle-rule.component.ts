import { Component, OnInit } from "@angular/core";
import { AddThrottleService } from "../add-throttle-service";

@Component({
    selector: 'add-throttle-rule',
    templateUrl: './add-throttle-rule.component.html',
    styleUrls: ['./add-throttle-rule.component.scss']
})
export class AddThrottleRuleComponent implements OnInit {
    index = 0;
    summaryTableActive: boolean = false;

    constructor(
        private addThrottleService: AddThrottleService,
    ) { }

    ngOnInit() { 
        this.addThrottleService.summaryTableActive.subscribe(
            isActivated => {
                this.summaryTableActive = isActivated;
            }
        );
    }

    onChange(event) {
        if (event.index == 0) {
            this.index = 0;
        } else if (event.index == 1) {
            this.index = 1;
        } else if (event.index == 2) {
            this.index = 2;
        }
    }
}

