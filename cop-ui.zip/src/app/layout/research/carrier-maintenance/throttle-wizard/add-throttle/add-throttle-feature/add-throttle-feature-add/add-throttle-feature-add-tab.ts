import { Subject } from "rxjs";
import { Component, ViewEncapsulation, OnInit, ViewChildren, ViewChild, Output, Inject } from '@angular/core';
import { ConfirmationService } from 'primeng/primeng';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { takeUntil } from 'rxjs/operators';
import { CarrierMaintenanceService } from '../../../../../../../Services/carrierMaintenance.service';
import { CarrierMaintenanceHelper } from "../../../../carrier-maintenance-helper";
import { ToasterService } from "../../../../../../../Services/toaster.service";
import { AddThrottleWizardHelper } from "../../add-throttle-helper";
import { AddThrottleService } from "../../add-throttle-service";
import { MAT_DIALOG_DATA } from "@angular/material";

@Component({
    selector: 'add-throttle-feature-add',
    templateUrl: './add-throttle-feature-add-tab.html',
    styleUrls: ['./add-throttle-feature-add-tab.scss',
        "../../../../../../components/ngxtable/material.scss",
        "../../../../../../components/ngxtable/datatable.component.scss",
        "../../../../../../components/ngxtable/icons.css",
        "../../../../../../components/ngxtable/app.css"],
})

export class AddThrottleFeatureAddTab implements OnInit {
    private unsubscribe = new Subject<void>();
    public showLoadingScreen: boolean;
    public frmGroupThrottle: FormGroup;
    public tableRows: any = [];
    public alerts: Array<any> = [];

    constructor(
        @Inject(MAT_DIALOG_DATA) public data: any,
        private _formBuilder: FormBuilder,
        private wizardService: CarrierMaintenanceService,
        private toasterService: ToasterService,
        private wizardHelper: CarrierMaintenanceHelper,
        private confirmationService: ConfirmationService,
        private addThrottleWizardHelper: AddThrottleWizardHelper,
        private addThrottleService: AddThrottleService,
    ) {
        this.frmGroupThrottle = new FormGroup({});
    }

    ngOnInit() {
        this.createSearchForm();
        this.alerts = [];
    }

    //to create search form
    public createSearchForm() {
        this.frmGroupThrottle = this._formBuilder.group({
            featureFlagName: ['', [Validators.required, Validators.maxLength(40)]],
            featureFlagValue: ['', [Validators.maxLength(1)]],
            featureName: ['', [Validators.required, Validators.maxLength(30)]],
            featureValue: ['', [Validators.maxLength(30)]],
            status: ['', [Validators.required, Validators.maxLength(1)]],
        });
    }

    //to add throttle feature
    public addThrottleFeature() {
        this.showLoadingScreen = true;
        this.alerts = [];
        let obj = this.frmGroupThrottle.value;
        obj = this.wizardHelper.checkRequestObject(obj);
        obj.ruleId = this.data.dataKey.objId;
        obj.dbEnv = this.wizardHelper.dbEnv;
        this.wizardService.addThrottleFeature([obj]).pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.addThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_ADD_THROTTLE_FEATURE_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                const d = data[0].message;
                if(d==""){
                    this.toasterService.showErrorMessage(
                    this.addThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_DUPLICATE_THROTTLE_FEATURE_ERROR_MESSAGE")
                );
                }else{
                this.tableRows.push(obj);
                this.frmGroupThrottle.reset();
                this.addThrottleService.isFeatureSummaryActive(true);
                this.successAlert("Throttle Feature has been added successfully.")
                }
                this.showLoadingScreen = false;
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.addThrottleWizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }

    public closeAlert(alert: any) {
	    const index: number = this.alerts.indexOf(alert);
	    this.alerts.splice(index, 1);
	}
	
	private successAlert(successMsg:string){
		this.alerts = [];
		this.alerts.push(
            {
                id: 1,
                type: 'success',
                message: successMsg
            }
        );
	}

}


