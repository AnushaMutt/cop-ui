import { Component, OnInit } from "@angular/core";

@Component({
    selector: 'throttle-wizard',
    templateUrl: './throttle-wizard.html',
})
export class ThrottleWizardComponent implements OnInit {

    constructor() { }

    ngOnInit() { }
}


