import { Injectable } from "@angular/core";
import { Subject } from "rxjs";

@Injectable({
    providedIn: "root"
})
export class OrderTypesService {
    step2Data: any = [];

    currentStep= new Subject<number>();;

    constructor() {}

    public setOrderTypeData(step2Data) {
        this.step2Data = step2Data;
    }

    public getOrderTypeData() {
        return this.step2Data;
    }

    
    resetAll(){
        this.step2Data = [];
    }
}
