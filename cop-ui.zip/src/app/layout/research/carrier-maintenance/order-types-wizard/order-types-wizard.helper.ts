import { Injectable } from "@angular/core";
import { Subject } from "rxjs";

@Injectable({
    providedIn: "root"
})
export class OrderTypesHelper {
    
    constructor() { }

    public OrderTypesConstantObject = {
        "TRACFONE_DEFAULT_ERROR_MESSAGE": "Unable to process request",
        "TRACFONE_ADD_IG_ORDER_TYPES_ERROR_MESSAGE": "Unable to add IG Order Types",
        "TRACFONE_ADD_IG_ORDER_TYPES_SUCCESS_MESSAGE": "IG Order Type has been added successfully",
        "TRACFONE_DONE_CREATING_IG_ORDER_TYPES_CONFIRM_MESSAGE": "Are you done creating IG Order Types ?",
        "TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE": "Please complete previous operation",  
		"TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE" : "Please fix validation errors",
        "TRACFONE_UPDATE_IG_ORDER_TYPES_ERROR_MESSAGE" : "Unable to update IG Order Types",
        "TRACFONE_UPDATE_IG_ORDER_TYPES_SUCCESS_MESSAGE" : "IG Order Type has been updated successfully",
        "TRACFONE_RETRIEVE_IG_ORDER_TYPES_ERROR_MESSAGE" : "Unable to search IG Order Types",
        "TRACFONE_SEARCH_IG_ORDER_TYPES_ERROR_MESSAGE" : "No IG Order Types found",

        
    }

    public getTracfoneConstantMethod(msg) {
        return this.OrderTypesConstantObject[msg];
    }

}