import { Component, OnInit } from "@angular/core";

@Component({
    selector: 'order-types-wizard',
    templateUrl: './order-types-wizard.html',
})
export class OrderTypesComponent implements OnInit {

    constructor() { }

    ngOnInit() { }
}


