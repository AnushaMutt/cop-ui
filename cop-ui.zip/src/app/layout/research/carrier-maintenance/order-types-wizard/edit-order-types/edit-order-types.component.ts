import { Subject } from "rxjs";
import { Component, ViewEncapsulation, OnInit, ViewChildren } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { ConfirmationService } from 'primeng/primeng';
import { takeUntil } from 'rxjs/operators';
import { MatSelect } from "@angular/material";
import { CarrierMaintenanceService } from '../../../../../Services/carrierMaintenance.service';
import { CarrierMaintenanceHelper } from "../../carrier-maintenance-helper";
import { ToasterService } from "../../../../../Services/toaster.service";
import { OrderTypesHelper } from "../order-types-wizard.helper";
import { NgbModal, ModalDismissReasons, NgbTabset } from '@ng-bootstrap/ng-bootstrap';

@Component({
    selector: 'edit-order-types',
    templateUrl: './edit-order-types.component.html',
    styleUrls: ['./edit-order-types.component.scss',
        "../../../../components/ngxtable/material.scss",
        "../../../../components/ngxtable/datatable.component.scss",
        "../../../../components/ngxtable/icons.css",
        "../../../../components/ngxtable/app.css"],
    animations: [],
    encapsulation: ViewEncapsulation.None,
})

export class EditOrderTypesComponent implements OnInit {
    @ViewChildren(DatatableComponent)
    table: any;
    @ViewChildren(MatSelect) matSelect: any;
    private unsubscribe = new Subject<void>();
    public showLoadingScreen: boolean;
    public frmOrderTypes;
    public panelOpenState = false;
    customCollapsedHeight: string = '40px';
    customExpandedHeight: string = '40px';
    public tableColumns = [];
    public selected = [];
    public selectedTablecols: any = [];
    public optionalColumns = [];
    public optionalColumnsMainData = [];
    public orderTypeData = [];
    public orderTypeMainData = [];
    public selectedColumns = [];
    isEditable = {};
    private editedRow: any = {};
    private defaultEditedRow: any = {};
    public selectedFields = [];
    public searchColumns: any = [];
    public searchColumnsMaindata: any = [];
    public allAvailablecols: any = [];
    public defaultcols: any = [];
    public availableFilterValue;
    public selectedOptionalField = [];

    constructor(
        private formBuilder: FormBuilder,
        private wizardService: CarrierMaintenanceService,
        private orderTypesHelper: OrderTypesHelper,
        private toasterService: ToasterService,
        private wizardHelper: CarrierMaintenanceHelper,
        private confirmationService: ConfirmationService,
        private modalService: NgbModal,

    ) {
        this.frmOrderTypes = new FormGroup({});
    }

    ngOnInit() {
        this.panelOpenState = false;
        this.availableFilterValue = "";
        this.tableColumns = [
            { name: 'ADDON CASH CARD FLAG', prop: 'addonCashCardFlag', width: "200" },
            { name: 'BOGO CONFIG FLAG', prop: 'bogoConfigFlag', width: "200" },
            { name: 'BRM NOTIFICATION FLAG', prop: 'brmNotificationFlag', width: "200" },
            { name: 'CONTACT PIN UPDATE FLAG', prop: 'contactPinUpdateFlag', width: "200" },
            { name: 'CREATE BUCKETS FLAG', prop: 'createBucketsFlag', width: "200" },
            { name: 'CREATE IG ACM FLAG', prop: 'createIGACMFlag', width: "200" },
            { name: 'CREATE IG APN FLAG', prop: 'createIGAPNFlag', width: "200" },
            { name: 'CREATE MFORM IG FLAG', prop: 'createMFormIGFlag', width: "200" },
            { name: 'CREATE MFORM PORT FLAG', prop: 'createMFormPortFlag', width: "200" },
            { name: 'CREATE SO GENCODE FLAG', prop: 'createSOGencodeFlag', width: "200" },
            { name: 'DEP IG TRANS FLAG', prop: 'depIGTransFlag', width: "200" },
            { name: 'GENERATE ACCOUNT FLAG', prop: 'generateAccountFlag', width: "200" },
            { name: 'INSERT ILD TRANS FLAG', prop: 'insertILDTransFlag', width: "200" },
            { name: 'NEWER TRANS FLAG', prop: 'newerTransFlag', width: "200" },
            { name: 'PROCESS IGATE IN3 FLAG', prop: 'processIgateIN3Flag', width: "200" },
            { name: 'PROCESS IGATE IN3 LITE FLAG', prop: 'processIgateIN3LiteFlag', width: "200" },
            { name: 'SAFELINK BATCH FLAG', prop: 'safeLinkBatchFlag', width: "200" },
            { name: 'SKIP ESN VALIDATION FLAG', prop: 'skipESNValidationFlag', width: "200" },
            { name: 'SKIP MIN UPDATE FLAG', prop: 'skipMinUpdateFlag', width: "200" },
            { name: 'SKIP MIN VALIDATION FLAG', prop: 'skipMinValidationForm', width: "200" },
            { name: 'SQL TEXT', prop: 'sqlText', width: "200" },
            { name: 'SUI ACTION TYPE', prop: 'sUIActionType', width: "200" },
            { name: 'UPDATE CASE2TASK FLAG', prop: 'updateXCase2TaskFlag', width: "200" },
            { name: 'UPDATE MSID FLAG', prop: 'updateMSIDFlag', width: "200" },
        ];
        this.allAvailablecols = [
            { name: 'IG ORDER TYPE', prop: 'igOrderType', width: "250" },
            { name: 'PROGRAMME NAME', prop: 'programmeName', width: "280" },
            { name: 'PRIORITY', prop: 'priority', width: "100" },
            { name: 'ACTUAL ORDER TYPE', prop: 'actualOrderType', width: "250" },
            { name: 'ADDON CASH CARD FLAG', prop: 'addonCashCardFlag', width: "200" },
            { name: 'BOGO CONFIG FLAG', prop: 'bogoConfigFlag', width: "200" },
            { name: 'BRM NOTIFICATION FLAG', prop: 'brmNotificationFlag', width: "200" },
            { name: 'CONTACT PIN UPDATE FLAG', prop: 'contactPinUpdateFlag', width: "200" },
            { name: 'CREATE BUCKETS FLAG', prop: 'createBucketsFlag', width: "200" },
            { name: 'CREATE IG ACM FLAG', prop: 'createIGACMFlag', width: "200" },
            { name: 'CREATE IG APN FLAG', prop: 'createIGAPNFlag', width: "200" },
            { name: 'CREATE MFORM IG FLAG', prop: 'createMFormIGFlag', width: "200" },
            { name: 'CREATE MFORM PORT FLAG', prop: 'createMFormPortFlag', width: "200" },
            { name: 'CREATE SO GENCODE FLAG', prop: 'createSOGencodeFlag', width: "200" },
            { name: 'DEP IG TRANS FLAG', prop: 'depIGTransFlag', width: "200" },
            { name: 'GENERATE ACCOUNT FLAG', prop: 'generateAccountFlag', width: "200" },
            { name: 'INSERT ILD TRANS FLAG', prop: 'insertILDTransFlag', width: "200" },
            { name: 'NEWER TRANS FLAG', prop: 'newerTransFlag', width: "200" },
            { name: 'PROCESS IGATE IN3 FLAG', prop: 'processIgateIN3Flag', width: "200" },
            { name: 'PROCESS IGATE IN3 LITE FLAG', prop: 'processIgateIN3LiteFlag', width: "200" },
            { name: 'SAFELINK BATCH FLAG', prop: 'safeLinkBatchFlag', width: "200" },
            { name: 'SKIP ESN VALIDATION FLAG', prop: 'skipESNValidationFlag', width: "200" },
            { name: 'SKIP MIN UPDATE FLAG', prop: 'skipMinUpdateFlag', width: "200" },
            { name: 'SKIP MIN VALIDATION FLAG', prop: 'skipMinValidationForm', width: "200" },
            { name: 'SQL TEXT', prop: 'sqlText', width: "200" },
            { name: 'SUI ACTION TYPE', prop: 'sUIActionType', width: "200" },
            { name: 'UPDATE CASE2TASK FLAG', prop: 'updateXCase2TaskFlag', width: "200" },
            { name: 'UPDATE MSID FLAG', prop: 'updateMSIDFlag', width: "200" },
        ];
        this.defaultcols = [
            { name: 'IG ORDER TYPE', prop: 'igOrderType', width: "250" },
            { name: 'PROGRAMME NAME', prop: 'programmeName', width: "280" },
            { name: 'PRIORITY', prop: 'priority', width: "100" },
            { name: 'ACTUAL ORDER TYPE', prop: 'actualOrderType', width: "250" },
        ];
        this.optionalColumns = this.tableColumns;
        this.optionalColumnsMainData = [...this.optionalColumns];
        this.selectedColumns = this.allAvailablecols;
        this.selectedTablecols = [...this.optionalColumns];
        this.selectedFields = [];
        this.searchColumns = [...this.tableColumns];
        this.searchColumnsMaindata = [...this.searchColumns];
        this.createForm();
    }

    //to create form
    private createForm() {
        this.frmOrderTypes = this.formBuilder.group({
            programmeName: ['', [Validators.maxLength(30)]],
            actualOrderType: ['', [Validators.maxLength(30)]],
            igOrderType: ['', [Validators.maxLength(30)]],
            priority: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(38)]],
            sqlText: ['', [Validators.maxLength(4000)]],
            createSOGencodeFlag: ['', [Validators.maxLength(1)]],
            createMFormIGFlag: ['', [Validators.maxLength(1)]],
            createMFormPortFlag: ['', [Validators.maxLength(1)]],
            skipMinValidationForm: ['', [Validators.maxLength(1)]],
            skipESNValidationFlag: ['', [Validators.maxLength(1)]],
            createIGAPNFlag: ['', [Validators.maxLength(1)]],
            insertILDTransFlag: ['', [Validators.maxLength(1)]],
            bogoConfigFlag: ['', [Validators.maxLength(1)]],
            sUIActionType: ['', [Validators.maxLength(10)]],
            updateMSIDFlag: ['', [Validators.maxLength(1)]],
            addonCashCardFlag: ['', [Validators.maxLength(1)]],
            contactPinUpdateFlag: ['', [Validators.maxLength(1)]],
            brmNotificationFlag: ['', [Validators.maxLength(1)]],
            newerTransFlag: ['', [Validators.maxLength(1)]],
            skipMinUpdateFlag: ['', [Validators.maxLength(1)]],
            safeLinkBatchFlag: ['', [Validators.maxLength(1)]],
            createBucketsFlag: ['', [Validators.maxLength(3)]],
            processIgateIN3Flag: ['', [Validators.maxLength(1)]],
            processIgateIN3LiteFlag: ['', [Validators.maxLength(1)]],
            updateXCase2TaskFlag: ['', [Validators.maxLength(1)]],
            depIGTransFlag: ['', [Validators.maxLength(1)]],
            generateAccountFlag: ['', [Validators.maxLength(1)]],
            createIGACMFlag: ['', [Validators.maxLength(1)]],
        })
    }

    //to search order types
    public onSearchForm() {
        this.optionalColumns = [...this.optionalColumnsMainData];
        this.availableFilterValue = "";
        this.showLoadingScreen = true;
        this.orderTypeData = [];
        this.orderTypeMainData = [];
        this.isEditable = {};
        this.editedRow = {};
        this.defaultEditedRow = {};
        let obj: any = {};
        obj = this.frmOrderTypes.value;
        obj.dbEnv = this.wizardHelper.dbEnv;
        obj = this.wizardHelper.checkRequestObject(obj);
        this.wizardService.searchIgOrderTypes(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.orderTypesHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_IG_ORDER_TYPES_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (
                        let i = commaSeperatedArr.length - 1;
                        i >= 0;
                        i--
                    ) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                this.showLoadingScreen = false;
                this.orderTypeData = data[0];
                this.orderTypeMainData = [...this.orderTypeData];

                if (data[0] && data[0].length == 0)
                    this.toasterService.showErrorMessage(
                        this.orderTypesHelper.getTracfoneConstantMethod("TRACFONE_SEARCH_IG_ORDER_TYPES_ERROR_MESSAGE")
                    );
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.orderTypesHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != " ")
                            this.toasterService.showMultiple(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }

    private inputValueChanged(event, column, row, oldValue) {
        if (column == 'programmeName' || column == 'actualOrderType' || column == 'igOrderType' || column == 'priority' || column == 'sqlText' || column == 'sUIActionType') {
            this.editedRow[column] = event.target.value;
            this.defaultEditedRow[column] = event.target.defaultValue;
        }
        else {
            this.defaultEditedRow[column] = oldValue;
            this.editedRow[column] = event.value;
        }
    }

    editButtonClicked(rowData, rowIndex) {
        let alreadyEnabled = false;
        this.defaultEditedRow = { ...rowData }
        for (let i = 0; i < this.orderTypeData.length; i++) {
            if (this.isEditable[i])
                alreadyEnabled = true;
        }
        if (!alreadyEnabled)
            this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        else
            this.toasterService.showErrorMessage(
                this.orderTypesHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE")
            );
    }

    //to update order types
    public editOrderTypes(configdata, rowIndex) {
        if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
            this.toasterService.showErrorMessage(
                this.orderTypesHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            return;
        }
        this.showLoadingScreen = true;
        let obj = { ...configdata, ...this.editedRow }

        obj = this.wizardHelper.checkRequestObject(obj);
        obj.dbEnv = this.wizardHelper.dbEnv;
        this.wizardService.updateIgOrderTypes(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.orderTypesHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_IG_ORDER_TYPES_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                for (let i = 0; i < this.orderTypeMainData.length; i++) {
                    if (this.orderTypeMainData[i].rowId == this.defaultEditedRow.rowId) {
                        this.orderTypeMainData[i] = obj;
                    }
                }
                this.isEditable[rowIndex] = !this.isEditable[rowIndex];
                this.showLoadingScreen = false;
                this.editedRow = {};
                this.defaultEditedRow = {};
                this.orderTypeData = [...this.orderTypeMainData];
                this.orderTypeData = [...this.orderTypeData];
                this.onSearchForm();

                this.toasterService.showSuccessMessage(
                    this.orderTypesHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_IG_ORDER_TYPES_SUCCESS_MESSAGE")
                );

            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.orderTypesHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }

    //to cancel update
    private cancelCarrierFeatureForm(rowData, rowIndex) {
        this.showLoadingScreen = true;
        this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        this.selectedColumns.forEach(e1 => {
            if (document.getElementById(e1.prop + rowIndex)) {
                (<HTMLInputElement>(
                    document.getElementById(e1.prop + rowIndex)
                )).value = rowData[e1.prop] || '';
            }
        });

        this.matSelect._results.forEach(matSelectData => {
            if (matSelectData.id.indexOf('createSOGencodeFlag' + rowIndex) == 0)
                matSelectData.value = rowData['createSOGencodeFlag'] || '';
            else if (matSelectData.id.indexOf('createMFormIGFlag' + rowIndex) == 0)
                matSelectData.value = rowData['createMFormIGFlag'] || '';
            else if (matSelectData.id.indexOf('createMFormPortFlag' + rowIndex) == 0)
                matSelectData.value = rowData['createMFormPortFlag'] || '';
            else if (matSelectData.id.indexOf('skipMinValidationForm' + rowIndex) == 0)
                matSelectData.value = rowData['skipMinValidationForm'] || '';
            else if (matSelectData.id.indexOf('skipESNValidationFlag' + rowIndex) == 0)
                matSelectData.value = rowData['skipESNValidationFlag'] || '';
            else if (matSelectData.id.indexOf('createIGAPNFlag' + rowIndex) == 0)
                matSelectData.value = rowData['createIGAPNFlag'] || '';
            else if (matSelectData.id.indexOf('insertILDTransFlag' + rowIndex) == 0)
                matSelectData.value = rowData['insertILDTransFlag'] || '';
            else if (matSelectData.id.indexOf('bogoConfigFlag' + rowIndex) == 0)
                matSelectData.value = rowData['bogoConfigFlag'] || '';
            else if (matSelectData.id.indexOf('sUIActionType' + rowIndex) == 0)
                matSelectData.value = rowData['sUIActionType'] || '';
            else if (matSelectData.id.indexOf('updateMSIDFlag' + rowIndex) == 0)
                matSelectData.value = rowData['updateMSIDFlag'] || '';
            else if (matSelectData.id.indexOf('addonCashCardFlag' + rowIndex) == 0)
                matSelectData.value = rowData['addonCashCardFlag'] || '';
            else if (matSelectData.id.indexOf('contactPinUpdateFlag' + rowIndex) == 0)
                matSelectData.value = rowData['contactPinUpdateFlag'] || '';
            else if (matSelectData.id.indexOf('brmNotificationFlag' + rowIndex) == 0)
                matSelectData.value = rowData['brmNotificationFlag'] || '';
            else if (matSelectData.id.indexOf('newerTransFlag' + rowIndex) == 0)
                matSelectData.value = rowData['newerTransFlag'] || '';
            else if (matSelectData.id.indexOf('skipMinUpdateFlag' + rowIndex) == 0)
                matSelectData.value = rowData['skipMinUpdateFlag'] || '';
            else if (matSelectData.id.indexOf('safeLinkBatchFlag' + rowIndex) == 0)
                matSelectData.value = rowData['safeLinkBatchFlag'] || '';
            else if (matSelectData.id.indexOf('createBucketsFlag' + rowIndex) == 0)
                matSelectData.value = rowData['createBucketsFlag'] || '';
            else if (matSelectData.id.indexOf('processIgateIN3Flag' + rowIndex) == 0)
                matSelectData.value = rowData['processIgateIN3Flag'] || '';
            else if (matSelectData.id.indexOf('processIgateIN3LiteFlag' + rowIndex) == 0)
                matSelectData.value = rowData['processIgateIN3LiteFlag'] || '';
            else if (matSelectData.id.indexOf('updateXCase2TaskFlag' + rowIndex) == 0)
                matSelectData.value = rowData['updateXCase2TaskFlag'] || '';
            else if (matSelectData.id.indexOf('depIGTransFlag' + rowIndex) == 0)
                matSelectData.value = rowData['depIGTransFlag'] || '';
            else if (matSelectData.id.indexOf('generateAccountFlag' + rowIndex) == 0)
                matSelectData.value = rowData['generateAccountFlag'] || '';
            else if (matSelectData.id.indexOf('createIGACMFlag' + rowIndex) == 0)
                matSelectData.value = rowData['createIGACMFlag'] || '';
        });
        this.editedRow = {};
        this.defaultEditedRow = {};
        this.showLoadingScreen = false;
    }

    //to filter table
    private updateSummaryTable(event) {
        const val = event.target.value.toLowerCase();

        const temp = this.orderTypeMainData.filter(function (d) {
            return (d.priority ? d.priority.indexOf(val) !== -1 : !val)
                || (d.programmeName ? d.programmeName.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.actualOrderType ? d.actualOrderType.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.igOrderType ? d.igOrderType.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.createSOGencodeFlag ? d.createSOGencodeFlag.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.createMFormIGFlag ? d.createMFormIGFlag.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.createMFormPortFlag ? d.createMFormPortFlag.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.skipMinValidationForm ? d.skipMinValidationForm.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.skipESNValidationFlag ? d.skipESNValidationFlag.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.createIGAPNFlag ? d.createIGAPNFlag.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.insertILDTransFlag ? d.insertILDTransFlag.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.bogoConfigFlag ? d.bogoConfigFlag.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.sUIActionType ? d.sUIActionType.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.updateMSIDFlag ? d.updateMSIDFlag.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.addonCashCardFlag ? d.addonCashCardFlag.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.contactPinUpdateFlag ? d.contactPinUpdateFlag.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.brmNotificationFlag ? d.brmNotificationFlag.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.newerTransFlag ? d.newerTransFlag.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.skipMinUpdateFlag ? d.skipMinUpdateFlag.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.safeLinkBatchFlag ? d.safeLinkBatchFlag.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.createBucketsFlag ? d.createBucketsFlag.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.processIgateIN3Flag ? d.processIgateIN3Flag.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.processIgateIN3LiteFlag ? d.processIgateIN3LiteFlag.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.updateXCase2TaskFlag ? d.updateXCase2TaskFlag.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.depIGTransFlag ? d.depIGTransFlag.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.generateAccountFlag ? d.generateAccountFlag.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.createIGACMFlag ? d.createIGACMFlag.toLowerCase().indexOf(val) !== -1 : !val)
                || (d.sqlText ? d.sqlText.toLowerCase().indexOf(val) !== -1 : !val)
        });
        this.orderTypeData = temp;
        this.table.offset = 0;
    }

    onExpand() {
        this.panelOpenState = true;
    }
    //get selected Available columns
    public saveOptionalFields() {
        this.panelOpenState = !this.panelOpenState;
        this.optionalColumns = [...this.optionalColumnsMainData];
        this.availableFilterValue = "";
    }

    //Available columns filter
    public updateOptionalColumns(event) {
        const val = event.target.value.toLowerCase();
        // filter our data
        const temp = this.optionalColumnsMainData.filter(function (d) {
            return d.name.toLowerCase().indexOf(val) !== -1 || !val;
        });
        // update the rows
        this.optionalColumns = temp;
    }

    //Checkbox selection from available columns accrodian
    onSelectOptionalFields(row) {
        this.selectedColumns = [];
        this.selectedColumns = [...this.defaultcols];
        let columns: any = [];
        if (row && row.selected) {
            for (let i = 0; i < row.selected.length; i++) {
                let obj = { ...row.selected[i] };
                columns.push(obj);
            }
        }
        columns.sort((_e1, _e2) => {
            return _e1.name.localeCompare(_e2.name) || _e2.prop - _e1.prop;
        });
        columns.forEach(e => {
            this.selectedColumns.push(e)
        });
        this.selectedColumns = [...this.selectedColumns]
    }

    rowIdentity = (row: any) => {
        return row.name;
    }

    private updateOptionalSearchColumns(event) {
        const val = event.target.value.toLowerCase();

        // filter our data
        const temp = this.searchColumnsMaindata.filter(function (d) {
            return d.name.toLowerCase().indexOf(val) !== -1 || !val;
        });

        // update the rows
        this.searchColumns = temp;

    }

    private resetOptionalFields() {
        this.searchColumns = [...this.searchColumnsMaindata];
    }

    private onSelectFields({selected}) {
        if(selected.length == 0){
            this.searchColumns.forEach((_e1) => this.frmOrderTypes.controls[`${_e1.prop}`].reset());
        }else {
            let intersection = this.selectedFields.filter((e) => !selected.includes(e));
            intersection.forEach((_e1) => this.frmOrderTypes.controls[`${_e1.prop}`].reset())
        }
        this.selectedFields.splice(0, this.selectedFields.length);
        this.selectedFields.push(...selected);
        this.selectedOptionalField.splice(0, this.selectedOptionalField.length);
        this.selectedOptionalField.push(...selected)
        this.selectedFields.sort((_e1, _e2) => {
            return _e1.name.localeCompare(_e2.name) || _e2.prop - _e1.prop;
        });
    }

    //for optional search fields pop up
    openSml(content) {
        this.modalService.open(content, { size: 'lg' });
    }

    //to reset the form
    public revert() {
        this.frmOrderTypes.reset();
        this.orderTypeData = [];
        this.orderTypeMainData = [];
        this.optionalColumns = [...this.optionalColumnsMainData];
        this.availableFilterValue = "";
        this.isEditable = {};
        this.editedRow = {};
        this.defaultEditedRow = {};
    }

}