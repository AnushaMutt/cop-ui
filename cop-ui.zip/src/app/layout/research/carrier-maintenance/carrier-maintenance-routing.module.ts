import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CarrierMaintenanceComponent } from './carrier-maintenance.component';

const routes: Routes = [
	{
		path: '',
	    component: CarrierMaintenanceComponent
	}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CarrierMaintenanceRoutingModule { }
