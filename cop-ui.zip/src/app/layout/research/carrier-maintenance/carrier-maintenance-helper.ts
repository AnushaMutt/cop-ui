import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable()
export class CarrierMaintenanceHelper {

  public 'dbEnv': String;
  public breadcrumbListUpdate = new Subject<number>();
  public breadcrumbList = [];

  constructor() { }

  public setDbEnv(dbEnv) {
    this.dbEnv = dbEnv;
  }

  public getDbEnv() {
    return this.dbEnv;
  }
  public checkRequestObject(obj) {
    Object.keys(obj).forEach(key => {
      if (!obj[key]) delete obj[key];
    });
    return obj;
  }

  public checkRequestObjectSetToNull(obj) {
    Object.keys(obj).forEach(key => {
      if (!obj[key]) obj[key] = null;
    });
    return obj;
  }

  public checkReqForObjectInsideObject(obj) {
    Object.keys(obj).forEach(key => {
      if (obj[key] && typeof obj[key] === 'object') {
        const innerArray = this.checkRequestObject(obj[key])
        if (innerArray === undefined) {
          delete obj[key]
        }
      }
      else if (!obj[key]) delete obj[key];
    });
    return obj;
  }

  public checkReqForObjectInsideObjectSetToNull(obj) {
    Object.keys(obj).forEach(key => {
      if (obj[key] && typeof obj[key] === 'object') {
        const innerArray = this.checkRequestObject(obj[key])
        if (innerArray === undefined) {
          obj[key] = null;
        }
      }
      else if (!obj[key]) obj[key] = null;
    });
    return obj;
  }

  checkRequestObjectForArray(obj) {
    Object.keys(obj).forEach(key => {
      if (obj[key] && typeof obj[key] === 'object') {
        const innerArray = this.checkRequestObjectForArray(obj[key])
        if (innerArray === undefined) {
          delete obj[key];
          obj.pop();
        } else if (innerArray && innerArray.constructor === Array && innerArray.length === 0) {
          delete obj[key]
        }
      }
      else if (!obj[key]) delete obj[key]
    });
    return Object.keys(obj).length > 0 || obj instanceof Array ? obj : undefined;
  };

  public updateBreadcrumbList(breadcrumb: string, index: number) {
    this.breadcrumbList[index] = breadcrumb;
    this.breadcrumbListUpdate.next(Math.random());
  }

  public deleteBreadcrumbList(index: number) {
    this.breadcrumbList.splice(index, 1);
    this.breadcrumbListUpdate.next(Math.random());
  }

  public emptyBreadcrumbList() {
    this.breadcrumbList = [];
    this.breadcrumbListUpdate.next(Math.random());
  }

  public getBreadcrumbList() {
    return this.breadcrumbList;
  }

  public carrierMaintenanceComponentConstantObject = {
    "TRACFONE_DEFAULT_ERROR_MESSAGE": "Unable to process request",
    "TRACFONE_RETRIEVE_CARRIER_ERROR_MESSAGE": "Unable to retrieve Carriers",
    "TRACFONE_RETRIEVE_DATABASE_ERROR_MESSAGE": "Unable to retrieve Database Environments",
    "TRACFONE_RETRIEVE_PARENT_NAME_ERROR_MESSAGE": "Unable to retrieve Parent Name",
    "TRACFONE_UNABLE_SEARCH_MESSAGE": "Unable to search Parents",
    "TRACFONE_UNABLE_SEARCH_CARRIER_GROUPS_MESSAGE": "Unable to search Carrier Groups",
    "TRACFONE_UNABLE_SEARCH_CARRIER_MESSAGE": "Unable to search Carriers",
    "TRACFONE_UNABLE_RETRIEVE_DATABASE": "Unable to retrieve Database Environments",
    "TRACFONE_UNABLE_RETRIEVE_CARRIER": "Unable to retrieve Carriers",
    "TRACFONE_UNABLE_UPDATE_PARENTS": "Unable to update Parent",
    "TRACFONE_PARENT_UPDATE_SUCCESS_MESSAGE": "Parent has been updated successfully",
    "TRACFONE_UNABLE_DELETE_RATEPLAN": "Unable to delete Rate Plan",
    "NO_PARENTS_FOUND": "No Parents found",
    "NO_CARRIER_GROUPS_FOUND": "No Carrier Groups found",
    "NO_CARRIERS_FOUND": "No Carriers found",
    "TRACFONE_UPDATE_CARRIER_GROUP_ERROR_MESSAGE": "Unable to update Carrier Group",
    "TRACFONE_SUCCESS_UPDATE_CARRIER_GROUP_MESSAGE": "Carrier Group has been updated successfully",
    "TRACFONE_UPDATE_CARRIER_ERROR_MESSAGE": "Unable to update Carrier",
    "TRACFONE_SUCCESS_UPDATE_CARRIER_MESSAGE": "Carrier has been updated successfully",
    "COMPLETE_PREVIOUS_ACTION": "Please complete previous operation",
    "TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE": "Please fix validation errors",
    "TRACFONE_CANCEL_UPDATE_CARRIER_CONFIRM_MESSAGE": "Are you sure you want to cancel ?",
    "TRACFONE_UPDATE_CARRIER_CONFIRM_MESSAGE": "Are you sure you want to update ?",
    "NO_ORDER_TYPE_FOUND": "No Order Types found",
    "TRACFONE_UNABLE_SEARCH_ORDER_TYPES_MESSAGE": "Unable to search Order Types",
    "TRACFONE_DONE_ORDER_TYPES_CONFIRM_MESSAGE": "Are you done creating Order Types ?",
    "TRACFONE_ADD_ORDER_TYPES_SUCCESS_MESSAGE": "Order Types has been added successfully",
    "TRACFONE_ADD_ORDER_TYPES_ERROR_MESSAGE": "Unable to add Order Types",
    "TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE": "Please complete previous operation",
    "TRACFONE_COPY_CARRIER_GROUPS_ERROR_MESSAGE": "Unable to copy Carrier Groups",
    "TRACFONE_COPY_CARRIER_GROUPS_SUCCESS_MESSAGE": "Carrier Groups has been copied successfully",
    "TRACFONE_COPY_CARRIERS_ERROR_MESSAGE": "Unable to copy Carriers",
    "TRACFONE_COPY_CARRIERS_SUCCESS_MESSAGE": "Carriers has been copied successfully",
    "TRACFONE_COPY_ORDER_TYPES_SUCCESS_MESSAGE": "Order Types has been copied successfully",
    "TRACFONE_COPY_ORDER_TYPES_ERROR_MESSAGE": "Unable to copy Carrier Groups",
    "TRACFONE_UPDATE_ORDER_TYPES_ERROR_MESSAGE": "Unable to update Carrier Groups",
    "TRACFONE_UPDATE_ORDER_TYPES_SUCCESS_MESSAGE": "Order Type has been updated successfully",
    "NO_CARRIER_RULES_FOUND": "No Carrier Rules found",
    "TRACFONE_UNABLE_SEARCH_CARRIER_RULES_MESSAGE": "Unable to search Carrier Rules",
    "TRACFONE_UNABLE_ADD_CARRIER_RULES_MESSAGE": "Unable to add Carrier Rule",
    "TRACFONE_ADD_CARRIER_RULES_SUCCESS_MESSAGE": "Carrier Rule has been added successfully",
    "TRACFONE_UNABLE_UPDATE_CARRIER_RULES_MESSAGE": "Unable to update Carrier Rule",
    "TRACFONE_UPDATE_CARRIER_RULES_SUCCESS_MESSAGE": "Carrier Rule has been updated successfully",
    "TRACFONE_ADD_PARENT_SUCCESS_MESSAGE": "Parent has been copied successfully",
    "TRACFONE_ADD_PARENT_ERROR_MESSAGE": "Unable to copy Parent",
    "TRACFONE_DELETE_ORDER_TYPES_ERROR_MESSAGE": "Unable to delete Order Type",
    "TRACFONE_DELETE_ORDER_TYPES_SUCCESS_MESSAGE": "Order Type has been deleted successfully",


    "TRACFONE_ADD_POSTAL_ZIPS_ERROR_MESSAGE": "Unable to add Postal Zips",
    "TRACFONE_ADD_POSTAL_ZIPS_SUCCESS_MESSAGE": "Postal Zips has been added successfully",
    "TRACFONE_RETRIEVE_POSTAL_ZIPS_ERROR_MESSAGE": "Unable to retrieve Postal Zips",
    "TRACFONE_RETRIEVE_POSTAL_ZIPS_SUCCESS_MESSAGE": "Postal Zips retrieved successfully",
    "NO_POSTAL_ZIPS_FOUND": "No Postal Zips found",
    "TRACFONE_DELETE_POSTAL_ZIPS_ERROR_MESSAGE": "Unable to delete Postal Zips",
    "TRACFONE_DELETE_POSTAL_ZIPS_SUCCESS_MESSAGE": "Postal Zips has been deleted successfully",
    "TRACFONE_UPDATE_POSTAL_ZIPS_SUCCESS_MESSAGE": "Postal Zips has been updated successfully",
    "TRACFONE_UPDATE_POSTAL_ZIPS_ERROR_MESSAGE": "Unable to update Postal Zips",
    "TRACFONE_BULK_UPDATE_POSTAL_ZIPS_ERROR_MESSAGE": "Unable to bulk update Postal Zips",
    "TRACFONE_DONE_CREATING_POSTAL_ZIPS_CONFIRM_MESSAGE": "Are you done creating Postal Zips ?",
    "TRACFONE_NO_SUMMARY_FOUND_ERROR_MESSAGE": "No records found",

    "TRACFONE_RETRIEVE_USER_ERROR_MESSAGE" : "Unable to retrieve user",
    "NO_USER_FOUND" : "No User found",
    "TRACFONE_ADD_GEO_LOC_ERROR_MESSAGE": "Unable to add Geo Loc",
    "TRACFONE_ADD_GEO_LOC_SUCCESS_MESSAGE": "Geo Loc has been added successfully",
    "TRACFONE_UPDATE_GEO_LOC_ERROR_MESSAGE": "Unable to update Geo Loc",
    "TRACFONE_DONE_CREATING_GEO_LOC_CONFIRM_MESSAGE": "Are you done creating Geo Loc ?",
    "TRACFONE_UPDATE_GEO_LOC_SUCCESS_MESSAGE": "Geo Loc has been updated successfully",
    "TRACFONE_DELETE_GEO_LOC_SUCCESS_MESSAGE": "Geo Loc has been deleted successfully",
    "TRACFONE_RETRIEVE_GEO_LOC_ERROR_MESSAGE": "Unable to retrieve Geo Loc",
    "NO_GEO_LOC_FOUND" : "No Geo Loc found",
    "TRACFONE_DELETE_GEO_LOC_ERROR_MESSAGE": "Unable to delete Geo Loc",
    "TRACFONE_BULK_UPDATE_GEO_LOC_ERROR_MESSAGE": "Unable to bulk update Geo Loc",
    "TRACFONE_BULK_INSERT_GEO_LOC_ERROR_MESSAGE": "Unable to bulk insert Geo Loc",
  }

  public getTracfoneConstantMethod(msg) {
    return this.carrierMaintenanceComponentConstantObject[msg];
  }
}
