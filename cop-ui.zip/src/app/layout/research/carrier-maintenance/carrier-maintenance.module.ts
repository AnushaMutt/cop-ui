import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { PageHeaderModule } from "./../../../shared";
import { NgxDatatableModule } from "@swimlane/ngx-datatable";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { MatTabsModule } from "@angular/material";
import { BreadcrumbModule } from 'primeng/breadcrumb';
import { PrimengTreeTableModule } from "./../../../shared";
import {
    MatAutocompleteModule,
    MatBadgeModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDatepickerModule,
    MatDialogModule,
    MatDividerModule,
    MatExpansionModule,
    MatGridListModule,
    MatIconModule,
    MatListModule,
    MatMenuModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatStepperModule,
    MatTableModule,
    MatToolbarModule,
    MatTooltipModule,
    MatTreeModule,
    MatInputModule
} from "@angular/material";

import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { TreeTableModule } from "primeng/primeng";
import { TableModule } from "primeng/table";
import { CarrierMaintenanceRoutingModule } from "./carrier-maintenance-routing.module";
import { CarrierMaintenanceComponent } from "./carrier-maintenance.component";
import { UpdateParentWizardComponent } from "./parent-wizard/update-parent-wizard/update-parent-wizard.component";
import { StepParentComponent } from "./parent-wizard/update-parent-wizard/step-parents/step-parents.component";
import { UpdateParentService } from "./parent-wizard/update-parent-wizard/services/update-parent-wizard.service";
import { StepCarrierGroupsComponent } from "./parent-wizard/update-parent-wizard/step-carrier-groups/step-carrier-groups.component";
import { ViewCarrierGroupsComponent } from "./parent-wizard/update-parent-wizard/step-carrier-groups/view-carrier-groups/view-carrier-groups.component";
import { CarrierMaintenanceHelper } from "./carrier-maintenance-helper";
import { StepCarriersComponent } from "./parent-wizard/update-parent-wizard/step-carriers/step-carriers.component";
import { CopyCarrierGroupsComponent } from "./parent-wizard/update-parent-wizard/step-carrier-groups/copy-carrier-groups/copy-carrier-groups.component";
import { ViewCarriersComponent } from "./parent-wizard/update-parent-wizard/step-carriers/view-carriers/view-carriers.component";
import { UpdateCarrierDialogComponent } from "./parent-wizard/update-parent-wizard/step-carriers/view-carriers/update-carriers-dialog/update-carriers-dialog.component";
import { OrderTypesDialogComponent } from "./parent-wizard/update-parent-wizard/step-carriers/view-carriers/order-types-dialog/order-types-dialog.component";
import { ViewOrderTypesComponent } from "./parent-wizard/update-parent-wizard/step-carriers/view-carriers/order-types-dialog/view-order-types/view-order-types.component";
import { CopyOrderTypesComponent } from "./parent-wizard/update-parent-wizard/step-carriers/view-carriers/order-types-dialog/copy-order-types/copy-order-types.component";
import { CopyCarriersComponent } from "./parent-wizard/update-parent-wizard/step-carriers/copy-carriers/copy-carriers.component";
import { AddDataConfigMappingComponent } from "./data-config-mapping-wizard/add-data-config-mapping/add-data-config-mapping";
import { EditDataConfigMappingComponent } from "./data-config-mapping-wizard/edit-data-config-mapping/edit-data-config-mapping";
import { CarrierRulesDialogComponent } from "./parent-wizard/update-parent-wizard/step-carriers/view-carriers/carrier-rules-dialog/carrier-rules-dialog.component";
import { AddParentWizardComponent } from "./parent-wizard/add-parent-wizard/add-parent-wizard.component";
import { StepCopyParentComponent } from "./parent-wizard/add-parent-wizard/step-copy-parents/step-copy-parents.component";
import { StepCopyCarrierGroupsComponent } from "./parent-wizard/add-parent-wizard/step-copy-carrier-groups/step-copy-carrier-groups.component";
import { StepCopyCarriersComponent } from "./parent-wizard/add-parent-wizard/step-copy-carriers/step-copy-carriers.component";
import { DataConfigMappingComponent } from "./data-config-mapping-wizard/data-config-mapping-wizard";
import { ParentComponent } from "./parent-wizard/parent-wizard";
import { OrderTypesComponent } from "./order-types-wizard/order-types-wizard";
import { AddOrderTypesComponent } from "./order-types-wizard/add-order-types/add-order-types.component";
import { EditOrderTypesComponent } from "./order-types-wizard/edit-order-types/edit-order-types.component";
import { ThrottleWizardComponent } from "./throttle-wizard/throttle-wizard";
import { AddThrottleWizardComponent } from "./throttle-wizard/add-throttle/add-throttle.component";
import { EditThrottleWizardComponent } from "./throttle-wizard/edit-throttle/edit-throttle.component";
import { AddThrottleFeatureComponent } from "./throttle-wizard/add-throttle/add-throttle-feature/add-throttle-feature.component";
import { AddThrottlePolicyComponent } from "./throttle-wizard/add-throttle/add-throttle-policy/add-throttle-policy.component";
import { AddThrottleRuleComponent } from "./throttle-wizard/add-throttle/add-throttle-rule/add-throttle-rule.component";
import { EditThrottleFeatureComponent } from "./throttle-wizard/edit-throttle/edit-throttle-feature/edit-throttle-feature.component";
import { EditThrottlePolicyComponent } from "./throttle-wizard/edit-throttle/edit-throttle-policy/edit-throttle-policy.component";
import { EditThrottleRuleComponent } from "./throttle-wizard/edit-throttle/edit-throttle-rule/edit-throttle-rule.component";
import { EditThrottleRuleSummaryTab } from "./throttle-wizard/edit-throttle/edit-throttle-rule/edit-throttle-rule-summary/edit-throttle-rule-summary-tab";
import { EditThrottleRuleCopyTab } from "./throttle-wizard/edit-throttle/edit-throttle-rule/edit-throttle-rule-copy/edit-throttle-rule-copy-tab";
import { EditThrottleRuleAddTab } from "./throttle-wizard/edit-throttle/edit-throttle-rule/edit-throttle-rule-add/edit-throttle-rule-add-tab";
import { EditThrottleFeatureSummaryTab } from "./throttle-wizard/edit-throttle/edit-throttle-feature/edit-throttle-feature-summary/edit-throttle-feature-summary-tab";
import { EditThrottleFeatureCopyTab } from "./throttle-wizard/edit-throttle/edit-throttle-feature/edit-throttle-feature-copy/edit-throttle-feature-copy-tab";
import { EditThrottleFeatureAddTab } from "./throttle-wizard/edit-throttle/edit-throttle-feature/edit-throttle-feature-add/edit-throttle-feature-add-tab";
import { ConfirmationService } from "primeng/api";
import { AddThrottleFeatureAddTab } from "./throttle-wizard/add-throttle/add-throttle-feature/add-throttle-feature-add/add-throttle-feature-add-tab";
import { AddThrottleFeatureCopyTab } from "./throttle-wizard/add-throttle/add-throttle-feature/add-throttle-feature-copy/add-throttle-feature-copy-tab";
import { AddThrottleFeatureSummaryTab } from "./throttle-wizard/add-throttle/add-throttle-feature/add-throttle-feature-summary/add-throttle-feature-summary-tab";
import { AddThrottleRuleAddTab } from "./throttle-wizard/add-throttle/add-throttle-rule/add-throttle-rule-add/add-throttle-rule-add-tab";
import { AddThrottleRuleSummaryTab } from "./throttle-wizard/add-throttle/add-throttle-rule/add-throttle-rule-summary/add-throttle-rule-summary-tab";
import { AddThrottleRuleCopyTab } from "./throttle-wizard/add-throttle/add-throttle-rule/add-throttle-rule-copy/add-throttle-rule-copy-tab";
import { VerizonZipNPANXXComponent } from "./verizon-zip-npanxx-wizard/verizon-zip-npanxx-wizard";
import { UpdateVerizonZipNPANXXComponent } from "./verizon-zip-npanxx-wizard/update-verizon-zip-npanxx/update-verizon-zip-npanxx";
import { AddVerizonZipNPANXXComponent } from "./verizon-zip-npanxx-wizard/add-verizon-zip-npanxx/add-verizon-zip-npanxx";
import { BulkInsertVerizonZipNPANXXComponent } from "./verizon-zip-npanxx-wizard/bulk-insert-verizon-zip-npanxx/bulk-insert-vzn";
import { SummaryVerizonZipNPANXXComponent } from "./verizon-zip-npanxx-wizard/bulk-summary-verizon-zip-npanxx/bulk-summary-verizon-zip-npanxx";
import { TmoZipNgpComponent } from "./tmo-zip-ngp-wizard/tmo-zip-ngp-wizard";
import { AddTmoZipNgpComponent } from "./tmo-zip-ngp-wizard/add-tmo-zip-ngp/add-tmo-zip-ngp";
import { BulkInsertTmoZipNgpComponent } from "./tmo-zip-ngp-wizard/bulk-insert-tmo-zip-ngp/bulk-insert-tmo-zip-ngp";
import { BulkSummaryTmoZipNgpComponent } from "./tmo-zip-ngp-wizard/bulk-summary-tmo-zip-ngp/bulk-summary-tmo-zip-ngp";
import { UpdateTmoZipNgpComponent } from "./tmo-zip-ngp-wizard/update-tmo-zip-ngp/update-tmo-zip-ngp";
import { CingularMrktInfoComponent } from "./cingular-mrkt-info/cingular-mrkt-info";
import { AddCingularMrktInfoComponent } from "./cingular-mrkt-info/add-cingular-mrkt-info/add-cingular-mrkt-info";
import { BulkInsertCingularMrktInfoComponent } from "./cingular-mrkt-info/bulk-insert-cingular-mrkt-info/bulk-insert-cingular-mrkt-info";
import { BulkSummaryCingularMrktInfoComponent } from "./cingular-mrkt-info/bulk-summary-cingular-mrkt-info/bulk-summary-cingular-mrkt-info";
import { UpdateCingularMrktInfoComponent } from "./cingular-mrkt-info/update-cingular-mrkt-info/update-cingular-mrkt-info";
import { NotCertifyModelComponent } from "./not-certify-model/not-certify-model";
import { AddNotCertifyModelComponent } from "./not-certify-model/add-not-certify-model/add-not-certify-model";
import { UpdateNotCertifyModelComponent } from "./not-certify-model/update-not-certify-model/update-not-certify-model";
import { BulkInsertNotCertifyModelComponent } from "./not-certify-model/bulk-insert-not-certify-model/bulk-insert-not-certify-model";
import { BulkSummaryNotCertifyModelComponent } from "./not-certify-model/bulk-summary-not-certify-model/bulk-summary-not-certify-model";
import { CarriersimprefComponent } from "./carriersimpref/carriersimpref.component";
import { AddCarriersimprefComponent } from "./carriersimpref/add-carriersimpref/add-carriersimpref.component";
import { BulkInsertCarriersimprefComponent } from "./carriersimpref/bulk-insert-carriersimpref/bulk-insert-carriersimpref";
import { BulkSummaryCarriersimprefComponent } from "./carriersimpref/bulk-summary-carriersimpref/bulk-summary-carriersimpref";
import { UpdateCarriersimprefComponent } from "./carriersimpref/update-carriersimpref/update-carriersimpref.component";
import { Npanxx2CarrierZonesComponent } from "./npanxx2carrierzones/npanxx2carrierzones.component";
import { AddNpanxx2CarrierZonesComponent } from "./npanxx2carrierzones/add-npanxx2carrierzones/add-npanxx2carrierzones.component";
import { BulkInsertNpanxx2carrierzonesComponent } from "./npanxx2carrierzones/bulk-insert-npanxx2carrierzones/bulk-insert-npanxx2carrierzones";
import { BulkSummaryNpanxx2CarrierZonesComponent } from "./npanxx2carrierzones/bulk-summary-npanxx2carrierzones/bulk-summary-npanxx2carrierzones";
import { UpdateNpanxx2CarrierZonesComponent } from "./npanxx2carrierzones/update-npanxx2carrierzones/update-npanxx2carrierzones.component";
import { AddPostalZipsComponent } from "./postal-zips/add-postal-zips/add-zips.component";
import { UpdatePostalZipsComponent } from "./postal-zips/update-postal-zips/update-zips.component";
import { PostalZipsComponent } from "./postal-zips/postal-zips.component";
import { ArUsaMarketComponent } from "./ar-usa-market/ar-usa-marketcomponent";
import { AddArUsaMarketComponent } from "./ar-usa-market/add-ar-usa-market/add-ar-usa-market.component";
import { UpdateArUsaMarketComponent } from "./ar-usa-market/update-ar_usa_market/update-ar-usa-market.component";
import { BulkInsertArUsaMarketComponent } from "./ar-usa-market/bulk-add-ar-usa-market/bulk-add-ar-usa-market.component";
import { BulkInsertSummaryArUsaMarketComponent } from "./ar-usa-market/bulk-insert-summary-ar-usa-market/bulk-insert-summary-ar-usa-market.component";
import { BulkInsertPostalZipsComponent } from "./postal-zips/bulk-add-postal-zips/bulk-add-postal-zips.component";
import { BulkInsertSummaryPostalZipsComponent } from "./postal-zips/bulk-insert-summary-postal-zips/bulk-insert-summary-postal-zips.component";
import { BulkGeoLocComponent } from "./geo-loc/bulk-opr-geo-loc/bulk-opr-geo.component";
import { UpdateGeoLocComponent } from "./geo-loc/update-geo-loc/update-geo.component";
import { AddGeoLocComponent } from "./geo-loc/add-geo-loc/add-geo.component";
import { GeoLocComponent } from "./geo-loc/geo-loc.component";
import { SummaryGeoLocComponent } from "./geo-loc/geo-loc-summary/geo-loc-summary.component";
import { AddCarrierZonesComponent } from "./carrier-zones/add-carrier-zones/add-carrier-zones.component";
import { CarrierZonesComponent } from "./carrier-zones/carrier-zones.component";
import { SearchCarrierZonesComponent } from "./carrier-zones/search-carrier-zones/search-carrier-zones.component";
import { BulkOperationCarrierZonesComponent } from "./carrier-zones/bulk-operation/bulk-operation.component";
import { SummaryCarrierZonesComponent } from "./carrier-zones/carrier-zones-summary/carrier-zones-summary.component";
import { ExportToCsvService } from "../../../Services/export-to-csv.service";
import { BulkDeletePostalZipsComponent } from "./postal-zips/bulk-delete-postal-zips/bulk-delete-postal-zips.component";
import { BulkDeleteArUsaMarketComponent } from "./ar-usa-market/bulk-delete-ar-usa-market/bulk-delete-ar-usa-market.component";
import { BulkDeleteNpaNxx2CarrrierZonesComponent } from "./npanxx2carrierzones/bulk-delete-npanxx2-carrier-zones/bulk-delete-npanxx2-carrier-zones.component";

@NgModule({
    imports: [
        CommonModule,
        CarrierMaintenanceRoutingModule,
        PageHeaderModule,
        PrimengTreeTableModule,
        FormsModule,
        ReactiveFormsModule,
        NgxDatatableModule,
        MatAutocompleteModule,
        MatBadgeModule,
        MatBottomSheetModule,
        MatButtonModule,
        MatButtonToggleModule,
        MatCardModule,
        MatCheckboxModule,
        MatChipsModule,
        MatStepperModule,
        MatDatepickerModule,
        MatDialogModule,
        MatDividerModule,
        MatExpansionModule,
        MatGridListModule,
        MatIconModule,
        MatListModule,
        MatMenuModule,
        MatNativeDateModule,
        MatPaginatorModule,
        MatProgressBarModule,
        MatProgressSpinnerModule,
        MatRadioModule,
        MatRippleModule,
        MatSelectModule,
        MatSidenavModule,
        MatSliderModule,
        MatSlideToggleModule,
        MatSnackBarModule,
        MatSortModule,
        MatTableModule,
        MatToolbarModule,
        MatTooltipModule,
        MatTreeModule,
        MatInputModule,
        MatTabsModule,
        MatButtonModule,
        MatButtonToggleModule,
        ConfirmDialogModule,
        BreadcrumbModule,
        NgbModule.forRoot(),
        TreeTableModule,
        TableModule,
    ],
    declarations: [
        CarrierMaintenanceComponent,
        UpdateParentWizardComponent,
        StepParentComponent,
        StepCarrierGroupsComponent,
        ViewCarrierGroupsComponent,
        StepCarriersComponent,
        CopyCarrierGroupsComponent,
        ViewCarriersComponent,
        UpdateCarrierDialogComponent,
        OrderTypesDialogComponent,
        ViewOrderTypesComponent,
        CopyOrderTypesComponent,
        CopyCarriersComponent,
        AddDataConfigMappingComponent,
        EditDataConfigMappingComponent,
        CarrierRulesDialogComponent,
        AddParentWizardComponent,
        StepCopyParentComponent,
        StepCopyCarrierGroupsComponent,
        StepCopyCarriersComponent,
        DataConfigMappingComponent,
        ParentComponent,
        OrderTypesComponent,
        AddOrderTypesComponent,
        EditOrderTypesComponent,
        ThrottleWizardComponent,
        AddThrottleWizardComponent,
        EditThrottleWizardComponent,
        AddThrottleFeatureComponent,
        AddThrottlePolicyComponent,
        AddThrottleRuleComponent,
        EditThrottleFeatureComponent,
        EditThrottlePolicyComponent,
        EditThrottleRuleComponent,
        EditThrottleRuleSummaryTab,
        EditThrottleRuleCopyTab,  
        EditThrottleRuleAddTab,    
        EditThrottleFeatureSummaryTab, 
        EditThrottleFeatureCopyTab, 
        EditThrottleFeatureAddTab,
        AddThrottleRuleAddTab,
        AddThrottleRuleSummaryTab,
        AddThrottleRuleCopyTab,
        AddThrottleFeatureAddTab,
        AddThrottleFeatureCopyTab,
        AddThrottleFeatureSummaryTab,
        VerizonZipNPANXXComponent,
        UpdateVerizonZipNPANXXComponent,
        AddVerizonZipNPANXXComponent,
        BulkInsertVerizonZipNPANXXComponent,
        SummaryVerizonZipNPANXXComponent,
        TmoZipNgpComponent,
        AddTmoZipNgpComponent,
        BulkInsertTmoZipNgpComponent,
        BulkSummaryTmoZipNgpComponent,
        UpdateTmoZipNgpComponent,
        CingularMrktInfoComponent,
        AddCingularMrktInfoComponent,
        BulkInsertCingularMrktInfoComponent,
        BulkSummaryCingularMrktInfoComponent,
        UpdateCingularMrktInfoComponent,
        NotCertifyModelComponent,
        AddNotCertifyModelComponent,
        UpdateNotCertifyModelComponent,
        BulkInsertNotCertifyModelComponent,
        BulkSummaryNotCertifyModelComponent,
        CarriersimprefComponent,
        AddCarriersimprefComponent,
        BulkInsertCarriersimprefComponent,
        BulkSummaryCarriersimprefComponent,
        UpdateCarriersimprefComponent,
        Npanxx2CarrierZonesComponent,
        AddNpanxx2CarrierZonesComponent,
        BulkInsertNpanxx2carrierzonesComponent,
        BulkSummaryNpanxx2CarrierZonesComponent,
        UpdateNpanxx2CarrierZonesComponent,
        PostalZipsComponent,UpdatePostalZipsComponent,
        AddPostalZipsComponent,
        ArUsaMarketComponent,
        AddArUsaMarketComponent,
        UpdateArUsaMarketComponent,
        BulkInsertArUsaMarketComponent,
        BulkInsertSummaryArUsaMarketComponent,
        BulkInsertPostalZipsComponent,
        BulkInsertSummaryPostalZipsComponent,
        GeoLocComponent, UpdateGeoLocComponent, BulkGeoLocComponent, AddGeoLocComponent, SummaryGeoLocComponent,
        CarrierZonesComponent,
        AddCarrierZonesComponent,
        SearchCarrierZonesComponent,
        BulkOperationCarrierZonesComponent,
        SummaryCarrierZonesComponent,
        BulkDeletePostalZipsComponent,
        BulkDeleteArUsaMarketComponent,
        BulkDeleteNpaNxx2CarrrierZonesComponent
    ],
    providers: [UpdateParentService,CarrierMaintenanceHelper,ConfirmationService,ExportToCsvService],
    entryComponents: [UpdateCarrierDialogComponent, OrderTypesDialogComponent, CarrierRulesDialogComponent, EditThrottleFeatureComponent, AddThrottleFeatureComponent, BulkInsertVerizonZipNPANXXComponent, BulkInsertTmoZipNgpComponent, BulkInsertCingularMrktInfoComponent, BulkInsertNotCertifyModelComponent, BulkInsertCarriersimprefComponent,BulkInsertNpanxx2carrierzonesComponent,BulkInsertArUsaMarketComponent,BulkInsertPostalZipsComponent,BulkDeletePostalZipsComponent,BulkDeleteArUsaMarketComponent,BulkDeleteNpaNxx2CarrrierZonesComponent]
})
export class CarrierMaintenanceModule { }
