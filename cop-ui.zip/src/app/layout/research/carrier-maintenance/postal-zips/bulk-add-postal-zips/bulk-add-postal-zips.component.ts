import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { ToasterService } from "../../../../../Services/toaster.service";
import { ExportToCsvService } from "../../../../../Services/export-to-csv.service";
import { ImportFromCsvService } from "../../../../../Services/import-from-csv.service";
import { MatDialogRef } from "@angular/material";

@Component({
    selector: 'bulk-add-postal-zips',
    templateUrl: './bulk-add-postal-zips.component.html',
    styleUrls: ['./bulk-add-postal-zips.component.scss',
        "../../../../components/ngxtable/material.scss",
        "../../../../components/ngxtable/datatable.component.scss",
        "../../../../components/ngxtable/icons.css",
        "../../../../components/ngxtable/app.css"],
    animations: [],
    encapsulation: ViewEncapsulation.None,
    providers: [ExportToCsvService, ImportFromCsvService]
})

export class BulkInsertPostalZipsComponent implements OnInit {
    public multiColumnEditColumns = [];
    public fileContent: Boolean;
    public filename: string = null;
    public uploadedData: any = [];
    public uploadedMainData: any = [];
    public alerts: any = [];
    public exportColumns = [];
    public tableColmns = [];
    readonly EXPORT_FILE_NAME = "Insert_PostalZips_template";
    public showLoadingScreen: Boolean = false;
    public showMssg = false;

    constructor(
        private toasterService: ToasterService,
        private exportToCsvService: ExportToCsvService,
        private importFromCsvService: ImportFromCsvService,
        public dialogRef: MatDialogRef<BulkInsertPostalZipsComponent>,
    ) { dialogRef.disableClose = true;  }

    ngOnInit() {
        this.fileContent = false;
        this.filename = "";
        this.uploadedData = [];
        this.uploadedMainData = [];
        this.alerts = [];
        this.exportColumns = ["Postal Code","Key Code","State","City"];
                              
        this.tableColmns = [
            { name: 'Postal Code', prop: 'postalCode', width: "80" },
            { name: 'Key Code', prop: 'keyCode', width: "90" },
            { name: 'State', prop: 'state', width: "200" },
            { name: 'City', prop: 'city', width: "200" },
        ];
        this.showMssg = false;
    }

    //Used to Download Template
    exportToCSV() {
        this.exportToCsvService.downloadFile([], this.EXPORT_FILE_NAME, this.exportColumns);
    }

    saveUploadDialog() {
        if (document.getElementsByClassName("tableError") && document.getElementsByClassName("tableError").length > 0) {
            this.toasterService.showErrorMessage("Please fix validation errors.");
            return;
        }
        for(let i=0;i<this.uploadedMainData.length;i++){
            delete this.uploadedMainData[i]['Postal Code'];
            delete this.uploadedMainData[i]['Key Code'];
            delete this.uploadedMainData[i]['State'];
            delete this.uploadedMainData[i]['City']; 
        }
        let uploadData = [];
        
        uploadData = this.uploadedMainData.filter((v,i,a)=>a.findIndex(t=>
            (t.postalCode == v.postalCode))===i)           
        this.dialogRef.close(uploadData);
    }

    //Read File and show data on the table
    public changeListener(files: FileList) {
        let invalidFile = "Please select a valid file to upload.";
        let noDataInFile = "There is no data to upload in this file.";
        let limitExceed = "You cannot insert more than 500 records at a time.";
        this.alerts = [];
        if (files && files.length > 0) { 
            this.fileContent = true;
            let file: File = files.item(0);
            let name = file.name;
            var ext = name.substring(name.lastIndexOf('.') + 1);
            if (ext.toLowerCase() == 'csv') {
                this.filename = name.substr(0, name.lastIndexOf("."));
                if (this.filename.split(" ")[0] != this.EXPORT_FILE_NAME) {
                    this.toasterService.showErrorMessage(invalidFile);
                    return;
                }
            } else {
                this.toasterService.showErrorMessage(invalidFile);
                return;
            }
            let reader: FileReader = new FileReader();
            reader.readAsText(file);
            reader.onload = (e) => {
                let uploadData = this.importFromCsvService.csvToArray(reader.result);
                if (uploadData.length == 0) {
                    this.toasterService.showErrorMessage(noDataInFile);
                } else if (uploadData.length > 500) {
                    this.toasterService.showErrorMessage(limitExceed);
                } else {
                    let keys = Object.keys(uploadData[0]);
                    for (let i = 1, j = 0; j < this.exportColumns.length; i++, j++) {
                        if (keys[i] != this.exportColumns[j]) {
                            this.toasterService.showErrorMessage(invalidFile);
                            return;
                        }
                    }
                    uploadData.forEach(_e1 => {
                        _e1.postalCode = _e1['Postal Code'];
                        _e1.keyCode= _e1['Key Code'];
                        _e1.state = _e1['State'];
                        _e1.city = _e1['City'];
                    });
                    this.uploadedData = [...this.checkUploadedData(uploadData)];
                }
            }
        }
    }

    //Removes file and table from the screen
    public removeFile() {
        this.fileContent = false;
        this.filename = null;
        this.uploadedData = [];
        this.uploadedMainData = [];
        this.alerts = [];
    }

    public checkUploadedData(data) {
        let errorData = [];
        let successData = [];
        data.forEach(element => {
            element.rowNum = element['S.NO'];
        });
        data.forEach(element => {
            if (element.rowNum.length == 0 || element["Postal Code"].length == 0 || element["Key Code"].length == 0  || element["City"].length == 0 || element["State"].length == 0 
            || element["Postal Code"].length > 5 || element["Key Code"].length > 15 || element["City"].length > 50 || element["State"].length > 2) {
                errorData.push(element);
            } else
            successData.push(element);
        });
        this.uploadedMainData = [...errorData, ...successData];
        return this.uploadedMainData;
    }

    //Removes Row from the table
    deleteRow(row) {
        this.uploadedMainData.forEach((data, key) => {
            if (row.rowNum == data.rowNum) {
                this.uploadedMainData.splice(key, 1);
            }
        });
        this.uploadedData = [...this.uploadedMainData];
    }

    //inline values changes
    public editValueChanged(event, column, row, oldValue) {
        for (let i = 0; i < this.uploadedMainData.length; i++) {
            if (this.uploadedMainData[i].rowNum == row.rowNum) {
                this.uploadedMainData[i][column] = event.target.value;
            }
        }
        this.uploadedData = [...this.uploadedMainData];
    }

     //Filter for result table
     public filterTableData(event) {
        const val = event.target.value.toLowerCase();
        // filter our data
        const temp = this.uploadedMainData.filter(function (d) {
            return (d.postalCode ? d.postalCode.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.keyCode ? d.keyCode.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.state ? d.state.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.city ? d.city.toLowerCase().indexOf(val) !== -1 : !val) || !val
        });
        // update the rows
        this.uploadedData = temp;
    }
    
    cancelUploadDialog(): void {
        this.dialogRef.close();
    }

}