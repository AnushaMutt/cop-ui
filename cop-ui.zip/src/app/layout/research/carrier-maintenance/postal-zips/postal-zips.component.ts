import { Component, OnInit, ViewChild } from "@angular/core";
import { NgbTabset} from '@ng-bootstrap/ng-bootstrap';


@Component({
    selector: 'postal-zips',
    templateUrl: './postal-zips.component.html',
})
export class PostalZipsComponent implements OnInit {
    @ViewChild('tabs')
	private tabs: NgbTabset;
    readonly SUMMARY_TAB = "summaryTab";

    constructor() { }

    ngOnInit() { }


public returnedDatas(data) {
    if (data.lastInsertedRecord) {
        this.tabs.select(this.SUMMARY_TAB);
      }
}

}