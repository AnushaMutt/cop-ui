import { Component, OnInit, ViewEncapsulation, ViewChildren, Output, EventEmitter, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { ConfirmationService } from 'primeng/primeng';
import { takeUntil } from 'rxjs/operators';
import { Subject } from "rxjs";
import { CarrierMaintenanceService } from '../../../../../Services/carrierMaintenance.service';
import { CarrierMaintenanceHelper } from "../../carrier-maintenance-helper";
import { ToasterService } from "../../../../../Services/toaster.service";
import { MatDialog } from "@angular/material";
import { MatSelect } from "@angular/material";
import { ExportToCsvService } from "../../../../../Services/export-to-csv.service";
import { BulkDeletePostalZipsComponent } from "../bulk-delete-postal-zips/bulk-delete-postal-zips.component";


@Component({
    selector: 'update-postal-zips',
    templateUrl: './update-zips.component.html',
    styleUrls: ['./update-zips.component.scss',
        "../../../../components/ngxtable/material.scss",
        "../../../../components/ngxtable/datatable.component.scss",
        "../../../../components/ngxtable/icons.css",
        "../../../../components/ngxtable/app.css"],
    animations: [],
    encapsulation: ViewEncapsulation.None,
})

export class UpdatePostalZipsComponent implements OnInit {
    public showLoadingScreen = false;
    public alreadyEnabled = true;
    public filteredRows: any;

    private unsubscribe = new Subject<void>();
    public searchFromGroup: FormGroup;
    public errorMessage = "";
    public isEditable = {};
    public filteredValues: any = {};
    public selected = [];
    public editAlreadyEnabled = false;
    public postalZipsColumns: any = [];
    public postalZipsMainData: any = [];
    public postalZipsData: any = [];
    private editedRow: any = {};
    public defaultEditedRow: any = {};
    public checkDuplicate = false;
    public selectedPostalZipsTechs = [];
    public bulkEditColumns = [];
    public showBulkUpdateButton = false;
    public otherColumn: boolean = false;
    public bulkEditBoolean: boolean;
    @ViewChild('multicolumnEditValue') multicolumnEditValue: any;
    public tableFrmGroupMain: FormGroup;
    public alerts = [];


    constructor(
        private formBuilder: FormBuilder,
        private toasterService: ToasterService,
        private wizardHelper: CarrierMaintenanceHelper,
        private confirmationService: ConfirmationService,
        private wizardService: CarrierMaintenanceService,
        private exportToCsvService :ExportToCsvService,
        public dialog: MatDialog
    ) { }

    ngOnInit() {
        this.createSearchFormGroup();
        this.createTableForm();
        this.postalZipsColumns = [
            { name: 'Postal Code', prop: 'postalCode', width: "80" },
            { name: 'Key Code', prop: 'keyCode', width: "90" },
            { name: 'State', prop: 'state', width: "200" },
            { name: 'City', prop: 'city', width: "200" },
        ];
        this.bulkEditColumns = [...this.postalZipsColumns];

    }

    //Filter Table data based on all the columns values
    public filterPostalZips(event) {
        let val: any;
        if (event.target)
            val = event.target.value.toLowerCase();
        else
            val = event.toLowerCase();
        // filter our data
        const temp = this.postalZipsMainData.filter(function (d) {
            return (d.postalCode ? d.postalCode.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.keyCode ? d.keyCode.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.state ? d.state.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.city ? d.city.toLowerCase().indexOf(val) !== -1 : !val) || !val
        });
        // update the rows
        this.postalZipsData = temp;
    }



    bulkUpdateColumn(column) {
        if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
            this.toasterService.showErrorMessage(
                this.wizardHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            return;
        }
        this.showLoadingScreen = true;
        let requestObj = [];
        this.selectedPostalZipsTechs.forEach(e => {
            let obj: any = {};
            if (column == "City") {
                obj.city = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.city = e.city;
            }
            if (column == "State") {
                obj.state = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.state = e.state;
            }
            if (column == "Key Code") {
                obj.keyCode = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.keyCode = e.keyCode;
            }
            if (column == "Postal Code") {
                obj.postalCode = this.multicolumnEditValue.nativeElement.value;
                obj.oldPostalCode = e.postalCode;
                obj.checkDuplicate = true;
            } else {
                obj.postalCode = e.postalCode;
                obj.oldPostalCode = e.postalCode;
                obj.checkDuplicate = false;
            }


            requestObj.push(obj);
        });

        this.bulkUpdatePostalZips(requestObj);
    }

    public bulkUpdatePostalZips(request) {
        this.wizardService.bulkUpdatePostalZips(request).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_BULK_UPDATE_POSTAL_ZIPS_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    this.showLoadingScreen = false;
                    this.alreadyEnabled = true;
                    this.editAlreadyEnabled = false;
                    this.bulkEditBoolean = false;
                    this.otherColumn = false;
                    this.showBulkUpdateButton = false;
                    this.selectedPostalZipsTechs = [];
                    this.selected = [];
                    this.editedRow = {};
                    this.defaultEditedRow = {};
                    // this.searchForm();

                    this.toasterService.showSuccessMessage(
                        this.wizardHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_POSTAL_ZIPS_SUCCESS_MESSAGE")
                    );
                    this.searchPostalZips(this.searchFromGroup.value);
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }


    public showBulkUpdateButtonFun(event) {
        if (event)
            this.showBulkUpdateButton = true;
        else
            this.showBulkUpdateButton = false;
    }

    public assignmultiColumnName(column) {
        this.showBulkUpdateButton = false;
        this.otherColumn = true;
    }

    // Checkbox selection from search result table
    public onSelect(row) {
        // this.multiColumnEditSection = true;

        this.selectedPostalZipsTechs = [];
        if (row && row.selected) {
            for (let i = 0; i < row.selected.length; i++) {
                let obj = { ...row.selected[i] };
                this.selectedPostalZipsTechs.push(obj);
            }
        }
        this.selectedPostalZipsTechs = [...this.selectedPostalZipsTechs]
        if (this.selectedPostalZipsTechs.length == 0) {
            this.bulkEditBoolean = false;
            this.otherColumn = false;

            this.showBulkUpdateButton = false;
            // this.serviceColumnSelected = false;
            // this.techkeyColumnSelected = false;
            // this.productKeyColumnSelected = false;
            // this.bpCodeColumnSelected = false;
        }
    }

    // confirm box
    public showConfirm(row) {
        this.confirmationService.confirm({
            key: 'confirm-delete-postalZips',
            message: "Are you sure you want to delete Postal Zips ?",
            accept: () => {
                this.deletePostalZips(row);
            }
        });
    }

    public deletePostalZips(row) {
        this.showLoadingScreen = true;
        let obj: any = {};
        obj.postalCode = row.postalCode;
        this.wizardService.deletePostalZips(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DELETE_POSTAL_ZIPS_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        return;
                    }
                    this.toasterService.showSuccessMessage(
                        this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DELETE_POSTAL_ZIPS_SUCCESS_MESSAGE")
                    );
                    // this.revert();
                    this.postalZipsMainData = [];
                    this.postalZipsData = [];
                    
                    // this.displayTable = false;
                    this.showLoadingScreen = false;
                    this.searchPostalZips(this.searchFromGroup.value);

                },
                (err: any) => {
                    this.showErr(err);
                    return;
                }
            );
    }

    private inputValueChanged(event, column, row, oldValue) {
        this.editedRow[column] = event.target.value;
        this.defaultEditedRow[column] = event.target.defaultValue;

    }

    //Enable inline editing
    public editButtonClicked(rowData, rowIndex) {
        this.editAlreadyEnabled = true;
        this.defaultEditedRow = { ...rowData }
        let alreadyEnabled = false;
        for (let i = 0; i < this.postalZipsColumns.length; i++) {
            if (this.isEditable[i])
                alreadyEnabled = true;
        }
        if (!alreadyEnabled)
            this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        else
            this.toasterService.showErrorMessage(
                this.wizardHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE"),
            );
    }

    // to filter columns
    public filterReportResults(): void {
        const filterFormObject = this.tableFrmGroupMain.value;
        this.filteredValues.postalCode = filterFormObject.postalCode;
        this.filteredValues.keyCode = filterFormObject.keyCode;
        this.filteredValues.state = filterFormObject.state;
        this.filteredValues.city = filterFormObject.city;
        const newRows = Object.keys(filterFormObject).reduce((acc, key) => {
            if (!filterFormObject[key].length) return acc;
            const filteredRows = acc.filter(val => filterFormObject[key].indexOf(val[key]) > -1);
            return filteredRows;
        }, this.postalZipsMainData);

        this.postalZipsData = newRows;
    }

    public generateFilters(): void {
        this.filteredRows = Object.keys(this.postalZipsColumns)
            .map(i => this.postalZipsColumns[i].prop)
            .reduce((filterObject, columnName) => {
                const uniqueValuesPerRow = this.postalZipsData.reduce((set, row) => set.add(row[columnName]), new Set());
                let val: any = Array.from(uniqueValuesPerRow);
                if (/^[0-9]*$/.test(val[0])) {
                    filterObject[columnName] = val.sort(function (a, b) { return a - b });
                } else {
                    filterObject[columnName] = val.sort((a, b) => {
                        a = a || '';
                        b = b || '';
                        return a.localeCompare(b);
                    });
                }
                return filterObject;
            }, {});
    }


    //to cancel update
    public cancelEditForm(rowData, rowIndex) {
        this.showLoadingScreen = true;
        this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        this.postalZipsColumns.forEach(e => {
            if (document.getElementById(e.prop + rowIndex)) {
                (<HTMLInputElement>(
                    document.getElementById(e.prop + rowIndex)
                )).value = rowData[e.prop] || '';
            }
        });
        this.editedRow = {};
        this.showLoadingScreen = false;
        this.editAlreadyEnabled = false;
    }

    searchPostalZips(req) {
        this.showLoadingScreen = true;
        this.otherColumn = false;
        this.selected = [];
        this.isEditable = {};
        this.filteredValues = {};

        let obj: any = {};
        obj.postalCode = req.postalCode;
        obj.keyCode = req.keyCode;
        obj.state = req.state;
        obj.city = req.city;
        obj = this.wizardHelper.checkRequestObject(obj);

        let filterKeys = Object.keys(this.tableFrmGroupMain.controls);
        filterKeys.forEach(_e1 => {
            this.tableFrmGroupMain.controls[`${_e1}`].patchValue([]);
        });

        this.wizardService.searchPostalZips(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_POSTAL_ZIPS_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    this.showLoadingScreen = false;

                    this.postalZipsMainData = data[0];
                    this.postalZipsData = [...this.postalZipsMainData];
                  
                    if (this.filteredValues.mainTableFilter) {
                        this.filterPostalZips(this.filteredValues.mainTableFilter);
                    }
                    this.editAlreadyEnabled = false;
                    if (this.postalZipsMainData && this.postalZipsMainData.length == 0) {
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("NO_POSTAL_ZIPS_FOUND")
                        );
                    }

                    this.generateFilters();
                    this.filterReportResults();

                    this.bulkEditBoolean = false;
                    this.otherColumn = false;
                    this.showBulkUpdateButton = false;
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    public inlineUpdatePostalZips(editData, rowIndex) {
        if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
            this.toasterService.showErrorMessage(
                this.wizardHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            return;
        }
        this.showLoadingScreen = true;

        let obj = { ...editData, ...this.editedRow }
        if (this.editedRow.postalCode) {
            obj.checkDuplicate = true;
        }
        obj.oldPostalCode = editData.postalCode;

        obj = this.wizardHelper.checkRequestObject(obj);
        if(obj.oldPostalCode == obj.postalCode) {
            obj.checkDuplicate = false;
        }
        this.wizardService.updatePostalZips(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_POSTAL_ZIPS_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    // for (let i = 0; i < this.tableRowsMainData.length; i++) {
                    //     if (this.tableRowsMainData[i].rowId == this.defaultEditedRow.rowId) {
                    //         this.tableRowsMainData[i] = obj;
                    //     }
                    // }
                    this.isEditable[rowIndex] = !this.isEditable[rowIndex];
                    this.showLoadingScreen = false;
                    this.editedRow = {};
                    this.defaultEditedRow = {};
                    this.alreadyEnabled = true;
                    this.checkDuplicate = false;
                    this.generateFilters();
                    this.filterReportResults();

                    this.toasterService.showSuccessMessage(
                        this.wizardHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_POSTAL_ZIPS_SUCCESS_MESSAGE")
                    );

                    this.searchPostalZips(this.searchFromGroup.value);
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    createTableForm() {
        this.tableFrmGroupMain = this.formBuilder.group({
            postalCode: [""],
            keyCode: [""],
            state: [""],
            city: [""],
        });
    }

    createSearchFormGroup() {
        this.searchFromGroup = this.formBuilder.group({
            postalCode: [""],
            keyCode: [""],
            state: [""],
            city: [""],
        });
    }

    revert() {
        this.filteredValues = {};
        this.errorMessage = "";
        this.searchFromGroup.reset();
        this.postalZipsData = [];
        this.postalZipsMainData = [];
        let filterKeys = Object.keys(this.tableFrmGroupMain.controls);
        filterKeys.forEach(_e1 => {
            this.tableFrmGroupMain.controls[`${_e1}`].patchValue([]);
        });
        this.otherColumn = false;
        this.alreadyEnabled = true;
    }

    public showErr(err) {
        this.showLoadingScreen = false;
        if (err.error === undefined || err.error === null)
            this.toasterService.showErrorMessage(
                this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
            );
        else if (err.error && err.error.ERR) {
            const commaSeperatedArr = err.error.ERR.split(",");
            for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                if (commaSeperatedArr[i] != "")
                    this.toasterService.showErrorMessage(
                        commaSeperatedArr[i]
                    );
            }
        }
        else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
            return;
        else this.toasterService.showErrorMessage(err.error);
    }

     // to open bulk Delete pop up
  openUploadCSVDialog() {
    const dialogRef = this.dialog.open(BulkDeletePostalZipsComponent, {
        width: "90%",
        height: "90%",
    });
}

 //Used to Download Template
 exportToCSV() {
    let columns = [];
    this.postalZipsColumns.forEach(x=>{
        columns.push(x.prop)            
    })
    this.exportToCsvService.downloadFile(this.selectedPostalZipsTechs, "PostalZipsexport", columns);
}

    /*
* Show error when service returns error
*/
    public showServiceErr(data) {
        const commaSeperatedArr = data[0].ERR.split(",");
        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
            if (commaSeperatedArr[i] != "")
                this.toasterService.showErrorMessage(commaSeperatedArr[i]);
        }
        return;
    }

    public closeAlert(alert: any) {
        const index: number = this.alerts.indexOf(alert);
        this.alerts.splice(index, 1);
      }
}