import { Injectable } from "@angular/core";
import { Subject } from "rxjs";

@Injectable({
    providedIn: "root"
})
export class PostalZipsHelper {
    
    public breadcrumbListUpdate = new Subject<number>();
    public breadcrumbList = [];
    constructor() { }

    public PostalConstantObject = {
    }

    public getTracfoneConstantMethod(msg) {
        return this.PostalConstantObject[msg];
    }

}