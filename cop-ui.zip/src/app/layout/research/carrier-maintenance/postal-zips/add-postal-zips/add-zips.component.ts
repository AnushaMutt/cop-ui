import { Component, OnInit, ViewEncapsulation, ViewChildren, Output, EventEmitter } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { ConfirmationService } from 'primeng/primeng';
import { takeUntil } from 'rxjs/operators';
import { Subject } from "rxjs";
import { CarrierMaintenanceService } from '../../../../../Services/carrierMaintenance.service';
import { CarrierMaintenanceHelper } from "../../carrier-maintenance-helper";
import { ToasterService } from "../../../../../Services/toaster.service";
import { MatDialog } from "@angular/material";
import { MatSelect } from "@angular/material";
import { PostalZiplocalService } from "../postal-zips-service";
import { BulkInsertPostalZipsComponent } from "../bulk-add-postal-zips/bulk-add-postal-zips.component";

@Component({
    selector: 'add-postal-zips',
    templateUrl: './add-zips.component.html',
    styleUrls: ['./add-zips.component.scss',
        "../../../../components/ngxtable/material.scss",
        "../../../../components/ngxtable/datatable.component.scss",
        "../../../../components/ngxtable/icons.css",
        "../../../../components/ngxtable/app.css"],
    animations: [],
    encapsulation: ViewEncapsulation.None,
})

export class AddPostalZipsComponent implements OnInit {
    @ViewChildren(DatatableComponent)
    table: any;
    public showLoadingScreen = false;
    public alerts = [];
    private unsubscribe = new Subject<void>();
    public addFromGroup: FormGroup;
    public displayTable = false;
    private checkedAnother = false;
    public postalZipsColumns: any = [];
    public postalZipsMainData: any = [];
    public postalZipsData: any = [];
    public selected = [];
    public isEditable = {};
    public editAlreadyEnabled = false;
    public defaultEditedRow: any = {};
    private editedRow: any = {};
    public checkDuplicate = false;
    public alreadyEnabled = true;
    public filteredValues: any = {};
    public bulkInsertData = [];
    public showMssg = false;
    @Output("returnedData") returnedData: any = new EventEmitter();



    constructor(
        private formBuilder: FormBuilder,
        private toasterService: ToasterService,
        private wizardHelper: CarrierMaintenanceHelper,
        private confirmationService: ConfirmationService,
        private wizardService: CarrierMaintenanceService,
        private postalZiplocalService: PostalZiplocalService,
        public dialog: MatDialog
    ) { }

    ngOnInit() {
        this.createAddFormGroup();
        this.postalZiplocalService.setAddData([]);
        this.postalZipsColumns = [
            { name: 'Postal Code', prop: 'postalCode', width: "80" },
            { name: 'Key Code', prop: 'keyCode', width: "90" },
            { name: 'State', prop: 'state', width: "200" },
            { name: 'City', prop: 'city', width: "200" },
        ];
        this.showMssg =false ; 
    }

    createAddFormGroup() {
        this.addFromGroup = this.formBuilder.group({
            postalCode: ["", [Validators.required, Validators.maxLength(5)]],
            keyCode: ["", [Validators.required, Validators.maxLength(15)]],
            state: ["", [Validators.required, Validators.maxLength(50)]],
            city: ["", [Validators.required, Validators.maxLength(50)]],
        });
    }

    public inlineUpdatePostalZips(editData, rowIndex) {
        if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
            this.toasterService.showErrorMessage(
                this.wizardHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            return;
        }
        this.showLoadingScreen = true;

        let obj = { ...editData, ...this.editedRow }
        if (this.editedRow.postalCode) {
            obj.checkDuplicate = true;
        }
        obj.oldPostalCode = editData.postalCode;

        obj = this.wizardHelper.checkRequestObject(obj);

        if (obj.oldPostalCode == obj.postalCode) {
            obj.checkDuplicate = false;
        }

        this.wizardService.updatePostalZips(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_POSTAL_ZIPS_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    for (let i = 0; i < this.postalZipsMainData.length; i++) {
                        if (this.postalZipsMainData[i].rowId == this.defaultEditedRow.rowId) {
                            this.postalZipsMainData[i] = obj;
                        }
                    }

                    this.isEditable[rowIndex] = !this.isEditable[rowIndex];
                    this.showLoadingScreen = false;
                    this.editedRow = {};
                    this.defaultEditedRow = {};
                    this.postalZipsData = [...this.postalZipsMainData];
                    this.alreadyEnabled = true;
                    // this.generateFilters();
                    // this.filterReportResults();

                    this.checkDuplicate = false;

                    this.toasterService.showSuccessMessage(
                        this.wizardHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_POSTAL_ZIPS_SUCCESS_MESSAGE")
                    );

                    this.editAlreadyEnabled = false;
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    //to cancel update
    private cancelEditForm(rowData, rowIndex) {
        this.showLoadingScreen = true;
        this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        this.postalZipsColumns.forEach(e1 => {
            if (document.getElementById(e1.prop + rowIndex)) {
                (<HTMLInputElement>(
                    document.getElementById(e1.prop + rowIndex)
                )).value = rowData[e1.prop] || '';
            }
        });
        this.editAlreadyEnabled = false;
        this.editedRow = {};
        this.defaultEditedRow = {};
        this.showLoadingScreen = false;
        this.alreadyEnabled = true;
        this.checkDuplicate = false;
    }

    private inputValueChanged(event, column, row, oldValue) {
        this.editedRow[column] = event.target.value;
        this.defaultEditedRow[column] = event.target.defaultValue;

    }

    // confirm box
    public showConfirm(row) {
        this.confirmationService.confirm({
            key: 'confirm-delete-postalZips',
            message: "Are you sure you want to delete Postal Zips ?",
            accept: () => {
                this.deletePostalZips(row);
            }
        });
    }

    public deletePostalZips(row) {
        this.showLoadingScreen = true;
        let obj: any = {};
        obj.postalCode = row.postalCode;
        this.wizardService.deletePostalZips(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DELETE_POSTAL_ZIPS_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        return;
                    }
                    this.toasterService.showSuccessMessage(
                        this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DELETE_POSTAL_ZIPS_SUCCESS_MESSAGE")
                    );

                    this.postalZipsData.forEach((rec: any, key) => {
                        if (obj.postalCode == rec.postalCode) {
                            this.postalZipsData.splice(key, 1);
                            this.postalZiplocalService.getAddData().splice(key, 1);
                        }
                    });
                    this.postalZipsData = [...this.postalZipsData];
                    this.postalZipsMainData = [...this.postalZipsData];
                    if (this.postalZipsData.length === 0) {
                        this.displayTable = false;
                        this.checkedAnother = false;
                        this.postalZipsData = [];
                        this.revert();
                        this.postalZiplocalService.setAddData([]);
                    }

                    // this.revert();
                    // this.displayTable = false;
                    this.showLoadingScreen = false;

                },
                (err: any) => {
                    this.showErr(err);
                    return;
                }
            );
    }


    revert() {
        this.addFromGroup.reset();
        this.postalZipsData = [];
        this.postalZipsMainData = [];
    }

    onChangeCheckbox(event) {
        if (event.checked) this.checkedAnother = true;
        else this.checkedAnother = false;
    }

    //Enable inline editing
    public editButtonClicked(rowData, rowIndex) {
        this.editAlreadyEnabled = true;
        this.defaultEditedRow = { ...rowData }
        let alreadyEnabled = false;
        for (let i = 0; i < this.postalZipsColumns.length; i++) {
            if (this.isEditable[i])
                alreadyEnabled = true;
        }
        if (!alreadyEnabled)
            this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        else
            this.toasterService.showErrorMessage(
                this.wizardHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE"),
            );
    }

    //Filter Table data based on all the columns values
    public filterPostalZips(event) {
        let val: any;
        if (event.target)
            val = event.target.value.toLowerCase();
        else
            val = event.toLowerCase();
        // filter our data
        const temp = this.postalZipsMainData.filter(function (d) {
            return (d.postalCode ? d.postalCode.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.keyCode ? d.keyCode.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.state ? d.state.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.city ? d.city.toLowerCase().indexOf(val) !== -1 : !val) || !val
        });
        // update the rows
        this.postalZipsData = temp;
    }

    searchPostalZips(req) {
        this.selected = [];
        this.filteredValues = {};
        this.displayTable = true;
        this.showLoadingScreen = true;
        this.postalZipsMainData = [];
        this.postalZipsData = [];
        this.wizardService.searchPostalZips(req).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_POSTAL_ZIPS_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    this.showLoadingScreen = false;

                    this.postalZipsMainData = data[0];
                    this.postalZipsData = [...this.postalZipsMainData];
                    if (this.filteredValues.mainTableFilter) {
                        this.filterPostalZips(this.filteredValues.mainTableFilter);
                    }
                    this.editAlreadyEnabled = false;
                    if (this.postalZipsMainData && this.postalZipsMainData.length == 0) {
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("NO_POSTAL_ZIPS_FOUND")
                        );
                    }

                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    public showSummaryConfirm(f, index) {
        this.confirmationService.confirm({
            key: 'confirm-add-show-summary',
            message: this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DONE_CREATING_POSTAL_ZIPS_CONFIRM_MESSAGE"),
            accept: () => {
                this.displayTable = true;
                this.checkedAnother = false;
            }
        });
    }

    public addPostalZips(obj) {
        this.showLoadingScreen = true;
        obj = this.wizardHelper.checkRequestObject(obj);
        this.wizardService
            .addPostalZips(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.toasterService.showErrorMessage(
                            this.wizardHelper.getTracfoneConstantMethod("TRACFONE_ADD_POSTAL_ZIPS_ERROR_MESSAGE")
                        );
                        this.showLoadingScreen = false;
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        return;
                    }

                    this.toasterService.showSuccessMessage(
                        this.wizardHelper.getTracfoneConstantMethod("TRACFONE_ADD_POSTAL_ZIPS_SUCCESS_MESSAGE")
                    );

                    let fullObject = this.postalZiplocalService.getAddData();
                    if (!this.postalZiplocalService.getAddData() ||
                        (this.postalZiplocalService.getAddData() && this.postalZiplocalService.getAddData().length == 0)) {
                        fullObject.push(obj);
                    } else if (this.postalZiplocalService.getAddData().length > 0) {
                        fullObject = this.postalZiplocalService.getAddData();
                        fullObject.forEach((data, key) => {
                            if (data.postalCode == obj.postalCode && data.keyCode == obj.keyCode &&
                                data.state == obj.state && data.city == obj.city) {
                                fullObject.splice(key, 1);
                                fullObject = [...fullObject];
                            }
                        });
                        fullObject.push(obj);
                    }
                    this.postalZiplocalService.setAddData(fullObject);
                    this.postalZipsMainData = [];
                    this.postalZipsData = [];
                    for (let i = 0; i < this.postalZiplocalService.getAddData().length; i++) {
                        this.postalZipsMainData.push(this.postalZiplocalService.getAddData()[i]);
                    }
                    let rowId = 1;
                    this.postalZipsMainData.forEach(element => {
                        element.rowId = rowId;
                        rowId++;
                    });
                    this.postalZipsData = [...this.postalZipsMainData];

                    this.showLoadingScreen = false;
                    if (this.checkedAnother) {
                        this.displayTable = false;
                        // this.revert();
                    } else {
                        this.displayTable = true;
                        // this.searchPostalZips(obj);
                    }
                    this.addFromGroup.reset();

                },
                (err: any) => {
                    this.showErr(err);
                    return;
                }
            );
    }

    public showErr(err) {
        this.showLoadingScreen = false;
        if (err.error === undefined || err.error === null)
            this.toasterService.showErrorMessage(
                this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
            );
        else if (err.error && err.error.ERR) {
            const commaSeperatedArr = err.error.ERR.split(",");
            for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                if (commaSeperatedArr[i] != "")
                    this.toasterService.showErrorMessage(
                        commaSeperatedArr[i]
                    );
            }
        }
        else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
            return;
        else this.toasterService.showErrorMessage(err.error);
    }

    // to open bulk insert pop up
  openUploadCSVDialog() {
    const dialogRef = this.dialog.open(BulkInsertPostalZipsComponent, {
        width: "90%",
        height: "90%",
    });
    // Create subscription
    dialogRef.afterClosed().subscribe((bulkInsertData) => {
        if (bulkInsertData && bulkInsertData.length > 0) {
            this.warningAlert("Your upload is complete. Please click on Submit to begin database insertions.")
            this.bulkInsertData = [...bulkInsertData];
            let filterKeys = Object.keys(this.addFromGroup.controls);
        filterKeys.forEach(_e1 => {
            this.addFromGroup.controls[`${_e1}`].setValidators([]);
            this.addFromGroup.controls[`${_e1}`].updateValueAndValidity();
        });
        }
    });
}

//to bulk insert Postal Zips
private bulkInsertPostalZips() {
    this.showLoadingScreen = true;
    let obj: any = [];
    this.alreadyEnabled = true;
    obj = [...this.bulkInsertData];
    obj.forEach(element => {
        element.dbEnv = this.wizardHelper.dbEnv;
    });
    obj = this.wizardHelper.checkRequestObject(obj);
    obj.dbEnv = this.wizardHelper.dbEnv;
    this.wizardService.bulkInsertPostalZips(obj).pipe(takeUntil(this.unsubscribe))
        .subscribe(
        (data: any) => {
            if (data[0] === null || data[0] === undefined) {
                this.showLoadingScreen = false;
                this.toasterService.showErrorMessage(
                    this.wizardHelper.getTracfoneConstantMethod("TRACFONE_ADD_POSTAL_ZIPS_ERROR_MESSAGE")
                );
                return;
            }
            if (data[0] && data[0].ERR) {
                this.showLoadingScreen = false;
                const commaSeperatedArr = data[0].ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
                return;
            }
            this.showLoadingScreen = false;
            this.showMssg = true;
            this.revert();
        },
        (err: any) => {
            this.showLoadingScreen = false;
            if (err.error === undefined || err.error === null)
                this.toasterService.showErrorMessage(
                    this.wizardHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                );
            else if (err.error && err.error.ERR) {
                const commaSeperatedArr = err.error.ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
            }
            else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                return;
            else this.toasterService.showErrorMessage(err.error);
        }
        );
}

private warningAlert(warningMsg: string) {
    window.scrollTo(0, 0);
    this.alerts = [];
    this.alerts.push({
        id: 3,
        type: 'warning',
        message: warningMsg
    });
  }

    /*
* Show error when service returns error
*/
    public showServiceErr(data) {
        const commaSeperatedArr = data[0].ERR.split(",");
        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
            if (commaSeperatedArr[i] != "")
                this.toasterService.showErrorMessage(commaSeperatedArr[i]);
        }
        return;
    }
    
      public closeAlert(alert: any) {
        const index: number = this.alerts.indexOf(alert);
        this.alerts.splice(index, 1);
      }

      public showLastInsertedRecords() {
        this.returnedData.emit({ lastInsertedRecord: true });
      }
}