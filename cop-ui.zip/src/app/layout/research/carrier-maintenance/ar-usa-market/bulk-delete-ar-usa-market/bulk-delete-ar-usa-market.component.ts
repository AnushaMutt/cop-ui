import { Component, OnInit, SimpleChanges, ViewEncapsulation } from "@angular/core";
import { Subject } from "rxjs";
import { takeUntil } from "rxjs/operators";
import { ToasterService } from "../../../../../Services/toaster.service";
import { ExportToCsvService } from "../../../../../Services/export-to-csv.service";
import { ImportFromCsvService } from "../../../../../Services/import-from-csv.service";
import { CarrierMaintenanceService } from '../../../../../Services/carrierMaintenance.service';
import { CarrierMaintenanceHelper } from "../../carrier-maintenance-helper";
import { MatDialogRef } from "@angular/material";
import { ArUsaMarketHelper } from "../ar-usa-market-helper";


@Component({
    selector: 'bulk-delete-ar-usa-market',
    templateUrl: './bulk-delete-ar-usa-market.component.html',
    styleUrls: ['./bulk-delete-ar-usa-market.component.scss',
        '../../../../components/ngxtable/material.scss',
        '../../../../components/ngxtable/datatable.component.scss',
        '../../../../components/ngxtable/icons.css',
        '../../../../components/ngxtable/app.css'],
    encapsulation: ViewEncapsulation.None,
    providers: [ExportToCsvService, ImportFromCsvService],
})
export class BulkDeleteArUsaMarketComponent implements OnInit {
    private unsubscribe = new Subject<void>();
    public fileContentDelete: Boolean;
    public filenameDelete: string = null;
    public uploadedDataDelete: any = [];
    public uploadedMainDataDelete: any = [];
    public alerts: any = [];
    public exportColumnsDelete = [];
    public tableColmnsDelete = [];
    readonly EXPORT_FILE_NAME_DELETE = "Delete_Ar_Usa_Market_template";
    public showLoadingScreen: Boolean = false;
    public showMssg = false;

    constructor(
        private toasterService: ToasterService,
        private exportToCsvService: ExportToCsvService,
        private importFromCsvService: ImportFromCsvService,
        private wizardService: CarrierMaintenanceService,
        private wizardHelper: CarrierMaintenanceHelper,
        private carrierZonesHelper : ArUsaMarketHelper,
        public dialogRef: MatDialogRef<BulkDeleteArUsaMarketComponent>,
    )  { dialogRef.disableClose = true;  }


    ngOnInit() {
        this.fileContentDelete = false;
        this.filenameDelete = "";
        this.uploadedDataDelete = [];
        this.uploadedMainDataDelete = [];
        this.alerts = [];
        this.exportColumnsDelete = ["Key Code","Carrier Entity"];
        this.tableColmnsDelete = [
            { name: 'Key Code', prop: 'keyCode', width: "250" },
            { name: 'Carrier Entity', prop: 'carrierEntity', width: "250" },
        ];
        this.showMssg = false;
    }

    //Used to Download Template
    exportToCSVDelete() {
        this.exportToCsvService.downloadFile([], this.EXPORT_FILE_NAME_DELETE, this.exportColumnsDelete);
    }

    bulkDeleteArUsaMarket() {
        if (document.getElementsByClassName("tableError") && document.getElementsByClassName("tableError").length > 0) {
            this.toasterService.showErrorMessage("Please fix validation errors.");
            return;
        }
        for (let i = 0; i < this.uploadedMainDataDelete.length; i++) {
            delete this.uploadedMainDataDelete[i]['S.NO'];
            delete this.uploadedMainDataDelete[i].rowNum;
            delete this.uploadedMainDataDelete[i]['Carrier Entity'];
            delete this.uploadedMainDataDelete[i]['Key Code'];          
        }
        let uploadData = [];

        uploadData = this.uploadedMainDataDelete.filter((v, i, a) => a.findIndex(t => (t.keyCode === v.keyCode && t.carrierEntity == v.carrierEntity)) === i);

        let callTimes: number = Math.ceil(uploadData.length / 500);
        for (let i = 0; i < callTimes; i++) {
            let obj = [];
            for (let j = 500 * i; j < uploadData.length; j++) {
                if (j < (i + 1) * 500)
                    obj.push(uploadData[j]);
                else
                    break;
            }
            this.bulkDelete(obj);
        }
    }

    private bulkDelete(obj) {
        this.showLoadingScreen = true;
        let success = "We have started deleting Ar Usa Market .This may take a while before it completes." 
        this.wizardService.bulkDeleteArUsaMarket(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.carrierZonesHelper.getTracfoneConstantMethod("TRACFONE_DELETE_ARUSAMARKET_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    else{
                        this.toasterService.showSuccessMessage(
                            success
                        );
                        this.dialogRef.close();
                    }
                    this.showLoadingScreen = false;
                    this.showMssg = true;
                    this.removeFile();
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.carrierZonesHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    //Read File and show data on the table
    public changeListenerDelete(files: FileList) {
        let invalidFile = "Please select a valid file to upload.";
        let noDataInFile = "There is no data to upload in this file.";
        this.alerts = [];
        if (files && files.length > 0) {
            this.fileContentDelete = true;
            let file: File = files.item(0);
            let name = file.name;
            var ext = name.substring(name.lastIndexOf('.') + 1);
            if (ext.toLowerCase() == 'csv') {
                this.filenameDelete = name.substr(0, name.lastIndexOf("."));
                if (this.filenameDelete.split(" ")[0] != this.EXPORT_FILE_NAME_DELETE) {
                    this.toasterService.showErrorMessage(invalidFile);
                    return;
                }
            } else {
                this.toasterService.showErrorMessage(invalidFile);
                return;
            }
            let reader: FileReader = new FileReader();
            reader.readAsText(file);
            reader.onload = (e) => {
                let uploadData = this.importFromCsvService.csvToArray(reader.result);
                if (uploadData.length == 0) {
                    this.toasterService.showErrorMessage(noDataInFile);
                } else {
                    let keys = Object.keys(uploadData[0]);
                    for (let i = 1, j = 0; j < this.exportColumnsDelete.length; i++, j++) {
                        if (keys[i] != this.exportColumnsDelete[j]) {
                            this.toasterService.showErrorMessage(invalidFile);
                            return;
                        }
                    }
                    uploadData.forEach(_e1 => { 
                        _e1.keyCode = _e1['Key Code'];
                        _e1.carrierEntity = _e1['Carrier Entity'];
                });
                    this.uploadedDataDelete = [...this.checkUploadedDataDelete(uploadData)];
                }
            }
        }
    }

    //Removes file and table from the screen
    public removeFile() {
        this.fileContentDelete = false;
        this.filenameDelete = null;
        this.uploadedDataDelete = [];
        this.uploadedMainDataDelete = [];
        this.alerts = [];
    }

    public checkUploadedDataDelete(data) {
        let errorData = [];
        let successData = [];
        data.forEach(element => {
            element.rowNum = element['S.NO'];
        });
        data.forEach(element => {
            if (element.rowNum.length == 0 || element["Key Code"].length == 0 || element["Carrier Entity"].length == 0 
            || element["Carrier Entity"].length > 200 || element["Key Code"].length > 200 )
            {
             errorData.push(element);   
            } else
                successData.push(element);
        });
        this.uploadedMainDataDelete = [...errorData, ...successData];
        return this.uploadedMainDataDelete;
    }
    //Removes Row from the table
    deleteRowDelete(row) {
        this.uploadedMainDataDelete.forEach((data, key) => {
            if (row.rowNum == data.rowNum) {
                this.uploadedMainDataDelete.splice(key, 1);
            }
        });
        this.uploadedDataDelete = [...this.uploadedMainDataDelete];
    }
    public editValueChangedDelete(event, column, row, oldValue) {
        for (let i = 0; i < this.uploadedMainDataDelete.length; i++) {
            if (this.uploadedMainDataDelete[i].rowNum == row.rowNum) {
                this.uploadedMainDataDelete[i][column] = event.target.value;
            }
        }
        this.uploadedDataDelete = [...this.uploadedMainDataDelete];
    }

    //Filter for result table
    public filterTableDataDelete(event) {
        const val = event.target.value.toLowerCase();
        // filter our data
        const temp = this.uploadedMainDataDelete.filter(function (d) {
            return (d.carrierEntity ? d.carrierEntity.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.keyCode ? d.keyCode.toLowerCase().indexOf(val) !== -1 : !val)
        });
        // update the rows
        this.uploadedDataDelete = temp;
    }

    cancelUploadDialog(): void {
        this.dialogRef.close();
    }
}