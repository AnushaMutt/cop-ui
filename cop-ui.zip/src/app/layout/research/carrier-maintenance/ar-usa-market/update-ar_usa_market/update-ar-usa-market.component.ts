import { Component, OnInit, ViewEncapsulation, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ConfirmationService } from 'primeng/primeng';
import { takeUntil } from 'rxjs/operators';
import { Subject } from "rxjs";
import { CarrierMaintenanceService } from '../../../../../Services/carrierMaintenance.service';
import { CarrierMaintenanceHelper } from "../../carrier-maintenance-helper";
import { ToasterService } from "../../../../../Services/toaster.service";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { ArUsaMarketService } from "../ar-usa-market-service";
import { ArUsaMarketHelper } from "../ar-usa-market-helper";
import { ExportToCsvService } from "../../../../../Services/export-to-csv.service";
import { MatDialog } from "@angular/material";
import { BulkDeleteArUsaMarketComponent } from "../bulk-delete-ar-usa-market/bulk-delete-ar-usa-market.component";

@Component({
    selector: 'update-ar-usa-market',
    templateUrl: './update-ar-usa-market.component.html',
    styleUrls: ['./update-ar-usa-market.component.scss',
        "../../../../components/ngxtable/material.scss",
        "../../../../components/ngxtable/datatable.component.scss",
        "../../../../components/ngxtable/icons.css",
        "../../../../components/ngxtable/app.css"],
    animations: [],
    encapsulation: ViewEncapsulation.None,
})

export class UpdateArUsaMarketComponent implements OnInit {
    private unsubscribe = new Subject<void>();
    public frmArUsaMarket: FormGroup;
    public showLoadingScreen: boolean;
    public tableRows: any = [];
    public tableRowsMainData: any = [];
    isEditable = {};
    private editedRow: any = {};
    private defaultEditedRow: any = {};
    public tableColumns: any = [];
    public alreadyEnabled = true;
    public showNoRecordsFoundMessage: Boolean = true;
    public filteredValues: any = {};
    public selected: any = [];
    public multiColumnEditSection = false;
    public filteredRows: any;
    public tableFrmGroupMain: FormGroup;
    public showBulkUpdateButton = false;
    public selectedArUsaMarket = [];
    public bulkEditBoolean: boolean;
    public otherColumn: boolean = false;
    public editAlreadyEnabled = false;
    public checkDuplicate = false;
    public bulkEditColumns = [];
    @ViewChild('multicolumnEditValue') multicolumnEditValue: any;
    public searchColumns: any = [];
    public searchColumnsMaindata = [];
    public selectedFields = [];
    public showOptionalFields = false;
    PAGINATION_AMOUNT = 200;
    public paginationStart: number;
    public paginationEnd: number;
    public paginationCount: number;
    public paginationOffSet: number;
    public pageindex: any = 1;
    public lastTransactionRequest: any = {};

    constructor(
        private formBuilder: FormBuilder,
        private wizardService: CarrierMaintenanceService,
        private toasterService: ToasterService,
        private wizardHelper: CarrierMaintenanceHelper,
        private confirmationService: ConfirmationService,
        private modalService: NgbModal,
        private arUsaMarketService: ArUsaMarketService,
        private arUsaMarketHelper: ArUsaMarketHelper,
        private exportToCsvService :ExportToCsvService,
        public dialog: MatDialog
    ) { }


    ngOnInit() {
        this.selectedFields = [];
        this.showOptionalFields = false;
        this.paginationOffSet = this.PAGINATION_AMOUNT;
        this.paginationEnd = this.PAGINATION_AMOUNT;
        this.paginationStart = 0;
        this.createForm();
        this.createTableForm();
        this.tableColumns = [
            { name: 'Carrier Entity', prop: 'carrierEntity', width: "250" },
            { name: 'Key Code', prop: 'keyCode', width: "250" },
            { name: 'BEA MKT Code', prop: 'beaMktCode', width: "250" },
            { name: 'BEA MKT Multi State', prop: 'beaMktMultiState', width: "250" },
            { name: 'BEA MKT Name', prop: 'beaMktName', width: "250" },
            { name: 'BEA MKT Name Alternate', prop: 'beaMktNameAlternate', width: "250" },
            { name: 'BEA MKT State', prop: 'beaMktState', width: "250" },
            { name: 'BID1', prop: 'bid1', width: "250" },
            { name: 'BID1 BSID1', prop: 'bid1Bsid1', width: "250" },
            { name: 'BID1 BSID2', prop: 'bid1Bsid2', width: "250" },
            { name: 'BID1 BSID3', prop: 'bid1Bsid3', width: "250" },
            { name: 'BID1 MNC', prop: 'bid1Mnc', width: "250" },
            { name: 'BID1 Name', prop: 'bid1Name', width: "250" },
            { name: 'BID2', prop: 'bid2', width: "250" },
            { name: 'BID2 BSID1', prop: 'bid2Bsid1', width: "250" },
            { name: 'BID2 BSID2', prop: 'bid2Bsid2', width: "250" },
            { name: 'BID2 BSID3', prop: 'bid2Bsid3', width: "250" },
            { name: 'BID2 MNC', prop: 'bid2Mnc', width: "250" },
            { name: 'BID2 Name', prop: 'bid2Name', width: "250" },
            { name: 'BID3', prop: 'bid3', width: "250" },
            { name: 'BID3 BSID1', prop: 'bid3Bsid1', width: "250" },
            { name: 'BID3 BSID2', prop: 'bid3Bsid2', width: "250" },
            { name: 'BID3 BSID3', prop: 'bid3Bsid3', width: "250" },
            { name: 'BID3 MNC', prop: 'bid3Mnc', width: "250" },
            { name: 'BID3 Name', prop: 'bid3Name', width: "250" },
            { name: 'BID4', prop: 'bid4', width: "250" },
            { name: 'BID4 BSID1', prop: 'bid4Bsid1', width: "250" },
            { name: 'BID4 BSID2', prop: 'bid4Bsid2', width: "250" },
            { name: 'BID4 BSID3', prop: 'bid4Bsid3', width: "250" },
            { name: 'BID4 MNC', prop: 'bid4Mnc', width: "250" },
            { name: 'BID4 Name', prop: 'bid4Name', width: "250" },
            { name: 'BTA MKT Code', prop: 'btaMktCode', width: "250" },
            { name: 'BTA MKT Multi State', prop: 'btaMktMultiState', width: "250" },
            { name: 'BTA MKT Name', prop: 'btaMktName', width: "250" },
            { name: 'BTA MKT Name Alternate', prop: 'btaMktNameAlternate', width: "250" },
            { name: 'BTA MKT State', prop: 'btaMktState', width: "250" },
            { name: 'CMA MKT Code', prop: 'cmaMktCode', width: "250" },
            { name: 'CMA MKT Multi State', prop: 'cmaMktMultiState', width: "250" },
            { name: 'CMA MKT Name', prop: 'cmaMktName', width: "250" },
            { name: 'CMA MKT Name Alternate', prop: 'cmaMktNameAlternate', width: "250" },
            { name: 'CMA MKT State', prop: 'cmaMktState', width: "250" },
            { name: 'County', prop: 'county', width: "250" },
            { name: 'Extended Services', prop: 'extendedServices', width: "250" },
            { name: 'Marketing Name', prop: 'marketingName', width: "250" },
            { name: 'MHZ Total', prop: 'mhzTotal', width: "250" },
            { name: 'Nation', prop: 'nation', width: "250" },
            { name: 'Protocol', prop: 'protocol', width: "250" },
            { name: 'Spectrum Blocks', prop: 'spectrumBlocks', width: "250" },
            { name: 'State', prop: 'state', width: "250" },
        ];
        this.searchColumns = [
            { name: 'BEA MKT Code', prop: 'beaMktCode', width: "250" },
            { name: 'BEA MKT Multi State', prop: 'beaMktMultiState', width: "250" },
            { name: 'BEA MKT Name', prop: 'beaMktName', width: "250" },
            { name: 'BEA MKT Name Alternate', prop: 'beaMktNameAlternate', width: "250" },
            { name: 'BEA MKT State', prop: 'beaMktState', width: "250" },
            { name: 'BID1', prop: 'bid1', width: "250" },
            { name: 'BID1 BSID1', prop: 'bid1Bsid1', width: "250" },
            { name: 'BID1 BSID2', prop: 'bid1Bsid2', width: "250" },
            { name: 'BID1 BSID3', prop: 'bid1Bsid3', width: "250" },
            { name: 'BID1 MNC', prop: 'bid1Mnc', width: "250" },
            { name: 'BID1 Name', prop: 'bid1Name', width: "250" },
            { name: 'BID2', prop: 'bid2', width: "250" },
            { name: 'BID2 BSID1', prop: 'bid2Bsid1', width: "250" },
            { name: 'BID2 BSID2', prop: 'bid2Bsid2', width: "250" },
            { name: 'BID2 BSID3', prop: 'bid2Bsid3', width: "250" },
            { name: 'BID2 MNC', prop: 'bid2Mnc', width: "250" },
            { name: 'BID2 Name', prop: 'bid2Name', width: "250" },
            { name: 'BID3', prop: 'bid3', width: "250" },
            { name: 'BID3 BSID1', prop: 'bid3Bsid1', width: "250" },
            { name: 'BID3 BSID2', prop: 'bid3Bsid2', width: "250" },
            { name: 'BID3 BSID3', prop: 'bid3Bsid3', width: "250" },
            { name: 'BID3 MNC', prop: 'bid3Mnc', width: "250" },
            { name: 'BID3 Name', prop: 'bid3Name', width: "250" },
            { name: 'BID4', prop: 'bid4', width: "250" },
            { name: 'BID4 BSID1', prop: 'bid4Bsid1', width: "250" },
            { name: 'BID4 BSID2', prop: 'bid4Bsid2', width: "250" },
            { name: 'BID4 BSID3', prop: 'bid4Bsid3', width: "250" },
            { name: 'BID4 MNC', prop: 'bid4Mnc', width: "250" },
            { name: 'BID4 Name', prop: 'bid4Name', width: "250" },
            { name: 'BTA MKT Code', prop: 'btaMktCode', width: "250" },
            { name: 'BTA MKT Multi State', prop: 'btaMktMultiState', width: "250" },
            { name: 'BTA MKT Name', prop: 'btaMktName', width: "250" },
            { name: 'BTA MKT Name Alternate', prop: 'btaMktNameAlternate', width: "250" },
            { name: 'BTA MKT State', prop: 'btaMktState', width: "250" },
            { name: 'CMA MKT Code', prop: 'cmaMktCode', width: "250" },
            { name: 'CMA MKT Multi State', prop: 'cmaMktMultiState', width: "250" },
            { name: 'CMA MKT Name', prop: 'cmaMktName', width: "250" },
            { name: 'CMA MKT Name Alternate', prop: 'cmaMktNameAlternate', width: "250" },
            { name: 'CMA MKT State', prop: 'cmaMktState', width: "250" },
            { name: 'County', prop: 'county', width: "250" },
            { name: 'Extended Services', prop: 'extendedServices', width: "250" },
            { name: 'Marketing Name', prop: 'marketingName', width: "250" },
            { name: 'MHZ Total', prop: 'mhzTotal', width: "250" },
            { name: 'Nation', prop: 'nation', width: "250" },
            { name: 'Protocol', prop: 'protocol', width: "250" },
            { name: 'Spectrum Blocks', prop: 'spectrumBlocks', width: "250" },
            { name: 'State', prop: 'state', width: "250" },

        ];
        this.searchColumnsMaindata = [...this.searchColumns];
        this.bulkEditColumns = [...this.tableColumns];
        this.filteredValues = {};
        this.multiColumnEditSection = false;
        this.showBulkUpdateButton = false
    }

    //to create form
    private createForm() {
        this.frmArUsaMarket = this.formBuilder.group({
            keyCode: ['', [Validators.maxLength(200)]],
            carrierEntity: ['', [Validators.maxLength(200)]],
            beaMktCode: ['', [Validators.maxLength(200)]],
            beaMktMultiState: ['', [Validators.maxLength(200)]],
            beaMktName: ['', [Validators.maxLength(200)]],
            beaMktNameAlternate: ['', [Validators.maxLength(200)]],
            beaMktState: ['', [Validators.maxLength(200)]],
            bid1: ['', [Validators.maxLength(200)]],
            bid1Bsid1: ['', [Validators.maxLength(200)]],
            bid1Bsid2: ['', [Validators.maxLength(200)]],
            bid1Bsid3: ['', [Validators.maxLength(200)]],
            bid1Mnc: ['', [Validators.maxLength(200)]],
            bid1Name: ['', [Validators.maxLength(200)]],
            bid2: ['', [Validators.maxLength(200)]],
            bid2Bsid1: ['', [Validators.maxLength(200)]],
            bid2Bsid2: ['', [Validators.maxLength(200)]],
            bid2Bsid3: ['', [Validators.maxLength(200)]],
            bid2Mnc: ['', [Validators.maxLength(200)]],
            bid2Name: ['', [Validators.maxLength(200)]],
            bid3: ['', [Validators.maxLength(200)]],
            bid3Bsid1: ['', [Validators.maxLength(200)]],
            bid3Bsid2: ['', [Validators.maxLength(200)]],
            bid3Bsid3: ['', [Validators.maxLength(200)]],
            bid3Mnc: ['', [Validators.maxLength(200)]],
            bid3Name: ['', [Validators.maxLength(200)]],
            bid4: ['', [Validators.maxLength(200)]],
            bid4Bsid1: ['', [Validators.maxLength(200)]],
            bid4Bsid2: ['', [Validators.maxLength(200)]],
            bid4Bsid3: ['', [Validators.maxLength(200)]],
            bid4Mnc: ['', [Validators.maxLength(200)]],
            bid4Name: ['', [Validators.maxLength(200)]],
            btaMktCode: ['', [Validators.maxLength(200)]],
            btaMktMultiState: ['', [Validators.maxLength(200)]],
            btaMktName: ['', [Validators.maxLength(200)]],
            btaMktNameAlternate: ['', [Validators.maxLength(200)]],
            btaMktState: ['', [Validators.maxLength(200)]],
            cmaMktCode: ['', [Validators.maxLength(200)]],
            cmaMktMultiState: ['', [Validators.maxLength(200)]],
            cmaMktName: ['', [Validators.maxLength(200)]],
            cmaMktNameAlternate: ['', [Validators.maxLength(200)]],
            cmaMktState: ['', [Validators.maxLength(200)]],
            county: ['', [Validators.maxLength(200)]],
            extendedServices: ['', [Validators.maxLength(200)]],
            marketingName: ['', [Validators.maxLength(200)]],
            mhzTotal: ['', [Validators.maxLength(200)]],
            nation: ['', [Validators.maxLength(3)]],
            protocol: ['', [Validators.maxLength(200)]],
            spectrumBlocks: ['', [Validators.maxLength(200)]],
            state: ['', [Validators.maxLength(2)]],
        })
    }

    //form for column level filter
    public createTableForm() {
        this.tableFrmGroupMain = this.formBuilder.group({
            keyCode: [''],
            carrierEntity: [''],
            beaMktCode: [''],
            beaMktMultiState: [''],
            beaMktName: [''],
            beaMktNameAlternate: [''],
            beaMktState: [''],
            bid1: [''],
            bid1Bsid1: [''],
            bid1Bsid2: [''],
            bid1Bsid3: [''],
            bid1Mnc: [''],
            bid1Name: [''],
            bid2: [''],
            bid2Bsid1: [''],
            bid2Bsid2: [''],
            bid2Bsid3: [''],
            bid2Mnc: [''],
            bid2Name: [''],
            bid3: [''],
            bid3Bsid1: [''],
            bid3Bsid2: [''],
            bid3Bsid3: [''],
            bid3Mnc: [''],
            bid3Name: [''],
            bid4: [''],
            bid4Bsid1: [''],
            bid4Bsid2: [''],
            bid4Bsid3: [''],
            bid4Mnc: [''],
            bid4Name: [''],
            btaMktCode: [''],
            btaMktMultiState: [''],
            btaMktName: [''],
            btaMktNameAlternate: [''],
            btaMktState: [''],
            cmaMktCode: [''],
            cmaMktMultiState: [''],
            cmaMktName: [''],
            cmaMktNameAlternate: [''],
            cmaMktState: [''],
            county: [''],
            extendedServices: [''],
            marketingName: [''],
            mhzTotal: [''],
            nation: [''],
            protocol: [''],
            spectrumBlocks: [''],
            state: [''],
        });
    }

    // reset the form
    revert() {
        this.pageindex = 1;
        this.PAGINATION_AMOUNT = 200;
        this.frmArUsaMarket.reset();
        this.tableRows = [];
        this.tableRowsMainData = [];
        this.filteredValues = {};
        let filterKeys = Object.keys(this.tableFrmGroupMain.controls);
        filterKeys.forEach(_e1 => {
            this.tableFrmGroupMain.controls[`${_e1}`].patchValue([]);
        });
        this.selectedArUsaMarket = [];
        this.alreadyEnabled = true;
        this.showBulkUpdateButton = false;
        this.selected = [];
        this.otherColumn = false;
        this.lastTransactionRequest = {};
    }

    // search Ar Usa Market
    public searchForm() {
        this.tableRowsMainData = [];
        this.tableRows = [];
        this.pageindex = 1;
        this.showLoadingScreen = true;
        let obj = this.frmArUsaMarket.value;
        this.editedRow = {};
        this.defaultEditedRow = {};
        this.isEditable = {};
        this.selectedArUsaMarket = [];
        this.selected = [];
        this.showBulkUpdateButton = false;
        this.otherColumn = false;
        this.checkDuplicate = false;
        this.arUsaMarketService.setSearchData([]);
        let filterKeys = Object.keys(this.tableFrmGroupMain.controls);
        filterKeys.forEach(_e1 => {
            this.tableFrmGroupMain.controls[`${_e1}`].patchValue([]);
        });
        this.filteredValues = {};
        this.alreadyEnabled = true;
        obj = this.wizardHelper.checkRequestObject(obj);
        obj.paginationSearch = this.createPaginationRequest(0, 200);
        this.lastTransactionRequest = obj;
        this.paginationStart = 0;
        this.paginationOffSet = this.PAGINATION_AMOUNT;
        this.fireSubmitMethod(obj);
    }

    public fireSubmitMethod(obj) {
        this.showLoadingScreen = true;
        this.wizardService.getArUsaMarketDetails(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.arUsaMarketHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_ARUSAMARKET_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }

                    let response = data[0];
                    let fullObject = [];
                    this.arUsaMarketService.setSearchData([]);
                    if (!this.arUsaMarketService.getSearchData() || (this.arUsaMarketService.getSearchData() && this.arUsaMarketService.getSearchData().length == 0)) {
                        response.arUsaMarkets.forEach(e1 => {
                            fullObject.push(e1)
                        });
                    } else if (this.arUsaMarketService.getSearchData().length > 0) {
                        fullObject = this.arUsaMarketService.getSearchData();
                        response.arUsaMarkets.forEach(e1 => {
                            fullObject.push(e1)
                        });
                    }
                    this.arUsaMarketService.setSearchData(fullObject);
                    this.tableRowsMainData = [];
                    this.tableRows = [];
                    for (let i = 0; i < this.arUsaMarketService.getSearchData().length; i++) {
                        this.tableRowsMainData.push(this.arUsaMarketService.getSearchData()[i]);
                    }
                    let rowId = 1;
                    this.tableRowsMainData.forEach(element => {
                        element.rowId = rowId;
                        rowId++;
                    });

                    this.tableRows = [...this.tableRowsMainData];
                    let pag = data[0].paginationSearch;
                    this.paginationCount = pag.total;
                    this.showLoadingScreen = false;
                    if (data[0].arUsaMarkets && data[0].arUsaMarkets.length == 0 && this.showNoRecordsFoundMessage)
                        this.toasterService.showErrorMessage(
                            this.arUsaMarketHelper.getTracfoneConstantMethod("TRACFONE_SEARCH_ARUSAMARKET_ERROR_MESSAGE")
                        );

                    this.generateFilters();
                    this.filterReportResults();
                    this.multiColumnEditSection = false;
                    this.showNoRecordsFoundMessage = true;
                    if (this.filteredValues && this.filteredValues.mainTableFilter) {
                        this.updateSummaryTable(this.filteredValues.mainTableFilter);
                    }
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.arUsaMarketHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );

    }

    // to filter columns
    public filterReportResults(): void {
        const filterFormObject = this.tableFrmGroupMain.value;
        this.filteredValues.carrierEntity = filterFormObject.carrierEntity;
        this.filteredValues.keyCode = filterFormObject.keyCode;
        this.filteredValues.beaMktCode = filterFormObject.beaMktCode;
        this.filteredValues.beaMktMultiState = filterFormObject.beaMktMultiState;
        this.filteredValues.beaMktName = filterFormObject.beaMktName;
        this.filteredValues.beaMktNameAlternate = filterFormObject.beaMktNameAlternate;
        this.filteredValues.beaMktState = filterFormObject.beaMktState;
        this.filteredValues.bid1 = filterFormObject.bid1;
        this.filteredValues.bid1Bsid1 = filterFormObject.bid1Bsid1;
        this.filteredValues.bid1Bsid2 = filterFormObject.bid1Bsid2;
        this.filteredValues.bid1Bsid3 = filterFormObject.bid1Bsid3;
        this.filteredValues.bid1Mnc = filterFormObject.bid1Mnc;
        this.filteredValues.bid1Name = filterFormObject.bid1Name;
        this.filteredValues.bid2 = filterFormObject.bid2;
        this.filteredValues.bid2Bsid1 = filterFormObject.bid2Bsid1;
        this.filteredValues.bid2Bsid2 = filterFormObject.bid2Bsid2;
        this.filteredValues.bid2Bsid3 = filterFormObject.bid2Bsid3;
        this.filteredValues.bid2Mnc = filterFormObject.bid2Mnc;
        this.filteredValues.bid2Name = filterFormObject.bid2Name;
        this.filteredValues.bid3 = filterFormObject.bid3;
        this.filteredValues.bid3Bsid1 = filterFormObject.bid3Bsid1;
        this.filteredValues.bid3Bsid2 = filterFormObject.bid3Bsid2;
        this.filteredValues.bid3Bsid3 = filterFormObject.bid3Bsid3;
        this.filteredValues.bid3Mnc = filterFormObject.bid3Mnc;
        this.filteredValues.bid3Name = filterFormObject.bid3Name;
        this.filteredValues.bid4 = filterFormObject.bid4;
        this.filteredValues.bid4Bsid1 = filterFormObject.bid4Bsid1;
        this.filteredValues.bid4Bsid2 = filterFormObject.bid4Bsid2;
        this.filteredValues.bid4Bsid3 = filterFormObject.bid4Bsid3;
        this.filteredValues.bid4Mnc = filterFormObject.bid4Mnc;
        this.filteredValues.bid4Name = filterFormObject.bid4Name;
        this.filteredValues.btaMktCode = filterFormObject.btaMktCode;
        this.filteredValues.btaMktMultiState = filterFormObject.btaMktMultiState;
        this.filteredValues.btaMktName = filterFormObject.btaMktName;
        this.filteredValues.btaMktNameAlternate = filterFormObject.btaMktNameAlternate;
        this.filteredValues.btaMktState = filterFormObject.btaMktState;
        this.filteredValues.cmaMktCode = filterFormObject.cmaMktCode;
        this.filteredValues.cmaMktMultiState = filterFormObject.cmaMktMultiState;
        this.filteredValues.cmaMktName = filterFormObject.cmaMktName;
        this.filteredValues.cmaMktNameAlternate = filterFormObject.cmaMktNameAlternate;
        this.filteredValues.cmaMktState = filterFormObject.cmaMktState;
        this.filteredValues.county = filterFormObject.county;
        this.filteredValues.extendedServices = filterFormObject.extendedServices;
        this.filteredValues.marketingName = filterFormObject.marketingName;
        this.filteredValues.mhzTotal = filterFormObject.mhzTotal;
        this.filteredValues.nation = filterFormObject.nation;
        this.filteredValues.protocol = filterFormObject.protocol;
        this.filteredValues.spectrumBlocks = filterFormObject.spectrumBlocks;
        this.filteredValues.state = filterFormObject.state;
        const newRows = Object.keys(filterFormObject).reduce((acc, key) => {
            if (!filterFormObject[key].length) return acc;
            const filteredRows = acc.filter(val => filterFormObject[key].indexOf(val[key]) > -1);
            return filteredRows;
        }, this.tableRowsMainData);

        this.tableRows = newRows;
    }

    public generateFilters(): void {
        this.filteredRows = Object.keys(this.tableColumns)
            .map(i => this.tableColumns[i].prop)
            .reduce((filterObject, columnName) => {
                const uniqueValuesPerRow = this.tableRows.reduce((set, row) => set.add(row[columnName]), new Set());
                let val: any = Array.from(uniqueValuesPerRow);
                if (/^[0-9]*$/.test(val[0])) {
                    filterObject[columnName] = val.sort(function (a, b) { return a - b });
                } else {
                    filterObject[columnName] = val.sort((a, b) => {
                        a = a || '';
                        b = b || '';
                        return a.localeCompare(b);
                    });
                }
                return filterObject;
            }, {});
    }

    public onSelect(row) {
        this.multiColumnEditSection = true;
        this.selectedArUsaMarket = [];
        if (row && row.selected) {
            for (let i = 0; i < row.selected.length; i++) {
                let obj = { ...row.selected[i] };
                this.selectedArUsaMarket.push(obj);
            }
        }
        this.selectedArUsaMarket = [...this.selectedArUsaMarket]
        if (this.selectedArUsaMarket.length == 0) {
            this.bulkEditBoolean = false;
            this.otherColumn = false;
            this.showBulkUpdateButton = false;
        }
    }
    public editButtonClicked(rowData, rowIndex) {
        this.alreadyEnabled = false;
        this.defaultEditedRow = { ...rowData }
        for (let i = 0; i < this.tableRowsMainData.length; i++) {
            if (this.isEditable[i])
                this.alreadyEnabled = true;
        }
        if (!this.alreadyEnabled)
            this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        else {
            this.alreadyEnabled = false;
            this.toasterService.showErrorMessage(
                this.arUsaMarketHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE")
            );
        }
    }
    private inputValueChanged(event, column, row, oldValue) {
        this.editedRow[column] = event.target.value;
        this.defaultEditedRow[column] = event.target.defaultValue;

    }

    //to update AR USA Market
    public updateArUsaMarketDetails(editData, rowIndex) {
        if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
            this.toasterService.showErrorMessage(
                this.arUsaMarketHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            return;
        }
        this.showLoadingScreen = true;
        let obj = { ...editData, ...this.editedRow }

        obj = this.wizardHelper.checkRequestObject(obj);
        obj.oldKeyCode = this.defaultEditedRow.keyCode;
        obj.oldCarrierEntity = this.defaultEditedRow.carrierEntity;
        if (obj.keyCode != this.defaultEditedRow.keyCode || obj.carrierEntity != this.defaultEditedRow.carrierEntity) {
            this.checkDuplicate = true;
        } else {
            this.checkDuplicate = false;
        }
        obj.checkDuplicate = this.checkDuplicate;
        delete obj.rowId;
        this.wizardService.updateArUsaMarketDetails(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.arUsaMarketHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_ARUSAMARKET_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    for (let i = 0; i < this.tableRowsMainData.length; i++) {
                        if (this.tableRowsMainData[i].rowId == this.defaultEditedRow.rowId) {
                            this.tableRowsMainData[i] = obj;
                        }
                    }
                    this.isEditable[rowIndex] = !this.isEditable[rowIndex];
                    this.showLoadingScreen = false;
                    this.alreadyEnabled = true;
                    this.editedRow = {};
                    this.defaultEditedRow = {};
                    this.tableRows = [...this.tableRowsMainData];
                    this.checkDuplicate = false;

                    this.toasterService.showSuccessMessage(
                        this.arUsaMarketHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_ARUSAMARKET_SUCCESS_MESSAGE")
                    );

                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.arUsaMarketHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    //to cancel update
    private cancelEditForm(rowData, rowIndex) {
        this.showLoadingScreen = true;
        this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        this.tableColumns.forEach(e1 => {
            if (document.getElementById(e1.prop + rowIndex)) {
                (<HTMLInputElement>(
                    document.getElementById(e1.prop + rowIndex)
                )).value = rowData[e1.prop] || '';
            }
        });

        this.editedRow = {};
        this.defaultEditedRow = {};
        this.showLoadingScreen = false;
        this.checkDuplicate = false;
        this.alreadyEnabled = true;
    }

    //to filter table
    private updateSummaryTable(event) {
        let val: any;
        if (event.target)
            val = event.target.value.toLowerCase();
        else
            val = event.toLowerCase();

        const temp = this.tableRowsMainData.filter(function (d) {
            return (d.carrierEntity ? d.carrierEntity.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.keyCode ? d.keyCode.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.beaMktCode ? d.beaMktCode.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.beaMktMultiState ? d.beaMktMultiState.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.beaMktName ? d.beaMktName.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.beaMktNameAlternate ? d.beaMktNameAlternate.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.beaMktState ? d.beaMktState.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid1 ? d.bid1.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid1Bsid1 ? d.bid1Bsid1.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid1Bsid2 ? d.bid1Bsid2.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid1Bsid3 ? d.bid1Bsid3.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid1Mnc ? d.bid1Mnc.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid1Name ? d.bid1Name.toLowerCase().indexOf(val) !== -1 : !val)
			|| (d.bid2 ? d.bid2.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid2Bsid1 ? d.bid2Bsid1.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid2Bsid2 ? d.bid2Bsid2.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid2Bsid3 ? d.bid2Bsid3.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid2Mnc ? d.bid2Mnc.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid2Name ? d.bid2Name.toLowerCase().indexOf(val) !== -1 : !val)
			|| (d.bid3 ? d.bid3.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid3Bsid1 ? d.bid3Bsid1.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid3Bsid2 ? d.bid3Bsid2.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid3Bsid3 ? d.bid3Bsid3.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid3Mnc ? d.bid3Mnc.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid3Name ? d.bid3Name.toLowerCase().indexOf(val) !== -1 : !val)
			|| (d.bid4 ? d.bid4.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid4Bsid1 ? d.bid4Bsid1.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid4Bsid2 ? d.bid4Bsid2.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid4Bsid3 ? d.bid4Bsid3.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid4Mnc ? d.bid4Mnc.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid4Name ? d.bid4Name.toLowerCase().indexOf(val) !== -1 : !val)
			|| (d.btaMktCode ? d.btaMktCode.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.btaMktMultiState ? d.btaMktMultiState.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.btaMktName ? d.btaMktName.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.btaMktNameAlternate ? d.btaMktNameAlternate.toLowerCase().indexOf(val) !== -1 : !val)	
            || (d.btaMktState ? d.btaMktState.toLowerCase().indexOf(val) !== -1 : !val)
			|| (d.cmaMktCode ? d.cmaMktCode.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.cmaMktMultiState ? d.cmaMktMultiState.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.cmaMktName ? d.cmaMktName.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.cmaMktNameAlternate ? d.cmaMktNameAlternate.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.cmaMktState ? d.cmaMktState.toLowerCase().indexOf(val) !== -1 : !val)
			|| (d.county ? d.county.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.extendedServices ? d.extendedServices.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.marketingName ? d.marketingName.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.mhzTotal ? d.mhzTotal.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.nation ? d.nation.toLowerCase().indexOf(val) !== -1 : !val)
			|| (d.protocol ? d.protocol.toLowerCase().indexOf(val) !== -1 : !val)
			|| (d.spectrumBlocks ? d.spectrumBlocks.toLowerCase().indexOf(val) !== -1 : !val)
			|| (d.state ? d.state.toLowerCase().indexOf(val) !== -1 : !val)
        });
        this.tableRows = temp;
    }

    // delete confirm
    public showConfirm(esnData, rowIndex) {
        this.confirmationService.confirm({
            key: 'confirm-delete-cmi',
            message: "Are you sure you want to delete AR USA Market ?",
            accept: () => {
                this.deleteArUsaMarketDetails(esnData, rowIndex)
            }
        });
    }

    // to delete AR USA Market
    public deleteArUsaMarketDetails(esnData, rowIndex) {
        this.showLoadingScreen = true;
        let obj: any = {};
        obj = esnData
        delete obj.rowId;
        this.wizardService.deleteArUsaMarketDetails(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.arUsaMarketHelper.getTracfoneConstantMethod("TRACFONE_DELETE_ARUSAMARKET_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    this.toasterService.showSuccessMessage(
                        this.arUsaMarketHelper.getTracfoneConstantMethod("TRACFONE_DELETE_ARUSAMARKET_SUCCESS_MESSAGE")
                    );
                    this.showNoRecordsFoundMessage = false;
                    this.searchForm();
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.arUsaMarketHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    public assignmultiColumnName(column) {
        this.showBulkUpdateButton = false;
        this.otherColumn = true;
    }

    public showBulkUpdateButtonFun(event) {
        if (event)
            this.showBulkUpdateButton = true;
        else
            this.showBulkUpdateButton = false;
    }

    bulkUpdateColumn(column) {
        if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
            this.toasterService.showErrorMessage(
                this.arUsaMarketHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            return;
        }
        this.showLoadingScreen = true;
        let requestObj = [];
        this.selectedArUsaMarket.forEach(e => {
            let obj: any = {};
            obj.checkDuplicate =false
            if (column == "Carrier Entity") {
                obj.carrierEntity = this.multicolumnEditValue.nativeElement.value;
                obj.checkDuplicate=true;
            } else {
                obj.carrierEntity = e.carrierEntity;
            }
            if (column == "Key Code") {
                obj.keyCode = this.multicolumnEditValue.nativeElement.value;
                obj.checkDuplicate=true;
            } else {
                obj.keyCode = e.keyCode;
            }
            if (column == "BEA MKT Code") {
                obj.beaMktCode = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.beaMktCode = e.beaMktCode;
            }
            if (column == "BEA MKT Multi State") {
                obj.beaMktMultiState = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.beaMktMultiState = e.beaMktMultiState;
            }
            if (column == "BEA MKT Name") {
                obj.beaMktName = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.beaMktName = e.beaMktName;

            }
            if (column == "BEA MKT Name Alternate") {
                obj.beaMktNameAlternate = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.beaMktNameAlternate = e.beaMktNameAlternate;

            }
            if (column == "BEA MKT State") {
                obj.beaMktState = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.beaMktState = e.beaMktState;

            }
            if (column == "BID1") {
                obj.bid1 = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.bid1 = e.bid1;

            }
            if (column == "BID1 BSID1") {
                obj.bid1Bsid1 = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.bid1Bsid1 = e.bid1Bsid1;

            }
            if (column == "BID1 BSID2") {
                obj.bid1Bsid2 = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.bid1Bsid2 = e.bid1Bsid2;

            }
            if (column == "BID1 BSID3") {
                obj.bid1Bsid3 = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.bid1Bsid3 = e.bid1Bsid3;

            }
            if (column == "BID1 MNC") {
                obj.bid1Mnc = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.bid1Mnc = e.bid1Mnc;

            }
            if (column == "BID1 Name") {
                obj.bid1Name = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.bid1Name = e.bid1Name;

            }
            if (column == "BID2") {
                obj.bid2 = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.bid2 = e.bid2;

            }
            if (column == "BID2 BSID1") {
                obj.bid2Bsid1 = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.bid2Bsid1 = e.bid2Bsid1;

            }
            if (column == "BID2 BSID2") {
                obj.bid2Bsid2 = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.bid2Bsid2 = e.bid2Bsid2;

            }
            if (column == "BID2 BSID3") {
                obj.bid2Bsid3 = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.bid2Bsid3 = e.bid2Bsid3;

            }
            if (column == "BID2 MNC") {
                obj.bid2Mnc = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.bid2Mnc = e.bid2Mnc;

            }
            if (column == "BID2 Name") {
                obj.bid2Name = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.bid2Name = e.bid2Name;

            }
            if (column == "BID3") {
                obj.bid3 = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.bid3 = e.bid3;

            }
            if (column == "BID3 BSID1") {
                obj.bid3Bsid1 = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.bid3Bsid1 = e.bid3Bsid1;

            }
            if (column == "BID3 BSID2") {
                obj.bid3Bsid2 = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.bid3Bsid2 = e.bid3Bsid2;

            }
            if (column == "BID3 BSID3") {
                obj.bid3Bsid3 = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.bid3Bsid3 = e.bid3Bsid3;

            }
            if (column == "BID3 MNC") {
                obj.bid3Mnc = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.bid3Mnc = e.bid3Mnc;

            }
            if (column == "BID3 Name") {
                obj.bid3Name = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.bid3Name = e.bid3Name;

            }
            if (column == "BID4") {
                obj.bid4 = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.bid4 = e.bid4;

            }
            if (column == "BID4 BSID1") {
                obj.bid4Bsid1 = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.bid4Bsid1 = e.bid4Bsid1;

            }
            if (column == "BID4 BSID2") {
                obj.bid4Bsid2 = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.bid4Bsid2 = e.bid4Bsid2;

            }
            if (column == "BID4 BSID3") {
                obj.bid4Bsid3 = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.bid4Bsid3 = e.bid4Bsid3;

            }
            if (column == "BID4 MNC") {
                obj.bid4Mnc = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.bid4Mnc = e.bid4Mnc;

            }
            if (column == "BID4 Name") {
                obj.bid4Name = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.bid4Name = e.bid4Name;

            }
            if (column == "BTA MKT Code") {
                obj.btaMktCode = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.btaMktCode = e.btaMktCode;
            }
            if (column == "BTA MKT Multi State") {
                obj.btaMktMultiState = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.btaMktMultiState = e.btaMktMultiState;
            }
            if (column == "BTA MKT Name") {
                obj.btaMktName = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.btaMktName = e.btaMktName;

            }
            if (column == "BTA MKT Name Alternate") {
                obj.btaMktNameAlternate = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.btaMktNameAlternate = e.btaMktNameAlternate;

            }
            if (column == "BTA MKT State") {
                obj.btaMktState = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.btaMktState = e.btaMktState;

            }
            if (column == "CMA MKT Code") {
                obj.cmaMktCode = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.cmaMktCode = e.cmaMktCode;
            }
            if (column == "CMA MKT Multi State") {
                obj.cmaMktMultiState = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.cmaMktMultiState = e.cmaMktMultiState;
            }
            if (column == "CMA MKT Name") {
                obj.cmaMktName = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.cmaMktName = e.cmaMktName;

            }
            if (column == "CMA MKT Name Alternate") {
                obj.cmaMktNameAlternate = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.cmaMktNameAlternate = e.cmaMktNameAlternate;

            }
            if (column == "CMA MKT State") {
                obj.cmaMktState = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.cmaMktState = e.cmaMktState;

            }
            if (column == "County") {
                obj.county = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.county = e.county;

            }
            if (column == "Extended Services") {
                obj.extendedServices = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.extendedServices = e.extendedServices;

            }
            if (column == "Marketing Name") {
                obj.marketingName = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.marketingName = e.marketingName;

            }
            if (column == "MHZ Total") {
                obj.mhzTotal = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.mhzTotal = e.mhzTotal;

            }
            if (column == "Nation") {
                obj.nation = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.nation = e.nation;

            }
            if (column == "Protocol") {
                obj.protocol = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.protocol = e.protocol;

            }
            if (column == "Spectrum Blocks") {
                obj.spectrumBlocks = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.spectrumBlocks = e.spectrumBlocks;

            }
            if (column == "State") {
                obj.state = this.multicolumnEditValue.nativeElement.value;
            } else {
                obj.state = e.state;

            }
           
            obj.oldCarrierEntity = e.carrierEntity;
            obj.oldKeyCode= e.keyCode;
            requestObj.push(obj);
        });

        this.bulkUpdateArUsaMarketDetails(requestObj);
    }
    public bulkUpdateArUsaMarketDetails(request) {
        this.wizardService.bulkUpdateArUsaMarketDetails(request).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.arUsaMarketHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_ARUSAMARKET_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    this.showLoadingScreen = false;
                    this.alreadyEnabled = true;
                    this.editAlreadyEnabled = false;
                    this.bulkEditBoolean = false;
                    this.otherColumn = false;
                    this.showBulkUpdateButton = false;
                    this.selectedArUsaMarket = [];
                    this.selected = [];
                    this.editedRow = {};
                    this.defaultEditedRow = {};
                    this.checkDuplicate = false;
                    this.searchForm();

                    this.toasterService.showSuccessMessage(
                        this.arUsaMarketHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_ARUSAMARKET_SUCCESS_MESSAGE")
                    );

                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.arUsaMarketHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                });
    }

    /*opens the available columns popup*/
    openSml(content) {
        this.modalService.open(content, { size: 'lg' });
    }

    /*This method is used for filter in Available columns popup*/
    public updateOptionalColumns(event) {
        const val = event.target.value.toLowerCase();
        // filter our data
        const temp = this.searchColumnsMaindata.filter(function (d) {
            return d.name.toLowerCase().indexOf(val) !== -1 || !val;
        });
        // update the rows
        this.searchColumns = temp;
    }

    //reset the selected available columns 
    private resetOptionalFields() {
        this.searchColumns = this.searchColumnsMaindata;
    }

    private onSelectFields({ selected }) {
        this.selectedFields.splice(0, this.selectedFields.length);
        this.selectedFields.push(...selected);
    }

    /**
     * Sends request to retrieve the previous batch of transactions from the search parameter criteria.
     */
    paginationNextBatch() {
        let viewTransactionPagination: any = {};
        if (this.paginationStart >= this.paginationCount || this.paginationOffSet >= this.paginationCount) {
            this.paginationOffSet = this.paginationCount;
        } else {
            this.paginationStart = this.paginationStart + this.paginationEnd;
            this.paginationOffSet = this.paginationOffSet + this.paginationEnd;
        }
        viewTransactionPagination.startIndex = this.paginationStart;
        viewTransactionPagination.endIndex = this.paginationOffSet;
        this.pageindex = this.pageindex + 1;
        this.lastTransactionRequest.paginationSearch = viewTransactionPagination;
        this.fireSubmitMethod(this.lastTransactionRequest);
    }

    /**
     * Sends request to retrieve the previous batch of transactions from the search parameter criteria.
     */
    paginationPreviousBatch() {
        let viewTransactionPagination: any = {};
        if (this.paginationStart <= 1) {
            this.paginationStart = 1;
            this.paginationOffSet = this.paginationEnd;
        } else {
            this.paginationStart = this.paginationStart - this.paginationEnd;
            this.paginationOffSet = this.paginationOffSet - this.paginationEnd;
        }
        viewTransactionPagination.startIndex = this.paginationStart;
        viewTransactionPagination.endIndex = this.paginationOffSet;
        this.pageindex = this.pageindex - 1;
        this.lastTransactionRequest.paginationSearch = viewTransactionPagination;
        this.fireSubmitMethod(this.lastTransactionRequest);
    }


    private resetPaginationCounters() {
        this.paginationStart = 0;
        this.paginationOffSet = Number(this.PAGINATION_AMOUNT);
    }

    private createPaginationRequest(startIndex, endIndex) {
        this.resetPaginationCounters();
        let viewTransactionPagination: any = {};
        viewTransactionPagination.startIndex = startIndex;
        viewTransactionPagination.endIndex = Number(endIndex);
        this.paginationEnd = Number(endIndex);
        this.paginationOffSet = Number(endIndex);
        return viewTransactionPagination;
    }

        // to open bulk Delete pop up
  openUploadCSVDialog() {
    const dialogRef = this.dialog.open(BulkDeleteArUsaMarketComponent, {
        width: "90%",
        height: "90%",
    });
}


     //Used to Download Template
     exportToCSV() {
        let columns = [];
        this.tableColumns.forEach(x=>{
            columns.push(x.prop)            
        })
        this.exportToCsvService.downloadFile(this.selectedArUsaMarket, "ARUSAMarketexport", columns);
    }
}