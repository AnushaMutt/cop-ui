import { Component, OnInit, ViewEncapsulation, ViewChildren, Output, EventEmitter } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { ConfirmationService } from 'primeng/primeng';
import { takeUntil } from 'rxjs/operators';
import { Subject } from "rxjs";
import { CarrierMaintenanceService } from '../../../../../Services/carrierMaintenance.service';
import { CarrierMaintenanceHelper } from "../../carrier-maintenance-helper";
import { ToasterService } from "../../../../../Services/toaster.service";
import { MatDialog } from "@angular/material";
import { ArUsaMarketHelper } from "../ar-usa-market-helper";
import { ArUsaMarketService } from "../ar-usa-market-service";
import { BulkInsertArUsaMarketComponent } from "../bulk-add-ar-usa-market/bulk-add-ar-usa-market.component";

@Component({
    selector: 'add-ar-usa-market',
    templateUrl: './add-ar-usa-market.component.html',
    styleUrls: ['./add-ar-usa-market.component.scss',
        "../../../../components/ngxtable/material.scss",
        "../../../../components/ngxtable/datatable.component.scss",
        "../../../../components/ngxtable/icons.css",
        "../../../../components/ngxtable/app.css"],
    animations: [],
    encapsulation: ViewEncapsulation.None,
})

export class AddArUsaMarketComponent implements OnInit {
    
    @ViewChildren(DatatableComponent)
    table: any;
    private unsubscribe = new Subject<void>();
    public frmArUsaMarket: FormGroup;
    public showLoadingScreen: boolean;
    public displayTable = false;
    private checkedAnother = false;
    public tableRows: any = [];
    public tableRowsMainData: any = [];
    isEditable = {};
    private editedRow: any = {};
    private defaultEditedRow: any = {};
    public tableColumns:any = [];
    public alerts = [];
    public bulkInsertData = [];
    public showMssg = false;
    @Output("returnedData") returnedData: any = new EventEmitter();
    public alreadyEnabled = true;
    public filteredRows: any;
    public tableFrmGroupMain: FormGroup;
    public filteredValues: any = {};
    public checkDuplicate = false;
    


    constructor(
        private formBuilder: FormBuilder,
        private wizardService: CarrierMaintenanceService,
        private arusamarketHelper: ArUsaMarketHelper,
        private toasterService: ToasterService,
        private wizardHelper: CarrierMaintenanceHelper,
        private confirmationService: ConfirmationService,
        private arusamarketService: ArUsaMarketService,
        public dialog: MatDialog,
    ) {
        this.frmArUsaMarket = new FormGroup({});
    }

    ngOnInit() { 
        this.createForm();
        this.createTableForm();
        this.tableColumns = [
            { name: 'Carrier Entity', prop: 'carrierEntity', width: "250" },
            { name: 'Key Code', prop: 'keyCode', width: "250" },
            { name: 'BEA MKT Code', prop: 'beaMktCode', width: "250" },
            { name: 'BEA MKT Multi State', prop: 'beaMktMultiState', width: "250" },
            { name: 'BEA MKT Name', prop: 'beaMktName', width: "250" },
            { name: 'BEA MKT Name Alternate', prop: 'beaMktNameAlternate', width: "250" },
            { name: 'BEA MKT State', prop: 'beaMktState', width: "250" },
            { name: 'BID1', prop: 'bid1', width: "250" },
            { name: 'BID1 BSID1', prop: 'bid1Bsid1', width: "250" },
            { name: 'BID1 BSID2', prop: 'bid1Bsid2', width: "250" },
            { name: 'BID1 BSID3', prop: 'bid1Bsid3', width: "250" },
            { name: 'BID1 MNC', prop: 'bid1Mnc', width: "250" },
            { name: 'BID1 Name', prop: 'bid1Name', width: "250" },
            { name: 'BID2', prop: 'bid2', width: "250" },
            { name: 'BID2 BSID1', prop: 'bid2Bsid1', width: "250" },
            { name: 'BID2 BSID2', prop: 'bid2Bsid2', width: "250" },
            { name: 'BID2 BSID3', prop: 'bid2Bsid3', width: "250" },
            { name: 'BID2 MNC', prop: 'bid2Mnc', width: "250" },
            { name: 'BID2 Name', prop: 'bid2Name', width: "250" },
            { name: 'BID3', prop: 'bid3', width: "250" },
            { name: 'BID3 BSID1', prop: 'bid3Bsid1', width: "250" },
            { name: 'BID3 BSID2', prop: 'bid3Bsid2', width: "250" },
            { name: 'BID3 BSID3', prop: 'bid3Bsid3', width: "250" },
            { name: 'BID3 MNC', prop: 'bid3Mnc', width: "250" },
            { name: 'BID3 Name', prop: 'bid3Name', width: "250" },
            { name: 'BID4', prop: 'bid4', width: "250" },
            { name: 'BID4 BSID1', prop: 'bid4Bsid1', width: "250" },
            { name: 'BID4 BSID2', prop: 'bid4Bsid2', width: "250" },
            { name: 'BID4 BSID3', prop: 'bid4Bsid3', width: "250" },
            { name: 'BID4 MNC', prop: 'bid4Mnc', width: "250" },
            { name: 'BID4 Name', prop: 'bid4Name', width: "250" },
            { name: 'BTA MKT Code', prop: 'btaMktCode', width: "250" },
            { name: 'BTA MKT Multi State', prop: 'btaMktMultiState', width: "250" },
            { name: 'BTA MKT Name', prop: 'btaMktName', width: "250" },
            { name: 'BTA MKT Name Alternate', prop: 'btaMktNameAlternate', width: "250" },
            { name: 'BTA MKT State', prop: 'btaMktState', width: "250" },
            { name: 'CMA MKT Code', prop: 'cmaMktCode', width: "250" },
            { name: 'CMA MKT Multi State', prop: 'cmaMktMultiState', width: "250" },
            { name: 'CMA MKT Name', prop: 'cmaMktName', width: "250" },
            { name: 'CMA MKT Name Alternate', prop: 'cmaMktNameAlternate', width: "250" },
            { name: 'CMA MKT State', prop: 'cmaMktState', width: "250" },
            { name: 'County', prop: 'county', width: "250" },
            { name: 'Extended Services', prop: 'extendedServices', width: "250" },
            { name: 'Marketing Name', prop: 'marketingName', width: "250" },
            { name: 'MHZ Total', prop: 'mhzTotal', width: "250" },
            { name: 'Nation', prop: 'nation', width: "250" },
            { name: 'Protocol', prop: 'protocol', width: "250" },
            { name: 'Spectrum Blocks', prop: 'spectrumBlocks', width: "250" },
            { name: 'State', prop: 'state', width: "250" },
        ];
        this.showMssg = false;
        this.arusamarketService.setAddData([]);
    }

        //to create form
        private createForm() {
            this.frmArUsaMarket = this.formBuilder.group({
                carrierEntity: ['', [Validators.required, Validators.maxLength(200)]],  
                keyCode: ['', [Validators.required, Validators.maxLength(200)]],        
                beaMktCode: ['', [Validators.maxLength(200)]],
                beaMktMultiState: ['', [Validators.maxLength(200)]],
                beaMktName: ['', [Validators.maxLength(200)]],
                beaMktNameAlternate: ['', [Validators.maxLength(200)]],
                beaMktState: ['', [Validators.maxLength(200)]],
                bid1: ['', [Validators.maxLength(200)]],
                bid1Bsid1: ['', [Validators.maxLength(200)]],
                bid1Bsid2: ['', [Validators.maxLength(200)]],
                bid1Bsid3: ['', [Validators.maxLength(200)]],
                bid1Mnc: ['', [Validators.maxLength(200)]],
                bid1Name: ['', [Validators.maxLength(200)]],
                bid2: ['', [Validators.maxLength(200)]],
                bid2Bsid1: ['', [Validators.maxLength(200)]],
                bid2Bsid2: ['', [Validators.maxLength(200)]],
                bid2Bsid3: ['', [Validators.maxLength(200)]],
                bid2Mnc: ['', [Validators.maxLength(200)]],
                bid2Name: ['', [Validators.maxLength(200)]],
                bid3: ['', [Validators.maxLength(200)]],
                bid3Bsid1: ['', [Validators.maxLength(200)]],
                bid3Bsid2: ['', [Validators.maxLength(200)]],
                bid3Bsid3: ['', [Validators.maxLength(200)]],
                bid3Mnc: ['', [Validators.maxLength(200)]],
                bid3Name: ['', [Validators.maxLength(200)]],
                bid4: ['', [Validators.maxLength(200)]],
                bid4Bsid1: ['', [Validators.maxLength(200)]],
                bid4Bsid2: ['', [Validators.maxLength(200)]],
                bid4Bsid3: ['', [Validators.maxLength(200)]],
                bid4Mnc: ['', [Validators.maxLength(200)]],
                bid4Name: ['', [Validators.maxLength(200)]],
                btaMktCode: ['', [Validators.maxLength(200)]],
                btaMktMultiState: ['', [Validators.maxLength(200)]],
                btaMktName: ['', [Validators.maxLength(200)]],
                btaMktNameAlternate: ['', [Validators.maxLength(200)]],
                btaMktState: ['', [Validators.maxLength(200)]],
                cmaMktCode: ['', [Validators.maxLength(200)]],
                cmaMktMultiState: ['', [Validators.maxLength(200)]],
                cmaMktName: ['', [Validators.maxLength(200)]],
                cmaMktNameAlternate: ['', [Validators.maxLength(200)]],
                cmaMktState: ['', [Validators.maxLength(200)]],
                county: ['', [Validators.maxLength(200)]],
                extendedServices: ['', [Validators.maxLength(200)]],
                marketingName: ['', [Validators.maxLength(200)]],
                mhzTotal: ['', [Validators.maxLength(200)]],
                nation: ['', [Validators.maxLength(3)]],
                protocol: ['', [Validators.maxLength(200)]],
                spectrumBlocks: ['', [Validators.maxLength(200)]],
                state: ['', [Validators.maxLength(2)]],              
            })
        }

    //form for column level filter
    public createTableForm() {
        this.tableFrmGroupMain = this.formBuilder.group({
            carrierEntity: [''],
            keyCode: [''],          
            beaMktCode: [''],
            beaMktMultiState: [''],
            beaMktName: [''],
            beaMktNameAlternate: [''],
            beaMktState: [''],
            bid1: [''],
            bid1Bsid1: [''],
            bid1Bsid2: [''],
            bid1Bsid3: [''],
            bid1Mnc: [''],
            bid1Name: [''],
            bid2: [''],
            bid2Bsid1: [''],
            bid2Bsid2: [''],
            bid2Bsid3: [''],
            bid2Mnc: [''],
            bid2Name: [''],
            bid3: [''],
            bid3Bsid1: [''],
            bid3Bsid2: [''],
            bid3Bsid3: [''],
            bid3Mnc: [''],
            bid3Name: [''],
            bid4: [''],
            bid4Bsid1: [''],
            bid4Bsid2: [''],
            bid4Bsid3: [''],
            bid4Mnc: [''],
            bid4Name: [''],
            btaMktCode: [''],
            btaMktMultiState: [''],
            btaMktName: [''],
            btaMktNameAlternate: [''],
            btaMktState: [''],
            cmaMktCode: [''],
            cmaMktMultiState: [''],
            cmaMktName: [''],
            cmaMktNameAlternate: [''],
            cmaMktState: [''],
            county: [''],
            extendedServices: [''],
            marketingName: [''],
            mhzTotal: [''],
            nation: [''],
            protocol: [''],
            spectrumBlocks: [''],
            state: [''],       
        });
    }

    //to add Ar Usa Market Details
    private addArUsaMarketDetails(f) {
        this.showLoadingScreen = true;
        this.alreadyEnabled = true;
        let obj = f.value;
        obj = this.wizardHelper.checkRequestObject(obj);
        this.wizardService.addArUsaMarketDetails(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.arusamarketHelper.getTracfoneConstantMethod("TRACFONE_ADD_ARUSAMARKET_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }

                const d = data[0].message;
                if(d==""){
                    this.toasterService.showErrorMessage(
                    this.arusamarketHelper.getTracfoneConstantMethod("TRACFONE_DUPLICATE_ARUSAMARKET_ERROR_MESSAGE")
                );
                }else{
                    let fullObject = [];
                    if (!this.arusamarketService.getAddData() || (this.arusamarketService.getAddData() && this.arusamarketService.getAddData().length == 0)) {
                            fullObject.push(obj);
                    } else if (this.arusamarketService.getAddData().length > 0) {
                        fullObject = this.arusamarketService.getAddData();
                        fullObject.forEach((data, key) => {
                            if (data.carrierEntity == obj.carrierEntity && data.keyCode == obj.keyCode) {
                                fullObject.splice(key, 1);
                                fullObject = [...fullObject];
                            }
                        });
                            fullObject.push(obj);
                    }
                    this.arusamarketService.setAddData(fullObject);
                    this.tableRowsMainData = [];
                    this.tableRows = [];
                    for (let i = 0; i < this.arusamarketService.getAddData().length; i++) {
                        this.tableRowsMainData.push(this.arusamarketService.getAddData()[i]);
                    }
                    let rowId = 1;
                    this.tableRowsMainData.forEach(element => {
                        element.rowId = rowId;
                        rowId++;
                    });
                    this.tableRows = [...this.tableRowsMainData];
                    if (this.checkedAnother) {
                        this.displayTable = false;
                    } else {
                        this.displayTable = true;
                    }
                    this.generateFilters();
                    this.filterReportResults();
                    this.frmArUsaMarket.reset();
                    this.toasterService.showSuccessMessage(
                        data[0].message
                    );
                }
                this.checkDuplicate = false;
                this.showLoadingScreen = false;
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.arusamarketHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }

    onChangeCheckbox(event) {
        if (event.checked) this.checkedAnother = true;
        else this.checkedAnother = false;
    }

    //show summary confirm
    public showSummaryConfirm(f, index) {
        this.confirmationService.confirm({
            key: 'confirm-add-show-summary',
            message: this.arusamarketHelper.getTracfoneConstantMethod("TRACFONE_DONE_CREATING_ARUSAMARKET_CONFIRM_MESSAGE"),
            accept: () => {
                this.displayTable = true;
                this.checkedAnother = false;
            }
        });
    }
    
    // reset the form
    revert() {
        this.frmArUsaMarket.reset();
        this.tableRows = [];
        this.tableRowsMainData = [];
        this.filteredValues = {};
        this.alerts = [];
        let filterKeys = Object.keys(this.tableFrmGroupMain.controls);
        filterKeys.forEach(_e1 => {
            this.tableFrmGroupMain.controls[`${_e1}`].patchValue([]);
        });
        this.alreadyEnabled = true;
    }

    public  editButtonClicked(rowData,rowIndex) {
        this.alreadyEnabled = false;
        this.defaultEditedRow = { ...rowData }
        for (let i = 0; i < this.tableRowsMainData.length; i++) {
          if (this.isEditable[i])
            this.alreadyEnabled = true;
        }
        if (!this.alreadyEnabled)
          this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        else{
          this.alreadyEnabled = false;
          this.toasterService.showErrorMessage(
            this.arusamarketHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE")
          );
        }
      }
    
    private inputValueChanged(event, column, row, oldValue) {
            this.editedRow[column] = event.target.value;
            this.defaultEditedRow[column] = event.target.defaultValue;
    
    }
    
    //to update Ar Usa Market Details
    public updateArUsaMarketDetails(editData, rowIndex) {
        if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
            this.toasterService.showErrorMessage(
                this.arusamarketHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            return;
        }
        this.showLoadingScreen = true;
        let obj = { ...editData, ...this.editedRow }

        obj = this.wizardHelper.checkRequestObject(obj);
        obj.oldCarrierEntity = this.defaultEditedRow.carrierEntity;
        obj.oldKeyCode = this.defaultEditedRow.keyCode;
        if (obj.keyCode != this.defaultEditedRow.keyCode || obj.carrierEntity != this.defaultEditedRow.carrierEntity) {
            this.checkDuplicate = true;
        } else {
            this.checkDuplicate = false;
        }
        obj.checkDuplicate = this.checkDuplicate;
        this.wizardService.updateArUsaMarketDetails(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.arusamarketHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_ARUSAMARKET_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                for (let i = 0; i < this.tableRowsMainData.length; i++) {
                    if (this.tableRowsMainData[i].rowId == this.defaultEditedRow.rowId) {
                        this.tableRowsMainData[i] = obj;
                    }
                }
                this.isEditable[rowIndex] = !this.isEditable[rowIndex];
                this.showLoadingScreen = false;
                this.editedRow = {};
                this.defaultEditedRow = {};
                this.tableRows = [...this.tableRowsMainData];
                this.alreadyEnabled = true;
                this.generateFilters();
                // this.filterReportResults();
    
                this.toasterService.showSuccessMessage(
                    this.arusamarketHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_ARUSAMARKET_SUCCESS_MESSAGE")
                );
    
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.arusamarketHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }
    
    //to cancel update
    private cancelEditForm(rowData, rowIndex) {
        this.showLoadingScreen = true;
        this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        this.tableColumns.forEach(e1 => {
            if (document.getElementById(e1.prop + rowIndex)) {
                (<HTMLInputElement>(
                    document.getElementById(e1.prop + rowIndex)
                )).value = rowData[e1.prop] || '';
            }
        });
    
        this.editedRow = {};
        this.defaultEditedRow = {};
        this.showLoadingScreen = false;
        this.alreadyEnabled = true;
    }
    
    //to filter table
    private updateSummaryTable(event) {
        const val = event.target.value.toLowerCase();
    
        const temp = this.tableRowsMainData.filter(function (d) {
            return (d.carrierEntity ? d.carrierEntity.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.keyCode ? d.keyCode.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.beaMktCode ? d.beaMktCode.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.beaMktMultiState ? d.beaMktMultiState.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.beaMktName ? d.beaMktName.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.beaMktNameAlternate ? d.beaMktNameAlternate.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.beaMktState ? d.beaMktState.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid1 ? d.bid1.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid1Bsid1 ? d.bid1Bsid1.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid1Bsid2 ? d.bid1Bsid2.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid1Bsid3 ? d.bid1Bsid3.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid1Mnc ? d.bid1Mnc.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid1Name ? d.bid1Name.toLowerCase().indexOf(val) !== -1 : !val)
			|| (d.bid2 ? d.bid2.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid2Bsid1 ? d.bid2Bsid1.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid2Bsid2 ? d.bid2Bsid2.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid2Bsid3 ? d.bid2Bsid3.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid2Mnc ? d.bid2Mnc.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid2Name ? d.bid2Name.toLowerCase().indexOf(val) !== -1 : !val)
			|| (d.bid3 ? d.bid3.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid3Bsid1 ? d.bid3Bsid1.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid3Bsid2 ? d.bid3Bsid2.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid3Bsid3 ? d.bid3Bsid3.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid3Mnc ? d.bid3Mnc.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid3Name ? d.bid3Name.toLowerCase().indexOf(val) !== -1 : !val)
			|| (d.bid4 ? d.bid4.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid4Bsid1 ? d.bid4Bsid1.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid4Bsid2 ? d.bid4Bsid2.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid4Bsid3 ? d.bid4Bsid3.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid4Mnc ? d.bid4Mnc.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid4Name ? d.bid4Name.toLowerCase().indexOf(val) !== -1 : !val)
			|| (d.btaMktCode ? d.btaMktCode.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.btaMktMultiState ? d.btaMktMultiState.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.btaMktName ? d.btaMktName.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.btaMktNameAlternate ? d.btaMktNameAlternate.toLowerCase().indexOf(val) !== -1 : !val)	
            || (d.btaMktState ? d.btaMktState.toLowerCase().indexOf(val) !== -1 : !val)
			|| (d.cmaMktCode ? d.cmaMktCode.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.cmaMktMultiState ? d.cmaMktMultiState.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.cmaMktName ? d.cmaMktName.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.cmaMktNameAlternate ? d.cmaMktNameAlternate.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.cmaMktState ? d.cmaMktState.toLowerCase().indexOf(val) !== -1 : !val)
			|| (d.county ? d.county.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.extendedServices ? d.extendedServices.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.marketingName ? d.marketingName.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.mhzTotal ? d.mhzTotal.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.nation ? d.nation.toLowerCase().indexOf(val) !== -1 : !val)
			|| (d.protocol ? d.protocol.toLowerCase().indexOf(val) !== -1 : !val)
			|| (d.spectrumBlocks ? d.spectrumBlocks.toLowerCase().indexOf(val) !== -1 : !val)
			|| (d.state ? d.state.toLowerCase().indexOf(val) !== -1 : !val)
        });
        this.tableRows = temp;
    }


// delete confirm
public showConfirm(cmiData, rowIndex) {
    this.confirmationService.confirm({
      key: 'confirm-delete-cmi',
      message: "Are you sure you want to delete AR USA MARKET ?",
      accept: () => {
        this.deleteArUsaMarketDetails(cmiData, rowIndex)
      }
    });
  }

  // to delete Ar Usa MarketDetails
  public deleteArUsaMarketDetails(cmiData, rowIndex) {
    this.showLoadingScreen = true;
    let obj:any = {};
    obj = cmiData
    delete obj.rowId;
    this.wizardService.deleteArUsaMarketDetails(obj).pipe(takeUntil(this.unsubscribe))
      .subscribe(
      (data: any) => {
        if (data[0] === null || data[0] === undefined) {
          this.showLoadingScreen = false;
          this.toasterService.showErrorMessage(
            this.arusamarketHelper.getTracfoneConstantMethod("TRACFONE_DELETE_ARUSAMARKET_ERROR_MESSAGE")
          );
          return;
        }
        if (data[0] && data[0].ERR) {
          this.showLoadingScreen = false;
          const commaSeperatedArr = data[0].ERR.split(",");
          for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
            if (commaSeperatedArr[i] != "")
              this.toasterService.showErrorMessage(
                commaSeperatedArr[i]
              );
          }
          return;
        }
        this.toasterService.showSuccessMessage(
          this.arusamarketHelper.getTracfoneConstantMethod("TRACFONE_DELETE_ARUSAMARKET_SUCCESS_MESSAGE")
        );

        this.tableRows.forEach((rec: any, key) => {
            if (obj.carrierEntity == rec.carrierEntity && obj.keyCode == rec.keyCode) {
              this.tableRows.splice(key, 1);
              this.arusamarketService.getAddData().splice(key, 1);
            }
          });
          this.tableRows = [...this.tableRows];
          this.tableRowsMainData = [...this.tableRows];
          if (this.tableRows.length === 0) {
            this.displayTable = false;
            this.checkedAnother = false;
            this.tableRows = [];
            this.revert();
            this.arusamarketService.setAddData([]);
          }
        this.showLoadingScreen = false;
      },
      (err: any) => {
        this.showLoadingScreen = false;
        if (err.error === undefined || err.error === null)
          this.toasterService.showErrorMessage(
            this.arusamarketHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
          );
        else if (err.error && err.error.ERR) {
          const commaSeperatedArr = err.error.ERR.split(",");
          for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
            if (commaSeperatedArr[i] != "")
              this.toasterService.showErrorMessage(
                commaSeperatedArr[i]
              );
          }
        }
        else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
          return;
        else this.toasterService.showErrorMessage(err.error);
      }
      );
  }

  // to open bulk insert pop up
  openUploadCSVDialog() {
    const dialogRef = this.dialog.open(BulkInsertArUsaMarketComponent, {
        width: "90%",
        height: "90%",
    });
    // Create subscription
    dialogRef.afterClosed().subscribe((bulkInsertData) => {
        if (bulkInsertData && bulkInsertData.length > 0) {
            this.warningAlert("Your upload is complete. Please click on Submit to begin database insertions.")
            this.bulkInsertData = [...bulkInsertData];
            let filterKeys = Object.keys(this.frmArUsaMarket.controls);
        filterKeys.forEach(_e1 => {
            this.frmArUsaMarket.controls[`${_e1}`].setValidators([]);
            this.frmArUsaMarket.controls[`${_e1}`].updateValueAndValidity();
        });
        }
    });
}

//to bulk insert AR USA Market
private bulkInsertArUsaMarket() {
    this.showLoadingScreen = true;
    let obj: any = [];
    this.alreadyEnabled = true;
    obj = [...this.bulkInsertData];
    obj.forEach(element => {
        element.dbEnv = this.wizardHelper.dbEnv;
    });
    obj = this.wizardHelper.checkRequestObject(obj);
    obj.dbEnv = this.wizardHelper.dbEnv;
    this.wizardService.bulkInsertArUsaMarket(obj).pipe(takeUntil(this.unsubscribe))
        .subscribe(
        (data: any) => {
            if (data[0] === null || data[0] === undefined) {
                this.showLoadingScreen = false;
                this.toasterService.showErrorMessage(
                    this.arusamarketHelper.getTracfoneConstantMethod("TRACFONE_ADD_ARUSAMARKET_ERROR_MESSAGE")
                );
                return;
            }
            if (data[0] && data[0].ERR) {
                this.showLoadingScreen = false;
                const commaSeperatedArr = data[0].ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
                return;
            }
            this.showLoadingScreen = false;
            this.showMssg = true;
            this.revert();
        },
        (err: any) => {
            this.showLoadingScreen = false;
            if (err.error === undefined || err.error === null)
                this.toasterService.showErrorMessage(
                    this.arusamarketHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                );
            else if (err.error && err.error.ERR) {
                const commaSeperatedArr = err.error.ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
            }
            else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                return;
            else this.toasterService.showErrorMessage(err.error);
        }
        );
}

private warningAlert(warningMsg: string) {
    window.scrollTo(0, 0);
    this.alerts = [];
    this.alerts.push({
        id: 3,
        type: 'warning',
        message: warningMsg
    });
  }

  public closeAlert(alert: any) {
    const index: number = this.alerts.indexOf(alert);
    this.alerts.splice(index, 1);
  }

  public showLastInsertedRecords() {
    this.returnedData.emit({ lastInsertedRecord: true });
  }

  // to filter columns
public filterReportResults(): void {
    const filterFormObject = this.tableFrmGroupMain.value;
    this.filteredValues.carrierEntity = filterFormObject.carrierEntity;
    this.filteredValues.keyCode = filterFormObject.keyCode;
    this.filteredValues.beaMktCode = filterFormObject.beaMktCode;
    this.filteredValues.beaMktMultiState = filterFormObject.beaMktMultiState;
    this.filteredValues.beaMktName = filterFormObject.beaMktName;
    this.filteredValues.beaMktNameAlternate = filterFormObject.beaMktNameAlternate;
    this.filteredValues.beaMktState = filterFormObject.beaMktState;
    this.filteredValues.bid1 = filterFormObject.bid1;
    this.filteredValues.bid1Bsid1 = filterFormObject.bid1Bsid1;
    this.filteredValues.bid1Bsid2 = filterFormObject.bid1Bsid2;
    this.filteredValues.bid1Bsid3 = filterFormObject.bid1Bsid3;
    this.filteredValues.bid1Mnc = filterFormObject.bid1Mnc;
    this.filteredValues.bid1Name = filterFormObject.bid1Name;	
	this.filteredValues.bid2 = filterFormObject.bid2;
    this.filteredValues.bid2Bsid1 = filterFormObject.bid2Bsid1;
    this.filteredValues.bid2Bsid2 = filterFormObject.bid2Bsid2;
    this.filteredValues.bid2Bsid3 = filterFormObject.bid2Bsid3;
    this.filteredValues.bid2Mnc = filterFormObject.bid2Mnc;
    this.filteredValues.bid2Name = filterFormObject.bid2Name;	
	this.filteredValues.bid3 = filterFormObject.bid3;
    this.filteredValues.bid3Bsid1 = filterFormObject.bid3Bsid1;
    this.filteredValues.bid3Bsid2 = filterFormObject.bid3Bsid2;
    this.filteredValues.bid3Bsid3 = filterFormObject.bid3Bsid3;
    this.filteredValues.bid3Mnc = filterFormObject.bid3Mnc;
    this.filteredValues.bid3Name = filterFormObject.bid3Name;	
	this.filteredValues.bid4 = filterFormObject.bid4;
    this.filteredValues.bid4Bsid1 = filterFormObject.bid4Bsid1;
    this.filteredValues.bid4Bsid2 = filterFormObject.bid4Bsid2;
    this.filteredValues.bid4Bsid3 = filterFormObject.bid4Bsid3;
    this.filteredValues.bid4Mnc = filterFormObject.bid4Mnc;
    this.filteredValues.bid4Name = filterFormObject.bid4Name;	
	this.filteredValues.btaMktCode = filterFormObject.btaMktCode;
    this.filteredValues.btaMktMultiState = filterFormObject.btaMktMultiState;
    this.filteredValues.btaMktName = filterFormObject.btaMktName;
    this.filteredValues.btaMktNameAlternate = filterFormObject.btaMktNameAlternate;
    this.filteredValues.btaMktState = filterFormObject.btaMktState;	
	this.filteredValues.cmaMktCode = filterFormObject.cmaMktCode;
    this.filteredValues.cmaMktMultiState = filterFormObject.cmaMktMultiState;
    this.filteredValues.cmaMktName = filterFormObject.cmaMktName;
    this.filteredValues.cmaMktNameAlternate = filterFormObject.cmaMktNameAlternate;
    this.filteredValues.cmaMktState = filterFormObject.cmaMktState;
	this.filteredValues.county = filterFormObject.county;
    this.filteredValues.extendedServices = filterFormObject.extendedServices;
    this.filteredValues.marketingName = filterFormObject.marketingName;
    this.filteredValues.mhzTotal = filterFormObject.mhzTotal;
    this.filteredValues.nation = filterFormObject.nation;
	this.filteredValues.protocol = filterFormObject.protocol;
    this.filteredValues.spectrumBlocks = filterFormObject.spectrumBlocks;
    this.filteredValues.state = filterFormObject.state;
    const newRows = Object.keys(filterFormObject).reduce((acc, key) => {
        if (!filterFormObject[key].length) return acc;
        const filteredRows = acc.filter(val => filterFormObject[key].indexOf(val[key]) > -1);
        return filteredRows;
    }, this.tableRowsMainData);

    this.tableRows = newRows;
}

public generateFilters(): void {
    this.filteredRows = Object.keys(this.tableColumns)
        .map(i => this.tableColumns[i].prop)
        .reduce((filterObject, columnName) => {
            const uniqueValuesPerRow = this.tableRows.reduce((set, row) => set.add(row[columnName]), new Set());
            let val:any = Array.from(uniqueValuesPerRow);
          if( /^[0-9]*$/.test(val[0])){
               filterObject[columnName] = val.sort(function(a,b){return a - b});
          }else{
               filterObject[columnName] =val.sort((a, b) => {
                a = a || '';
                b = b || '';
                return a.localeCompare(b);
            });                   
          }
            return filterObject;
        }, {});
}

}
