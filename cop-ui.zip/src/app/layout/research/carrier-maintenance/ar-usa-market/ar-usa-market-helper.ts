import { Injectable } from "@angular/core";
import { Subject } from "rxjs";

@Injectable({
    providedIn: "root"
})
export class ArUsaMarketHelper {
    
    public breadcrumbListUpdate = new Subject<number>();
    public breadcrumbList = [];
    constructor() { }

    public ArUsaMarketConstantObject = {
        "TRACFONE_DEFAULT_ERROR_MESSAGE": "Unable to process request",
        "TRACFONE_DONE_CREATING_ARUSAMARKET_CONFIRM_MESSAGE": "Are you done creating ARUSA Market ?",
        "TRACFONE_ADD_ARUSAMARKET_ERROR_MESSAGE": "Unable to add ARUSA Market",
        "TRACFONE_ADD_ARUSAMARKET_SUCCESS_MESSAGE": "ARUSA Market has been added successfully",  
        "TRACFONE_RETRIEVE_ARUSAMARKET_ERROR_MESSAGE" : "Unable to search ARUSA Market",
        "TRACFONE_SEARCH_ARUSAMARKET_ERROR_MESSAGE" : "No ARUSA Market found",
        "TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE": "Please complete previous operation",  
        "TRACFONE_UPDATE_ARUSAMARKET_ERROR_MESSAGE" : "Unable to update ARUSA Market",
        "TRACFONE_UPDATE_ARUSAMARKET_SUCCESS_MESSAGE" : "ARUSA Market has been updated successfully",
        "TRACFONE_DELETE_ARUSAMARKET_SUCCESS_MESSAGE": "ARUSA Market has been deleted successfully",
        "TRACFONE_DELETE_ARUSAMARKET_ERROR_MESSAGE": "Unable to delete ARUSA Market",
        "TRACFONE_NO_SUMMARY_FOUND_ERROR_MESSAGE" : "No records found",
        "TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE" : "Please fix validation errors",
        "TRACFONE_DUPLICATE_ARUSAMARKET_ERROR_MESSAGE" : "Duplicate ARUSA Market found",
    }

    public getTracfoneConstantMethod(msg) {
        return this.ArUsaMarketConstantObject[msg];
    }

}