import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { ToasterService } from "../../../../../Services/toaster.service";
import { ExportToCsvService } from "../../../../../Services/export-to-csv.service";
import { ImportFromCsvService } from "../../../../../Services/import-from-csv.service";
import { MatDialogRef } from "@angular/material";

@Component({
    selector: 'bulk-add-ar-usa-market',
    templateUrl: './bulk-add-ar-usa-market.component.html',
    styleUrls: ['./bulk-add-ar-usa-market.component.scss',
        "../../../../components/ngxtable/material.scss",
        "../../../../components/ngxtable/datatable.component.scss",
        "../../../../components/ngxtable/icons.css",
        "../../../../components/ngxtable/app.css"],
    animations: [],
    encapsulation: ViewEncapsulation.None,
    providers: [ExportToCsvService, ImportFromCsvService]
})

export class BulkInsertArUsaMarketComponent implements OnInit {
    public multiColumnEditColumns = [];
    public fileContent: Boolean;
    public filename: string = null;
    public uploadedData: any = [];
    public uploadedMainData: any = [];
    public alerts: any = [];
    public exportColumns = [];
    public tableColmns = [];
    readonly EXPORT_FILE_NAME = "Insert_ArUsaMarket_template";
    public showLoadingScreen: Boolean = false;
    public showMssg = false;

    constructor(
        private toasterService: ToasterService,
        private exportToCsvService: ExportToCsvService,
        private importFromCsvService: ImportFromCsvService,
        public dialogRef: MatDialogRef<BulkInsertArUsaMarketComponent>,
    ) { dialogRef.disableClose = true;  }

    ngOnInit() {
        this.fileContent = false;
        this.filename = "";
        this.uploadedData = [];
        this.uploadedMainData = [];
        this.alerts = [];
        this.exportColumns = ["Key Code","Nation","State","County","Carrier Entity","Marketing Name","MHZ Total","Spectrum Blocks",
        "CMA MKT Code","CMA MKT State","CMA MKT Name","CMA MKT Name Alternate","CMA MKT Multi State",
        "BTA MKT Code","BTA MKT State","BTA MKT Name","BTA MKT Name Alternate","BTA MKT Multi State",
        "BEA MKT Code","BEA MKT State","BEA MKT Name","BEA MKT Name Alternate","BEA MKT Multi State",
        "Protocol","Extended Services",
        "BID1","BID1 Name","BID1 BSID1","BID1 BSID2","BID1 BSID3","BID1 MNC",
        "BID2","BID2 Name","BID2 BSID1","BID2 BSID2","BID2 BSID3","BID2 MNC",
        "BID3","BID3 Name","BID3 BSID1","BID3 BSID2","BID3 BSID3","BID3 MNC",
        "BID4","BID4 Name","BID4 BSID1","BID4 BSID2","BID4 BSID3","BID4 MNC",
        ];
        this.tableColmns = [
            { name: 'Carrier Entity', prop: 'carrierEntity', width: "250" },
            { name: 'Key Code', prop: 'keyCode', width: "250" },
            { name: 'BEA MKT Code', prop: 'beaMktCode', width: "250" },
            { name: 'BEA MKT Multi State', prop: 'beaMktMultiState', width: "250" },
            { name: 'BEA MKT Name', prop: 'beaMktName', width: "250" },
            { name: 'BEA MKT Name Alternate', prop: 'beaMktNameAlternate', width: "250" },
            { name: 'BEA MKT State', prop: 'beaMktState', width: "250" },
            { name: 'BID1', prop: 'bid1', width: "250" },
            { name: 'BID1 BSID1', prop: 'bid1Bsid1', width: "250" },
            { name: 'BID1 BSID2', prop: 'bid1Bsid2', width: "250" },
            { name: 'BID1 BSID3', prop: 'bid1Bsid3', width: "250" },
            { name: 'BID1 MNC', prop: 'bid1Mnc', width: "250" },
            { name: 'BID1 Name', prop: 'bid1Name', width: "250" },
            { name: 'BID2', prop: 'bid2', width: "250" },
            { name: 'BID2 BSID1', prop: 'bid2Bsid1', width: "250" },
            { name: 'BID2 BSID2', prop: 'bid2Bsid2', width: "250" },
            { name: 'BID2 BSID3', prop: 'bid2Bsid3', width: "250" },
            { name: 'BID2 MNC', prop: 'bid2Mnc', width: "250" },
            { name: 'BID2 Name', prop: 'bid2Name', width: "250" },
            { name: 'BID3', prop: 'bid3', width: "250" },
            { name: 'BID3 BSID1', prop: 'bid3Bsid1', width: "250" },
            { name: 'BID3 BSID2', prop: 'bid3Bsid2', width: "250" },
            { name: 'BID3 BSID3', prop: 'bid3Bsid3', width: "250" },
            { name: 'BID3 MNC', prop: 'bid3Mnc', width: "250" },
            { name: 'BID3 Name', prop: 'bid3Name', width: "250" },
            { name: 'BID4', prop: 'bid4', width: "250" },
            { name: 'BID4 BSID1', prop: 'bid4Bsid1', width: "250" },
            { name: 'BID4 BSID2', prop: 'bid4Bsid2', width: "250" },
            { name: 'BID4 BSID3', prop: 'bid4Bsid3', width: "250" },
            { name: 'BID4 MNC', prop: 'bid4Mnc', width: "250" },
            { name: 'BID4 Name', prop: 'bid4Name', width: "250" },
            { name: 'BTA MKT Code', prop: 'btaMktCode', width: "250" },
            { name: 'BTA MKT Multi State', prop: 'btaMktMultiState', width: "250" },
            { name: 'BTA MKT Name', prop: 'btaMktName', width: "250" },
            { name: 'BTA MKT Name Alternate', prop: 'btaMktNameAlternate', width: "250" },
            { name: 'BTA MKT State', prop: 'btaMktState', width: "250" },
            { name: 'CMA MKT Code', prop: 'cmaMktCode', width: "250" },
            { name: 'CMA MKT Multi State', prop: 'cmaMktMultiState', width: "250" },
            { name: 'CMA MKT Name', prop: 'cmaMktName', width: "250" },
            { name: 'CMA MKT Name Alternate', prop: 'cmaMktNameAlternate', width: "250" },
            { name: 'CMA MKT State', prop: 'cmaMktState', width: "250" },
            { name: 'County', prop: 'county', width: "250" },
            { name: 'Extended Services', prop: 'extendedServices', width: "250" },
            { name: 'Marketing Name', prop: 'marketingName', width: "250" },
            { name: 'MHZ Total', prop: 'mhzTotal', width: "250" },
            { name: 'Nation', prop: 'nation', width: "250" },
            { name: 'Protocol', prop: 'protocol', width: "250" },
            { name: 'Spectrum Blocks', prop: 'spectrumBlocks', width: "250" },
            { name: 'State', prop: 'state', width: "250" },
        ];
        this.showMssg = false;
    }

    //Used to Download Template
    exportToCSV() {
        this.exportToCsvService.downloadFile([], this.EXPORT_FILE_NAME, this.exportColumns);
    }

    saveUploadDialog() {
        if (document.getElementsByClassName("tableError") && document.getElementsByClassName("tableError").length > 0) {
            this.toasterService.showErrorMessage("Please fix validation errors.");
            return;
        }
        for(let i=0;i<this.uploadedMainData.length;i++){
            delete this.uploadedMainData[i]['Carrier Entity'];
            delete this.uploadedMainData[i]['Key Code'];
            delete this.uploadedMainData[i]['BEA MKT Code'];
            delete this.uploadedMainData[i]['BEA MKT Multi State'];
            delete this.uploadedMainData[i]['BEA MKT Name'];
            delete this.uploadedMainData[i]['BEA MKT Name Alternate'];
            delete this.uploadedMainData[i]['BEA MKT State'];
            delete this.uploadedMainData[i]['BID1'];
            delete this.uploadedMainData[i]['BID1 BSID1'];
            delete this.uploadedMainData[i]['BID1 BSID2'];
            delete this.uploadedMainData[i]['BID1 BSID3'];
            delete this.uploadedMainData[i]['BID1 MNC'];
            delete this.uploadedMainData[i]['BID1 Name'];
			delete this.uploadedMainData[i]['BID2'];
            delete this.uploadedMainData[i]['BID2 BSID1'];
            delete this.uploadedMainData[i]['BID2 BSID2'];
            delete this.uploadedMainData[i]['BID2 BSID3'];
            delete this.uploadedMainData[i]['BID2 MNC'];
            delete this.uploadedMainData[i]['BID2 Name'];
			delete this.uploadedMainData[i]['BID3'];
            delete this.uploadedMainData[i]['BID3 BSID1'];
            delete this.uploadedMainData[i]['BID3 BSID2'];
            delete this.uploadedMainData[i]['BID3 BSID3'];
            delete this.uploadedMainData[i]['BID3 MNC'];
            delete this.uploadedMainData[i]['BID3 Name'];
            delete this.uploadedMainData[i]['BID4'];
            delete this.uploadedMainData[i]['BID4 BSID1'];
            delete this.uploadedMainData[i]['BID4 BSID2'];
            delete this.uploadedMainData[i]['BID4 BSID3'];
            delete this.uploadedMainData[i]['BID4 MNC'];
            delete this.uploadedMainData[i]['BID4 Name'];
			delete this.uploadedMainData[i]['BTA MKT Code'];
            delete this.uploadedMainData[i]['BTA MKT Multi State'];
            delete this.uploadedMainData[i]['BTA MKT Name'];
            delete this.uploadedMainData[i]['BTA MKT Name Alternate'];
            delete this.uploadedMainData[i]['BTA MKT State'];
			delete this.uploadedMainData[i]['CMA MKT Code'];
            delete this.uploadedMainData[i]['CMA MKT Multi State'];
            delete this.uploadedMainData[i]['CMA MKT Name'];
            delete this.uploadedMainData[i]['CMA MKT Name Alternate'];
            delete this.uploadedMainData[i]['CMA MKT State'];
			delete this.uploadedMainData[i]['County'];
            delete this.uploadedMainData[i]['Extended Services'];
            delete this.uploadedMainData[i]['Marketing Name'];
			delete this.uploadedMainData[i]['MHZ Total'];
            delete this.uploadedMainData[i]['Nation'];
            delete this.uploadedMainData[i]['Protocol'];
            delete this.uploadedMainData[i]['Spectrum Blocks'];
            delete this.uploadedMainData[i]['State'];
        }
        let uploadData = [];
        
        uploadData = this.uploadedMainData.filter((v,i,a)=>a.findIndex(t=>
            (t.carrierEntity == v.carrierEntity && t.keyCode == v.keyCode))===i)           
        this.dialogRef.close(uploadData);
    }

    //Read File and show data on the table
    public changeListener(files: FileList) {
        let invalidFile = "Please select a valid file to upload.";
        let noDataInFile = "There is no data to upload in this file.";
        let limitExceed = "You cannot insert more than 500 records at a time.";
        this.alerts = [];
        if (files && files.length > 0) { 
            this.fileContent = true;
            let file: File = files.item(0);
            let name = file.name;
            var ext = name.substring(name.lastIndexOf('.') + 1);
            if (ext.toLowerCase() == 'csv') {
                this.filename = name.substr(0, name.lastIndexOf("."));
                if (this.filename.split(" ")[0] != this.EXPORT_FILE_NAME) {
                    this.toasterService.showErrorMessage(invalidFile);
                    return;
                }
            } else {
                this.toasterService.showErrorMessage(invalidFile);
                return;
            }
            let reader: FileReader = new FileReader();
            reader.readAsText(file);
            reader.onload = (e) => {
                let uploadData = this.importFromCsvService.csvToArray(reader.result);
                if (uploadData.length == 0) {
                    this.toasterService.showErrorMessage(noDataInFile);
                } else if (uploadData.length > 500) {
                    this.toasterService.showErrorMessage(limitExceed);
                } else {
                    let keys = Object.keys(uploadData[0]);
                    for (let i = 1, j = 0; j < this.exportColumns.length; i++, j++) {
                        if (keys[i] != this.exportColumns[j]) {
                            this.toasterService.showErrorMessage(invalidFile);
                            return;
                        }
                    }
                    uploadData.forEach(_e1 => {
                        _e1.carrierEntity = _e1['Carrier Entity'];
                        _e1.keyCode= _e1['Key Code'];
                        _e1.beaMktCode = _e1['BEA MKT Code'];
                        _e1.beaMktMultiState = _e1['BEA MKT Multi State'];
                        _e1.beaMktName= _e1['BEA MKT Name'];
                        _e1.beaMktNameAlternate = _e1['BEA MKT Name Alternate'];
                        _e1.beaMktState = _e1['BEA MKT State']; 
                        _e1.bid1 = _e1['BID1'];
                        _e1.bid1Bsid1 = _e1['BID1 BSID1'];
						_e1.bid1Bsid2 = _e1['BID1 BSID2'];
						_e1.bid1Bsid3 = _e1['BID1 BSID3'];
                        _e1.bid1Mnc = _e1['BID1 MNC'];         
                        _e1.bid1Name  = _e1['BID1 Name'];
                        _e1.bid2 = _e1['BID2'];
                        _e1.bid2Bsid1 = _e1['BID2 BSID1'];
						_e1.bid2Bsid2 = _e1['BID2 BSID2'];
						_e1.bid2Bsid3 = _e1['BID2 BSID3'];
                        _e1.bid2Mnc = _e1['BID2 MNC'];         
                        _e1.bid2Name  = _e1['BID2 Name'];
                        _e1.bid3 = _e1['BID3'];
                        _e1.bid3Bsid1 = _e1['BID3 BSID1'];
						_e1.bid3Bsid2 = _e1['BID3 BSID2'];
						_e1.bid3Bsid3 = _e1['BID3 BSID3'];
                        _e1.bid3Mnc = _e1['BID3 MNC'];         
                        _e1.bid3Name  = _e1['BID3 Name'];
                        _e1.bid4= _e1['BID4'];
                        _e1.bid4Bsid1 = _e1['BID4 BSID1'];
						_e1.bid4Bsid2 = _e1['BID4 BSID2'];
						_e1.bid4Bsid3 = _e1['BID4 BSID3'];
                        _e1.bid4Mnc = _e1['BID4 MNC'];         
                        _e1.bid4Name  = _e1['BID4 Name'];
                        _e1.btaMktCode = _e1['BTA MKT Code'];
                        _e1.btaMktMultiState = _e1['BTA MKT Multi State'];
                        _e1.btaMktName= _e1['BTA MKT Name'];
                        _e1.btaMktNameAlternate = _e1['BTA MKT Name Alternate'];
                        _e1.btaMktState = _e1['BTA MKT State'];
                        _e1.cmaMktCode = _e1['CMA MKT Code'];
                        _e1.cmaMktMultiState = _e1['CMA MKT Multi State'];
                        _e1.cmaMktName= _e1['CMA MKT Name'];
                        _e1.cmaMktNameAlternate = _e1['CMA MKT Name Alternate'];
                        _e1.cmaMktState = _e1['CMA MKT State'];
                        _e1.county= _e1['County'];
                        _e1.extendedServices = _e1['Extended Services'];
						_e1.marketingName= _e1['Marketing Name'];
                        _e1.mhzTotal = _e1['MHZ Total'];
                        _e1.nation= _e1['Nation'];
                        _e1.protocol = _e1['Protocol'];
                        _e1.spectrumBlocks= _e1['Spectrum Blocks'];
                        _e1.state = _e1['State'];
                    });
                    this.uploadedData = [...this.checkUploadedData(uploadData)];
                }
            }
        }
    }

    //Removes file and table from the screen
    public removeFile() {
        this.fileContent = false;
        this.filename = null;
        this.uploadedData = [];
        this.uploadedMainData = [];
        this.alerts = [];
    }

    public checkUploadedData(data) {
        let errorData = [];
        let successData = [];
        data.forEach(element => {
            element.rowNum = element['S.NO'];
        });
        data.forEach(element => {
            if (element.rowNum.length == 0 || element["Carrier Entity"].length == 0 || element["Key Code"].length == 0 || element["Carrier Entity"].length > 200|| element["Key Code"].length > 200
            || element["BEA MKT Code"].length > 200 || element["BEA MKT Multi State"].length > 200 || element["BEA MKT Name"].length > 200|| element["BEA MKT Name Alternate"].length > 200 || element["BEA MKT State"].length > 200
            || element["BID1"].length > 200 || element["BID1 BSID1"].length > 200 || element["BID1 BSID2"].length > 200|| element["BID1 BSID3"].length > 200 || element["BID1 MNC"].length > 200 || element["BID1 Name"].length > 200 
            || element["BID2"].length > 200 || element["BID2 BSID1"].length > 200 || element["BID2 BSID2"].length > 200|| element["BID2 BSID3"].length > 200 || element["BID2 MNC"].length > 200 || element["BID2 Name"].length > 200
            || element["BID3"].length > 200 || element["BID3 BSID1"].length > 200 || element["BID3 BSID2"].length > 200|| element["BID3 BSID3"].length > 200 || element["BID3 MNC"].length > 200 || element["BID3 Name"].length > 200 
            || element["BID4"].length > 200 || element["BID4 BSID1"].length > 200 || element["BID4 BSID2"].length > 200|| element["BID4 BSID3"].length > 200 || element["BID4 MNC"].length > 200 || element["BID4 Name"].length > 200 
            || element["BTA MKT Code"].length > 200 || element["BTA MKT Multi State"].length > 200 || element["BTA MKT Name"].length > 200|| element["BTA MKT Name Alternate"].length > 200 || element["BTA MKT State"].length > 200            
            || element["CMA MKT Code"].length > 200 || element["CMA MKT Multi State"].length > 200 || element["CMA MKT Name"].length > 200|| element["CMA MKT Name Alternate"].length > 200 || element["CMA MKT State"].length > 200
            || element["County"].length > 200 || element["Extended Services"].length > 200 || element["Marketing Name"].length > 200|| element["MHZ Total"].length > 200 || element["Nation"].length > 3 || element["Protocol"].length > 200 
            || element["Spectrum Blocks"].length > 200 || element["State"].length > 2) {
                errorData.push(element);
            } else
            successData.push(element);
        });
        this.uploadedMainData = [...errorData, ...successData];
        return this.uploadedMainData;
    }

    //Removes Row from the table
    deleteRow(row) {
        this.uploadedMainData.forEach((data, key) => {
            if (row.rowNum == data.rowNum) {
                this.uploadedMainData.splice(key, 1);
            }
        });
        this.uploadedData = [...this.uploadedMainData];
    }

    //inline values changes
    public editValueChanged(event, column, row, oldValue) {
        for (let i = 0; i < this.uploadedMainData.length; i++) {
            if (this.uploadedMainData[i].rowNum == row.rowNum) {
                this.uploadedMainData[i][column] = event.target.value;
            }
        }
        this.uploadedData = [...this.uploadedMainData];
    }

    //Filter for result table
    public filterTableData(event) {
        const val = event.target.value.toLowerCase();
        // filter our data
        const temp = this.uploadedMainData.filter(function (d) {
            return (d.carrierEntity ? d.carrierEntity.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.keyCode ? d.keyCode.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.beaMktCode ? d.beaMktCode.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.beaMktMultiState ? d.beaMktMultiState.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.beaMktName ? d.beaMktName.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.beaMktNameAlternate ? d.beaMktNameAlternate.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.beaMktState ? d.beaMktState.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid1 ? d.bid1.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid1Bsid1 ? d.bid1Bsid1.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid1Bsid2 ? d.bid1Bsid2.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid1Bsid3 ? d.bid1Bsid3.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid1Mnc ? d.bid1Mnc.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid1Name ? d.bid1Name.toLowerCase().indexOf(val) !== -1 : !val)
			|| (d.bid2 ? d.bid2.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid2Bsid1 ? d.bid2Bsid1.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid2Bsid2 ? d.bid2Bsid2.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid2Bsid3 ? d.bid2Bsid3.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid2Mnc ? d.bid2Mnc.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid2Name ? d.bid2Name.toLowerCase().indexOf(val) !== -1 : !val)
			|| (d.bid3 ? d.bid3.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid3Bsid1 ? d.bid3Bsid1.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid3Bsid2 ? d.bid3Bsid2.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid3Bsid3 ? d.bid3Bsid3.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid3Mnc ? d.bid3Mnc.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid3Name ? d.bid3Name.toLowerCase().indexOf(val) !== -1 : !val)
			|| (d.bid4 ? d.bid4.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid4Bsid1 ? d.bid4Bsid1.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid4Bsid2 ? d.bid4Bsid2.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid4Bsid3 ? d.bid4Bsid3.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid4Mnc ? d.bid4Mnc.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.bid4Name ? d.bid4Name.toLowerCase().indexOf(val) !== -1 : !val)
			|| (d.btaMktCode ? d.btaMktCode.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.btaMktMultiState ? d.btaMktMultiState.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.btaMktName ? d.btaMktName.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.btaMktNameAlternate ? d.btaMktNameAlternate.toLowerCase().indexOf(val) !== -1 : !val)	
            || (d.btaMktState ? d.btaMktState.toLowerCase().indexOf(val) !== -1 : !val)
			|| (d.cmaMktCode ? d.cmaMktCode.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.cmaMktMultiState ? d.cmaMktMultiState.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.cmaMktName ? d.cmaMktName.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.cmaMktNameAlternate ? d.cmaMktNameAlternate.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.cmaMktState ? d.cmaMktState.toLowerCase().indexOf(val) !== -1 : !val)
			|| (d.county ? d.county.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.extendedServices ? d.extendedServices.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.marketingName ? d.marketingName.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.mhzTotal ? d.mhzTotal.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.nation ? d.nation.toLowerCase().indexOf(val) !== -1 : !val)
			|| (d.protocol ? d.protocol.toLowerCase().indexOf(val) !== -1 : !val)
			|| (d.spectrumBlocks ? d.spectrumBlocks.toLowerCase().indexOf(val) !== -1 : !val)
			|| (d.state ? d.state.toLowerCase().indexOf(val) !== -1 : !val)
        });
        // update the rows
        this.uploadedData = temp;
    }

    cancelUploadDialog(): void {
        this.dialogRef.close();
    }

}