import { Component, OnInit, ViewEncapsulation, ViewChildren, Output, EventEmitter } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { ConfirmationService } from 'primeng/primeng';
import { takeUntil } from 'rxjs/operators';
import { Subject } from "rxjs";
import { CarrierMaintenanceService } from '../../../../../Services/carrierMaintenance.service';
import { CarrierMaintenanceHelper } from "../../carrier-maintenance-helper";
import { ToasterService } from "../../../../../Services/toaster.service";
import { CarriersimprefHelper } from "../carriersimpref-helper";
import { CarriersimprefService } from "../carriersimpref-service";
import { MatDialog } from "@angular/material";
import { BulkInsertCarriersimprefComponent } from "../bulk-insert-carriersimpref/bulk-insert-carriersimpref";

@Component({
    selector: 'add-carriersimpref',
    templateUrl: './add-carriersimpref.component.html',
    styleUrls: ['./add-carriersimpref.component.scss',
        "../../../../components/ngxtable/material.scss",
        "../../../../components/ngxtable/datatable.component.scss",
        "../../../../components/ngxtable/icons.css",
        "../../../../components/ngxtable/app.css"],
    animations: [],
    encapsulation: ViewEncapsulation.None,
})

export class AddCarriersimprefComponent implements OnInit {
    
    @ViewChildren(DatatableComponent)
    table: any;
    private unsubscribe = new Subject<void>();
    public frmCarriersimpref: FormGroup;
    public showLoadingScreen: boolean;
    public displayTable = false;
    private checkedAnother = false;
    public tableRows: any = [];
    public tableRowsMainData: any = [];
    isEditable = {};
    private editedRow: any = {};
    private defaultEditedRow: any = {};
    public tableColumns:any = [];
    public alerts = [];
    public bulkInsertData = [];
    public showMssg = false;
    @Output("returnedData") returnedData: any = new EventEmitter();
    public alreadyEnabled = true;
    public filteredRows: any;
    public tableFrmGroupMain: FormGroup;
    public filteredValues: any = {};

    constructor(
        private formBuilder: FormBuilder,
        private wizardService: CarrierMaintenanceService,
        private carriersimprefHelper: CarriersimprefHelper,
        private toasterService: ToasterService,
        private wizardHelper: CarrierMaintenanceHelper,
        private confirmationService: ConfirmationService,
        private carriersimprefService: CarriersimprefService,
        public dialog: MatDialog,
    ) {
        this.frmCarriersimpref = new FormGroup({});
    }

    ngOnInit() { 
        this.createForm();
        this.createTableForm();
        this.tableColumns = [
            { name: 'Carrier Name', prop: 'carrierName', width: "250" },
            { name: 'Rank', prop: 'rank', width: "150" },
            { name: 'Sim Profile', prop: 'simProfile', width: "250" },
            { name: 'Min DLL Exch', prop: 'minDllExch', width: "150" },
            { name: 'Max DLL Exch', prop: 'maxDllExch', width: "150" },
        ];
        this.showMssg = false;
        this.carriersimprefService.setAddData([]);
    }

        //to create form
        private createForm() {
            this.frmCarriersimpref = this.formBuilder.group({
                carrierName: ['', [Validators.required, Validators.maxLength(255)]],
                simProfile: ['', [Validators.required, Validators.maxLength(30)]],
                rank: ['', [Validators.required, Validators.pattern("^[0-9\n ,]*$"), Validators.maxLength(38)]],
                minDllExch: ['', [Validators.required, Validators.pattern("^-?[0-9\n ,]*$"), Validators.maxLength(38)]],
                maxDllExch: ['', [Validators.required, Validators.pattern("^-?[0-9\n ,]*$"), Validators.maxLength(38)]],
            })
        }

    //form for column level filter
    public createTableForm() {
        this.tableFrmGroupMain = this.formBuilder.group({
            carrierName: [''],
            simProfile: [''],
            rank: [''],
            minDllExch: [''],
            maxDllExch: [''],
        });
    }

    //to add carrier sim pref
    private addCarrierSimPref(f) {
        this.showLoadingScreen = true;
        this.alreadyEnabled = true;
        let obj = f.value;
        obj = this.wizardHelper.checkRequestObject(obj);
        obj.dbEnv = this.wizardHelper.dbEnv;
        this.wizardService.addCarrierSimPref(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.carriersimprefHelper.getTracfoneConstantMethod("TRACFONE_ADD_CARRIERSIMPREF_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }

                const d = data[0].message;
                obj.objId = d;
                if(d==""){
                    this.toasterService.showErrorMessage(
                    this.carriersimprefHelper.getTracfoneConstantMethod("TRACFONE_DUPLICATE_CARRIERSIMPREF_ERROR_MESSAGE")
                );
                }else{
                    let fullObject = [];
                    if (!this.carriersimprefService.getAddData() || (this.carriersimprefService.getAddData() && this.carriersimprefService.getAddData().length == 0)) {
                            fullObject.push(obj);
                    } else if (this.carriersimprefService.getAddData().length > 0) {
                        fullObject = this.carriersimprefService.getAddData();
                        fullObject.forEach((data, key) => {
                            if (data.carrierName == obj.carrierName && data.simProfile == obj.simProfile && 
                                data.minDllExch == obj.minDllExch && data.maxDllExch == obj.maxDllExch) {
                                fullObject.splice(key, 1);
                                fullObject = [...fullObject];
                            }
                        });
                            fullObject.push(obj);
                    }
                    this.carriersimprefService.setAddData(fullObject);
                    this.tableRowsMainData = [];
                    this.tableRows = [];
                    for (let i = 0; i < this.carriersimprefService.getAddData().length; i++) {
                        this.tableRowsMainData.push(this.carriersimprefService.getAddData()[i]);
                    }
                    let rowId = 1;
                    this.tableRowsMainData.forEach(element => {
                        element.rowId = rowId;
                        rowId++;
                    });
                    this.tableRows = [...this.tableRowsMainData];
                    if (this.checkedAnother) {
                        this.displayTable = false;
                    } else {
                        this.displayTable = true;
                    }
                    this.generateFilters();
                    this.filterReportResults();
                    this.frmCarriersimpref.reset();
                    this.toasterService.showSuccessMessage(
                        this.carriersimprefHelper.getTracfoneConstantMethod("TRACFONE_ADD_CARRIERSIMPREF_SUCCESS_MESSAGE")
                    );
                }
                this.showLoadingScreen = false;
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.carriersimprefHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }

    onChangeCheckbox(event) {
        if (event.checked) this.checkedAnother = true;
        else this.checkedAnother = false;
    }

    //show summary confirm
    public showSummaryConfirm(f, index) {
        this.confirmationService.confirm({
            key: 'confirm-add-show-summary',
            message: this.carriersimprefHelper.getTracfoneConstantMethod("TRACFONE_DONE_CREATING_CARRIERSIMPREF_CONFIRM_MESSAGE"),
            accept: () => {
                this.displayTable = true;
                this.checkedAnother = false;
            }
        });
    }
    
    // reset the form
    revert() {
        this.frmCarriersimpref.reset();
        this.tableRows = [];
        this.tableRowsMainData = [];
        this.filteredValues = {};
        this.alerts = [];
        let filterKeys = Object.keys(this.tableFrmGroupMain.controls);
        filterKeys.forEach(_e1 => {
            this.tableFrmGroupMain.controls[`${_e1}`].patchValue([]);
        });
        this.alreadyEnabled = true;
    }

    public  editButtonClicked(rowData,rowIndex) {
        this.alreadyEnabled = false;
        this.defaultEditedRow = { ...rowData }
        for (let i = 0; i < this.tableRowsMainData.length; i++) {
          if (this.isEditable[i])
            this.alreadyEnabled = true;
        }
        if (!this.alreadyEnabled)
          this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        else{
          this.alreadyEnabled = false;
          this.toasterService.showErrorMessage(
            this.carriersimprefHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE")
          );
        }
      }
    
    private inputValueChanged(event, column, row, oldValue) {
            this.editedRow[column] = event.target.value;
            this.defaultEditedRow[column] = event.target.defaultValue;
    
    }
    
    //to update carrier sim pref
    public updateCarrierSimPref(editData, rowIndex) {
        if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
            this.toasterService.showErrorMessage(
                this.carriersimprefHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            return;
        }
        this.showLoadingScreen = true;
        let obj = { ...editData, ...this.editedRow }

        obj = this.wizardHelper.checkRequestObject(obj);
        obj.dbEnv = this.wizardHelper.dbEnv;
        obj.oldCarrierName = this.defaultEditedRow.carrierName;
        obj.oldSimProfile = this.defaultEditedRow.simProfile;
        obj.oldMinDllExch = this.defaultEditedRow.minDllExch;
        obj.oldMaxDllExch = this.defaultEditedRow.maxDllExch;
        delete obj.rowId;
        this.wizardService.updateCarrierSimPref(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.carriersimprefHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_CARRIERSIMPREF_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                for (let i = 0; i < this.tableRowsMainData.length; i++) {
                    if (this.tableRowsMainData[i].rowId == this.defaultEditedRow.rowId) {
                        this.tableRowsMainData[i] = obj;
                    }
                }
                this.isEditable[rowIndex] = !this.isEditable[rowIndex];
                this.showLoadingScreen = false;
                this.editedRow = {};
                this.defaultEditedRow = {};
                this.tableRows = [...this.tableRowsMainData];
                this.alreadyEnabled = true;
                this.generateFilters();
                this.filterReportResults();
    
                this.toasterService.showSuccessMessage(
                    this.carriersimprefHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_CARRIERSIMPREF_SUCCESS_MESSAGE")
                );
    
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.carriersimprefHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }
    
    //to cancel update
    private cancelEditForm(rowData, rowIndex) {
        this.showLoadingScreen = true;
        this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        this.tableColumns.forEach(e1 => {
            if (document.getElementById(e1.prop + rowIndex)) {
                (<HTMLInputElement>(
                    document.getElementById(e1.prop + rowIndex)
                )).value = rowData[e1.prop] || '';
            }
        });
    
        this.editedRow = {};
        this.defaultEditedRow = {};
        this.showLoadingScreen = false;
        this.alreadyEnabled = true;
    }
    
    //to filter table
    private updateSummaryTable(event) {
        const val = event.target.value.toLowerCase();
    
        const temp = this.tableRowsMainData.filter(function (d) {
            return (d.carrierName ? d.carrierName.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.simProfile ? d.simProfile.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.rank ? d.rank.indexOf(val) !== -1 : !val)
            || (d.minDllExch ? d.minDllExch.indexOf(val) !== -1 : !val)
            || (d.maxDllExch ? d.maxDllExch.indexOf(val) !== -1 : !val)
        });
        this.tableRows = temp;
    }


// delete confirm
public showConfirm(cmiData, rowIndex) {
    this.confirmationService.confirm({
      key: 'confirm-delete-cmi',
      message: "Are you sure you want to delete Carrier Sim Preference ?",
      accept: () => {
        this.deleteCarrierSimPref(cmiData, rowIndex)
      }
    });
  }

  // to delete carrier sim pref
  public deleteCarrierSimPref(cmiData, rowIndex) {
    this.showLoadingScreen = true;
    let obj:any = {};
    obj = cmiData
    obj.dbEnv = this.wizardHelper.dbEnv;
    delete obj.rowId;
    this.wizardService.deleteCarrierSimPref(obj).pipe(takeUntil(this.unsubscribe))
      .subscribe(
      (data: any) => {
        if (data[0] === null || data[0] === undefined) {
          this.showLoadingScreen = false;
          this.toasterService.showErrorMessage(
            this.carriersimprefHelper.getTracfoneConstantMethod("TRACFONE_DELETE_CARRIERSIMPREF_ERROR_MESSAGE")
          );
          return;
        }
        if (data[0] && data[0].ERR) {
          this.showLoadingScreen = false;
          const commaSeperatedArr = data[0].ERR.split(",");
          for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
            if (commaSeperatedArr[i] != "")
              this.toasterService.showErrorMessage(
                commaSeperatedArr[i]
              );
          }
          return;
        }
        this.toasterService.showSuccessMessage(
          this.carriersimprefHelper.getTracfoneConstantMethod("TRACFONE_DELETE_CARRIERSIMPREF_SUCCESS_MESSAGE")
        );

        this.tableRows.forEach((rec: any, key) => {
            if (obj.zip == rec.zip && obj.nPANXX == rec.nPANXX && obj.accountNum == rec.accountNum) {
              this.tableRows.splice(key, 1);
              this.carriersimprefService.getAddData().splice(key, 1);
            }
          });
          this.tableRows = [...this.tableRows];
          this.tableRowsMainData = [...this.tableRows];
          if (this.tableRows.length === 0) {
            this.displayTable = false;
            this.checkedAnother = false;
            this.tableRows = [];
            this.revert();
            this.carriersimprefService.setAddData([]);
          }
        this.showLoadingScreen = false;
      },
      (err: any) => {
        this.showLoadingScreen = false;
        if (err.error === undefined || err.error === null)
          this.toasterService.showErrorMessage(
            this.carriersimprefHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
          );
        else if (err.error && err.error.ERR) {
          const commaSeperatedArr = err.error.ERR.split(",");
          for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
            if (commaSeperatedArr[i] != "")
              this.toasterService.showErrorMessage(
                commaSeperatedArr[i]
              );
          }
        }
        else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
          return;
        else this.toasterService.showErrorMessage(err.error);
      }
      );
  }

// to open bulk insert pop up
  openUploadCSVDialog() {
    const dialogRef = this.dialog.open(BulkInsertCarriersimprefComponent, {
        width: "90%",
        height: "90%",
    });
    // Create subscription
    dialogRef.afterClosed().subscribe((bulkInsertData) => {
        if (bulkInsertData && bulkInsertData.length > 0) {
            this.warningAlert("Your upload is complete. Please click on Submit to begin database insertions.")
            this.bulkInsertData = [...bulkInsertData];
            let filterKeys = Object.keys(this.frmCarriersimpref.controls);
        filterKeys.forEach(_e1 => {
            this.frmCarriersimpref.controls[`${_e1}`].setValidators([]);
            this.frmCarriersimpref.controls[`${_e1}`].updateValueAndValidity();
        });
        }
    });
}

//to bulk insert carrier sim pref
private bulkInsertCarrierSimPref() {
    this.showLoadingScreen = true;
    let obj: any = [];
    this.alreadyEnabled = true;
    obj = [...this.bulkInsertData];
    obj.forEach(element => {
        element.dbEnv = this.wizardHelper.dbEnv;
    });
    obj = this.wizardHelper.checkRequestObject(obj);
    obj.dbEnv = this.wizardHelper.dbEnv;
    this.wizardService.bulkInsertCarrierSimPref(obj).pipe(takeUntil(this.unsubscribe))
        .subscribe(
        (data: any) => {
            if (data[0] === null || data[0] === undefined) {
                this.showLoadingScreen = false;
                this.toasterService.showErrorMessage(
                    this.carriersimprefHelper.getTracfoneConstantMethod("TRACFONE_ADD_CARRIERSIMPREF_ERROR_MESSAGE")
                );
                return;
            }
            if (data[0] && data[0].ERR) {
                this.showLoadingScreen = false;
                const commaSeperatedArr = data[0].ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
                return;
            }
            this.showLoadingScreen = false;
            this.showMssg = true;
            this.revert();
        },
        (err: any) => {
            this.showLoadingScreen = false;
            if (err.error === undefined || err.error === null)
                this.toasterService.showErrorMessage(
                    this.carriersimprefHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                );
            else if (err.error && err.error.ERR) {
                const commaSeperatedArr = err.error.ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
            }
            else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                return;
            else this.toasterService.showErrorMessage(err.error);
        }
        );
}


private warningAlert(warningMsg: string) {
    window.scrollTo(0, 0);
    this.alerts = [];
    this.alerts.push({
        id: 3,
        type: 'warning',
        message: warningMsg
    });
  }

  public closeAlert(alert: any) {
    const index: number = this.alerts.indexOf(alert);
    this.alerts.splice(index, 1);
  }

  public showLastInsertedRecords() {
    this.returnedData.emit({ lastInsertedRecord: true });
  }

  // to filter columns
public filterReportResults(): void {
    const filterFormObject = this.tableFrmGroupMain.value;
    this.filteredValues.carrierName = filterFormObject.carrierName;
    this.filteredValues.simProfile = filterFormObject.simProfile;
    this.filteredValues.rank = filterFormObject.rank;
    this.filteredValues.minDllExch = filterFormObject.minDllExch;
    this.filteredValues.maxDllExch = filterFormObject.maxDllExch;
    const newRows = Object.keys(filterFormObject).reduce((acc, key) => {
        if (!filterFormObject[key].length) return acc;
        const filteredRows = acc.filter(val => filterFormObject[key].indexOf(val[key]) > -1);
        return filteredRows;
    }, this.tableRowsMainData);

    this.tableRows = newRows;
}

public generateFilters(): void {
    this.filteredRows = Object.keys(this.tableColumns)
        .map(i => this.tableColumns[i].prop)
        .reduce((filterObject, columnName) => {
            const uniqueValuesPerRow = this.tableRows.reduce((set, row) => set.add(row[columnName]), new Set());
            let val:any = Array.from(uniqueValuesPerRow);
          if( /^[0-9]*$/.test(val[0])){
               filterObject[columnName] = val.sort(function(a,b){return a - b});
          }else{
               filterObject[columnName] =val.sort((a, b) => {
                a = a || '';
                b = b || '';
                return a.localeCompare(b);
            });                   
          }
            return filterObject;
        }, {});
}

}
