import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { ToasterService } from "../../../../../Services/toaster.service";
import { ExportToCsvService } from "../../../../../Services/export-to-csv.service";
import { ImportFromCsvService } from "../../../../../Services/import-from-csv.service";
import { MatDialogRef } from "@angular/material";

@Component({
    selector: 'bulk-insert-carriersimpref',
    templateUrl: './bulk-insert-carriersimpref.html',
    styleUrls: ['./bulk-insert-carriersimpref.scss',
        "../../../../components/ngxtable/material.scss",
        "../../../../components/ngxtable/datatable.component.scss",
        "../../../../components/ngxtable/icons.css",
        "../../../../components/ngxtable/app.css"],
    animations: [],
    encapsulation: ViewEncapsulation.None,
    providers: [ExportToCsvService, ImportFromCsvService]
})

export class BulkInsertCarriersimprefComponent implements OnInit {
    public multiColumnEditColumns = [];
    public fileContent: Boolean;
    public filename: string = null;
    public uploadedData: any = [];
    public uploadedMainData: any = [];
    public alerts: any = [];
    public exportColumns = [];
    public tableColmns = [];
    readonly EXPORT_FILE_NAME = "Insert_CarrierSimPreferences_template";
    public showLoadingScreen: Boolean = false;
    public showMssg = false;

    constructor(
        private toasterService: ToasterService,
        private exportToCsvService: ExportToCsvService,
        private importFromCsvService: ImportFromCsvService,
        public dialogRef: MatDialogRef<BulkInsertCarriersimprefComponent>,
    ) { dialogRef.disableClose = true;  }

    ngOnInit() {
        this.fileContent = false;
        this.filename = "";
        this.uploadedData = [];
        this.uploadedMainData = [];
        this.alerts = [];
        this.exportColumns = ["Carrier Name", "Sim Profile", "Rank", "MinDLLExch", "MaxDLLExch"];
        this.tableColmns = [
            { name: 'Carrier Name', prop: 'carrierName', width: "250" },
            { name: 'Sim Profile', prop: 'simProfile', width: "250" },
            { name: 'Rank', prop: 'rank', width: "150" },
            { name: 'Min DLL Exch', prop: 'minDllExch', width: "200" },
            { name: 'Max DLL Exch', prop: 'maxDllExch', width: "200" },
        ];
        this.showMssg = false;
    }

    //Used to Download Template
    exportToCSV() {
        this.exportToCsvService.downloadFile([], this.EXPORT_FILE_NAME, this.exportColumns);
    }

    saveUploadDialog() {
        if (document.getElementsByClassName("tableError") && document.getElementsByClassName("tableError").length > 0) {
            this.toasterService.showErrorMessage("Please fix validation errors.");
            return;
        }
        for(let i=0;i<this.uploadedMainData.length;i++){
            delete this.uploadedMainData[i].Rank;
            delete this.uploadedMainData[i]['MaxDLLExch'];
            delete this.uploadedMainData[i]['Carrier Name'];
            delete this.uploadedMainData[i]['MinDLLExch'];
            delete this.uploadedMainData[i]['Sim Profile'];
            delete this.uploadedMainData[i]['S.NO'];
        }
        let uploadData = [];
        
        uploadData = this.uploadedMainData.filter((v,i,a)=>a.findIndex(t=>(t.carrierName === v.carrierName && t.simProfile === v.simProfile && t.rank === v.rank && t.minDllExch === v.minDllExch && t.maxDllExch === v.maxDllExch))===i)
        this.dialogRef.close(uploadData);
    }

    //Read File and show data on the table
    public changeListener(files: FileList) {
        let invalidFile = "Please select a valid file to upload.";
        let noDataInFile = "There is no data to upload in this file.";
        let limitExceed = "You cannot insert more than 500 records at a time.";
        this.alerts = [];
        if (files && files.length > 0) { 
            this.fileContent = true;
            let file: File = files.item(0);
            let name = file.name;
            var ext = name.substring(name.lastIndexOf('.') + 1);
            if (ext.toLowerCase() == 'csv') {
                this.filename = name.substr(0, name.lastIndexOf("."));
                if (this.filename.split(" ")[0] != this.EXPORT_FILE_NAME) {
                    this.toasterService.showErrorMessage(invalidFile);
                    return;
                }
            } else {
                this.toasterService.showErrorMessage(invalidFile);
                return;
            }
            let reader: FileReader = new FileReader();
            reader.readAsText(file);
            reader.onload = (e) => {
                let uploadData = this.importFromCsvService.csvToArray(reader.result);
                if (uploadData.length == 0) {
                    this.toasterService.showErrorMessage(noDataInFile);
                } else if (uploadData.length > 500) {
                    this.toasterService.showErrorMessage(limitExceed);
                } else {
                    let keys = Object.keys(uploadData[0]);
                    for (let i = 1, j = 0; j < this.exportColumns.length; i++, j++) {
                        if (keys[i] != this.exportColumns[j]) {
                            this.toasterService.showErrorMessage(invalidFile);
                            return;
                        }
                    }
                    uploadData.forEach(_e1 => {
                        _e1.rank = _e1.Rank;
                        _e1.maxDllExch = _e1["MaxDLLExch"];
                        _e1.carrierName = _e1["Carrier Name"];
                        _e1.minDllExch = _e1["MinDLLExch"];
                        _e1.simProfile = _e1["Sim Profile"];
                    });
                    this.uploadedData = [...this.checkUploadedData(uploadData)];
                }
            }
        }
    }

    //Removes file and table from the screen
    public removeFile() {
        this.fileContent = false;
        this.filename = null;
        this.uploadedData = [];
        this.uploadedMainData = [];
        this.alerts = [];
    }

    public checkUploadedData(data) {
        let errorData = [];
        let successData = [];
        data.forEach(element => {
            element.rowNum = element['S.NO'];
        });
        data.forEach(element => {
            if (element.rowNum.length == 0 || element.Rank.length == 0|| element["Carrier Name"].length == 0 || element["Sim Profile"].length == 0 
            || element["MinDLLExch"].length == 0 || element["MaxDLLExch"].length == 0
            || element.Rank.length > 20 || element["Carrier Name"].length > 30 || element["MinDLLExch"].length > 30 || element["Sim Profile"].length > 30
            || element["MaxDLLExch"].length > 20 ) {
                errorData.push(element);
            } else
            successData.push(element);
        });
        this.uploadedMainData = [...errorData, ...successData];
        return this.uploadedMainData;
    }

    //Removes Row from the table
    deleteRow(row) {
        this.uploadedMainData.forEach((data, key) => {
            if (row.rowNum == data.rowNum) {
                this.uploadedMainData.splice(key, 1);
            }
        });
        this.uploadedData = [...this.uploadedMainData];
    }

    //inline values changes
    public editValueChanged(event, column, row, oldValue) {
        for (let i = 0; i < this.uploadedMainData.length; i++) {
            if (this.uploadedMainData[i].rowNum == row.rowNum) {
                this.uploadedMainData[i][column] = event.target.value;
            }
        }
        this.uploadedData = [...this.uploadedMainData];
    }

    //Filter for result table
    public filterTableData(event) {
        const val = event.target.value.toLowerCase();
        // filter our data
        const temp = this.uploadedMainData.filter(function (d) {
            return (d.carrierName ? d.carrierName.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.simProfile ? d.simProfile.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.rank ? d.rank.indexOf(val) !== -1 : !val)
            || (d.minDllExch ? d.minDllExch.indexOf(val) !== -1 : !val)
            || (d.maxDllExch ? d.maxDllExch.indexOf(val) !== -1 : !val)
        });
        // update the rows
        this.uploadedData = temp;
    }

    cancelUploadDialog(): void {
        this.dialogRef.close();
    }

}