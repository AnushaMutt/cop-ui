import { Component, OnInit, ViewEncapsulation, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ConfirmationService } from 'primeng/primeng';
import { takeUntil } from 'rxjs/operators';
import { Subject } from "rxjs";
import { CarrierMaintenanceService } from '../../../../../Services/carrierMaintenance.service';
import { CarrierMaintenanceHelper } from "../../carrier-maintenance-helper";
import { ToasterService } from "../../../../../Services/toaster.service";
import { CarriersimprefHelper } from "../carriersimpref-helper";
import { CarriersimprefService } from "../carriersimpref-service";

@Component({
    selector: 'update-carriersimpref',
    templateUrl: './update-carriersimpref.component.html',
    styleUrls: ['./update-carriersimpref.component.scss',
        "../../../../components/ngxtable/material.scss",
        "../../../../components/ngxtable/datatable.component.scss",
        "../../../../components/ngxtable/icons.css",
        "../../../../components/ngxtable/app.css"],
    animations: [],
    encapsulation: ViewEncapsulation.None,
})

export class UpdateCarriersimprefComponent implements OnInit {
    private unsubscribe = new Subject<void>();
    public frmCarriersimpref: FormGroup;
    public showLoadingScreen: boolean;
    public tableRows: any = [];
    public tableRowsMainData: any = [];
    isEditable = {};
    private editedRow: any = {};
    private defaultEditedRow: any = {};
    public tableColumns:any = [];
    public alreadyEnabled = true;
    public showNoRecordsFoundMessage : Boolean = true;
    public filteredValues: any = {};
    public selected: any = [];
    public multiColumnEditSection = false;
    public filteredRows: any;
    public tableFrmGroupMain: FormGroup;
    public showBulkUpdateButton = false;
    public selectedCarrierSimPref = [];
    public bulkEditBoolean: boolean;
    public otherColumn: boolean = false;
    public editAlreadyEnabled = false;
    public bulkEditColumns = [];
    @ViewChild('multicolumnEditValue') multicolumnEditValue: any;

    constructor(
        private formBuilder: FormBuilder,
        private wizardService: CarrierMaintenanceService,
        private carriersimprefHelper: CarriersimprefHelper,
        private toasterService: ToasterService,
        private wizardHelper: CarrierMaintenanceHelper,
        private confirmationService: ConfirmationService,
        private carriersimprefService: CarriersimprefService
    ) { }
    

    ngOnInit() { 
        this.createForm();
        this.createTableForm();
        this.tableColumns = [
            { name: 'Carrier Name', prop: 'carrierName', width: "250" },
            { name: 'Rank', prop: 'rank', width: "150" },
            { name: 'Sim Profile', prop: 'simProfile', width: "250" },
            { name: 'Min DLL Exch', prop: 'minDllExch', width: "150" },
            { name: 'Max DLL Exch', prop: 'maxDllExch', width: "150" },
        ];
        this.bulkEditColumns = [...this.tableColumns];
        this.filteredValues = {};
        this.multiColumnEditSection = false;
        this.showBulkUpdateButton = false
    }

        //to create form
        private createForm() {
            this.frmCarriersimpref = this.formBuilder.group({
                carrierName: ['', [Validators.maxLength(255)]],
                simProfile: ['', [Validators.maxLength(30)]],
                rank: ['', [Validators.pattern("^[0-9\n ,]*$"), Validators.maxLength(38)]],
                minDllExch: ['', [Validators.pattern("^-?[0-9\n ,]*$"), Validators.maxLength(38)]],
                maxDllExch: ['', [Validators.pattern("^-?[0-9\n ,]*$"), Validators.maxLength(38)]],
            })
        }

    //form for column level filter
    public createTableForm() {
        this.tableFrmGroupMain = this.formBuilder.group({
            carrierName: [''],
            simProfile: [''],
            rank: [''],
            minDllExch: [''],
            maxDllExch: [''],
        });
    }

    // reset the form
    revert() {
        this.frmCarriersimpref.reset();
        this.tableRows = [];
        this.tableRowsMainData = [];
        this.filteredValues = {};
        let filterKeys = Object.keys(this.tableFrmGroupMain.controls);
        filterKeys.forEach(_e1 => {
            this.tableFrmGroupMain.controls[`${_e1}`].patchValue([]);
        });
        this.selectedCarrierSimPref = [];
        this.alreadyEnabled = true;
        this.showBulkUpdateButton = false;
        this.selected = [];
        this.otherColumn = false;
    }
    
   // search carrier sim pref
   public searchForm() {
    this.showLoadingScreen = true;
    let obj = this.frmCarriersimpref.value;
        this.editedRow = {};
        this.defaultEditedRow = {};
        this.isEditable = {};
        this.selectedCarrierSimPref = [];
        this.selected = [];
        this.showBulkUpdateButton = false;
        this.otherColumn = false;
        this.carriersimprefService.setSearchData([]);
        let filterKeys = Object.keys(this.tableFrmGroupMain.controls);
        filterKeys.forEach(_e1 => {
            this.tableFrmGroupMain.controls[`${_e1}`].patchValue([]);
        });
        this.filteredValues ={};
      this.alreadyEnabled = true;
    obj = this.wizardHelper.checkRequestObject(obj);
    obj.dbEnv = this.wizardHelper.dbEnv;
    this.wizardService.searchCarrierSimPref(obj).pipe(takeUntil(this.unsubscribe))
        .subscribe(
        (data: any) => {
            if (data[0] === null || data[0] === undefined) {
                this.showLoadingScreen = false;
                this.toasterService.showErrorMessage(
                    this.carriersimprefHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_CARRIERSIMPREF_ERROR_MESSAGE")
                );
                return;
            }
            if (data[0] && data[0].ERR) {
                this.showLoadingScreen = false;
                const commaSeperatedArr = data[0].ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
                return;
            }

            let response = data[0];
            let fullObject = [];
                if (!this.carriersimprefService.getSearchData() || (this.carriersimprefService.getSearchData() && this.carriersimprefService.getSearchData().length == 0)) {
                    response.forEach(e1 => {
                        fullObject.push(e1)
                    });
                    
                } else if (this.carriersimprefService.getSearchData().length > 0) {
                    fullObject = this.carriersimprefService.getSearchData();
                    response.forEach(e1 => {
                        fullObject.push(e1)
                    });
                }
                this.carriersimprefService.setSearchData(fullObject);
                this.tableRowsMainData = [];
                this.tableRows = [];
                for (let i = 0; i < this.carriersimprefService.getSearchData().length; i++) {
                    this.tableRowsMainData.push(this.carriersimprefService.getSearchData()[i]);
                }
                let rowId = 1;
                this.tableRowsMainData.forEach(element => {
                    element.rowId = rowId;
                    rowId++;
                });
                
            this.tableRows = [...this.tableRowsMainData];           
            this.showLoadingScreen = false;
            if (data[0] && data[0].length == 0  && this.showNoRecordsFoundMessage)
            this.toasterService.showErrorMessage(
            this.carriersimprefHelper.getTracfoneConstantMethod("TRACFONE_SEARCH_CARRIERSIMPREF_ERROR_MESSAGE")
            );

            this.generateFilters();
            this.filterReportResults();
            this.multiColumnEditSection = false;
            this.showNoRecordsFoundMessage = true;
            if (this.filteredValues && this.filteredValues.mainTableFilter) {
                this.updateSummaryTable(this.filteredValues.mainTableFilter);
            }
        },
        (err: any) => {
            this.showLoadingScreen = false;
            if (err.error === undefined || err.error === null)
                this.toasterService.showErrorMessage(
                    this.carriersimprefHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                );
            else if (err.error && err.error.ERR) {
                const commaSeperatedArr = err.error.ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
            }
            else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                return;
            else this.toasterService.showErrorMessage(err.error);
        }
        );
}

// to filter columns
public filterReportResults(): void {
    const filterFormObject = this.tableFrmGroupMain.value;
    this.filteredValues.carrierName = filterFormObject.carrierName;
    this.filteredValues.simProfile = filterFormObject.simProfile;
    this.filteredValues.rank = filterFormObject.rank;
    this.filteredValues.minDllExch = filterFormObject.minDllExch;
    this.filteredValues.maxDllExch = filterFormObject.maxDllExch;
    const newRows = Object.keys(filterFormObject).reduce((acc, key) => {
        if (!filterFormObject[key].length) return acc;
        const filteredRows = acc.filter(val => filterFormObject[key].indexOf(val[key]) > -1);
        return filteredRows;
    }, this.tableRowsMainData);

    this.tableRows = newRows;
}

public generateFilters(): void {
    this.filteredRows = Object.keys(this.tableColumns)
        .map(i => this.tableColumns[i].prop)
        .reduce((filterObject, columnName) => {
            const uniqueValuesPerRow = this.tableRows.reduce((set, row) => set.add(row[columnName]), new Set());
            let val:any = Array.from(uniqueValuesPerRow);
          if( /^[0-9]*$/.test(val[0])){
               filterObject[columnName] = val.sort(function(a,b){return a - b});
          }else{
               filterObject[columnName] =val.sort((a, b) => {
                a = a || '';
                b = b || '';
                return a.localeCompare(b);
            });                   
          }
            return filterObject;
        }, {});
}

public onSelect(row) {
    this.multiColumnEditSection = true;
        this.selectedCarrierSimPref = [];
        if (row && row.selected) {
            for (let i = 0; i < row.selected.length; i++) {
                let obj = { ...row.selected[i] };
                this.selectedCarrierSimPref.push(obj);
            }
        }
        this.selectedCarrierSimPref = [...this.selectedCarrierSimPref]
        if (this.selectedCarrierSimPref.length == 0) {
            this.bulkEditBoolean = false;
            this.otherColumn = false;
            this.showBulkUpdateButton = false;
        }
}


public  editButtonClicked(rowData,rowIndex) {
    this.alreadyEnabled = false;
    this.defaultEditedRow = { ...rowData }
    for (let i = 0; i < this.tableRowsMainData.length; i++) {
      if (this.isEditable[i])
        this.alreadyEnabled = true;
    }
    if (!this.alreadyEnabled)
      this.isEditable[rowIndex] = !this.isEditable[rowIndex];
    else{
      this.alreadyEnabled = false;
      this.toasterService.showErrorMessage(
        this.carriersimprefHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE")
      );
    }
  }


private inputValueChanged(event, column, row, oldValue) {
        this.editedRow[column] = event.target.value;
        this.defaultEditedRow[column] = event.target.defaultValue;

}

//to update carrier sim pref
public updateCarrierSimPref(editData, rowIndex) {
    if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
        this.toasterService.showErrorMessage(
            this.carriersimprefHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
        )
        return;
    }
    this.showLoadingScreen = true;
    let obj = { ...editData, ...this.editedRow }

    obj = this.wizardHelper.checkRequestObject(obj);
    obj.dbEnv = this.wizardHelper.dbEnv;
    obj.oldCarrierName = this.defaultEditedRow.carrierName;
    obj.oldSimProfile = this.defaultEditedRow.simProfile;
    obj.oldMinDllExch = this.defaultEditedRow.minDllExch;
    obj.oldMaxDllExch = this.defaultEditedRow.maxDllExch;
    delete obj.rowId;
    this.wizardService.updateCarrierSimPref(obj).pipe(takeUntil(this.unsubscribe))
        .subscribe(
        (data: any) => {
            if (data[0] === null || data[0] === undefined) {
                this.showLoadingScreen = false;
                this.toasterService.showErrorMessage(
                    this.carriersimprefHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_CARRIERSIMPREF_ERROR_MESSAGE")
                );
                return;
            }
            if (data[0] && data[0].ERR) {
                this.showLoadingScreen = false;
                const commaSeperatedArr = data[0].ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
                return;
            }
            for (let i = 0; i < this.tableRowsMainData.length; i++) {
                if (this.tableRowsMainData[i].rowId == this.defaultEditedRow.rowId) {
                    this.tableRowsMainData[i] = obj;
                }
            }
            this.isEditable[rowIndex] = !this.isEditable[rowIndex];
            this.showLoadingScreen = false;
            this.alreadyEnabled = true;
            this.editedRow = {};
            this.defaultEditedRow = {};
            this.tableRows = [...this.tableRowsMainData];
            this.searchForm();

            this.toasterService.showSuccessMessage(
                this.carriersimprefHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_CARRIERSIMPREF_SUCCESS_MESSAGE")
            );

        },
        (err: any) => {
            this.showLoadingScreen = false;
            if (err.error === undefined || err.error === null)
                this.toasterService.showErrorMessage(
                    this.carriersimprefHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                );
            else if (err.error && err.error.ERR) {
                const commaSeperatedArr = err.error.ERR.split(",");
                for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                    if (commaSeperatedArr[i] != "")
                        this.toasterService.showErrorMessage(
                            commaSeperatedArr[i]
                        );
                }
            }
            else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                return;
            else this.toasterService.showErrorMessage(err.error);
        }
        );
}

//to cancel update
private cancelEditForm(rowData, rowIndex) {
    this.showLoadingScreen = true;
    this.isEditable[rowIndex] = !this.isEditable[rowIndex];
    this.tableColumns.forEach(e1 => {
        if (document.getElementById(e1.prop + rowIndex)) {
            (<HTMLInputElement>(
                document.getElementById(e1.prop + rowIndex)
            )).value = rowData[e1.prop] || '';
        }
    });

    this.editedRow = {};
    this.defaultEditedRow = {};
    this.showLoadingScreen = false;
    this.alreadyEnabled = true;
}

//to filter table
private updateSummaryTable(event) {
    let val: any;
        if (event.target)
            val = event.target.value.toLowerCase();
        else
            val = event.toLowerCase();

    const temp = this.tableRowsMainData.filter(function (d) {
        return (d.carrierName ? d.carrierName.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.simProfile ? d.simProfile.toLowerCase().indexOf(val) !== -1 : !val)
            || (d.rank ? d.rank.indexOf(val) !== -1 : !val)
            || (d.minDllExch ? d.minDllExch.indexOf(val) !== -1 : !val)
            || (d.maxDllExch ? d.maxDllExch.indexOf(val) !== -1 : !val)
    });
    this.tableRows = temp;
}

// delete confirm
public showConfirm(esnData, rowIndex) {
    this.confirmationService.confirm({
      key: 'confirm-delete-cmi',
      message: "Are you sure you want to delete Carrier Sim Preference ?",
      accept: () => {
        this.deleteCarrierSimPref(esnData, rowIndex)
      }
    });
  }

  // to delete carrier sim pref
  public deleteCarrierSimPref(esnData, rowIndex) {
    this.showLoadingScreen = true;
    let obj:any = {};
    obj = esnData
    obj.dbEnv = this.wizardHelper.dbEnv;
    delete obj.rowId;
    this.wizardService.deleteCarrierSimPref(obj).pipe(takeUntil(this.unsubscribe))
      .subscribe(
      (data: any) => {
        if (data[0] === null || data[0] === undefined) {
          this.showLoadingScreen = false;
          this.toasterService.showErrorMessage(
            this.carriersimprefHelper.getTracfoneConstantMethod("TRACFONE_DELETE_CARRIERSIMPREF_ERROR_MESSAGE")
          );
          return;
        }
        if (data[0] && data[0].ERR) {
          this.showLoadingScreen = false;
          const commaSeperatedArr = data[0].ERR.split(",");
          for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
            if (commaSeperatedArr[i] != "")
              this.toasterService.showErrorMessage(
                commaSeperatedArr[i]
              );
          }
          return;
        }
        this.toasterService.showSuccessMessage(
          this.carriersimprefHelper.getTracfoneConstantMethod("TRACFONE_DELETE_CARRIERSIMPREF_SUCCESS_MESSAGE")
        );
        this.showNoRecordsFoundMessage = false;
        this.searchForm();
      },
      (err: any) => {
        this.showLoadingScreen = false;
        if (err.error === undefined || err.error === null)
          this.toasterService.showErrorMessage(
            this.carriersimprefHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
          );
        else if (err.error && err.error.ERR) {
          const commaSeperatedArr = err.error.ERR.split(",");
          for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
            if (commaSeperatedArr[i] != "")
              this.toasterService.showErrorMessage(
                commaSeperatedArr[i]
              );
          }
        }
        else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
          return;
        else this.toasterService.showErrorMessage(err.error);
      }
      );
  }

  public assignmultiColumnName(column) {
    this.showBulkUpdateButton = false;
    this.otherColumn = true;
}

public showBulkUpdateButtonFun(event) {
    if(event)
        this.showBulkUpdateButton = true;
    else
        this.showBulkUpdateButton = false;
}

  bulkUpdateColumn(column) {
    if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
        this.toasterService.showErrorMessage(
            this.carriersimprefHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
        )
        return;
    }
    this.showLoadingScreen = true;
    let requestObj = [];
    this.selectedCarrierSimPref.forEach(e => {
        let obj: any = {};
        if (column == "Carrier Name") {
            obj.carrierName = this.multicolumnEditValue.nativeElement.value;
        } else {
            obj.carrierName = e.carrierName;
        }
        if (column == "Rank") {
            obj.rank = this.multicolumnEditValue.nativeElement.value;
        } else {
            obj.rank = e.rank;
        }
        if (column == "Sim Profile") {
            obj.simProfile = this.multicolumnEditValue.nativeElement.value;
        } else {
            obj.simProfile = e.simProfile;
        }
        if (column == "Min DLL Exch") {
            obj.minDllExch = this.multicolumnEditValue.nativeElement.value;
        } else {
            obj.minDllExch = e.minDllExch;
        }
        if (column == "Max DLL Exch") {
            obj.maxDllExch = this.multicolumnEditValue.nativeElement.value;
        } else {
            obj.maxDllExch = e.maxDllExch;
        }
        obj.oldCarrierName = e.carrierName;
        obj.oldSimProfile = e.simProfile;
        obj.oldMinDllExch = e.minDllExch;
        obj.oldMaxDllExch = e.maxDllExch;
        obj.dbEnv = this.wizardHelper.dbEnv;
        requestObj.push(obj);
    });

    this.bulkUpdateCarrierSimPref(requestObj);
}

public bulkUpdateCarrierSimPref(request){
    this.wizardService.bulkUpdateCarrierSimPref(request).pipe(takeUntil(this.unsubscribe))
    .subscribe(
    (data: any) => {
        if (data[0] === null || data[0] === undefined) {
            this.showLoadingScreen = false;
            this.toasterService.showErrorMessage(
                this.carriersimprefHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_CARRIERSIMPREF_ERROR_MESSAGE")
            );
            return;
        }
        if (data[0] && data[0].ERR) {
            this.showLoadingScreen = false;
            const commaSeperatedArr = data[0].ERR.split(",");
            for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                if (commaSeperatedArr[i] != "")
                    this.toasterService.showErrorMessage(
                        commaSeperatedArr[i]
                    );
            }
            return;
        }
        this.showLoadingScreen = false;
        this.alreadyEnabled = true;
        this.editAlreadyEnabled = false;
        this.bulkEditBoolean = false;
        this.otherColumn = false;
        this.showBulkUpdateButton = false;
        this.selectedCarrierSimPref = [];
        this.selected = [];
        this.editedRow = {};
        this.defaultEditedRow = {};
        this.searchForm();

        this.toasterService.showSuccessMessage(
            this.carriersimprefHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_CARRIERSIMPREF_SUCCESS_MESSAGE")
        );

    },
    (err: any) => {
        this.showLoadingScreen = false;
        if (err.error === undefined || err.error === null)
            this.toasterService.showErrorMessage(
                this.carriersimprefHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
            );
        else if (err.error && err.error.ERR) {
            const commaSeperatedArr = err.error.ERR.split(",");
            for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                if (commaSeperatedArr[i] != "")
                    this.toasterService.showErrorMessage(
                        commaSeperatedArr[i]
                    );
            }
        }
        else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
            return;
        else this.toasterService.showErrorMessage(err.error);
    }
    );
}

}