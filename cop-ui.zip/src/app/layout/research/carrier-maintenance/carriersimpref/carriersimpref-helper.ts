import { Injectable } from "@angular/core";
import { Subject } from "rxjs";

@Injectable({
    providedIn: "root"
})
export class CarriersimprefHelper {
    
    public breadcrumbListUpdate = new Subject<number>();
    public breadcrumbList = [];
    constructor() { }

    public CarriersimprefConstantObject = {
        "TRACFONE_DEFAULT_ERROR_MESSAGE": "Unable to process request",
        "TRACFONE_DONE_CREATING_CARRIERSIMPREF_CONFIRM_MESSAGE": "Are you done creating Carrier SIM Preference ?",
        "TRACFONE_ADD_CARRIERSIMPREF_ERROR_MESSAGE": "Unable to add Carrier SIM Preference",
        "TRACFONE_ADD_CARRIERSIMPREF_SUCCESS_MESSAGE": "Carrier SIM Preference has been added successfully",  
        "TRACFONE_RETRIEVE_CARRIERSIMPREF_ERROR_MESSAGE" : "Unable to search Carrier SIM Preference",
        "TRACFONE_SEARCH_CARRIERSIMPREF_ERROR_MESSAGE" : "No Carrier SIM Preference found",
        "TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE": "Please complete previous operation",  
        "TRACFONE_UPDATE_CARRIERSIMPREF_ERROR_MESSAGE" : "Unable to update Carrier SIM Preference",
        "TRACFONE_UPDATE_CARRIERSIMPREF_SUCCESS_MESSAGE" : "Carrier SIM Preference has been updated successfully",
        "TRACFONE_DELETE_CARRIERSIMPREF_SUCCESS_MESSAGE": "Carrier SIM Preference has been deleted successfully",
        "TRACFONE_DELETE_CARRIERSIMPREF_ERROR_MESSAGE": "Unable to delete Carrier SIM Preference",
        "TRACFONE_NO_SUMMARY_FOUND_ERROR_MESSAGE" : "No records found",
        "TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE" : "Please fix validation errors",
        "TRACFONE_DUPLICATE_CARRIERSIMPREF_ERROR_MESSAGE" : "Duplicate Carrier SIM Preference found",
    }

    public getTracfoneConstantMethod(msg) {
        return this.CarriersimprefConstantObject[msg];
    }

}