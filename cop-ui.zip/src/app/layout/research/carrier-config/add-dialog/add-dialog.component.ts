import { Component, ViewEncapsulation, OnInit, Inject } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { ConfirmationService } from "primeng/api";
import { Subject } from "rxjs";
import { takeUntil } from "rxjs/operators";
import { IGCarrierConfigMaintenanceService } from "../../../../Services/igCarrierConfigMaintenance.service";
import { ToasterService } from "../../../../Services/toaster.service";
import { CarrierConfigHelper } from "../carrier-config-helper";

@Component({
    selector: "add-dialog",
    templateUrl: "./add-dialog.component.html",
    styleUrls: ["./add-dialog.component.scss"],
    encapsulation: ViewEncapsulation.None,
    providers: [ConfirmationService]
})
export class AddDialogComponent implements OnInit {
    public addFrmGroup: FormGroup;
    public isPropValueKey = false;
    public isPropValueKeyType = false;
    public isPropValueKeyKey = false
    public isPropTypeMap = false;
    public isPropTypeBoolean = false;
    public isPropTypeNumber = false;
    public rowData: any = {};
    public detailsData = [];
    public showLoadingScreen = false;
    private unsubscribe = new Subject<void>();

    constructor(
        public dialogRef: MatDialogRef<AddDialogComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any,
        private _formBuilder: FormBuilder,
        private helper: CarrierConfigHelper,
        private maintenanceService: IGCarrierConfigMaintenanceService,
        private toaster: ToasterService
    ) { dialogRef.disableClose = true; }

    ngOnInit(): void {
        this.addFrmGroup = this.initAddFormGroup();
        this.rowData = this.data.dataKey;
        this.detailsData = [...this.data.carrierDetails];
        this.createAddFormDynamically();
    }

    /**
     * Method to create add form
     */
    public initAddFormGroup() {
        return this._formBuilder.group({
            propValue: ['', [Validators.maxLength(2000), Validators.required]],
            propValueType: ['', [Validators.maxLength(10)]],
            propKey: ['', [Validators.maxLength(100)]],
            propValueKey: ['', [Validators.maxLength(100)]],
            propValueKeyType: ['', [Validators.maxLength(10)]],
            propValueKeyKey: ['', [Validators.maxLength(100)]],
            remarks: ['', [Validators.maxLength(256)]]
        });
    }

    revertAddForm() {
        this.addFrmGroup.reset();
    }

    createAddFormDynamically() {
        this.addFrmGroup.controls["propValueKey"].setValidators([])
        this.addFrmGroup.controls["propValueKey"].updateValueAndValidity();
        this.addFrmGroup.controls["propValueKeyType"].setValidators([])
        this.addFrmGroup.controls["propValueKeyType"].updateValueAndValidity();
        this.addFrmGroup.controls["propValueKeyKey"].setValidators([])
        this.addFrmGroup.controls["propValueKeyKey"].updateValueAndValidity();
        this.addFrmGroup.controls["propKey"].setValidators([])
        this.addFrmGroup.controls["propKey"].updateValueAndValidity();
        this.addFrmGroup.controls["propValueType"].setValidators([])
        this.addFrmGroup.controls["propValueType"].updateValueAndValidity();
        this.addFrmGroup.controls["propValue"].setValidators([Validators.maxLength(2000), Validators.required])
        this.addFrmGroup.controls["propValue"].updateValueAndValidity();
        this.isPropValueKeyKey = false;
        this.isPropValueKeyType = false;
        this.isPropValueKey = false;

        if (this.rowData.propType == "MAP") {
            this.isPropTypeMap = true;
            this.isPropTypeBoolean = false;
            this.isPropTypeNumber = false;
            this.addFrmGroup.controls["propKey"].setValidators([Validators.required, Validators.maxLength(100)])
            this.addFrmGroup.controls["propKey"].updateValueAndValidity();
            this.addFrmGroup.controls["propValueType"].setValidators([Validators.required, Validators.maxLength(10)])
            this.addFrmGroup.controls["propValueType"].updateValueAndValidity();
            if (this.detailsData && this.detailsData.length > 0) {
                if (this.detailsData[0].propValueKey) {
                    this.isPropValueKey = true;
                    this.addFrmGroup.controls["propValueKey"].setValidators([Validators.required, Validators.maxLength(100)])
                    this.addFrmGroup.controls["propValueKey"].updateValueAndValidity();
                } if (this.detailsData[0].propValueKeyType) {
                    this.isPropValueKeyType = true;
                    this.addFrmGroup.controls["propValueKeyType"].setValidators([Validators.required, Validators.maxLength(10)])
                    this.addFrmGroup.controls["propValueKeyType"].updateValueAndValidity();
                } if (this.detailsData[0].propValueKeyKey) {
                    this.isPropValueKeyKey = true;
                    this.addFrmGroup.controls["propValueKeyKey"].setValidators([Validators.required, Validators.maxLength(100)])
                    this.addFrmGroup.controls["propValueKeyKey"].updateValueAndValidity();
                }
            }
        } else if (this.rowData.propType == "Boolean") {
            this.isPropTypeBoolean = true;
            this.isPropTypeMap = false;
            this.isPropTypeNumber = false;
        } else if (this.rowData.propType == "Number") {
            this.isPropTypeBoolean = false;
            this.isPropTypeMap = false;
            this.isPropTypeNumber = true;
            this.addFrmGroup.controls["propValue"].setValidators([Validators.maxLength(2000), Validators.pattern("^[0-9]*$"), Validators.required])
            this.addFrmGroup.controls["propValue"].updateValueAndValidity();
        } else {
            this.isPropTypeBoolean = false;
            this.isPropTypeMap = false;
            this.isPropTypeNumber = false;
        }
    }

    closeDialog() {
        this.dialogRef.close(null);
    }

    //insert Carrier Details
    public addCarrierDetails(formData) {
        let obj: any = {};
        obj.dbEnv = this.helper.dbEnv;
        obj.configId = this.rowData.configId;
        obj.propType = this.rowData.propType;
        obj.igCarrierDetails = formData;
        obj.igCarrierDetails.dbEnv = this.helper.dbEnv;
        obj.igCarrierDetails.configId = this.rowData.configId;
        this.showLoadingScreen = true;
        this.maintenanceService
            .insertCarrierDetails(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.toaster.showErrorMessage(
                            this.helper.getTracfoneConstantMethod("TRACFONE_ADD_CARRIERS_DETAILS_ERROR_MESSAGE")
                        );
                        this.showLoadingScreen = false;
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        return;
                    }
                    this.showLoadingScreen = false;
                    let carrierDetailsTemp = [];
                    carrierDetailsTemp.push(obj.igCarrierDetails);
                    this.dialogRef.close(carrierDetailsTemp);
                    this.toaster.showSuccessMessage(
                        this.helper.getTracfoneConstantMethod("TRACFONE_ADD_CARRIERS_DETAILS_SUCCESS_MESSAGE")
                    );
                },
                (err: any) => {
                    this.showErr(err);
                    return;
                }
            );
    }

    /*
  * Show error if any service call fails to complete
  */
    public showErr(err) {
        this.showLoadingScreen = false;
        if (err.error === undefined || err.error === null)
            this.toaster.showErrorMessage(
                this.helper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
            );
        else if (err.error && err.error.ERR) {
            const commaSeperatedArr = err.error.ERR.split(",");
            for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                if (commaSeperatedArr[i] != "")
                    this.toaster.showErrorMessage(
                        commaSeperatedArr[i]
                    );
            }
        }
        else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
            return;
        else this.toaster.showErrorMessage(err.error);
    }

    /*
    * Show error when service returns error
    */
    public showServiceErr(data) {
        const commaSeperatedArr = data[0].ERR.split(",");
        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
            if (commaSeperatedArr[i] != "")
                this.toaster.showErrorMessage(commaSeperatedArr[i]);
        }
        return;
    }
}