import { Injectable } from '@angular/core';

@Injectable()
export class CarrierConfigHelper {

    public 'dbEnv': String;
    public limit = "20";
    constructor(
    ) { }

    public setDbEnv(dbEnv) {
        this.dbEnv = dbEnv;
    }

    public getDbEnv() {
        return this.dbEnv;
    }
    public checkRequestObject(obj) {
        Object.keys(obj).forEach(key => {
            if (!obj[key]) delete obj[key];
        });
        return obj;
    }

    public checkRequestObjectSetToNull(obj) {
        Object.keys(obj).forEach(key => {
            if (!obj[key]) obj[key] = null;
        });
        return obj;
    }

    public checkReqForObjectInsideObject(obj) {
        Object.keys(obj).forEach(key => {
            if (obj[key] && typeof obj[key] === 'object') {
                const innerArray = this.checkRequestObject(obj[key])
                if (innerArray === undefined) {
                    delete obj[key]
                }
            }
            else if (!obj[key]) delete obj[key];
        });
        return obj;
    }

    public checkReqForObjectInsideObjectSetToNull(obj) {
        Object.keys(obj).forEach(key => {
            if (obj[key] && typeof obj[key] === 'object') {
                const innerArray = this.checkRequestObject(obj[key])
                if (innerArray === undefined) {
                    obj[key] = null;
                }
            }
            else if (!obj[key]) obj[key] = null;
        });
        return obj;
    }

    checkRequestObjectForArray(obj) {
        Object.keys(obj).forEach(key => {
            if (obj[key] && typeof obj[key] === 'object') {
                const innerArray = this.checkRequestObjectForArray(obj[key])
                if (innerArray === undefined) {
                    delete obj[key];
                    obj.pop();
                } else if (innerArray && innerArray.constructor === Array && innerArray.length === 0) {
                    delete obj[key]
                }
            }
            else if (!obj[key]) delete obj[key]
        });
        return Object.keys(obj).length > 0 || obj instanceof Array ? obj : undefined;
    }
    /**
     * CONSTANT MESSAGES
     */
    public CarrierConfigConstantObject = {
        "TRACFONE_DEFAULT_ERROR_MESSAGE": "Unable to process request",
        "TRACFONE_RETRIEVE_CARRIER_ERROR_MESSAGE": "Unable to retrieve Carriers",
        "TRACFONE_RETRIEVE_DATABASE_ERROR_MESSAGE": "Unable to retrieve Database Environments",
        "TRACFONE_NO_CARRIERS_FOUND_ERROR_MESSAGE": "No Carriers found",
        "TRACFONE_RETRIEVE_CARRIERS_ERROR_MESSAGE": "Unable to retrieve Carriers",
        "TRACFONE_NO_DB2_IG_FOUND_ERROR_MESSAGE": "No records found",
        "TRACFONE_RETRIEVE_DB2_IG_ERROR_MESSAGE": "Unable to retrieve records",
        "TRACFONE_UPDATE_DB2_INTERGATE_SUCCESS_MESSAGE": "DB2 Intergate updated successfully",
        "TRACFONE_UPDATE_DB2_INTERGATE_ERROR_MESSAGE": "Unable to update DB2 Intergate",
        "TRACFONE_DELETE_CARRIER_DETAIL_CONFIRM_MESSAGE": "Are you sure you want to delete this Carrier Config Detail ?",
        "TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE": "Please fix validation errors",
        "TRACFONE_DELETE_CARRIERS_DETAILS_ERROR_MESSAGE": "Unable to delete Carrier Config Detail",
        "TRACFONE_DELETE_CARRIERS_DETAILS_SUCCESS_MESSAGE": "Carrier Config Detail has been deleted sucessfully",
        "TRACFONE_RETRIEVE_CARRIERS_CONFIGS_ERROR_MESSAGE": "Unable to retrieve Carrier Configs",
        "TRACFONE_NO_CARRIERS_CONFIGS_ERROR_MESSAGE": "No Carrier Configs found",
        "TRACFONE_ADD_CARRIERS_DETAILS_ERROR_MESSAGE": "Unable to add Carrier Config Detail",
        "TRACFONE_ADD_CARRIERS_DETAILS_SUCCESS_MESSAGE": "Carrier Config Detail has been added sucessfully",
        "TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE": "Please complete previous operation",
        "TRACFONE_UPDATE_CARRIERS_DETAILS_ERROR_MESSAGE": "Unable to update Carrier Config Detail",
        "TRACFONE_UPDATE_CARRIERS_DETAILS_SUCCESS_MESSAGE": "Carrier Config Detail has been updated sucessfully",
        "TRACFONE_ADD_CARRIERS_CONFIG_ERROR_MESSAGE": "Unable to add Carrier Config",
        "TRACFONE_ADD_CARRIERS_CONFIG_SUCCESS_MESSAGE": "Carrier Config has been added sucessfully",
        "TRACFONE_RETRIEVE_PROP_NAMES_CARRIER_ERROR_MESSAGE": "Please select Carrier to retrieve Prop Names for reference",
        "TRACFONE_NO_PROP_NAMES_FOUND_ERROR_MESSAGE": "No Prop Names found for reference",
        "TRACFONE_RETRIEVE_PROP_NAMES_ERROR_MESSAGE" : "Unable to retrieve Prop Names for reference"
    }

    public getTracfoneConstantMethod(msg) {
        return this.CarrierConfigConstantObject[msg];
    }
}
