import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CarrierConfigComponent } from './carrier-config.component';

const routes: Routes = [
    {
        path: '',
        component: CarrierConfigComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class CarrierConfigRoutingModule { }
