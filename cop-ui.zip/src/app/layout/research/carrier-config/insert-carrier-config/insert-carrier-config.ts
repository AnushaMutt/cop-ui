import { Component, ViewEncapsulation, OnInit, Inject } from "@angular/core";
import { FormArray, FormBuilder, FormGroup, Validators } from "@angular/forms";
import { MatDialogRef } from "@angular/material";
import { ConfirmationService } from "primeng/api";
import { Subject } from "rxjs";
import { takeUntil } from "rxjs/operators";
import { IGCarrierConfigMaintenanceService } from "../../../../Services/igCarrierConfigMaintenance.service";
import { ToasterService } from "../../../../Services/toaster.service";
import { CarrierConfigHelper } from "../carrier-config-helper";
import { CarrierConfigService } from "../carrier-config-service";

@Component({
    selector: "carrier-config-dialog",
    templateUrl: "./insert-carrier-config.html",
    styleUrls: ["./insert-carrier-config.scss"],
    encapsulation: ViewEncapsulation.None,
    providers: [ConfirmationService]
})
export class AddCarrierConfigComponent implements OnInit {
    public addFrmGroup: FormGroup;
    public showLoadingScreen = false;
    private unsubscribe = new Subject<void>();
    public carriersData = [];
    public carriersTemp = [];
    public isPropValueKey = false;
    public isPropValueKeyType = false;
    public isPropValueKeyKey = false
    public isPropTypeMap = false;
    public isPropTypeBoolean = false;
    public isPropTypeNumber = false;
    public propTypeData: any = [];
    public showDetailsButton = false;
    public type = "";
    public propNameData = [];
    public propNameTemp = [];
    public showPropNames = false
    public refType = false
    public showNote = false

    constructor(
        public dialogRef: MatDialogRef<AddCarrierConfigComponent>,
        private _formBuilder: FormBuilder,
        private helper: CarrierConfigHelper,
        private maintenanceService: IGCarrierConfigMaintenanceService,
        private toaster: ToasterService,
        public carrierConfigService: CarrierConfigService,
    ) { dialogRef.disableClose = true; }

    ngOnInit(): void {
        this.addFrmGroup = this.initAddFormGroup();
        if (this.carrierConfigService.getcarriersData() && this.carrierConfigService.getcarriersData().length > 0) {
            this.carriersTemp = this.carrierConfigService.getcarriersData();
            this.carriersData = [...this.carriersTemp];
        } else {
            this.getCarriers();
        }
        this.propTypeData = ["Boolean", "LIST", "Number", "STRING"]
        this.showDetailsButton = false;
        this.showPropNames = false
        this.refType = false;
        this.showNote = false
    }

    /**
     * Method to create add form
     */
    public initAddFormGroup() {
        return this._formBuilder.group({
            carrier: ['', [Validators.required]],
            propName: ['', [Validators.required, Validators.maxLength(100)]],
            propType: ['', [Validators.required, Validators.maxLength(10)]],
            description: ['', [Validators.required, Validators.maxLength(1000)]],
            igCarrierDetailsArray: this._formBuilder.array([
            ])
        });
    }

    revertAddForm() {
        this.addFrmGroup.reset();
        this.showDetailsButton = false;
        let arrayControl = this.addFrmGroup.get('igCarrierDetailsArray') as FormArray;
        for(let i= arrayControl['controls'].length; i >0; i--){
            arrayControl.removeAt(i-1);
        }
        this.showPropNames = false;
        this.propNameData = [];
        this.propNameTemp = [];
        this.refType = false;
        this.showNote = false;
    }

    closeDialog() {
        this.dialogRef.close(null);
    }

    // to retrieve carriers
    public getCarriers() {
        this.showLoadingScreen = true;
        let obj: any = {};
        this.carriersData = [];
        this.carriersTemp = [];
        obj.dbEnv = this.helper.dbEnv;
        this.maintenanceService
            .getCarriers(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {

                        this.toaster.showErrorMessage(
                            this.helper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_CARRIERS_ERROR_MESSAGE")
                        );
                        this.showLoadingScreen = false;
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        return;
                    }
                    if (data[0].length == 0)
                        this.toaster.showErrorMessage(
                            this.helper.getTracfoneConstantMethod("TRACFONE_NO_CARRIERS_FOUND_ERROR_MESSAGE")
                        );
                    this.carriersTemp = data[0];
                    this.carriersData = [...this.carriersTemp];
                    this.showLoadingScreen = false;
                },
                (err: any) => {
                    this.showErr(err);
                    return;
                }
            );
    }

    // get carriers
    public getCarrier() {
        return this.carriersData;
    }

    openedChange(option) {
        if (option == "carrier")
            this.carriersData = [...this.carriersTemp];
        if (option == "propValue")
            this.propNameData = [...this.propNameTemp];
    }

    onKey(value, option) {
        if (option == "carrier") {
            this.carriersData = [...this.carriersTemp];
            this.carriersData = this.search(value, "carriers");
        } else if (option == "propValue") {
            this.propNameData = [...this.propNameTemp];
            this.propNameData = this.search(value, "propValue");
        }
    }

    //filter for dropdown
    public search(value: string, choice: string) {
        let filter = value.toLowerCase();
        if(choice == 'carriers'){
            return this.carriersTemp.filter(option => option.toLowerCase().indexOf(filter) > -1);
        } else if(choice == 'propValue'){
            return this.propNameTemp.filter(option => option.toLowerCase().indexOf(filter) > -1);
        }
    }

    //insert Carrier Configs
    public addCarrierConfig(formData) {
        if(formData.igCarrierDetailsArray.length == 0){
            this.toaster.showErrorMessage('Please add Config Details');
            return;
        }
        
        let obj: any = {};
        obj = formData;
        obj.dbEnv = this.helper.dbEnv;
        formData.igCarrierDetailsArray.forEach(e => {
            e.dbEnv = this.helper.dbEnv
        });
       
        if (this.addFrmGroup.value.propType == 'LIST' || this.addFrmGroup.value.propType == 'refList'){
            let filteredData 
            formData.igCarrierDetailsArray.forEach(e => {
              filteredData  = this.checkDoubleQuotes(e.propValue)
            e.propValues = filteredData;
            if(this.addFrmGroup.value.propType == 'refList'){
            e.propValueType = "value-ref";
            }
        });
        if(filteredData == null){
            this.toaster.showErrorMessage('Missing double quotes (") in Status Message');
            return;
        }
        }
        if (this.addFrmGroup.value.propType == 'MAP'){
            formData.igCarrierDetailsArray.forEach(e => {
                if(e.propValueType == 'LIST'){
                let filteredData = this.checkDoubleQuotes(e.propValue)
                    if(filteredData == null){
                        this.toaster.showErrorMessage('Missing double quotes (") in Status Message');
                        return;
                    }
            e.propValues = filteredData;
            }
        });
        }
        if(this.addFrmGroup.value.propType == 'refList'){
            obj.propType = "LIST"
        }
        if(this.addFrmGroup.value.propType == 'refMap'){
            obj.propType = "MAP"
        }

        

        if(obj.propType == "LIST"){
            let uniqueValue = obj.igCarrierDetailsArray[0].propValues.filter((v, i) => 
            obj.igCarrierDetailsArray[0].propValues.findIndex(item => item == v) === i);
            obj.igCarrierDetailsArray[0].propValues = [...uniqueValue];
        }
    
    
        this.showLoadingScreen = true;
        this.maintenanceService
            .insertCarrierConfig(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.toaster.showErrorMessage(
                            this.helper.getTracfoneConstantMethod("TRACFONE_ADD_CARRIERS_CONFIG_ERROR_MESSAGE")
                        );
                        this.showLoadingScreen = false;
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        return;
                    }
                    this.showLoadingScreen = false;
                    this.dialogRef.close();
                    this.toaster.showSuccessMessage(
                        this.helper.getTracfoneConstantMethod("TRACFONE_ADD_CARRIERS_CONFIG_SUCCESS_MESSAGE")
                    );
                },
                (err: any) => {
                    this.showErr(err);
                    return;
                }
            );
    }

    /*
  * Show error if any service call fails to complete
  */
    public showErr(err) {
        this.showLoadingScreen = false;
        if (err.error === undefined || err.error === null)
            this.toaster.showErrorMessage(
                this.helper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
            );
        else if (err.error && err.error.ERR) {
            const commaSeperatedArr = err.error.ERR.split(",");
            for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                if (commaSeperatedArr[i] != "")
                    this.toaster.showErrorMessage(
                        commaSeperatedArr[i]
                    );
            }
        }
        else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
            return;
        else this.toaster.showErrorMessage(err.error);
    }

    /*
    * Show error when service returns error
    */
    public showServiceErr(data) {
        const commaSeperatedArr = data[0].ERR.split(",");
        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
            if (commaSeperatedArr[i] != "")
                this.toaster.showErrorMessage(commaSeperatedArr[i]);
        }
        return;
    }

    public populateDetails(event) {
        this.type = event.value;
        this.createAddFormDynamically();
        this.showDetailsButton = true;
        let arrayControl = this.addFrmGroup.get('igCarrierDetailsArray') as FormArray;
        for(let i= arrayControl['controls'].length; i >0; i--){
            arrayControl.removeAt(i-1);
        }
        this.propNameTemp = [];
        this.propNameData = [];
        this.showPropNames = false;
        if(event.value == 'refMap'){
            this.showPropNames = true;
            this.getPropNameForRef();
        }
        if(event.value == 'refList'){
            this.showPropNames = true;
            this.getPropNameForRefList();
        }
    }

    /**
     * Method to create add details form
     */
    public initAddDetailFormGroup() {
        return this._formBuilder.group({
            propValue: ['', [Validators.maxLength(2000), Validators.required]],
            propValueType: ['', [Validators.maxLength(10)]],
            propKey: ['', [Validators.maxLength(100)]],
            propValueKey: ['', [Validators.maxLength(100)]],
            propValueKeyType: ['', [Validators.maxLength(10)]],
            propValueKeyKey: ['', [Validators.maxLength(100)]],
            remarks: ['', [Validators.maxLength(256)]]
        });
    }

    createAddFormDynamically() {
        this.isPropValueKeyKey = false;
        this.isPropValueKeyType = false;
        this.isPropValueKey = false;

        if (this.addFrmGroup.value.propType == "MAP" || this.addFrmGroup.value.propType == "refMap") {
            this.isPropTypeMap = true;
            this.isPropTypeBoolean = false;
            this.isPropTypeNumber = false;
            this.isPropValueKey = true;
            this.isPropValueKeyType = true;
            this.isPropValueKeyKey = true;
        } else if (this.addFrmGroup.value.propType == "Boolean") {
            this.isPropTypeBoolean = true;
            this.isPropTypeMap = false;
            this.isPropTypeNumber = false;
        } else if (this.addFrmGroup.value.propType == "Number") {
            this.isPropTypeBoolean = false;
            this.isPropTypeMap = false;
            this.isPropTypeNumber = true;
        } else {
            this.isPropTypeBoolean = false;
            this.isPropTypeMap = false;
            this.isPropTypeNumber = false;
        }
    }

    public populateMap(j){
        let keys = Object.keys(this.addFrmGroup.controls['igCarrierDetailsArray']['controls'][j]['controls']);
        keys.forEach(e1 => {
            if(e1 != 'propValueType'){
            this.addFrmGroup.controls['igCarrierDetailsArray']['controls'][j]['controls'][`${e1}`].reset();
            }
        })

        this.addFrmGroup.controls['igCarrierDetailsArray']['controls'][j]['controls'].propValue.setValidators([Validators.maxLength(2000),Validators.required]);
        this.addFrmGroup.controls['igCarrierDetailsArray']['controls'][j]['controls'].propValue.updateValueAndValidity();

        if(this.addFrmGroup.controls['igCarrierDetailsArray']['controls'][j].value.propValueType == 'Boolean'){
            this.isPropTypeBoolean = true 
        } else {
            this.isPropTypeBoolean = false;
        }
        
        if(this.addFrmGroup.controls['igCarrierDetailsArray']['controls'][j].value.propValueType == 'Number'){
            this.addFrmGroup.controls['igCarrierDetailsArray']['controls'][j]['controls'].propValue.setValidators([Validators.maxLength(2000), Validators.pattern("^[0-9]*$"), Validators.required]);
            this.addFrmGroup.controls['igCarrierDetailsArray']['controls'][j]['controls'].propValue.updateValueAndValidity();
            this.isPropTypeNumber = true 
        } else {
            this.isPropTypeNumber = false;
        }
    }

    public addDetailButton(control) {
        control.push(this.initAddDetailFormGroup())
       this.validateDetilsForm();
        if(this.type == 'MAP'){
            this.showDetailsButton = true;
        } else {
            this.showDetailsButton = false;
        }

        if(this.type == 'refMap'){
            this.addFrmGroup.controls.igCarrierDetailsArray['controls'][0].controls.propValueType.setValue("value-ref");
            this.addFrmGroup.controls.igCarrierDetailsArray['controls'][0].controls.propValueType.updateValueAndValidity();
            this.refType = true;
        } else if(this.type == 'refList'){
            this.refType = true;
        } else {
            this.refType = false
        }

        if(this.type == 'LIST'){
            this.showNote = true
        } else {
            this.showNote = false
        }
    }

    public validateDetilsForm(){
        this.addFrmGroup.controls.igCarrierDetailsArray['controls'].forEach(e => {
            let keys = Object.keys(e.controls);
        keys.forEach(e1 => {
            e.controls[e1].setValidators([]);
            e.controls[e1].updateValueAndValidity();
            if(e1 == 'propValue'){
            e.controls[e1].setValidators([Validators.maxLength(2000), Validators.required]);
            }
            if(e1 == 'remarks'){
            e.controls[e1].setValidators([Validators.maxLength(256)]);
            e.controls[e1].updateValueAndValidity();
            }
            if(this.type == 'Number'){
                if(e1 == 'propValue'){
                    e.controls[e1].setValidators([Validators.maxLength(2000), Validators.pattern("^[0-9]*$"), Validators.required]);
                    e.controls[e1].updateValueAndValidity();
                }
        }
        if(this.type == 'MAP' || this.type == 'refMap'){
            if(e1 == 'propKey'){
                e.controls[e1].setValidators([Validators.maxLength(100), Validators.required]);
                e.controls[e1].updateValueAndValidity();
            }
            if(e1 == 'propValueType'){
                e.controls[e1].setValidators([ Validators.required]);
                e.controls[e1].updateValueAndValidity();
            }
        }
        });
        });
    }

    public removeDetail(control, i) {
        control.removeAt(i);
    }

    // to retrieve prop names for reference-map type
    public getPropNameForRef() {
        if(!this.addFrmGroup.controls['carrier'].value){
        this.toaster.showErrorMessage(
            this.helper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_PROP_NAMES_CARRIER_ERROR_MESSAGE")
        );
        return;
        }
        this.showLoadingScreen = true;
        let obj: any = {};
        obj.carrier = this.addFrmGroup.value.carrier;
        obj.dbEnv = this.helper.dbEnv;
        this.propNameData = [];
        this.propNameTemp = [];
        this.maintenanceService
            .getPropNameForRef(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {

                        this.toaster.showErrorMessage(
                            this.helper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_PROP_NAMES_ERROR_MESSAGE")
                        );
                        this.showLoadingScreen = false;
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        return;
                    }
                    if (data[0].length == 0)
                        this.toaster.showErrorMessage(
                            this.helper.getTracfoneConstantMethod("TRACFONE_NO_PROP_NAMES_FOUND_ERROR_MESSAGE")
                        );
                    this.propNameTemp = data[0];
                    this.propNameData = [...this.propNameTemp];
                    this.showLoadingScreen = false;
                },
                (err: any) => {
                    this.showErr(err);
                    return;
                }
            );
    }

    // to retrieve prop names for reference-list type
    public getPropNameForRefList() {
        if(!this.addFrmGroup.controls['carrier'].value){
        this.toaster.showErrorMessage(
            this.helper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_PROP_NAMES_CARRIER_ERROR_MESSAGE")
        );
        return;
        }
        this.showLoadingScreen = true;
        let obj: any = {};
        obj.carrier = this.addFrmGroup.value.carrier;
        obj.dbEnv = this.helper.dbEnv;
        this.propNameData = [];
        this.propNameTemp = [];
        this.maintenanceService
            .getPropNameForRefList(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {

                        this.toaster.showErrorMessage(
                            this.helper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_PROP_NAMES_ERROR_MESSAGE")
                        );
                        this.showLoadingScreen = false;
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        return;
                    }
                    if (data[0].length == 0)
                        this.toaster.showErrorMessage(
                            this.helper.getTracfoneConstantMethod("TRACFONE_NO_PROP_NAMES_FOUND_ERROR_MESSAGE")
                        );
                    this.propNameTemp = data[0];
                    this.propNameData = [...this.propNameTemp];
                    this.showLoadingScreen = false;
                },
                (err: any) => {
                    this.showErr(err);
                    return;
                }
            );
    }

    public isRefereceType(){
        if(this.addFrmGroup.controls['propType'].value == 'refMap'){
        this.getPropNameForRef();
        } else if(this.addFrmGroup.controls['propType'].value == 'refList'){
            this.getPropNameForRefList();
        }
    }

    checkDoubleQuotes(data){
        var matches = data.match(/"/g);
        var count = matches ? matches.length : 0;
        if (count % 2 == 0) {
          var arr = data.split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/);
          arr = arr.map(el => el.replace(/"/g, ''))
          arr = arr.filter(Boolean);
          return arr;
        } else {
          return null;
        }
      }

}