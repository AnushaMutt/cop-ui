import { Component, ViewEncapsulation, OnInit, ViewChild, ViewChildren } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ConfirmationService } from "primeng/api";
import { Subject } from "rxjs";
import { DatabaseEnvService } from "../../../Services/dbenv.service";
import { ToasterService } from "../../../Services/toaster.service";
import { routerTransition } from "../../../router.animations";
import { CarrierConfigHelper } from "./carrier-config-helper";
import { takeUntil } from "rxjs/operators";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { IGCarrierConfigService } from "../../../Services/IgCarrierConfig.service";
import { MatDialog, MatSelect } from "@angular/material";
import { IGCarrierConfigMaintenanceService } from "../../../Services/igCarrierConfigMaintenance.service";
import { AddDialogComponent } from "./add-dialog/add-dialog.component";
import { AddCarrierConfigComponent } from "./insert-carrier-config/insert-carrier-config";
import { CarrierConfigService } from "./carrier-config-service";

@Component({
    selector: 'app-carrier-config',
    templateUrl: './carrier-config.component.html',
    styleUrls: ["./carrier-config.component.scss",
        '../../components/ngxtable/material.scss',
        '../../components/ngxtable/datatable.component.scss',
        '../../components/ngxtable/icons.css',
        '../../components/ngxtable/app.css'],
    animations: [routerTransition()],
    encapsulation: ViewEncapsulation.None,
    providers: [ConfirmationService]

})
export class CarrierConfigComponent implements OnInit {
    @ViewChildren(MatSelect) matSelect: any;
    @ViewChild('table') table: any;
    public showLoadingScreen = false;
    private unsubscribe = new Subject<void>();
    public frmGroupMain: FormGroup;
    public fromGroupDB: FormGroup;
    public parentTableFormGroup: FormGroup;
    public dbEnvironments = [];
    public dbEnvironmentsMainData = [];
    public carriersData = [];
    public carriersTemp = [];
    public carrierConfigData = [];
    public carrierConfigTemp = [];
    public carrierDetails = [];
    public carrierDetailsTemp = [];
    public carrierConfigColumns = [];
    public detailsColumns = [];
    public detailMainColumns = [];
    public isEditable: any = {}
    public editedRow: any = {};
    public defaultEditedRow: any = {};
    public isPropTypeMap = false;
    public isPropTypeBoolean = false;
    public isPropTypeNumber = false;
    public rowAlreadyExpanded = false;
    public editAlreadyEnabled = false;
    public currentConfigId;
    public currentPropType;
    public filteredRows: any;
    public isIgConfigMaintenance = false;
    public isPropValueKey = false;
    public isPropValueKeyType = false;
    public isPropValueKeyKey = false
    public services: any;
    public rowData: any;
    public showAdd = true;

    constructor(
        private _formBuilder: FormBuilder,
        private toasterService: ToasterService,
        private helper: CarrierConfigHelper,
        private dbenvService: DatabaseEnvService,
        private service: IGCarrierConfigService,
        private maintenanceService: IGCarrierConfigMaintenanceService,
        private modalService: NgbModal,
        private confirmationService: ConfirmationService,
        public dialog: MatDialog,
        public carrierConfigService: CarrierConfigService,
    ) { }

    ngOnInit() {
        this.carrierConfigService.resetAll();
        this.showLoadingScreen = false;
        this.showAdd = true;
        this.frmGroupMain = this.initSearchFormGroup();

        this.parentTableFormGroup = this.initParentTableFormGroup();
        this.frmGroupMain.disable();
        this.fromGroupDB = this._formBuilder.group({
            dbEnv: ['', [Validators.required]]
        });
        this.carrierConfigColumns = [
            { name: "Config Id", prop: "configId", width: "30" },
            { name: "Carrier", prop: "carrier", width: "90" },
            { name: "Prop Type", prop: "propType", width: "30" },
            { name: "Prop Name", prop: "propName", width: "100" },
            { name: "Description", prop: "description", width: "300" },
        ];
        this.detailMainColumns = [
            { name: "Prop Key", prop: "propKey", width: "140" },
            { name: "Prop Value Type", prop: "propValueType", width: "140" },
            { name: "Prop Value", prop: "propValue", width: "140" },
            { name: "Prop Value Key", prop: "propValueKey", width: "140" },
            { name: "Prop Value Key Type", prop: "propValueKeyType", width: "140" },
            { name: "Prop Value Key Key", prop: "propValueKeyKey", width: "140" },
            { name: "Remarks", prop: "remarks", width: "140" },
        ];
        this.retrieveDBEnv();
        if (window.location.href.substring(window.location.href.lastIndexOf('/') + 1) == 'igconfigmaintenance') {
            this.isIgConfigMaintenance = true;
        } else { this.isIgConfigMaintenance = false; }
    }

    /**
     * Method to create search form
     */
    public initSearchFormGroup() {
        return this._formBuilder.group({
            carrier: [''],
            configId: [''],
            propName: [''],
        });
    }


    /**
    * Method to create Parent Table Form
    */
    public initParentTableFormGroup() {
        return this._formBuilder.group({
            carrier: [''],
            configId: [''],
            propName: [''],
            propType: [''],
            description: ['']
        });
    }

    public retrieveDBEnv() {
        this.showLoadingScreen = true;
        // If envs were previously retrieved, get it from internal storage.
        if (this.dbenvService.isDBEnvsInStorage()) {
            this.dbEnvironments = this.dbenvService.getDbEnvsFromStorage();
            this.dbEnvironmentsMainData = this.dbEnvironments;
            // making database as default selected if one database is available
            if (this.dbEnvironments.length == 1) {
                this.fromGroupDB
                    .get("dbEnv")
                    .setValue(this.dbEnvironments[0].name);
                this.dbSelect(this.dbEnvironments[0].name);
            }
            this.showLoadingScreen = false;
        } else {
            // Get envs from service request.
            this.dbenvService
                .getDbEnvsFromService()
                .pipe(takeUntil(this.unsubscribe))
                .subscribe(
                    data => {
                        if (data[0] === null || data[0] === undefined) {
                            this.toasterService.showErrorMessage(
                                this.helper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_DATABASE_ERROR_MESSAGE")
                            );
                            this.showLoadingScreen = false;
                            return;
                        }

                        this.dbEnvironments = data[0];
                        this.dbEnvironmentsMainData = this.dbEnvironments;
                        this.dbenvService.storeDbEnvs(this.dbEnvironments);
                        // making database as default selected if one database is available
                        if (this.dbEnvironments.length == 1) {
                            this.fromGroupDB
                                .get("dbEnv")
                                .setValue(this.dbEnvironments[0].name);
                            this.dbSelect(this.dbEnvironments[0].name);
                        }
                        this.showLoadingScreen = false;
                    },
                    (err: any) => {
                        this.showErr(err);
                        return;
                    }
                );
        }
    }

    public dbSelect(dbEnv) {
        this.helper.setDbEnv(dbEnv);
        this.frmGroupMain.enable();
        this.getCarriers();
        this.revertSearchForm();
        this.showAdd = false;
    }

    openedChange(option) {
        if (option == "carrier")
            this.carriersData = [...this.carriersTemp];
        else if (option == "database")
            this.dbEnvironments = [...this.dbEnvironmentsMainData];
    }

    onKey(value, option) {
        if (option == "database") {
            this.dbEnvironments = [...this.dbEnvironmentsMainData];
            this.dbEnvironments = this.search(value, "database");
        } else if (option == "carrier") {
            this.carriersData = [...this.carriersTemp];
            this.carriersData = this.search(value, "carriers");
        }
    }

    //filter for dropdown
    public search(value: string, choice: string) {
        let filter = value.toLowerCase();
        switch (choice) {
            case "database":
                return this.dbEnvironmentsMainData.filter(option => option.description.toLowerCase().indexOf(filter) > -1);
            case "carriers":
                return this.carriersTemp.filter(option => option.toLowerCase().indexOf(filter) > -1);
            default:
                return;
        }
    }

    public getDbEnvironments() {
        return this.dbEnvironments;
    }

    // to retrieve carriers
    public getCarriers() {
        this.showLoadingScreen = true;
        let obj: any = {};
        this.carriersData = [];
        this.carriersTemp = [];
        obj.dbEnv = this.helper.dbEnv;
        if (window.location.href.substring(window.location.href.lastIndexOf('/') + 1) == 'igconfigmaintenance') {
            this.services = this.maintenanceService;
        } else {
            this.services = this.service;
        }
        this.services
            .getCarriers(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {

                        this.toasterService.showErrorMessage(
                            this.helper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_CARRIERS_ERROR_MESSAGE")
                        );
                        this.showLoadingScreen = false;
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        return;
                    }
                    if (data[0].length == 0)
                        this.toasterService.showErrorMessage(
                            this.helper.getTracfoneConstantMethod("TRACFONE_NO_CARRIERS_FOUND_ERROR_MESSAGE")
                        );
                    this.carriersTemp = data[0];
                    this.carriersData = [...this.carriersTemp];
                    this.carrierConfigService.setcarriersData(this.carriersData);
                    this.showLoadingScreen = false;
                },
                (err: any) => {
                    this.showErr(err);
                    return;
                }
            );
    }

    // get carriers
    public getCarrier() {
        return this.carriersData;
    }

    revertSearchForm() {
        this.frmGroupMain.reset();
        this.carrierDetailsTemp = [];
        this.carrierDetails = [];
        this.carrierConfigData = [];
        this.carrierConfigTemp = [];
        this.rowAlreadyExpanded = false;
        this.editAlreadyEnabled = false;
        this.isEditable = {};
        this.isPropTypeMap = false;
        this.editedRow = {};
        this.defaultEditedRow = {};
        this.parentTableFormGroup.controls.configId.patchValue([]);
        this.parentTableFormGroup.controls.propType.patchValue([]);
        this.parentTableFormGroup.controls.propName.patchValue([]);
        this.parentTableFormGroup.controls.carrier.patchValue([]);
        this.parentTableFormGroup.controls.description.patchValue([]);
    }

    createSearchCarrierConfigRequest() {
        this.rowAlreadyExpanded = false;
        this.editAlreadyEnabled = false;
        this.isEditable = {};
        this.isPropTypeMap = false;
        this.editedRow = {};
        this.defaultEditedRow = {};
        let obj: any = {};
        this.carrierConfigTemp = [];
        this.carrierConfigData = [];
        this.carrierDetails = [];
        this.carrierDetailsTemp = [];
        this.parentTableFormGroup.controls.configId.patchValue([]);
        this.parentTableFormGroup.controls.propType.patchValue([]);
        this.parentTableFormGroup.controls.propName.patchValue([]);
        this.parentTableFormGroup.controls.carrier.patchValue([]);
        this.parentTableFormGroup.controls.description.patchValue([]);
        if (this.frmGroupMain.value.carrier)
            obj.carrier = this.frmGroupMain.value.carrier;
        if (this.frmGroupMain.value.configId)
            obj.configId = this.frmGroupMain.value.configId;
        if (this.frmGroupMain.value.propName)
            obj.propName = this.frmGroupMain.value.propName;
        obj.dbEnv = this.helper.dbEnv;
        this.getCarrierConfigs(obj);
    }

    // to retrieve carriers configs
    public getCarrierConfigs(obj) {
        this.showLoadingScreen = true;
        if (window.location.href.substring(window.location.href.lastIndexOf('/') + 1) == 'igconfigmaintenance') {
            this.services = this.maintenanceService;
        } else {
            this.services = this.service;
        }
        this.services
            .getCarrierConfigs(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.toasterService.showErrorMessage(
                            this.helper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_CARRIERS_CONFIGS_ERROR_MESSAGE")
                        );
                        this.showLoadingScreen = false;
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        return;
                    }
                    if (data[0].length == 0)
                        this.toasterService.showErrorMessage(
                            this.helper.getTracfoneConstantMethod("TRACFONE_NO_CARRIERS_CONFIGS_ERROR_MESSAGE")
                        );
                    let configTemp = data[0];
                    //filtering unique rows
                    this.carrierConfigTemp = [...configTemp.filter(
                        (value, index, array) => array.findIndex((_e1) => (_e1.configId === value.configId)) === index)];

                    //setting carrier details with unique config ids
                    this.carrierConfigTemp.forEach(_e1 => {
                        _e1.igCarrierDetails = [];
                        _e1.expanded = false
                        if (_e1.description) {
                            _e1.description = _e1.description.replace(/>/g, '&gt;');
                            _e1.description = _e1.description.replace(/</g, '&lt;');
                        }
                        configTemp.forEach(_e2 => {
                            if (_e2.configId == _e1.configId) {
                                _e2.carrierDetails.propType = _e2.propType;
                                _e1.igCarrierDetails.push(_e2.carrierDetails);
                            }
                        });
                    });
                    this.carrierConfigData = [...this.carrierConfigTemp];
                    this.parentTableFormGroup.controls.configId.patchValue([]);
                    this.parentTableFormGroup.controls.propType.patchValue([]);
                    this.parentTableFormGroup.controls.propName.patchValue([]);
                    this.parentTableFormGroup.controls.carrier.patchValue([]);
                    this.parentTableFormGroup.controls.description.patchValue([]);
                    this.generateFilters();
                    this.filterReportResults();
                    this.showLoadingScreen = false;
                },
                (err: any) => {
                    this.showErr(err);
                    return;
                }
            );
    }

    //Toggle Search result table row details
    toggleExpandRow(row) {
        //If row detail already open then close it and vice-versa
        if (row.expanded) {
            this.rowAlreadyExpanded = false;
            this.carrierConfigData.forEach(e1 => { e1.expanded = false });
            this.table.rowDetail.toggleExpandRow(row);
            this.currentConfigId = "";
            this.currentPropType = "";
            this.detailsColumns = [];
            return;
        }
        // Else Open new row detail and close the existing one 
        else {
            this.isEditable = {};
            this.editAlreadyEnabled = false;
            this.editedRow = {};
            this.defaultEditedRow = {};
            this.currentConfigId = row.configId;
            this.currentPropType = row.propType;
            this.rowData = { ...row };
            this.rowAlreadyExpanded = true;
            this.carrierDetailsTemp = [];
            this.carrierDetails = [];
            this.detailsColumns = [];
            this.carrierConfigData.forEach(e1 => { e1.expanded = false });
            row.expanded = !row.expanded;
            this.table.rowDetail.collapseAllRows();
            this.carrierConfigData.forEach(_e1 => {
                if (row.configId == _e1.configId) {
                    this.carrierDetailsTemp = [..._e1.igCarrierDetails];
                }
            });
            this.carrierDetails = [...this.carrierDetailsTemp];
            this.createDynamicDetailsTableColumns(row);
            this.table.rowDetail.toggleExpandRow(row);
        }
    }

    createDynamicDetailsTableColumns(row) {
        this.detailsColumns = [];
        if (this.carrierDetails && this.carrierDetails.length > 0) {
            let detailsKeys = Object.keys(this.carrierDetails[0]);
            this.carrierDetails.forEach(_e1 => {
                detailsKeys.forEach(_e2 => {
                    if (_e1[_e2]) {
                        this.detailMainColumns.forEach(_e3 => {
                            if (_e3.prop == _e2) {
                                if (this.detailsColumns.indexOf(_e3) === -1) { this.detailsColumns.push(_e3); }
                            }
                        });
                    }
                });
            });
        }
        this.detailMainColumns.forEach(_e1 => {
            if (_e1.prop == 'remarks')
                if (this.detailsColumns.indexOf(_e1) === -1) this.detailsColumns.push(_e1);
        });
        this.isPropValueKeyKey = false;
        this.isPropValueKeyType = false;
        this.isPropValueKey = false;
        if (this.carrierDetails && this.carrierDetails.length > 0) {
            if (this.carrierDetails[0].propValueKey) {
                this.isPropValueKey = true;
            } if (this.carrierDetails[0].propValueKeyType) {
                this.isPropValueKeyType = true;
            } if (this.carrierDetails[0].propValueKeyKey) {
                this.isPropValueKeyKey = true;
            }
        }
        if (row.propType == "MAP") {
            this.isPropTypeMap = true;
            this.isPropTypeBoolean = false;
            this.isPropTypeNumber = false;
        } else if (row.propType == "Boolean") {
            this.isPropTypeBoolean = true;
            this.isPropTypeMap = false;
            this.isPropTypeNumber = false;
        } else if (row.propType == "Number") {
            this.isPropTypeBoolean = false;
            this.isPropTypeMap = false;
            this.isPropTypeNumber = true;
        } else {
            this.isPropTypeBoolean = false;
            this.isPropTypeMap = false;
            this.isPropTypeNumber = false;
        }
    }

    public editButtonClicked(rowIndex) {
        let alreadyEnabled = false;
        for (let i = 0; i < this.carrierConfigData.length; i++) {
            if (this.isEditable[i])
                alreadyEnabled = true;
        }
        if (!alreadyEnabled) {
            this.editAlreadyEnabled = true;
            this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        }
        else
            this.toasterService.showErrorMessage(
                this.helper.getTracfoneConstantMethod("TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE")
            );
    }

    public cancelEditForm(rowData, rowIndex) {
        this.showLoadingScreen = true;
        this.isEditable[rowIndex] = !this.isEditable[rowIndex];

        this.detailsColumns.forEach(data => {
            if (document.getElementById(data.prop + rowIndex)) {
                (<HTMLInputElement>(
                    document.getElementById(data.prop + rowIndex)
                )).value = rowData[data.prop] || '';
            }
        });

        this.matSelect._results.forEach(matSelectData => {
            if (matSelectData.id.indexOf('propValue' + rowIndex) == 0)
                matSelectData.value = rowData['propValue'] || '';
        });
        this.editedRow = {};
        this.showLoadingScreen = false;
        this.editAlreadyEnabled = false;
    }

    public inputValueChanged(event, column, row, oldValue) {
        if (column == "propValue" && this.isPropTypeBoolean) {
            this.editedRow[column] = event.value;
            this.defaultEditedRow[column] = oldValue;
        } else {
            this.editedRow[column] = event.target.value;
            this.defaultEditedRow[column] = event.target.defaultValue;
        }
    }


    // confirm box
    showConfirm(f) {
        this.confirmationService.confirm({
            key: 'confirm-delete-details',
            message: this.helper.getTracfoneConstantMethod("TRACFONE_DELETE_CARRIER_DETAIL_CONFIRM_MESSAGE"),
            accept: () => {
                this.deleteCarreirDetails(f)
            }
        });
    }

    createUpdateRequest(rowData, rowIndex) {
        if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
            this.toasterService.showErrorMessage(
                this.helper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            return;
        }
        let obj: any = {};
        let oldRowData: any = {};
        oldRowData = { ...rowData };
        obj.configId = this.currentConfigId;
        obj.propType = this.currentPropType;
        obj.igCarrierDetails = {};
        obj.igCarrierDetails = { ...rowData, ...this.editedRow };
        obj.igCarrierDetails.oldPropValue = oldRowData.propValue;
        obj.igCarrierDetails.oldPropKey = oldRowData.propKey;
        obj.igCarrierDetails.oldPropValueType = oldRowData.propValueType;
        obj.igCarrierDetails.oldPropValueKey = oldRowData.propValueKey;
        obj.igCarrierDetails.oldPropValueKeyType = oldRowData.propValueKeyType;
        obj.igCarrierDetails.oldPropValueKeyKey = oldRowData.propValueKeyKey;
        obj.igCarrierDetails.oldRemark = oldRowData.remarks;
        obj = this.helper.checkRequestObject(obj);
        obj.dbEnv = this.helper.dbEnv;
        obj.igCarrierDetails.dbEnv = this.helper.dbEnv;
        this.updateCarrierDetails(obj, rowIndex);
    }

    //update carrier details
    public updateCarrierDetails(obj, rowIndex) {
        this.showLoadingScreen = true;
        this.maintenanceService
            .updateCarrierDetails(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.toasterService.showErrorMessage(
                            this.helper.getTracfoneConstantMethod("TRACFONE_UPDATE_CARRIERS_DETAILS_ERROR_MESSAGE")
                        );
                        this.showLoadingScreen = false;
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        return;
                    }
                    this.isEditable[rowIndex] = !this.isEditable[rowIndex];
                    this.editedRow = {};
                    this.defaultEditedRow = {};
                    this.showLoadingScreen = false;
                    for (let i = 0; i < this.carrierDetailsTemp.length; i++) {
                        if (this.carrierDetailsTemp[i].propKey == obj.igCarrierDetails.oldPropKey && this.carrierDetailsTemp[i].propValueType == obj.igCarrierDetails.oldPropValueType
                            && this.carrierDetailsTemp[i].propValue == obj.igCarrierDetails.oldPropValue && this.carrierDetailsTemp[i].propValueKey == obj.igCarrierDetails.oldPropValueKey
                            && this.carrierDetailsTemp[i].propValueKeyType == obj.igCarrierDetails.oldPropValueKeyType && this.carrierDetailsTemp[i].propValueKeyKey == obj.igCarrierDetails.propValueKeyKey
                            && this.carrierDetailsTemp[i].configId == obj.igCarrierDetails.configId) {
                            this.carrierDetailsTemp[i] = obj.igCarrierDetails;
                        }
                    }
                    this.carrierDetails = [...this.carrierDetailsTemp];
                    this.carrierConfigTemp.forEach(_e1 => {
                        if (obj.configId == _e1.configId)
                            _e1.igCarrierDetails = this.carrierDetails;
                    });
                    this.editAlreadyEnabled = false;
                    this.toasterService.showSuccessMessage(
                        this.helper.getTracfoneConstantMethod("TRACFONE_UPDATE_CARRIERS_DETAILS_SUCCESS_MESSAGE")
                    );
                },
                (err: any) => {
                    this.showErr(err);
                    return;
                }
            );
    }

    //delete carrier details
    public deleteCarreirDetails(f) {
        let obj: any = {};
        obj = f;
        obj = this.helper.checkRequestObject(obj);
        obj.dbEnv = this.helper.dbEnv;
        this.showLoadingScreen = true;
        this.maintenanceService
            .deleteCarrierDetails(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.toasterService.showErrorMessage(
                            this.helper.getTracfoneConstantMethod("TRACFONE_DELETE_CARRIERS_DETAILS_ERROR_MESSAGE")
                        );
                        this.showLoadingScreen = false;
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        return;
                    }
                    this.deleteRow(f);
                    this.toasterService.showSuccessMessage(
                        this.helper.getTracfoneConstantMethod("TRACFONE_DELETE_CARRIERS_DETAILS_SUCCESS_MESSAGE")
                    );
                    this.showLoadingScreen = false;
                },
                (err: any) => {
                    this.showErr(err);
                    return;
                }
            );
    }
    //this method is use to delete row from array
    public deleteRow(rowData) {
        this.carrierDetailsTemp.forEach((data, key) => {
            if (rowData.configId == data.configId && rowData.propValue == data.propValue
                && rowData.propKey == data.propKey && rowData.propValueKey == data.propValueKey
                && rowData.propValueKeyType == data.propValueKeyType && rowData.propValueKeyKey == data.propValueKeyKey)
                this.carrierDetailsTemp.splice(key, 1);
        });
        this.carrierDetails = [...this.carrierDetailsTemp];
        this.carrierConfigTemp.forEach(_e1 => {
            if (rowData.configId == _e1.configId)
                _e1.igCarrierDetails = this.carrierDetails;
        });
        if (this.carrierDetailsTemp.length === 0) {
            this.carrierDetails = [];
        }
    }

    //Filter parent Table data based on all the columns values
    public filterParentTable(event) {
        let val = event.target.value.toLowerCase();
        // filter our data
        const temp = this.carrierConfigTemp.filter(function (d) {
            return (d.configId ? d.configId.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.carrier ? d.carrier.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.propName ? d.propName.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.propType ? d.propType.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.description ? d.description.toLowerCase().indexOf(val) !== -1 : !val) || !val;
        });
        // update the rows
        this.carrierConfigData = temp;
    }

    // to filter columns
    public filterReportResults(): void {
        const filterFormObject = this.parentTableFormGroup.value;
        const newRows = Object.keys(filterFormObject).reduce((acc, key) => {
            if (!filterFormObject[key].length) return acc;
            const filteredRows = acc.filter(val => filterFormObject[key].indexOf(val[key]) > -1);
            return filteredRows;
        }, this.carrierConfigTemp);

        this.carrierConfigData = newRows;
    }

    public generateFilters(): void {

        this.filteredRows = Object.keys(this.carrierConfigColumns)
            .map(i => this.carrierConfigColumns[i].prop)
            .reduce((filterObject, columnName) => {

                const uniqueValuesPerRow = this.carrierConfigData.reduce((set, row) => set.add(row[columnName]), new Set());
                let val: any = Array.from(uniqueValuesPerRow);
                if (!isNaN(Date.parse(val[0]))) {
                    filterObject[columnName] = val.sort(function (date1, date2) {
                        date1 = new Date(date1);
                        date2 = new Date(date2);
                        if (date1 > date2) return 1;
                        if (date1 < date2) return -1;
                    })
                } else if (/^[0-9]*$/.test(val[0])) {
                    filterObject[columnName] = val.sort(function (a, b) { return a - b });
                } else {
                    filterObject[columnName] = val.sort((a, b) => {
                        a = a || '';
                        b = b || '';
                        return a.localeCompare(b);
                    });
                }
                return filterObject;
            }, {});
    }

    public openAddDialog() {
        const dialogRef = this.dialog.open(AddDialogComponent, {
            width: "65%",
            height: "85",
            data: {
                dataKey: this.rowData,
                carrierDetails: this.carrierDetails
            },
        });
        // Create subscription
        dialogRef.afterClosed().subscribe((carrierDetails) => {
            // Do stuff after the dialog has closed
            if (carrierDetails && carrierDetails.length > 0) {
                carrierDetails.forEach(element => {
                    this.carrierDetailsTemp.push(element);
                });
                this.carrierDetails = [...this.carrierDetailsTemp];
                this.carrierConfigTemp.forEach(_e1 => {
                    if (this.rowData.configId == _e1.configId)
                        _e1.igCarrierDetails = this.carrierDetails;
                });
            }

        });
    }
    /*
  * Show error if any service call fails to complete
  */
    public showErr(err) {
        this.showLoadingScreen = false;
        if (err.error === undefined || err.error === null)
            this.toasterService.showErrorMessage(
                this.helper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
            );
        else if (err.error && err.error.ERR) {
            const commaSeperatedArr = err.error.ERR.split(",");
            for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                if (commaSeperatedArr[i] != "")
                    this.toasterService.showErrorMessage(
                        commaSeperatedArr[i]
                    );
            }
        }
        else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
            return;
        else this.toasterService.showErrorMessage(err.error);
    }

    /*
    * Show error when service returns error
    */
    public showServiceErr(data) {
        const commaSeperatedArr = data[0].ERR.split(",");
        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
            if (commaSeperatedArr[i] != "")
                this.toasterService.showErrorMessage(commaSeperatedArr[i]);
        }
        return;
    }

    public openCarrierConfig() {
        const dialogRef = this.dialog.open(AddCarrierConfigComponent, {
            width: "65%",
            height: "85"
        });
    }
}