import { Injectable } from "@angular/core";
import { Subject } from "rxjs";

@Injectable({
    providedIn: "root"
})
export class CarrierConfigService {
    carriersData: any = [];

    constructor() {}

    public setcarriersData(carriersData) {
        this.carriersData = carriersData;
    }

    public getcarriersData() {
        return this.carriersData;
    }

    resetAll(){
        this.carriersData = [];
    }
}
