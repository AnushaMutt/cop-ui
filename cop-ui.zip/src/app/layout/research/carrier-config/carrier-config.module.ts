import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { PageHeaderModule, SelectCheckAllModule } from "./../../../shared";
import { NgxDatatableModule } from "@swimlane/ngx-datatable";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { MatTabsModule } from "@angular/material";
import {
    MatAutocompleteModule,
    MatBadgeModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDatepickerModule,
    MatDialogModule,
    MatDividerModule,
    MatExpansionModule,
    MatGridListModule,
    MatIconModule,
    MatListModule,
    MatMenuModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatStepperModule,
    MatTableModule,
    MatToolbarModule,
    MatTooltipModule,
    MatTreeModule,
    MatInputModule
} from "@angular/material";

import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { TreeTableModule } from "primeng/primeng";
import { TableModule } from "primeng/table";
import { CarrierConfigComponent } from "./carrier-config.component";
import { CarrierConfigRoutingModule } from "./carrier-config-routing";
import { CarrierConfigHelper } from "./carrier-config-helper";
import { AddDialogComponent } from "./add-dialog/add-dialog.component";
import { AddCarrierConfigComponent } from "./insert-carrier-config/insert-carrier-config";

@NgModule({
    imports: [
        CommonModule,
        CarrierConfigRoutingModule,
        PageHeaderModule,
        FormsModule,
        ReactiveFormsModule,
        NgxDatatableModule,
        MatAutocompleteModule,
        MatBadgeModule,
        MatBottomSheetModule,
        MatButtonModule,
        MatButtonToggleModule,
        MatCardModule,
        MatCheckboxModule,
        MatChipsModule,
        MatStepperModule,
        MatDatepickerModule,
        MatDialogModule,
        MatDividerModule,
        MatExpansionModule,
        MatGridListModule,
        MatIconModule,
        MatListModule,
        MatMenuModule,
        MatNativeDateModule,
        MatPaginatorModule,
        MatProgressBarModule,
        MatProgressSpinnerModule,
        MatRadioModule,
        MatRippleModule,
        MatSelectModule,
        MatSidenavModule,
        MatSliderModule,
        MatSlideToggleModule,
        MatSnackBarModule,
        MatSortModule,
        MatTableModule,
        MatToolbarModule,
        MatTooltipModule,
        MatTreeModule,
        MatInputModule,
        MatTabsModule,
        MatButtonModule,
        MatButtonToggleModule,
        ConfirmDialogModule,
        NgbModule.forRoot(),
        TreeTableModule,
        TableModule,
        SelectCheckAllModule
    ],
    declarations: [CarrierConfigComponent, AddDialogComponent, AddCarrierConfigComponent],
    providers: [CarrierConfigHelper],
    entryComponents: [AddDialogComponent, AddCarrierConfigComponent]
})
export class CarrierConfigModule { }
