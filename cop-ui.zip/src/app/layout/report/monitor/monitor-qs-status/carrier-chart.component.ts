    export class CarrierbarChart{
        name:string;
        barChartLabels = []; 
        barChartData = [];
        
        constructor(name: string, barChartLabels: string[], barChartData:any []){
    		this.name = name;
    		this.barChartLabels = barChartLabels;
    		this.barChartData = barChartData;
        }
    }