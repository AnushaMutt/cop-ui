import { Component, ViewEncapsulation, OnInit, OnDestroy } from "@angular/core";
import { FormBuilder } from "@angular/forms";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { interval as observableInterval, Subject } from "rxjs";
import { takeUntil } from "rxjs/operators";
import { BarChart } from './../../../../../model/chartModel/barChart';
import { CarrierService } from "../../../../../Services/carrier.service";
import { CarrierbarChart } from "../carrier-chart.component";

@Component({
    selector: 'status-tab2',
    templateUrl: './status-tab2.component.html',
    styleUrls: [
        './status-tab2.component.scss',
        '../../../../components/ngxtable/material.scss',
        '../../../../components/ngxtable/datatable.component.scss',
        '../../../../components/ngxtable/icons.css',
        '../../../../components/ngxtable/app.css'
    ],
    encapsulation: ViewEncapsulation.None
})
export class StatusTab2Component implements OnInit, OnDestroy {

    readonly REFRESH_DATA_TIME_MS = 60000;

    public PCRFCOLUMS = [
        { name: 'template' },
        { name: 'orderType' },
        { name: 'count' },
        { name: 'status' }
    ];
    public pcrfStatusToShow = ['C', 'L', 'F', 'PR', 'QR', 'S'];
    private unsubscribe = new Subject<void>();
    public alerts: Array<any> = [];
    public pcrfRows = [];
    public pcrfChachedRows = [];
    public pcrfFilteredRows = [];
    public pcrfColumns = [];
    public barChartLabels = [];
    public barChartData = [];
    public showLoadingScreen: boolean;
    public pcrfReportDate: string;
    public pcrfReportSQL: string;
    public carrierPCRFCharts: CarrierbarChart[];

    public filterPCRFForm = this.fb.group({
        template: [[]],
        orderType: [[]],
        status: [[]]
    });
    public pcrfSumOfCounts: number;

    ngOnInit(): void {
        this.pcrfColumns = this.PCRFCOLUMS;
        this.getPCRFReportData();
        observableInterval(this.REFRESH_DATA_TIME_MS)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(val => {
                this.getPCRFReportData();
            });
    }
    /**
     * Unsubscribe from all Observable.
     */
    public ngOnDestroy() {
        this.unsubscribe.next();
        this.unsubscribe.complete();
    }
    /**
    * Load services and time picket configuration to be used.
    */
    constructor(
        private fb: FormBuilder,
        protected carrierService: CarrierService,
        protected modalService: NgbModal
    ) { }



    protected populatePCRFChart() {
        let carrierMap: Map<string, string[]> = new Map<string, string[]>();

        for (let i = 0; i < this.pcrfRows.length; i++) {
            let carrier = this.pcrfRows[i].template;

            if (carrier === null) continue;

            if (this.pcrfStatusToShow.indexOf(this.pcrfRows[i].status) === -1) continue;

            if (carrierMap.has(carrier)) {
                carrierMap.get(carrier).push(this.pcrfRows[i]);
            } else {
                carrierMap.set(carrier, [this.pcrfRows[i]]);
            }
        }

        const carrierArr = [];
        carrierMap.forEach((carrierValues: any[], carrierKey: string) => {
            let labels = [];
            let barInfo = [];

            for (let carrierRow of carrierValues) {
                let barLabel = carrierRow.orderType + '-' + carrierRow.status;
                barInfo.push({ data: [carrierRow.count], label: barLabel });
            }

            carrierArr.push(new CarrierbarChart(carrierKey, labels, barInfo));
        });

        this.carrierPCRFCharts = carrierArr;
    }

    private builBarDataAndLabel(data: string[], label: string): BarChart {
        let bar = new BarChart();
        bar.data = data;
        bar.label = label;
        return bar;
    }

    public getPCRFReportData(): void {
        this.showLoadingScreen = true;

        try {
            this.carrierService
                .getReportMonitorStatus("pcrf")
                .pipe(takeUntil(this.unsubscribe))
                .subscribe(
                    data => {
                        if(data[0].jsonResponse){
                            let monitorJsonResponse = data[0].jsonResponse;
                            this.pcrfRows = JSON.parse(monitorJsonResponse);
                            this.pcrfChachedRows = [...this.pcrfRows];
                            this.pcrfReportDate = data[0].createDate;
                            this.pcrfReportSQL = data[0].reportSQL;
                            this.populatePCRFChart();
                            this.generateFilters('pcrfFilteredRows', this.pcrfColumns, this.pcrfRows);
                            this.filterPCRFReportResults();
                            this.generatePCRFSumOfCounts();
                            this.successAlert('Transactions retrieved successfully.');
                        }else{
                            this.pcrfRows = [];
                            this.pcrfChachedRows = [...this.pcrfRows];
                            this.successAlert('No transactions found.');
                        }
                        this.showLoadingScreen = false;
                    },
                    (err: any) => {
                        this.failedAlert(err.error);
                        this.showLoadingScreen = false;
                    }
                );
        } catch (Exception) {
            this.failedAlert('Unable to retrieve transactions.');
            this.showLoadingScreen = false;
            this.pcrfRows = [];
            this.pcrfReportSQL = "Unable to load data."
        }
    }

    // grab values from the filters Form (each will be an array)
    // filter the rows in chart based on if the value for the key is in
    // the filter form object, if the filter array is empty return the entire row
    filterPCRFReportResults(): void {
        const filterFormObject = this.filterPCRFForm.value;
        const newRows = Object.keys(filterFormObject).reduce((acc, key) => {
            if (!filterFormObject[key].length) return acc;

            const filteredRows = acc.filter(val => filterFormObject[key].indexOf(val[key]) > -1);
            return filteredRows;
        }, this.pcrfChachedRows);

        this.pcrfRows = newRows;
    }

    generatePCRFSumOfCounts(): void {
        this.pcrfSumOfCounts = this.pcrfRows.reduce((num, obj) => num += Number(obj.count), 0);
    }

    // map column names to an array
    // then grab an arry of all the unique values available in the rows
    // this will populate the dropdowns for the select boxes on the graph
    public generateFilters(filteredRows, columns, rows): void {
        this[filteredRows] = Object.keys(columns)
            .map(i => columns[i].name)
            .reduce((filterObject, columnName) => {

                const uniqueValuesPerRow = rows.reduce((set, row) => set.add(row[columnName]), new Set());
                filterObject[columnName] = Array.from(uniqueValuesPerRow);
                return filterObject;
            }, {});
    }

    /**
     * Options to modify the looks of the bar chart.
     */
    public barChartOptions: any = {
        scaleShowVerticalLines: true,
        responsive: true,
        legend: { position: 'bottom', fullWidth: true },
        scales: {
            yAxes: [
                {
                    ticks: {
                        beginAtZero: true
                    }
                }
            ]
        }
    };

    /**
     * Opens the modal with the SQL that was used
     * to retrieve the report.
     */
    public viewSqlModal(content) {
        this.modalService.open(content, { size: 'lg' });
    }

    /**
     * Receives event of bar chart clicked.
     */
    public chartClicked(e: any): void { }

    public filterMonitorBarGraph() {
        //       this.populateChart(false, this.selectedTemplate, this.selectedOrderType, this.selectedTransType);
    }

    public closeAlert(alert: any) {
        const index: number = this.alerts.indexOf(alert);
        this.alerts.splice(index, 1);
    }

    public successAlert(successMsg: string) {
        this.alerts = [];
        this.alerts.push({
            id: 1,
            type: 'success',
            message: successMsg
        });
    }

    public warningAlert(warningMsg: string) {
        this.alerts = [];
        this.alerts.push({
            id: 3,
            type: 'warning',
            message: warningMsg
        });
    }

    public failedAlert(errorMsg: string) {
        this.alerts = [];
        this.alerts.push({
            id: 4,
            type: 'danger',
            message: errorMsg
        });
    }
}