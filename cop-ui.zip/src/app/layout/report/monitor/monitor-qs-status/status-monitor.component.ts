import { interval as observableInterval, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { Component, ViewEncapsulation, ViewChild, OnInit, OnDestroy } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { NgbModal, NgbTimeStruct, NgbTimepickerConfig, NgbTabset } from '@ng-bootstrap/ng-bootstrap';
import { routerTransition } from '../../../../router.animations';
import { AdminService } from './../../../../Services/admin.service';
import { CarrierService } from './../../../../Services/carrier.service';
import { BarChart } from './../../../../model/chartModel/barChart';
import { ReportResponse } from './../../../../model/reportModel/ReportResponse';
import { BaseChartDirective } from 'ng2-charts/ng2-charts';

import { CarrierbarChart } from './carrier-chart.component';
import { ColumnMode } from '@swimlane/ngx-datatable';
import { FormBuilder } from '@angular/forms';

@Component({
    selector: 'statusmonitor',
    templateUrl: './status-monitor.component.html',
    styleUrls: [
        './status-monitor.component.scss',
        '../../../components/ngxtable/material.scss',
        '../../../components/ngxtable/datatable.component.scss',
        '../../../components/ngxtable/icons.css',
        '../../../components/ngxtable/app.css'
    ],
    animations: [routerTransition()],
    encapsulation: ViewEncapsulation.None
})
export class StatusMonitorComponent implements OnInit, OnDestroy {
    @ViewChild("tabRef") tabs: NgbTabset;
    readonly REFRESH_DATA_TIME_MS = 60000;

    public COLUMS = [
        { name: 'template' },
        { name: 'transType' },
        { name: 'orderType' },
        { name: 'count' },
        { name: 'status' }
    ];

    ColumnMode = ColumnMode;

    public statusToShow = ['F', 'L', 'Q', 'TF', 'W', 'WP', 'CP'];

    private unsubscribe = new Subject<void>();
    public alerts: Array<any> = [];
    public rows = [];
    public cachedRows = [];
    public filteredRows = [];
    public columns = [];
    public barChartLabels = [];
    public barChartData = [];

    public showLoadingScreen: boolean;
    public reportDate: string;
    public reportSQL: string;

    public carrierCharts: CarrierbarChart[];
    public filterForm = this.fb.group({
        template: [[]],
        transType: [[]],
        orderType: [[]],
        status: [[]]
    });
    public sumOfCounts: number;
    /**
     * Load default values for page.
     */
    public ngOnInit() {
        this.carrierCharts = [];
        this.columns = this.COLUMS;
        this.getReportData();

        observableInterval(this.REFRESH_DATA_TIME_MS)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(val => {
                if (this.tabs.activeId == "ig")
                    this.getReportData();
            });
    }

    /**
     * Unsubscribe from all Observable.
     */
    public ngOnDestroy() {
        this.unsubscribe.next();
        this.unsubscribe.complete();
    }

    /**
     * Load services and time picket configuration to be used.
     */
    constructor(
        private fb: FormBuilder,
        protected carrierService: CarrierService,
        protected modalService: NgbModal
    ) { }

    protected populateChart() {
        let carrierMap: Map<string, string[]> = new Map<string, string[]>();

        for (let i = 0; i < this.rows.length; i++) {
            let carrier = this.rows[i].template + '-' + this.rows[i].transType;

            if (carrier === null) continue;

            if (this.statusToShow.indexOf(this.rows[i].status) === -1) continue;

            if (carrierMap.has(carrier)) {
                carrierMap.get(carrier).push(this.rows[i]);
            } else {
                carrierMap.set(carrier, [this.rows[i]]);
            }
        }

        const carrierArr = [];
        carrierMap.forEach((carrierValues: any[], carrierKey: string) => {
            let labels = [];
            let barInfo = [];

            for (let carrierRow of carrierValues) {
                let barLabel = carrierRow.orderType + '-' + carrierRow.status;
                barInfo.push({ data: [carrierRow.count], label: barLabel });
            }

            carrierArr.push(new CarrierbarChart(carrierKey, labels, barInfo));
        });

        this.carrierCharts = carrierArr;
    }

    private builBarDataAndLabel(data: string[], label: string): BarChart {
        let bar = new BarChart();
        bar.data = data;
        bar.label = label;
        return bar;
    }

    /**
     * Service request that subscribes to retrieve the report information.
     */
    public getReportData(): void {
        this.showLoadingScreen = true;

        try {
            this.carrierService
                .getReportMonitorStatus("ig")
                .pipe(takeUntil(this.unsubscribe))
                .subscribe(
                    data => {
                        if(data[0].jsonResponse){
                            let monitorJsonResponse = data[0].jsonResponse;
                            this.rows = JSON.parse(monitorJsonResponse);
                            this.rows = [...this.rows];
                            this.cachedRows = JSON.parse(monitorJsonResponse);
                            this.reportDate = data[0].createDate;
                            this.reportSQL = data[0].reportSQL;
                            this.populateChart();
                            this.generateFilters('filteredRows', this.columns, this.rows);
                            this.filterReportResults();
                            this.generateSumOfCounts();
                            this.successAlert('Transactions retrieved successfully.');
                        } else{
                            this.rows = [];
                            this.cachedRows = [];
                            this.successAlert('No transactions found.');
                        }
                        this.showLoadingScreen = false;
                    },
                    (err: any) => {
                        this.failedAlert(err.error);
                        this.showLoadingScreen = false;
                    }
                );
        } catch (Exception) {
            this.failedAlert('Unable to retrieve transactions.');
            this.showLoadingScreen = false;
            this.rows = [];
            this.reportSQL = "Unable to load data."
        }
    }

    // grab values from the filters Form (each will be an array)
    // filter the rows in chart based on if the value for the key is in
    // the filter form object, if the filter array is empty return the entire row
    filterReportResults(): void {
        const filterFormObject = this.filterForm.value;
        const newRows = Object.keys(filterFormObject).reduce((acc, key) => {
            if (!filterFormObject[key].length) return acc;

            const filteredRows = acc.filter(val => filterFormObject[key].indexOf(val[key]) > -1);
            return filteredRows;
        }, this.cachedRows);

        this.rows = newRows;
    }

    generateSumOfCounts(): void {
        this.sumOfCounts = this.rows.reduce((num, obj) => num += Number(obj.count), 0);
    }

    // map column names to an array
    // then grab an arry of all the unique values available in the rows
    // this will populate the dropdowns for the select boxes on the graph
    public generateFilters(filteredRows, columns, rows): void {
        this[filteredRows] = Object.keys(columns)
            .map(i => columns[i].name)
            .reduce((filterObject, columnName) => {

                const uniqueValuesPerRow = rows.reduce((set, row) => set.add(row[columnName]), new Set());
                filterObject[columnName] = Array.from(uniqueValuesPerRow);
                return filterObject;
            }, {});
    }

    /**
     * Options to modify the looks of the bar chart.
     */
    public barChartOptions: any = {
        scaleShowVerticalLines: true,
        responsive: true,
        legend: { position: 'bottom', fullWidth: true },
        scales: {
            yAxes: [
                {
                    ticks: {
                        beginAtZero: true
                    }
                }
            ]
        }
    };

    /**
     * Opens the modal with the SQL that was used
     * to retrieve the report.
     */
    public viewSqlModal(content) {
        this.modalService.open(content, { size: 'lg' });
    }

    /**
     * Receives event of bar chart clicked.
     */
    public chartClicked(e: any): void { }

    public filterMonitorBarGraph() {
        //       this.populateChart(false, this.selectedTemplate, this.selectedOrderType, this.selectedTransType);
    }

    public closeAlert(alert: any) {
        const index: number = this.alerts.indexOf(alert);
        this.alerts.splice(index, 1);
    }

    public successAlert(successMsg: string) {
        this.alerts = [];
        this.alerts.push({
            id: 1,
            type: 'success',
            message: successMsg
        });
    }

    public warningAlert(warningMsg: string) {
        this.alerts = [];
        this.alerts.push({
            id: 3,
            type: 'warning',
            message: warningMsg
        });
    }

    public failedAlert(errorMsg: string) {
        this.alerts = [];
        this.alerts.push({
            id: 4,
            type: 'danger',
            message: errorMsg
        });
    }

    changeTabs(event){
        if(event.nextId == "ig"){
            this.rows = [];
            this.cachedRows = [];
            this.getReportData();
            this.carrierCharts = [];
            this.alerts = [];
            this.filteredRows = [];
            let keys = Object.keys(this.filterForm.controls);
            keys.forEach(_e1 => {
                this.filterForm.controls[`${_e1}`].patchValue("");
            });
        }
    }
}