import { Component, ViewEncapsulation, OnInit, OnDestroy } from "@angular/core";
import { FormBuilder } from "@angular/forms";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { interval as observableInterval, Subject } from "rxjs";
import { takeUntil } from "rxjs/operators";
import { CarrierService } from "../../../../../Services/carrier.service";
import { CarrierbarChart } from "../carrier-chart.component";
import { BarChart } from './../../../../../model/chartModel/barChart';

@Component({
    selector: 'status-tab1',
    templateUrl: './status-tab1.component.html',
    styleUrls: [
        './status-tab1.component.scss',
        '../../../../components/ngxtable/material.scss',
        '../../../../components/ngxtable/datatable.component.scss',
        '../../../../components/ngxtable/icons.css',
        '../../../../components/ngxtable/app.css'
    ],
    encapsulation: ViewEncapsulation.None
})
export class StatusTab1Component implements OnInit, OnDestroy {

    readonly REFRESH_DATA_TIME_MS = 60000;

    public TTCOLUMS = [
        { name: 'template' },
        { name: 'orderType' },
        { name: 'count' },
        { name: 'status' }
    ];

    public ttStatusToShow = ['C', 'L', 'E', 'NT', 'Q', 'S', 'SS', 'W'];

    private unsubscribe = new Subject<void>();
    public alerts: Array<any> = [];
    public ttRows = [];
    public ttChachedRows = [];
    public ttFilteredRows = [];
    public ttColumns = [];
    public barChartLabels = [];
    public barChartData = [];
    public showLoadingScreen: boolean;
    public ttReportDate: string;
    public ttReportSQL: string;
    public carrierTTCharts: CarrierbarChart[];

    public ttSumOfCounts: number;
    public filterTTForm = this.fb.group({
        template: [[]],
        orderType: [[]],
        status: [[]]
    });

    constructor(private fb: FormBuilder,
        protected carrierService: CarrierService,
        protected modalService: NgbModal
    ) { }

    ngOnInit() {
        this.ttColumns = this.TTCOLUMS;
        this.getTTReportData();
        observableInterval(this.REFRESH_DATA_TIME_MS)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(val => {
                this.getTTReportData();
            });
    }
    /**
    * Unsubscribe from all Observable.
    */
    public ngOnDestroy() {
        this.unsubscribe.next();
        this.unsubscribe.complete();
    }

    protected populateTTChart() {
        let carrierMap: Map<string, string[]> = new Map<string, string[]>();

        for (let i = 0; i < this.ttRows.length; i++) {
            let carrier = this.ttRows[i].template;

            if (carrier === null) continue;

            if (this.ttStatusToShow.indexOf(this.ttRows[i].status) === -1) continue;

            if (carrierMap.has(carrier)) {
                carrierMap.get(carrier).push(this.ttRows[i]);
            } else {
                carrierMap.set(carrier, [this.ttRows[i]]);
            }
        }

        const carrierArr = [];
        carrierMap.forEach((carrierValues: any[], carrierKey: string) => {
            let labels = [];
            let barInfo = [];

            for (let carrierRow of carrierValues) {
                let barLabel = carrierRow.orderType + '-' + carrierRow.status;
                barInfo.push({ data: [carrierRow.count], label: barLabel });
            }

            carrierArr.push(new CarrierbarChart(carrierKey, labels, barInfo));
        });

        this.carrierTTCharts = carrierArr;
    }

    private builBarDataAndLabel(data: string[], label: string): BarChart {
        let bar = new BarChart();
        bar.data = data;
        bar.label = label;
        return bar;
    }

    /**
     * Service request that subscribes to retrieve the TT Status Monitor Report information.
     */
    public getTTReportData(): void {
        this.showLoadingScreen = true;

        try {
            this.carrierService
                .getReportMonitorStatus("tt")
                .pipe(takeUntil(this.unsubscribe))
                .subscribe(
                    data => {
                        if(data[0].jsonResponse){
                            let monitorJsonResponse = data[0].jsonResponse;
                            this.ttRows = JSON.parse(monitorJsonResponse);
                            this.ttChachedRows = [...this.ttRows];
                            this.ttReportDate = data[0].createDate;
                            this.ttReportSQL = data[0].reportSQL;
                            this.populateTTChart();
                            this.generateFilters('ttFilteredRows', this.ttColumns, this.ttRows);
                            this.filterTTReportResults();
                            this.generateTTSumOfCounts();
                            this.successAlert('Transactions retrieved successfully.');
                        }else{
                            this.ttRows = [];
                            this.ttChachedRows = [...this.ttRows];
                            this.successAlert('No transactions found.');
                        }
                        this.showLoadingScreen = false;
                    },
                    (err: any) => {
                        this.failedAlert(err.error);
                        this.showLoadingScreen = false;
                    }
                );
        } catch (Exception) {
            this.failedAlert('Unable to retrieve transactions.');
            this.showLoadingScreen = false;
            this.ttRows = [];
            this.ttReportSQL = "Unable to load data."
        }
    }

    // grab values from the filters Form (each will be an array)
    // filter the rows in chart based on if the value for the key is in
    // the filter form object, if the filter array is empty return the entire row
    filterTTReportResults(): void {
        const filterFormObject = this.filterTTForm.value;
        const newRows = Object.keys(filterFormObject).reduce((acc, key) => {
            if (!filterFormObject[key].length) return acc;

            const filteredRows = acc.filter(val => filterFormObject[key].indexOf(val[key]) > -1);
            return filteredRows;
        }, this.ttChachedRows);

        this.ttRows = newRows;
    }

    generateTTSumOfCounts(): void {
        this.ttSumOfCounts = this.ttRows.reduce((num, obj) => num = num + Number(obj.count), 0);
    }

    // map column names to an array
    // then grab an arry of all the unique values available in the rows
    // this will populate the dropdowns for the select boxes on the graph
    public generateFilters(filteredRows, columns, rows): void {
        this[filteredRows] = Object.keys(columns)
            .map(i => columns[i].name)
            .reduce((filterObject, columnName) => {

                const uniqueValuesPerRow = rows.reduce((set, row) => set.add(row[columnName]), new Set());
                filterObject[columnName] = Array.from(uniqueValuesPerRow);
                return filterObject;
            }, {});
    }

    /**
     * Options to modify the looks of the bar chart.
     */
    public barChartOptions: any = {
        scaleShowVerticalLines: true,
        responsive: true,
        legend: { position: 'bottom', fullWidth: true },
        scales: {
            yAxes: [
                {
                    ticks: {
                        beginAtZero: true
                    }
                }
            ]
        }
    };

    /**
     * Opens the modal with the SQL that was used
     * to retrieve the report.
     */
    public viewSqlModal(content) {
        this.modalService.open(content, { size: 'lg' });
    }

    /**
     * Receives event of bar chart clicked.
     */
    public chartClicked(e: any): void { }

    public filterMonitorBarGraph() {
        //       this.populateChart(false, this.selectedTemplate, this.selectedOrderType, this.selectedTransType);
    }

    public closeAlert(alert: any) {
        const index: number = this.alerts.indexOf(alert);
        this.alerts.splice(index, 1);
    }

    public successAlert(successMsg: string) {
        this.alerts = [];
        this.alerts.push({
            id: 1,
            type: 'success',
            message: successMsg
        });
    }

    public warningAlert(warningMsg: string) {
        this.alerts = [];
        this.alerts.push({
            id: 3,
            type: 'warning',
            message: warningMsg
        });
    }

    public failedAlert(errorMsg: string) {
        this.alerts = [];
        this.alerts.push({
            id: 4,
            type: 'danger',
            message: errorMsg
        });
    }
}