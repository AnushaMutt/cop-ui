import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from "@angular/forms";
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { ChartsModule as Ng2Charts } from 'ng2-charts';
import { StatusMonitorRoutingModule } from './status-monitor-routing.module';
import { StatusMonitorComponent } from './status-monitor.component';
import { PageHeaderModule } from './../../../../shared';


import { MatButtonModule,
         MatCheckboxModule,
         MatSelectModule,

         MatDatepickerModule,
         MatNativeDateModule,
         MatInputModule}
    from '@angular/material';
import { StatusTab1Component } from './status-tab1/status-tab1.component';
import { StatusTab2Component } from './status-tab2/status-tab2.component';
@NgModule({
  imports: [
    CommonModule,
    NgxDatatableModule,
    Ng2Charts,
    ReactiveFormsModule,
    MatSelectModule,
    StatusMonitorRoutingModule,
    NgbModule.forRoot(),
    FormsModule,
    PageHeaderModule,
    MatButtonModule, MatCheckboxModule,MatDatepickerModule, MatNativeDateModule, MatInputModule
  ],
  declarations: [StatusMonitorComponent,StatusTab1Component,StatusTab2Component]
})
export class ChartsModule { }
