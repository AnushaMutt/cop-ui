
import { takeUntil } from 'rxjs/operators';
import { Component, ViewEncapsulation, ViewChild, OnInit, OnDestroy } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { NgbModal, NgbTimeStruct, NgbTimepickerConfig } from '@ng-bootstrap/ng-bootstrap';
import { Subject } from "rxjs";
import { routerTransition } from '../../../../router.animations';
import { AdminService } from './../../../../Services/admin.service';
import { CarrierService } from './../../../../Services/carrier.service';
import { BarChart } from './../../../../model/chartModel/barChart';
import { ReportResponse } from './../../../../model/reportModel/ReportResponse';
import { BaseChartDirective } from 'ng2-charts/ng2-charts';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

@Component({
  selector: 'adhocmonitor',
  templateUrl: './adhoc-monitor.component.html',
  styleUrls: ['./adhoc-monitor.component.scss',
  			  '../../../components/ngxtable/material.scss', 
	  		  '../../../components/ngxtable/datatable.component.scss', 
	  		  '../../../components/ngxtable/icons.css', 
	  		  '../../../components/ngxtable/app.css'],
  animations: [routerTransition()],
  encapsulation: ViewEncapsulation.None
  })
export class AdhocMonitorComponent implements OnInit, OnDestroy {
 
    readonly DROPDOWN_OPTION_ALL = "ALL";
 
    public COLUMS =  [
      {name:  'xDate', prop:  'xDate'},
        {name:  'template', prop:  'template'},
        {name:  'orderType', prop:  'orderType'},
        {name:  'sumAllQ', prop:  'sumAllQ'},
        {name:  'sumAllL', prop:  'sumAllL'},
        {name:  'sumAllCP', prop:  'sumAllCp'},
        {name:  'sumAllWP', prop:  'sumAllWp'},
        {name:  'sumAllW', prop:  'sumAllW'},
        {name:  'sumAllS', prop:  'sumAllS'},
        {name:  'sumAllE', prop:  'sumAllE'},
        {name:  'sumAllF', prop:  'sumAllF'},
        {name:  'sumAllTf', prop:  'sumAllTf'},
        {name:  'sumAllHw', prop:  'sumAllHw'},
        {name:  'transType', prop:  'transType'},
    ];

    public TTCOLUMS =  [
        {name:  'xDate', prop:  'xDate'},
        {name:  'template', prop:  'carrier'},
        {name:  'orderType', prop:  'transType'},
        {name:  'transNum', prop:  'transNum'},
        {name:  'sumAllQ', prop:  'sumAllQ'},
        {name:  'sumAllL', prop:  'sumAllL'},
        {name:  'sumAllCP', prop:  'sumAllCp'},
        {name:  'sumAllS', prop:  'sumAllS'},
        {name:  'sumAllNT', prop:  'sumAllNt'},
        {name:  'sumAllE', prop:  'sumAllE'},
        {name:  'sumAllC', prop:  'sumAllC'},
        {name:  'sumAllTF', prop:  'sumAllTf'},
        {name:  'other', prop:  'sumOther'},
        {name:  'totalTransCount', prop:  'totalTransCount'},
        {name:  'totalTransSegment', prop:  'totalTransSegment'},
        {name:  'failureCount', prop:  'failureCount'},
        {name:  'comp11Min', prop:  'comp11Min'},
        {name:  'comp15Min', prop:  'comp15Min'},
        {name:  'comp30Min', prop:  'comp30Min'},
        {name:  'compGT30Min', prop:  'compGt30Min'},
      ];

      public PCRFCOLUMS =  [
        {name:  'xDate', prop:  'xDate'},
        {name:  'template', prop:  'pcrfParentName'},
        {name:  'orderType', prop:  'orderType'},
        {name:  'sumAllQ', prop:  'sumQ'},
        {name:  'sumAllL', prop:  'sumL'},
        {name:  'sumAllW', prop:  'sumW'},
        {name:  'sumAllS', prop:  'sumS'},
        {name:  'sumAllC', prop:  'sumC'},
        {name:  'sumAllF', prop:  'sumF'},
        {name:  'sumAllE', prop:  'sumE'},
        {name:  'sumOthers', prop:  'sumOthers'},
      ];
    
    @ViewChild(BaseChartDirective) chart: BaseChartDirective;
    
    private unsubscribe = new Subject<void>();
    public alerts: Array<any> = [];
    public rows = [];
    public ttRows :any =[];
    public columns =[];
    public ttColumns:any = [];
    public barChartLabels = []; 
    public barChartData=[];
    public ttBarChartLabels = []; 
    public ttBarChartData=[];
    public pcrfBarChartLabels = [];
    public pcrfBarChartData = [];
    
    public fromDateTime: NgbTimeStruct;
    public toDateTime: NgbTimeStruct;
    public searchTimeObject: any = { fromTime: {hour: "00", minute: "00", second: "00", error: false},  toTime: {hour: "00", minute: "00", second: "00", error: false}};    
    public dpFromCreateDate: any;
    public dpToCreateDate: any;
    
    public isSearchButtonDisabled;
    public showLoadingScreen: boolean;
    public showbarChartLegend: boolean;
    public showTTChartLegend: boolean;
    public showPcrfChartLegend: boolean;
    
    public reportDate:string; 
    public reportSQL:string;
    public reportTTSQL:string;

    public carrierTemplates = [];
    public carrierOrderTypes = [];
    public carrierTransTypes = [];

     public carrierTTCarrier :any = [];
     public carrierTTTransNum = [];
     public carrierTTTransTypes = [];

     public carrierPcrfParent = [];
     public carrierPcrfOrederType = [];
    
    public selectedOrderType: string;
    public selectedTemplate: string;
    public selectedTransType: string;
    public selectedTTTransNum: string;
    public selectedTTCarrier: string;
    public selectedTTTransType: string;
    public selectedPcrfParent: string;
    public selectedPcrfOrderType: string;

    public ttTableFrmGroupMain: FormGroup;
    public tableFrmGroupMain: FormGroup;
    public pcrfFrmGroupMain: FormGroup;
    public filteredTTValues: any = {};
    public filteredTTRows: any;
    public filteredValues: any = {};
    public filteredPcrfValues: any = {};
    public filteredPcrfRows: any; 
    public filteredRows: any;
    public ttMainRows: any =[]; 
    public mainRows: any =[]; 
    public transaction:string = 'ig'; 

    public pcrfrows = [];
    public pcrfMainRows : any = [];
    public pcrfcolumns =[];
    public pcrfreportDate:string;
    public pcrfreportSQL:string;
    public frmOrderTypes;
    
    /**
     * Load default values for page.
     */
    public ngOnInit(){
        this.createSearchForm();
        this.createTableForm();
        this.createMonitorTableForm();
        this.createPcrfTableForm();
        this.searchTimeObject.fromTime.error = false;
        this.searchTimeObject.toTime.error = false;
        this.carrierTemplates.push(this.DROPDOWN_OPTION_ALL);
        this.carrierOrderTypes.push(this.DROPDOWN_OPTION_ALL);
        this.carrierTransTypes.push(this.DROPDOWN_OPTION_ALL);
        
        this.selectedOrderType = this.DROPDOWN_OPTION_ALL;
        this.selectedTemplate = this.DROPDOWN_OPTION_ALL;
        this.selectedTransType = this.DROPDOWN_OPTION_ALL;

        this.carrierTTCarrier.push(this.DROPDOWN_OPTION_ALL);
        this.carrierTTTransNum.push(this.DROPDOWN_OPTION_ALL);
        this.carrierTTTransTypes.push(this.DROPDOWN_OPTION_ALL);
        
        this.selectedTTCarrier = this.DROPDOWN_OPTION_ALL;
        this.selectedTTTransType = this.DROPDOWN_OPTION_ALL;
        this.selectedTTTransNum = this.DROPDOWN_OPTION_ALL;

        this.carrierPcrfParent.push(this.DROPDOWN_OPTION_ALL);
        this.carrierPcrfOrederType.push(this.DROPDOWN_OPTION_ALL);
        
        this.selectedPcrfParent = this.DROPDOWN_OPTION_ALL;
        this.selectedPcrfOrderType = this.DROPDOWN_OPTION_ALL;
        
        this.isSearchButtonDisabled = false;
        this.showLoadingScreen = false;
        this.showbarChartLegend = true;
        this.showTTChartLegend = true;
        this.showPcrfChartLegend = true;
        this.columns = this.COLUMS;  
        this.ttColumns = this.TTCOLUMS; 
        this.pcrfcolumns = this.PCRFCOLUMS;
      }
    
    /**
     * Unsubscribe from all Observable.
     */
    public ngOnDestroy() {
        this.unsubscribe.next();
        this.unsubscribe.complete();
    }
    
    /**
     * Load services and time picket configuration to be used.
     */
    constructor(protected http: HttpClient, 
                protected adminService: AdminService,
                protected carrierService: CarrierService, 
                protected modalService: NgbModal,
                private timePickerConfig: NgbTimepickerConfig,
                private _formBuilder: FormBuilder,) {
        
            timePickerConfig.seconds = true;
            timePickerConfig.spinners = false;
    }

    //form for search
    public createSearchForm() {
        this.frmOrderTypes = this._formBuilder.group({
            type: ['', [Validators.required]],
            toDate: ["", [Validators.required]],
            fromDate: ["",[Validators.required]],
            fromTime: ["",],
            toTime: ["",],
        })
    }

    public revert(){
        this.frmOrderTypes.reset();
        this.searchTimeObject = { fromTime: {hour: "00", minute: "00", second: "00", error: false},  toTime: {hour: "00", minute: "00", second: "00", error: false}};            
        this.clearFields();
        this.frmOrderTypes.controls["type"].patchValue("ig");
    }

    public clearFields(){
        this.rows = [];
        this.mainRows = [];
        this.ttRows = [];
        this.ttMainRows = [];
        this.pcrfrows = [];
        this.pcrfMainRows = [];
        this.barChartData = [];
        this.ttBarChartData = [];
        this.pcrfBarChartData = [];
        this.selectedOrderType = this.DROPDOWN_OPTION_ALL;
        this.selectedTemplate = this.DROPDOWN_OPTION_ALL;
        this.selectedTransType = this.DROPDOWN_OPTION_ALL;        
        this.selectedTTCarrier = this.DROPDOWN_OPTION_ALL;
        this.selectedTTTransType = this.DROPDOWN_OPTION_ALL;
        this.selectedTTTransNum = this.DROPDOWN_OPTION_ALL;        
        this.selectedPcrfParent = this.DROPDOWN_OPTION_ALL;
        this.selectedPcrfOrderType = this.DROPDOWN_OPTION_ALL;
        this.alerts = [];
        this.searchTimeObject.fromTime.error = false;
        this.searchTimeObject.toTime.error = false;        
    }

    timeValueChange(obj, event, typeVal){
        if(event.ariaLabel == "Hours"){
            this[obj][typeVal].hour = event.value;
            this[obj][typeVal].error = true;
        }
        else if (event.ariaLabel == "Minutes"){
            this[obj][typeVal].minute = event.value;
            this[obj][typeVal].error = true;
        }
        else {
            this[obj][typeVal].second = event.value;
            this[obj][typeVal].error = true;
        }
        if(this[obj][typeVal].hour == "" && this[obj][typeVal].minute == "" && this[obj][typeVal].second == ""){
            this[obj][typeVal].error = false;
        }
    }

    //form for throttle
    public createTableForm() {
        this.ttTableFrmGroupMain = this._formBuilder.group({
            xDate: [''],
            carrier: [""],
            transType: [""],
            transNum: [""],
            sumAllQ: [""],
            sumAllL: [""],
            sumAllCp: [""],
            sumAllS: [""],
            sumAllNt: [''],
            sumAllE: [""],
            sumAllC: [""],
            sumAllTf: [""],
            sumOther: [""],
            totalTransCount: [""],
            totalTransSegment: [""],
            failureCount: [""],
            comp11Min: [''],
            comp15Min: [""],
            comp30Min: [""],
            compGt30Min: [""],
        });
    }

    //form for IG
    public createMonitorTableForm() {
        this.tableFrmGroupMain = this._formBuilder.group({
            xDate: [''],
            template: [""],
            orderType: [""],
            sumAllQ: [""],
            sumAllL: [""],
            sumAllCp: [""],
            sumAllWp: [''],
            sumAllW: [""],
            sumAllS: [""],
            sumAllE: [""],
            sumAllTf: [""],
            sumAllF: [""],
            sumAllHw: [""],
            transType: [""],
        });
    }

    //form for PCRF
    public createPcrfTableForm() {
        this.pcrfFrmGroupMain = this._formBuilder.group({
            xDate: [''],
            pcrfParentName: [""],
            orderType: [""],
            sumQ: [""],
            sumL: [""],
            sumW: [""],
            sumS: [""],
            sumC: [""],
            sumF: [""],
            sumE: [""],
            sumOthers: [""],
        });
    }

    public transactionChanged(event) {
        this.transaction = event.value;
    }

    // throttle column filter
    public filterTTReportResults(): void {
        const filterFormObject = this.ttTableFrmGroupMain.value;
        this.filteredTTValues.xDate = filterFormObject.xDate;
        this.filteredTTValues.carrier = filterFormObject.carrier;
        this.filteredTTValues.transType = filterFormObject.transType;
        this.filteredTTValues.transNum = filterFormObject.transNum;
        this.filteredTTValues.sumAllQ = filterFormObject.sumAllQ;
        this.filteredTTValues.sumAllL = filterFormObject.sumAllL;
        this.filteredTTValues.sumAllCp = filterFormObject.sumAllCp;
        this.filteredTTValues.sumAllS = filterFormObject.sumAllS;
        this.filteredTTValues.sumAllNt = filterFormObject.sumAllNt;
        this.filteredTTValues.sumAllE = filterFormObject.sumAllE;
        this.filteredTTValues.sumAllC = filterFormObject.sumAllC;
        this.filteredTTValues.sumAllTf = filterFormObject.sumAllTf;
        this.filteredTTValues.sumOther = filterFormObject.sumOther;
        this.filteredTTValues.totalTransCount = filterFormObject.totalTransCount;
        this.filteredTTValues.totalTransSegment = filterFormObject.totalTransSegment;
        this.filteredTTValues.failureCount = filterFormObject.failureCount;
        this.filteredTTValues.comp11Min = filterFormObject.comp11Min;
        this.filteredTTValues.comp15Min = filterFormObject.comp15Min;
        this.filteredTTValues.comp30Min = filterFormObject.comp30Min;
        this.filteredTTValues.compGt30Min = filterFormObject.compGt30Min;
        const newRows = Object.keys(filterFormObject).reduce((acc, key) => {
            if (!filterFormObject[key].length) return acc;
            const filteredTTRows = acc.filter(val => filterFormObject[key].indexOf(val[key]) > -1);
            return filteredTTRows;
        }, this.ttMainRows);

        this.ttRows = newRows;
    }

    public generateTTFilters(): void {
        this.filteredTTRows = Object.keys(this.TTCOLUMS)
            .map(i => this.TTCOLUMS[i].prop)
            .reduce((filterObject, columnName) => {
                const uniqueValuesPerRow = this.ttRows.reduce((set, row) => set.add(row[columnName]), new Set());
                let val:any = Array.from(uniqueValuesPerRow);
               if(!isNaN(Date.parse(val[0]))){
                    filterObject[columnName] = val.sort(function(date1, date2) {
                    date1 = new Date(date1);
                    date2 = new Date(date2);
                    if (date1 > date2) return 1;
                    if (date1 < date2) return -1;
                    })
                } else if( /^[0-9]*$/.test(val[0])){
                   filterObject[columnName] = val.sort(function(a,b){return a - b});
              }else{
                   filterObject[columnName] =val.sort((a, b) => {
                    a = a || '';
                    b = b || '';
                    return a.localeCompare(b);
                });                   
              }
                return filterObject;
            }, {});
    }

    // IG column filter
    public filterReportResults(): void {
        const filterFormObject = this.tableFrmGroupMain.value;
        this.filteredValues.xDate = filterFormObject.xDate;
        this.filteredValues.template = filterFormObject.template;
        this.filteredValues.orderType = filterFormObject.orderType;
        this.filteredValues.sumAllQ = filterFormObject.sumAllQ;
        this.filteredValues.sumAllL = filterFormObject.sumAllL;
        this.filteredValues.sumAllCp = filterFormObject.sumAllCp;
        this.filteredValues.sumAllWp = filterFormObject.sumAllWp;
        this.filteredValues.sumAllW = filterFormObject.sumAllW;         
        this.filteredValues.sumAllS = filterFormObject.sumAllS;
        this.filteredValues.sumAllE = filterFormObject.sumAllE;
        this.filteredValues.sumAllTf = filterFormObject.sumAllTf;
        this.filteredValues.sumAllF = filterFormObject.sumAllF;
        this.filteredValues.sumAllHw = filterFormObject.sumAllHw;
        this.filteredValues.transType = filterFormObject.transType;
        const newRows = Object.keys(filterFormObject).reduce((acc, key) => {
            if (!filterFormObject[key].length) return acc;
            const filteredRows = acc.filter(val => filterFormObject[key].indexOf(val[key]) > -1);
            return filteredRows;
        }, this.mainRows);

        this.rows = newRows;
    }

    public generateFilters(): void {
        this.filteredRows = Object.keys(this.COLUMS)
            .map(i => this.COLUMS[i].prop)
            .reduce((filterObject, columnName) => {
                const uniqueValuesPerRow = this.rows.reduce((set, row) => set.add(row[columnName]), new Set());
                let val:any = Array.from(uniqueValuesPerRow);
               if(!isNaN(Date.parse(val[0]))){
                    filterObject[columnName] = val.sort(function(date1, date2) {
                    date1 = new Date(date1);
                    date2 = new Date(date2);
                    if (date1 > date2) return 1;
                    if (date1 < date2) return -1;
                    })
                } else if( /^[0-9]*$/.test(val[0])){
                   filterObject[columnName] = val.sort(function(a,b){return a - b});
              }else{
                   filterObject[columnName] =val.sort((a, b) => {
                    a = a || '';
                    b = b || '';
                    return a.localeCompare(b);
                });                   
              }
                return filterObject;
            }, {});
    }

    // PCRF column filter
    public filterPcrfReportResults(): void {
        const filterFormObject = this.pcrfFrmGroupMain.value;
        this.filteredPcrfValues.xDate = filterFormObject.xDate;
        this.filteredPcrfValues.pcrfParentName = filterFormObject.pcrfParentName;
        this.filteredPcrfValues.orderType = filterFormObject.orderType;
        this.filteredPcrfValues.sumQ = filterFormObject.sumQ;
        this.filteredPcrfValues.sumL = filterFormObject.sumL;
        this.filteredPcrfValues.sumW = filterFormObject.sumW;
        this.filteredPcrfValues.sumS = filterFormObject.sumS;
        this.filteredPcrfValues.sumC = filterFormObject.sumC;         
        this.filteredPcrfValues.sumF = filterFormObject.sumF;
        this.filteredPcrfValues.sumE = filterFormObject.sumE;
        this.filteredPcrfValues.sumOthers = filterFormObject.sumOthers;
        const newRows = Object.keys(filterFormObject).reduce((acc, key) => {
            if (!filterFormObject[key].length) return acc;
            const filteredRows = acc.filter(val => filterFormObject[key].indexOf(val[key]) > -1);
            return filteredRows;
        }, this.pcrfMainRows);

        this.pcrfrows = newRows;
    }

    public generatePcrfFilters(): void {
        this.filteredPcrfRows = Object.keys(this.PCRFCOLUMS)
            .map(i => this.PCRFCOLUMS[i].prop)
            .reduce((filterObject, columnName) => {
                const uniqueValuesPerRow = this.pcrfrows.reduce((set, row) => set.add(row[columnName]), new Set());
                let val:any = Array.from(uniqueValuesPerRow);
               if(!isNaN(Date.parse(val[0]))){
                    filterObject[columnName] = val.sort(function(date1, date2) {
                    date1 = new Date(date1);
                    date2 = new Date(date2);
                    if (date1 > date2) return 1;
                    if (date1 < date2) return -1;
                    })
                } else if( /^[0-9]*$/.test(val[0])){
                   filterObject[columnName] = val.sort(function(a,b){return a - b});
              }else{
                   filterObject[columnName] =val.sort((a, b) => {
                    a = a || '';
                    b = b || '';
                    return a.localeCompare(b);
                });                   
              }
                return filterObject;
            }, {});
    }

    /**
     * Populates the chart graph with the retrieved information from the service. for IG
     */
    protected populateChart(loadFilters: boolean, filterTemplate?:string, filterOrderType?:string, filterTransType?:string){
              
        if(this.rows.length <= 0)
            return;
        
        this.barChartLabels = [];
        this.barChartData = [];
        
        let sumAllQ = [];
        let sumAllL = [];
        let sumAllCp = [];
        let sumAllW = [];
        let sumAllWp = [];
        let sumAllS = [];
        let sumAllE = [];
        let sumAllF = [];
        let sumAllTF = [];
        let sumAllHW = [];

        // Build a graph bar data for each template.
        for (var i = 0; i < this.rows.length; i++) {
            
            let carrierTemplate = this.rows[i].template;    
            let transType = this.rows[i].transType;     
            let orderType = this.rows[i].orderType;
            let xDate = this.rows[i].xDate;
         
            if(loadFilters){                
                // retrieve carrier templates and order types.
                if(this.carrierTemplates.indexOf(carrierTemplate) == -1)
                    this.carrierTemplates.push(carrierTemplate);

                if(this.carrierOrderTypes.indexOf(orderType) == -1)
                    this.carrierOrderTypes.push(orderType);   
                
                if(this.carrierTransTypes.indexOf(transType) == -1)
                    this.carrierTransTypes.push(transType);   
            }
        
            // Filter templates if requested.
            if(filterTemplate!=null && filterTemplate != this.DROPDOWN_OPTION_ALL){
                 if(filterTemplate != carrierTemplate)
                     continue;
            }
            
            // Filter order types if requested.
            if(filterOrderType!=null && filterOrderType != this.DROPDOWN_OPTION_ALL){
                if(filterOrderType != orderType)
                    continue;
            }
            
            // Filter transction type if requested.
            if(filterTransType!=null && filterTransType != this.DROPDOWN_OPTION_ALL){
                if(filterTransType != transType)
                    continue;
            }
            
            if(transType != 'SYS_TRANS')
                carrierTemplate = carrierTemplate + " ("+orderType+") - " + xDate;
            
            this.barChartLabels.push(carrierTemplate);
            
            if(this.rows[i].sumAllQ != "0")
                sumAllQ.push(this.rows[i].sumAllQ);
            if(this.rows[i].sumAllL != "0")
                sumAllL.push (this.rows[i].sumAllL);
            if(this.rows[i].sumAllCp != "0")
                sumAllCp.push(this.rows[i].sumAllCp);
            if(this.rows[i].sumAllW != "0")
                sumAllW.push (this.rows[i].sumAllW);
            if(this.rows[i].sumAllWp != "0")
                sumAllWp.push(this.rows[i].sumAllWp);
            if(this.rows[i].sumAllS != "0")
                sumAllS.push (this.rows[i].sumAllS);
            if(this.rows[i].sumAllE != "0")
                sumAllE.push (this.rows[i].sumAllE);
            if(this.rows[i].sumAllF != "0")
                sumAllF.push (this.rows[i].sumAllF);
            if(this.rows[i].sumAllTF != "0")
                sumAllTF.push (this.rows[i].sumAllTF);
            if(this.rows[i].sumAllHW != "0")
                sumAllHW.push (this.rows[i].sumAllHW);
        }
        
        this.barChartData.push(this.builBarDataAndLabel(sumAllQ, "Sum of all Q"));
        this.barChartData.push(this.builBarDataAndLabel(sumAllL, "Sum of all L"));
        this.barChartData.push(this.builBarDataAndLabel(sumAllCp, "Sum of all CP"));
        this.barChartData.push(this.builBarDataAndLabel(sumAllW, "Sum of all W"));
        this.barChartData.push(this.builBarDataAndLabel(sumAllWp, "Sum of all WP"));
        this.barChartData.push(this.builBarDataAndLabel(sumAllS, "Sum of all S"));
        this.barChartData.push(this.builBarDataAndLabel(sumAllE,"Sum of all E"));
        this.barChartData.push(this.builBarDataAndLabel(sumAllF, "Sum of all F"));
        this.barChartData.push(this.builBarDataAndLabel(sumAllTF, "Sum of all TF"));
        this.barChartData.push(this.builBarDataAndLabel(sumAllHW, "Sum of all HW"));
       
        // Hack to update chart labels when filtered.
        if(this.chart != null)
            this.chart.chart.config.data.labels = this.barChartLabels;
    }
    
    private builBarDataAndLabel(data: string[], label: string):BarChart{     
        let bar = new BarChart();
        bar.data = data;
        bar.label = label; 
        return bar;  
    }

    protected populateTTChart(loadFilters: boolean, filterCarrier?:string, filterTransNum?:string, filterTransType?:string){
              
        if(this.ttRows.length <= 0)
            return;
        
        this.ttBarChartLabels = [];
        this.ttBarChartData = [];
        
        let sumAllQ = [];
        let sumAllL = [];
        let sumAllCP = [];
        let sumAllS = [];
        let sumAllNT = [];
        let sumAllE = [];
        let sumAllC = [];
        let sumAllTF = [];
        let sumOther = [];
        let totalTransCount = [];
        let totalTransSegment = [];
        let failureCount = [];
        let comp11Min = [];
        let comp15Min = [];
        let comp30Min = [];
        let compGt30Min = [];

        // Build a graph bar data for each carrier.
        for (var i = 0; i < this.ttRows.length; i++) {
            
            let carrier = this.ttRows[i].carrier;    
            let transType = this.ttRows[i].transType;     
            let transNum = this.ttRows[i].transNum;
            let xDate = this.ttRows[i].xDate;
         
            if(loadFilters){                
                // retrieve carrier templates and order types.
                if(this.carrierTTCarrier.indexOf(carrier) == -1)
                    this.carrierTTCarrier.push(carrier);

                if(this.carrierTTTransTypes.indexOf(transType) == -1)
                    this.carrierTTTransTypes.push(transType);   
                
                if(this.carrierTTTransNum.indexOf(transNum) == -1)
                    this.carrierTTTransNum.push(transNum);   
            }
        
            // Filter templates if requested.
            if(filterCarrier!=null && filterCarrier != this.DROPDOWN_OPTION_ALL){
                 if(filterCarrier != carrier)
                     continue;
            }
            
            // Filter order types if requested.
            if(filterTransNum!=null && filterTransNum != this.DROPDOWN_OPTION_ALL){
                if(filterTransNum != transNum)
                    continue;
            }
            
            // Filter transction type if requested.
            if(filterTransType!=null && filterTransType != this.DROPDOWN_OPTION_ALL){
                if(filterTransType != transType)
                    continue;
            }
            
            if(transType != 'SYS_TRANS')
                carrier = carrier + " ("+transType+") - " + xDate;
            
            this.ttBarChartLabels.push(carrier);
            
            if(this.ttRows[i].sumAllQ != "0")
                sumAllQ.push(this.ttRows[i].sumAllQ);
            if(this.ttRows[i].sumAllL != "0")
                sumAllL.push (this.ttRows[i].sumAllL);
            if(this.ttRows[i].sumAllCp != "0")
                sumAllCP.push(this.ttRows[i].sumAllCp);
            if(this.ttRows[i].sumAllS != "0")
                sumAllS.push (this.ttRows[i].sumAllS);
            if(this.ttRows[i].sumAllNt != "0")
                sumAllNT.push(this.ttRows[i].sumAllNt);
            if(this.ttRows[i].sumAllE != "0")
                sumAllE.push (this.ttRows[i].sumAllE);
            if(this.ttRows[i].sumAllC != "0")
                sumAllC.push (this.ttRows[i].sumAllC);
            if(this.ttRows[i].sumAllTf != "0")
                sumAllTF.push (this.ttRows[i].sumAllTf);
            if(this.ttRows[i].sumOther != "0")
                sumOther.push (this.ttRows[i].sumOther);
            if(this.ttRows[i].totalTransCount != "0")
                totalTransCount.push (this.ttRows[i].totalTransCount);
            if(this.ttRows[i].totalTransSegment != "0")
                totalTransSegment.push (this.ttRows[i].totalTransSegment);
            if(this.ttRows[i].failureCount != "0")
                failureCount.push (this.ttRows[i].failureCount);
            if(this.ttRows[i].comp11Min != "0")
                comp11Min.push (this.ttRows[i].comp11Min);
            if(this.ttRows[i].comp15Min != "0")
                comp15Min.push (this.ttRows[i].comp15Min);
            if(this.ttRows[i].comp30Min != "0")
                comp30Min.push (this.ttRows[i].comp30Min);
            if(this.ttRows[i].compGt30Min != "0")
                compGt30Min.push (this.ttRows[i].compGt30Min);
        }
        
        this.ttBarChartData.push(this.builBarDataAndLabel(sumAllQ, "Sum of all Q"));
        this.ttBarChartData.push(this.builBarDataAndLabel(sumAllL, "Sum of all L"));
        this.ttBarChartData.push(this.builBarDataAndLabel(sumAllCP, "Sum of all CP"));
        this.ttBarChartData.push(this.builBarDataAndLabel(sumAllS, "Sum of all S"));        
        this.ttBarChartData.push(this.builBarDataAndLabel(sumAllNT, "Sum of all NT"));
        this.ttBarChartData.push(this.builBarDataAndLabel(sumAllE,"Sum of all E"));        
        this.ttBarChartData.push(this.builBarDataAndLabel(sumAllC, "Sum of all C"));
        this.ttBarChartData.push(this.builBarDataAndLabel(sumAllTF, "Sum of all TF"));        
        this.ttBarChartData.push(this.builBarDataAndLabel(sumOther, "Other"));
        this.ttBarChartData.push(this.builBarDataAndLabel(totalTransCount, "Total Trans Count"));
        this.ttBarChartData.push(this.builBarDataAndLabel(totalTransSegment, "Total Trans Segment"));
        this.ttBarChartData.push(this.builBarDataAndLabel(failureCount, "Failure Count"));
        this.ttBarChartData.push(this.builBarDataAndLabel(comp11Min, "Comp 11 Min"));
        this.ttBarChartData.push(this.builBarDataAndLabel(comp15Min, "Comp 15 Min"));
        this.ttBarChartData.push(this.builBarDataAndLabel(comp30Min, "Comp 30 Min"));
        this.ttBarChartData.push(this.builBarDataAndLabel(compGt30Min, "Comp GT 30 Min"));
       
        // Hack to update chart labels when filtered.
        if(this.chart != null)
            this.chart.chart.config.data.labels = this.ttBarChartLabels;
    }

    
protected populatePcrfChart(loadFilters: boolean, filterParent?:string, filterOrderType?:string){
              
        if(this.pcrfrows.length <= 0)
            return;
        
        this.pcrfBarChartLabels = [];
        this.pcrfBarChartData = [];
        
        let sumQ = [];
        let sumL = [];
        let sumW = [];
        let sumS = [];
        let sumC = [];
        let sumF = [];
        let sumE = [];
        let sumOthers = [];

        // Build a graph bar data for each carrier.
        for (var i = 0; i < this.pcrfrows.length; i++) {
            
            let parent = this.pcrfrows[i].pcrfParentName;    
            let transType = this.pcrfrows[i].orderType;     
            let xDate = this.pcrfrows[i].xDate;
         
            if(loadFilters){                
                // retrieve carrier templates and order types.
                if(this.carrierPcrfParent.indexOf(parent) == -1)
                    this.carrierPcrfParent.push(parent);

                if(this.carrierPcrfOrederType.indexOf(transType) == -1)
                    this.carrierPcrfOrederType.push(transType);    
            }
        
            // Filter templates if requested.
            if(filterParent!=null && filterParent != this.DROPDOWN_OPTION_ALL){
                 if(filterParent != parent)
                     continue;
            }
            
            // Filter order types if requested.
            if(filterOrderType!=null && filterOrderType != this.DROPDOWN_OPTION_ALL){
                if(filterOrderType != transType)
                    continue;
            }
            
            if(transType != 'SYS_TRANS')
                parent = parent + " ("+transType+") - " + xDate;
            
            this.pcrfBarChartLabels.push(parent);
            
            if(this.pcrfrows[i].sumQ != "0")
                sumQ.push(this.pcrfrows[i].sumQ);
            if(this.pcrfrows[i].sumL != "0")
                sumL.push (this.pcrfrows[i].sumL);
            if(this.pcrfrows[i].sumW != "0")
                sumW.push(this.pcrfrows[i].sumW);
            if(this.pcrfrows[i].sumS != "0")
                sumS.push (this.pcrfrows[i].sumS);
            if(this.pcrfrows[i].sumC != "0")
                sumC.push(this.pcrfrows[i].sumC);
            if(this.pcrfrows[i].sumF != "0")
                sumF.push (this.pcrfrows[i].sumF);
            if(this.pcrfrows[i].sumE != "0")
                sumE.push (this.pcrfrows[i].sumE);
            if(this.pcrfrows[i].sumOthers != "0")
                sumOthers.push (this.pcrfrows[i].sumOthers);
        }
        
        this.pcrfBarChartData.push(this.builBarDataAndLabel(sumQ, "Sum of all Q"));
        this.pcrfBarChartData.push(this.builBarDataAndLabel(sumL, "Sum of all L"));
        this.pcrfBarChartData.push(this.builBarDataAndLabel(sumW, "Sum of all W"));
        this.pcrfBarChartData.push(this.builBarDataAndLabel(sumS, "Sum of all S"));        
        this.pcrfBarChartData.push(this.builBarDataAndLabel(sumC, "Sum of all C"));
        this.pcrfBarChartData.push(this.builBarDataAndLabel(sumF,"Sum of all F"));        
        this.pcrfBarChartData.push(this.builBarDataAndLabel(sumE, "Sum of all E"));
        this.pcrfBarChartData.push(this.builBarDataAndLabel(sumOthers, "Sum of Others"));               
        // Hack to update chart labels when filtered.
        if(this.chart != null)
            this.chart.chart.config.data.labels = this.pcrfBarChartLabels;
    }

    /**
     * Send request to get monitor report with selected date.
     */
    public onSubmit(f){
        this.clearFields();
        
        if(!f.valid){
            this.warningAlert("Please select a date range before submitting request. ");
            return;
        }

        var fromDate = this.dpFromCreateDate;//this.controlDateToStringDate(f.value.dpFromCreateDate);
        var toDate = this.dpToCreateDate; //this.controlDateToStringDate(f.value.dpToCreateDate);
        
            if (this.searchTimeObject.fromTime) {
            try{
                let fromDateHour = this.searchTimeObject.fromTime.hour;
                let fromDateMins = this.searchTimeObject.fromTime.minute;
                let fromDateSecs = this.searchTimeObject.fromTime.second;               
                fromDate = fromDate + " " + fromDateHour + ":" + fromDateMins + ":" + fromDateSecs;
            }
            catch(exception){
                this.warningAlert("Unable to parse field (From Date). ");
                return;
            }
            }
            
            if (this.searchTimeObject.toTime) {
            try{
                let toDateHour = this.searchTimeObject.toTime.hour;
                let toDateMins = this.searchTimeObject.toTime.minute;
                let toDateSecs = this.searchTimeObject.toTime.second;
                toDate = toDate + " " + toDateHour + ":" + toDateMins + ":" + toDateSecs;
            }
            catch(exception){
                this.warningAlert("Unable to parse field (To Date). ");
                return;
            }
        }

        if (new Date(fromDate) > new Date(toDate)) {
            this.warningAlert("Please select From Create Date less than To Create Date before submitting request.");
            return;
        }

        if(this.transaction == 'ig'){
            this.getReportData(fromDate, toDate);
        } else if(this.transaction == 'tt'){
            this.getTTReportData(fromDate, toDate);
        } else if(this.transaction == 'pcrf'){
            this.getPcrfReportData(fromDate, toDate);
        }
    }

    /**
     * Service request that subscribes to retrieve the report information.
     */
   public getReportData(fromDate: string, toDate: string ): void{
       this.showLoadingScreen = true;
       
       try{
           this.carrierService.getAdhocReportMonitorQueue(fromDate, toDate, this.transaction).pipe(
               takeUntil(this.unsubscribe))  
               .subscribe(
 				      data => {
               
                            // Make sure we have a valid response.
                            if(data[0].jsonResponse === null || data[0].jsonResponse === undefined){
                                this.failedAlert("Unable to retrieve Report. Service error.");
                                this.showLoadingScreen = false;
                                return;
                            }    
               
                           let monitorJsonResponse = data[0].jsonResponse;
                           this.isSearchButtonDisabled = true;
                            this.rows = JSON.parse(monitorJsonResponse);
                            this.rows.forEach(e =>{
                                e.xDate = e.xDate.split(".")[0]
                              })
                            this.mainRows = [...this.rows];
                           this.reportDate = data[0].createDate;
                           this.reportSQL = data[0].reportSQL;                       
 				           this.populateChart(true);
                           this.showLoadingScreen = false;
                           this.isSearchButtonDisabled = false;
                           this.tableFrmGroupMain.controls["xDate"].patchValue([]);
                           this.tableFrmGroupMain.controls["template"].patchValue([]);
                           this.tableFrmGroupMain.controls["orderType"].patchValue([]);
                           this.tableFrmGroupMain.controls["sumAllQ"].patchValue([]);
                           this.tableFrmGroupMain.controls["sumAllL"].patchValue([]);
                           this.tableFrmGroupMain.controls["sumAllCp"].patchValue([]);
                           this.tableFrmGroupMain.controls["sumAllWp"].patchValue([]);
                           this.tableFrmGroupMain.controls["sumAllW"].patchValue([]);
                           this.tableFrmGroupMain.controls["sumAllS"].patchValue([]);
                           this.tableFrmGroupMain.controls["sumAllE"].patchValue([]);
                           this.tableFrmGroupMain.controls["sumAllTf"].patchValue([]);
                           this.tableFrmGroupMain.controls["sumAllF"].patchValue([]);
                           this.tableFrmGroupMain.controls["sumAllHw"].patchValue([]);
                           this.tableFrmGroupMain.controls["transType"].patchValue([]);
                           this.filteredValues = {};
                           this.generateFilters();
                           this.filterReportResults()
                              
                            if(this.rows.length > 0){
                                this.successAlert("Date range records retrieved successfully.");
                            }
                            else{
                                this.successAlert("No reports found for given date range.");    
                            }                              
 				        },
                        (err: any) => {   
                            this.failedAlert(err.error);
                            this.showLoadingScreen = false;
                            this.isSearchButtonDisabled = false;
                        }
 				      );
           }
       catch(Exception) {
           this.failedAlert("Unable to retrieve Report for given date range.");
           this.showLoadingScreen = false;
           this.isSearchButtonDisabled = false;
       }      
    }

    public getTTReportData(fromDate: string, toDate: string ): void{
       this.showLoadingScreen = true;
       
       try{
           this.carrierService.getAdhocReportMonitorQueue(fromDate, toDate, this.transaction).pipe(
               takeUntil(this.unsubscribe))  
               .subscribe(
 				      data => {
               
                            // Make sure we have a valid response.
                            if(data[0].jsonResponse === null || data[0].jsonResponse === undefined){
                                this.failedAlert("Unable to retrieve Report. Service error.");
                                this.showLoadingScreen = false;
                                return;
                            }    
               
                           let monitorJsonResponse = data[0].jsonResponse;
                           this.isSearchButtonDisabled = true;
                            this.ttRows = JSON.parse(monitorJsonResponse);
                            this.ttRows.forEach(e1 =>{
                                e1.xDate = e1.xDate.split(".")[0]
                              })
                            this.ttMainRows = [...this.ttRows];
                           this.reportDate = data[0].createDate;
                           this.reportTTSQL = data[0].reportSQL;                       
 				           this.populateTTChart(true);
                           this.showLoadingScreen = false;
                           this.isSearchButtonDisabled = false;
                            this.ttTableFrmGroupMain.controls["xDate"].patchValue([]);
                            this.ttTableFrmGroupMain.controls["carrier"].patchValue([]);
                            this.ttTableFrmGroupMain.controls["transType"].patchValue([]);
                            this.ttTableFrmGroupMain.controls["transNum"].patchValue([]);
                            this.ttTableFrmGroupMain.controls["sumAllQ"].patchValue([]);
                            this.ttTableFrmGroupMain.controls["sumAllL"].patchValue([]);
                            this.ttTableFrmGroupMain.controls["sumAllCp"].patchValue([]);
                            this.ttTableFrmGroupMain.controls["sumAllS"].patchValue([]);
                            this.ttTableFrmGroupMain.controls["sumAllNt"].patchValue([]);
                            this.ttTableFrmGroupMain.controls["sumAllE"].patchValue([]);
                            this.ttTableFrmGroupMain.controls["sumAllC"].patchValue([]);
                            this.ttTableFrmGroupMain.controls["sumAllTf"].patchValue([]);
                            this.ttTableFrmGroupMain.controls["sumOther"].patchValue([]);
                            this.ttTableFrmGroupMain.controls["totalTransCount"].patchValue([]);
                            this.ttTableFrmGroupMain.controls["totalTransSegment"].patchValue([]);
                            this.ttTableFrmGroupMain.controls["failureCount"].patchValue([]);
                            this.ttTableFrmGroupMain.controls["comp11Min"].patchValue([]);
                            this.ttTableFrmGroupMain.controls["comp15Min"].patchValue([]);
                            this.ttTableFrmGroupMain.controls["comp30Min"].patchValue([]);
                            this.ttTableFrmGroupMain.controls["compGt30Min"].patchValue([]);
                           this.filteredTTValues = {};
                           this.generateTTFilters();
                           this.filterTTReportResults();
                              
                            if(this.ttRows.length > 0){
                                this.successAlert("Date range records retrieved successfully.");
                            }
                            else{
                                this.successAlert("No reports found for given date range.");    
                            }                              
 				        },
                        (err: any) => {   
                            this.failedAlert(err.error);
                            this.showLoadingScreen = false;
                            this.isSearchButtonDisabled = false;
                        }
 				      );
           }
       catch(Exception) {
           this.failedAlert("Unable to retrieve Report for given date range.");
           this.showLoadingScreen = false;
           this.isSearchButtonDisabled = false;
       }      
    }

    public getPcrfReportData(fromDate: string, toDate: string ): void{
       this.showLoadingScreen = true;
       
       try{
           this.carrierService.getAdhocReportMonitorQueue(fromDate, toDate, this.transaction).pipe(
               takeUntil(this.unsubscribe))  
               .subscribe(
 				      data => {
               
                            // Make sure we have a valid response.
                            if(data[0].jsonResponse === null || data[0].jsonResponse === undefined){
                                this.failedAlert("Unable to retrieve Report. Service error.");
                                this.showLoadingScreen = false;
                                return;
                            }    
               
                           let monitorJsonResponse = data[0].jsonResponse;
                           this.isSearchButtonDisabled = true;
 				    	   this.pcrfrows = JSON.parse(monitorJsonResponse);
                            this.pcrfMainRows = [...this.pcrfrows];
                           this.pcrfreportDate = data[0].createDate;
                           this.pcrfreportSQL = data[0].reportSQL;                       
 				           this.populatePcrfChart(true);
                           this.showLoadingScreen = false;
                           this.isSearchButtonDisabled = false;
                            this.pcrfFrmGroupMain.controls["xDate"].patchValue([]);
                            this.pcrfFrmGroupMain.controls["pcrfParentName"].patchValue([]);
                            this.pcrfFrmGroupMain.controls["orderType"].patchValue([]);
                            this.pcrfFrmGroupMain.controls["sumQ"].patchValue([]);
                            this.pcrfFrmGroupMain.controls["sumL"].patchValue([]);
                            this.pcrfFrmGroupMain.controls["sumW"].patchValue([]);
                            this.pcrfFrmGroupMain.controls["sumS"].patchValue([]);
                            this.pcrfFrmGroupMain.controls["sumC"].patchValue([]);
                            this.pcrfFrmGroupMain.controls["sumF"].patchValue([]);
                            this.pcrfFrmGroupMain.controls["sumE"].patchValue([]);
                            this.pcrfFrmGroupMain.controls["sumOthers"].patchValue([]);
                           this.filteredPcrfValues = {};
                           this.generatePcrfFilters();
                           this.filterPcrfReportResults();
                              
                            if(this.pcrfrows.length > 0){
                                this.successAlert("Date range records retrieved successfully.");
                            }
                            else{
                                this.successAlert("No reports found for given date range.");    
                            }                              
 				        },
                        (err: any) => {   
                            this.failedAlert(err.error);
                            this.showLoadingScreen = false;
                            this.isSearchButtonDisabled = false;
                        }
 				      );
           }
       catch(Exception) {
           this.failedAlert("Unable to retrieve Report for given date range.");
           this.showLoadingScreen = false;
           this.isSearchButtonDisabled = false;
       }      
    }
    
    fromCreateDateClickEvent(type: string, event: any) {
        var controlDate = event.value.getUTCFullYear() + "/"  + (event.value.getMonth() + 1) +  "/" +  event.value.getDate();
        this.dpFromCreateDate = controlDate;
         
  }
    
     toCreateDateClickEvent(type: string, event: any) {
        var controlDate = event.value.getUTCFullYear() + "/"  + (event.value.getMonth() + 1) +  "/" +  event.value.getDate();
        this.dpToCreateDate = controlDate;
         
  }
   
    /**
     * Converts the java script object date from datepicker 
     * to a string formatted date YYYY-MM-DD. 
     */
    private controlDateToStringDate(controlDate: any): string{
        var formattedDate = "";
        
        try{
            if( controlDate != null){
                var year = controlDate.year;
                var month = controlDate.month;
                var day = controlDate.day;
            }
        }
        catch(Exception){
            return "";
        }
        
        // Format YYYY-MM-DD.
        if(year != null && month != null && day != null){
            formattedDate = year + "/" +  month + "/" + day;
        }
        
        return formattedDate;
    }
    
    /**
     * aligns the content of legend in chart 
     */
    private options: any = {         
        legend: { position: 'top'}
    }
      
    /**
     * Options to modify the looks of the bar chart.
     */
    public barChartOptions: any = {
        scaleShowVerticalLines: true,
        responsive: true,
        legend: { position: 'top'}
    };
    
    /**
     * Opens the modal with the SQL that was used 
     * to retrieve the report.
     */
    public viewSqlModal(content) {
        this.modalService.open(content, { size: 'lg' });
    }
    
   /**
    * Receives event of bar chart clicked.
    */
   public chartClicked(e: any): void {}


   public filterMonitorBarGraph(){
       this.populateChart(false, this.selectedTemplate, this.selectedOrderType, this.selectedTransType); 
   }

   public filterTTMonitorBarGraph(){
       this.populateTTChart(false, this.selectedTTCarrier, this.selectedTTTransNum, this.selectedTTTransType); 
   } 

   public filterPcrfMonitorBarGraph(){
       this.populatePcrfChart(false, this.selectedPcrfParent, this.selectedPcrfOrderType); 
   } 
    
    public closeAlert(alert: any) {
        const index: number = this.alerts.indexOf(alert);
        this.alerts.splice(index, 1);
    }

    public successAlert(successMsg: string) {
        this.alerts = [];
        this.alerts.push(
            {
                id: 1,
                type: 'success',
                message: successMsg
            }
        );
    }

    public warningAlert(warningMsg: string) {
        this.alerts = [];
        this.alerts.push(
            {
                id: 3,
                type: 'warning',
                message: warningMsg
            }
        );
    }

    public failedAlert(errorMsg: string) {
        this.alerts = [];
        this.alerts.push(
            {
                id: 4,
                type: 'danger',
                message: errorMsg
            }
        );
    }
}
