import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdhocMonitorComponent } from './adhoc-monitor.component';

const routes: Routes = [
	{
		path:'',
		component: AdhocMonitorComponent
	}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdhockMonitorRoutingModule { }
