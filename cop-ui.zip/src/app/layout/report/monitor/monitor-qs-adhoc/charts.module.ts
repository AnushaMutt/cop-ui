import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';

import { ChartsModule as Ng2Charts } from 'ng2-charts';
import { AdhockMonitorRoutingModule } from './adhoc-monitor-routing.module';
import { AdhocMonitorComponent } from './adhoc-monitor.component';
import { PageHeaderModule } from './../../../../shared';

import { MatButtonModule, 
         MatCheckboxModule, 
         MatDatepickerModule, 
         MatNativeDateModule, 
         MatInputModule,
        MatSelectModule} 
    from '@angular/material';

@NgModule({
  imports: [
    CommonModule,
    NgxDatatableModule,
    Ng2Charts,
    AdhockMonitorRoutingModule,
    NgbModule.forRoot(),
    FormsModule,
    PageHeaderModule,
    MatButtonModule, MatCheckboxModule,MatDatepickerModule, MatNativeDateModule,MatInputModule,MatSelectModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  declarations: [AdhocMonitorComponent]
})
export class ChartsModule { }
