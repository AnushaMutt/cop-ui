import { interval as observableInterval, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { Component, ViewEncapsulation, ViewChild, OnInit, OnDestroy } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { NgbModal, ModalDismissReasons, NgbTabset} from '@ng-bootstrap/ng-bootstrap';
import { routerTransition } from '../../../../router.animations';
import { AdminService } from './../../../../Services/admin.service';
import { CarrierService } from './../../../../Services/carrier.service';
import { ReportResponse } from './../../../../model/reportModel/ReportResponse';
import { FormBuilder, FormGroup } from "@angular/forms";
import { MatTabChangeEvent } from "@angular/material";
import { URLHandlerService } from './../../../../Services/urlhandler.service';

@Component({
  selector: 'chkbox-selection-template-demo',
  templateUrl: './monitor-qs.component.html',
  styleUrls: ['./monitor-qs.component.scss',
  			  '../../../components/ngxtable/material.scss', 
	  		  '../../../components/ngxtable/datatable.component.scss', 
	  		  '../../../components/ngxtable/icons.css', 
	  		  '../../../components/ngxtable/app.css'],
  animations: [routerTransition()],
  encapsulation: ViewEncapsulation.None
  })

export class MonitorQsComponent implements OnInit, OnDestroy {

    index = 0;
	readonly REFRESH_DATA_TIME_MS = 60000;
    public kibanareportlink = "";
	
    public COLUMS =  [
        {name:  'xDate', prop:  'xDate'},
        {name:  'template', prop:  'template'},
        {name:  'orderType', prop:  'orderType'},
        {name:  'sumAllQ', prop:  'sumAllQ'},
        {name:  'sumAllL', prop:  'sumAllL'},
        {name:  'sumAllCP', prop:  'sumAllCp'},
        {name:  'sumAllWP', prop:  'sumAllWp'},
        {name:  'sumAllW', prop:  'sumAllW'},
        {name:  'sumAllS', prop:  'sumAllS'},
        {name:  'sumAllE', prop:  'sumAllE'},
        {name:  'sumAllF', prop:  'sumAllF'},
        {name:  'sumAllTf', prop:  'sumAllTf'},
        {name:  'sumAllHw', prop:  'sumAllHw'},
        {name:  'transType', prop:  'transType'},
      ];

    private unsubscribe = new Subject<void>();
    public alerts: Array<any> = [];
    public rows = [];
    public columns =[];

    public showLoadingScreen: boolean;
    public reportDate:string; 
    public reportSQL:string;

    public tableFrmGroupMain: FormGroup;
    public pcrfFrmGroupMain: FormGroup;
    
    public filteredValues: any = {};
    public filteredRows: any;
    public mainRows: any =[];
    
    tab:number = 1;
    @ViewChild("tabRef") tabs: NgbTabset;
	
    ngOnInit(){
        this.showLoadingScreen = false;
        this.columns = this.COLUMS;
        
        
        this.createMonitorTableForm();
        
        this.getReportData();
                
		observableInterval(this.REFRESH_DATA_TIME_MS).pipe(
		takeUntil(this.unsubscribe))
        .subscribe((val) => { if(this.tabs.activeId == 'ig')
                this.getReportData();});
      }

      changeTabs(event){
        if(event.nextId == "ig"){
            this.rows = [];
            this.mainRows = [];
            this.getReportData();
            this.alerts = [];
            this.filteredRows = [];
            let keys = Object.keys(this.tableFrmGroupMain.controls);
            keys.forEach(_e1 => {
                this.tableFrmGroupMain.controls[`${_e1}`].patchValue("");
            });
        }
    }
    
    /**
     * Un-subscribe from all Observable.
     */
    public ngOnDestroy() {
        this.unsubscribe.next();
        this.unsubscribe.complete();
    }
    
    constructor(protected http: HttpClient, 
                protected adminService: AdminService,
                protected carrierService: CarrierService, 
                protected modalService: NgbModal,
                private _formBuilder: FormBuilder,
                private urlHandler: URLHandlerService) {
                    this.kibanareportlink = this.urlHandler.HTTP_URL_KIBANAMONITORREPORT;
                }

     
    //form for IG
    public createMonitorTableForm() {
        this.tableFrmGroupMain = this._formBuilder.group({
            xDate: [''],
            template: [""],
            orderType: [""],
            sumAllQ: [""],
            sumAllL: [""],
            sumAllCp: [""],
            sumAllWp: [''],
            sumAllW: [""],
            sumAllS: [""],
            sumAllE: [""],
            sumAllTf: [""],
            sumAllF: [""],
            sumAllHw: [""],
            transType: [""],
        });
    }
    
    public generateFilters(): void {
        this.filteredRows = Object.keys(this.COLUMS)
            .map(i => this.COLUMS[i].prop)
            .reduce((filterObject, columnName) => {
                const uniqueValuesPerRow = this.rows.reduce((set, row) => set.add(row[columnName]), new Set());
                let val:any = Array.from(uniqueValuesPerRow);
               if(!isNaN(Date.parse(val[0]))){
                    filterObject[columnName] = val.sort(function(date1, date2) {
                    date1 = new Date(date1);
                    date2 = new Date(date2);
                    if (date1 > date2) return 1;
                    if (date1 < date2) return -1;
                    })
                } else if( /^[0-9]*$/.test(val[0])){
                   filterObject[columnName] = val.sort(function(a,b){return a - b});
              }else{
                   filterObject[columnName] =val.sort((a, b) => {
                    a = a || '';
                    b = b || '';
                    return a.localeCompare(b);
                });
              }
                return filterObject;
            }, {});
    }

    // IG column filter
    public filterReportResults(): void {
        const filterFormObject = this.tableFrmGroupMain.value;
        this.filteredValues.xDate = filterFormObject.xDate;
        this.filteredValues.template = filterFormObject.template;
        this.filteredValues.orderType = filterFormObject.orderType;
        this.filteredValues.sumAllQ = filterFormObject.sumAllQ;
        this.filteredValues.sumAllL = filterFormObject.sumAllL;
        this.filteredValues.sumAllCp = filterFormObject.sumAllCp;
        this.filteredValues.sumAllWp = filterFormObject.sumAllWp;
        this.filteredValues.sumAllW = filterFormObject.sumAllW;
        this.filteredValues.sumAllS = filterFormObject.sumAllS;
        this.filteredValues.sumAllE = filterFormObject.sumAllE;
        this.filteredValues.sumAllTf = filterFormObject.sumAllTf;
        this.filteredValues.sumAllF = filterFormObject.sumAllF;
        this.filteredValues.sumAllHw = filterFormObject.sumAllHw;
        this.filteredValues.transType = filterFormObject.transType;
        const newRows = Object.keys(filterFormObject).reduce((acc, key) => {
            if (!filterFormObject[key].length) return acc;
            const filteredRows = acc.filter(val => filterFormObject[key].indexOf(val[key]) > -1);
            return filteredRows;
        }, this.mainRows);

        this.rows = newRows;
    }

    /**
     * Get monitor data from service.
     */
      public getReportData(): void{
          this.showLoadingScreen = true;
          
          try{
              this.carrierService.getReportMonitorQueue().pipe(
                  takeUntil(this.unsubscribe))
                  .subscribe(
				      data => {
				    	  if(data[0] === null || data[0] === undefined){
	                            this.showLoadingScreen = false;
	                            return;
                          }
                          if(data[0].jsonResponse){
                            let monitorJsonResponse = data[0].jsonResponse;
                            this.rows = JSON.parse(monitorJsonResponse);
                            this.rows.forEach(e =>{
                                e.xDate = e.xDate.split(".")[0]
                            })
                            this.rows = [...this.rows];
                            this.mainRows = [...this.rows];
                            this.reportDate = data[0].createDate;
                            this.reportSQL = data[0].reportSQL;
                            this.generateFilters();
                            this.filterReportResults();
                          }else{
                            this.rows = [];
                            this.mainRows = [...this.rows];
                            this.successAlert("No transactions found.");
                          }
                          this.showLoadingScreen = false;
				        },
                        (err: any) => {   
                            this.failedAlert(err.error);
                            this.showLoadingScreen = false;
                        }
			      );
          }
          catch(Exception) {
	    	  this.rows = [];
              this.reportSQL = "Unable to load data.";
              this.failedAlert("Unable to retrieve Report.");
          }
      }
  
      public refreshPage(){
    	  window.location.reload();
      }
      
      /**
       * Opens the modal with the SQL that was used 
       * to retrieve the report.
       */
      public viewSqlModal(content) {
          this.modalService.open(content, { size: 'lg' });
      }
      
      /**
       * Receives event of bar chart clicked.
       */
      public chartClicked(e: any): void {}
      
      public closeAlert(alert: any) {
          const index: number = this.alerts.indexOf(alert);
          this.alerts.splice(index, 1);
      }
      
      public successAlert(successMsg: string) {
          this.alerts = [];
          this.alerts.push(
              {
                  id: 1,
                  type: 'success',
                  message: successMsg
              }
          );
      }

      public warningAlert(warningMsg: string) {
          window.scrollTo(0,0);
          this.alerts = [];
          this.alerts.push(
              {
                  id: 3,
                  type: 'warning',
                  message: warningMsg
              }
          );
      }

      public failedAlert(errorMsg: string) {
          window.scrollTo(0,0);
          this.alerts = [];
          this.alerts.push(
              {
                  id: 4,
                  type: 'danger',
                  message: errorMsg
              }
          );
      }


}