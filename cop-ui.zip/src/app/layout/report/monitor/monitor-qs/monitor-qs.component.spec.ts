import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MonitorQsComponent } from './monitor-qs.component';

describe('MonitorQsComponent', () => {
  let component: MonitorQsComponent;
  let fixture: ComponentFixture<MonitorQsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MonitorQsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MonitorQsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
