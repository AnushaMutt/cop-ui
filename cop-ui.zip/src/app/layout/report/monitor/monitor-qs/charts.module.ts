import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MonitorQsRoutingModule } from './monitor-qs-routing.module';
import { MonitorQsComponent } from './monitor-qs.component';
import { PageHeaderModule } from './../../../../shared';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { ChartsModule as Ng2Charts } from 'ng2-charts';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { QsPCRFComponent } from './qs-pcrf-tab/qs-pcrf.component';
import { QsTTComponent } from './qs-tt-tab/qs-tt-component';
import { SafePipe } from './SafePipe.pipe'

import { MatButtonModule, 
         MatCheckboxModule, 
         MatDatepickerModule, 
         MatNativeDateModule, 
         MatInputModule,
        MatSelectModule}
    from '@angular/material';

@NgModule({
  imports: [
    CommonModule,
    NgxDatatableModule,
    Ng2Charts,
    MonitorQsRoutingModule,
    MatButtonModule, MatCheckboxModule,MatDatepickerModule, MatNativeDateModule,MatInputModule,MatSelectModule,
    NgbModule.forRoot(),
    PageHeaderModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  declarations: [MonitorQsComponent, QsTTComponent, QsPCRFComponent, SafePipe]
})
export class ChartsModule { }
