
import { interval as observableInterval, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { Component, ViewEncapsulation, OnInit, OnDestroy } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { routerTransition } from '../../../../../router.animations';
import { AdminService } from '../../../../../Services/admin.service';
import { CarrierService } from '../../../../../Services/carrier.service';
import { FormBuilder, FormGroup } from "@angular/forms";

@Component({
  selector: 'throttle-tab',
  templateUrl: './qs-tt-component.html',
  styleUrls: ['./qs-tt-component.scss',
    '../../../../components/ngxtable/material.scss',
    '../../../../components/ngxtable/datatable.component.scss',
    '../../../../components/ngxtable/icons.css',
    '../../../../components/ngxtable/app.css'],
  animations: [routerTransition()],
  encapsulation: ViewEncapsulation.None
})

export class QsTTComponent implements OnInit, OnDestroy {
  readonly REFRESH_DATA_TIME_MS = 60000;
  public TTCOLUMS = [
    { name: 'xDate', prop: 'xDate' },
    { name: 'template', prop: 'carrier' },
    { name: 'orderType', prop: 'transType' },
    { name: 'transNum', prop: 'transNum' },
    { name: 'sumAllQ', prop: 'sumAllQ' },
    { name: 'sumAllL', prop: 'sumAllL' },
    { name: 'sumAllCP', prop: 'sumAllCp' },
    { name: 'sumAllS', prop: 'sumAllS' },
    { name: 'sumAllNT', prop: 'sumAllNt' },
    { name: 'sumAllE', prop: 'sumAllE' },
    { name: 'sumAllC', prop: 'sumAllC' },
    { name: 'sumAllTF', prop: 'sumAllTf' },
    { name: 'other', prop: 'sumOther' },
    { name: 'totalTransCount', prop: 'totalTransCount' },
    { name: 'totalTransSegment', prop: 'totalTransSegment' },
    { name: 'failureCount', prop: 'failureCount' },
    { name: 'comp11Min', prop: 'comp11Min' },
    { name: 'comp15Min', prop: 'comp15Min' },
    { name: 'comp30Min', prop: 'comp30Min' },
    { name: 'compGT30Min', prop: 'compGt30Min' },
  ];

  private unsubscribe = new Subject<void>();
  public alerts: Array<any> = [];
  public showLoadingScreen: boolean;
  public ttrows = [];
  public ttcolumns = [];
  public ttreportDate: string;
  public ttreportSQL: string;
  public ttTableFrmGroupMain: FormGroup;
  public filteredTTValues: any = {};
  public filteredTTRows: any;
  public ttMainRows: any = [];

  ngOnInit() {
    this.showLoadingScreen = false;
    this.ttcolumns = this.TTCOLUMS;
    this.createTableForm();
    this.getTTReportData();

    observableInterval(this.REFRESH_DATA_TIME_MS).pipe(
      takeUntil(this.unsubscribe))
      .subscribe((val) => { this.getTTReportData(); });
  }

  /**
   * Un-subscribe from all Observable.
   */
  public ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }

  constructor(protected http: HttpClient,
    protected adminService: AdminService,
    protected carrierService: CarrierService,
    protected modalService: NgbModal,
    private _formBuilder: FormBuilder,) { }

  //form for throttle
  public createTableForm() {
    this.ttTableFrmGroupMain = this._formBuilder.group({
      xDate: [''],
      carrier: [""],
      transType: [""],
      transNum: [""],
      sumAllQ: [""],
      sumAllL: [""],
      sumAllCp: [""],
      sumAllS: [""],
      sumAllNt: [''],
      sumAllE: [""],
      sumAllC: [""],
      sumAllTf: [""],
      sumOther: [""],
      totalTransCount: [""],
      totalTransSegment: [""],
      failureCount: [""],
      comp11Min: [''],
      comp15Min: [""],
      comp30Min: [""],
      compGt30Min: [""],
    });
  }

  // throttle column filter
  public filterTTReportResults(): void {
    const filterFormObject = this.ttTableFrmGroupMain.value;
    this.filteredTTValues.xDate = filterFormObject.xDate;
    this.filteredTTValues.carrier = filterFormObject.carrier;
    this.filteredTTValues.transType = filterFormObject.transType;
    this.filteredTTValues.transNum = filterFormObject.transNum;
    this.filteredTTValues.sumAllQ = filterFormObject.sumAllQ;
    this.filteredTTValues.sumAllL = filterFormObject.sumAllL;
    this.filteredTTValues.sumAllCp = filterFormObject.sumAllCp;
    this.filteredTTValues.sumAllS = filterFormObject.sumAllS;
    this.filteredTTValues.sumAllNt = filterFormObject.sumAllNt;
    this.filteredTTValues.sumAllE = filterFormObject.sumAllE;
    this.filteredTTValues.sumAllC = filterFormObject.sumAllC;
    this.filteredTTValues.sumAllTf = filterFormObject.sumAllTf;
    this.filteredTTValues.sumOther = filterFormObject.sumOther;
    this.filteredTTValues.totalTransCount = filterFormObject.totalTransCount;
    this.filteredTTValues.totalTransSegment = filterFormObject.totalTransSegment;
    this.filteredTTValues.failureCount = filterFormObject.failureCount;
    this.filteredTTValues.comp11Min = filterFormObject.comp11Min;
    this.filteredTTValues.comp15Min = filterFormObject.comp15Min;
    this.filteredTTValues.comp30Min = filterFormObject.comp30Min;
    this.filteredTTValues.compGt30Min = filterFormObject.compGt30Min;
    const newRows = Object.keys(filterFormObject).reduce((acc, key) => {
      if (!filterFormObject[key].length) return acc;
      const filteredTTRows = acc.filter(val => filterFormObject[key].indexOf(val[key]) > -1);
      return filteredTTRows;
    }, this.ttMainRows);

    this.ttrows = newRows;
  }

  public generateTTFilters(): void {
    this.filteredTTRows = Object.keys(this.TTCOLUMS)
      .map(i => this.TTCOLUMS[i].prop)
      .reduce((filterObject, columnName) => {
        const uniqueValuesPerRow = this.ttrows.reduce((set, row) => set.add(row[columnName]), new Set());
        let val: any = Array.from(uniqueValuesPerRow);
        if (!isNaN(Date.parse(val[0]))) {
          filterObject[columnName] = val.sort(function (date1, date2) {
            date1 = new Date(date1);
            date2 = new Date(date2);
            if (date1 > date2) return 1;
            if (date1 < date2) return -1;
          })
        } else if (/^[0-9]*$/.test(val[0])) {
          filterObject[columnName] = val.sort(function (a, b) { return a - b });
        } else {
          filterObject[columnName] = val.sort((a, b) => {
            a = a || '';
            b = b || '';
            return a.localeCompare(b);
          });
        }
        return filterObject;
      }, {});
  }

  // to fetch tt monitor report data
  public getTTReportData(): void {
    this.showLoadingScreen = true;

    try {
      this.carrierService.getReportTTMonitorQueue().pipe(
        takeUntil(this.unsubscribe))
        .subscribe(
          data => {
            if (data[0] === null || data[0] === undefined) {
              this.showLoadingScreen = false;
              return;
            }if(data[0].jsonResponse){
              let monitorJsonResponse = data[0].jsonResponse;
              this.ttrows = JSON.parse(monitorJsonResponse);
              this.ttrows.forEach(e =>{
                e.xDate = e.xDate.split(".")[0]
              })
              this.ttMainRows = [...this.ttrows];
              this.ttreportDate = data[0].createDate;
              this.ttreportSQL = data[0].reportSQL;
              this.generateTTFilters();
              this.filterTTReportResults();
            }else{
              this.ttrows = [];
              this.ttMainRows = [...this.ttrows];
              this.successAlert("No transactions found.");
            }
            this.showLoadingScreen = false;
          },
          (err: any) => {
            this.failedAlert(err.error);
            this.showLoadingScreen = false;
          }
        );
    }
    catch (Exception) {
      this.ttrows = [];
      this.ttreportSQL = "Unable to load data.";
      this.failedAlert("Unable to retrieve Report.");
    }
  }

  public refreshPage() {
    window.location.reload();
  }

  /**
   * Opens the modal with the SQL that was used 
   * to retrieve the report.
   */
  public viewSqlModal(content) {
    this.modalService.open(content, { size: 'lg' });
  }

  /**
   * Receives event of bar chart clicked.
   */
  public chartClicked(e: any): void { }

  public closeAlert(alert: any) {
    const index: number = this.alerts.indexOf(alert);
    this.alerts.splice(index, 1);
  }

  public successAlert(successMsg: string) {
    this.alerts = [];
    this.alerts.push(
      {
        id: 1,
        type: 'success',
        message: successMsg
      }
    );
  }

  public warningAlert(warningMsg: string) {
    window.scrollTo(0, 0);
    this.alerts = [];
    this.alerts.push(
      {
        id: 3,
        type: 'warning',
        message: warningMsg
      }
    );
  }

  public failedAlert(errorMsg: string) {
    window.scrollTo(0, 0);
    this.alerts = [];
    this.alerts.push(
      {
        id: 4,
        type: 'danger',
        message: errorMsg
      }
    );
  }

}


