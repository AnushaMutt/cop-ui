
import { interval as observableInterval, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { Component, ViewEncapsulation, ViewChild, OnInit, OnDestroy } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { routerTransition } from '../../../../../router.animations';
import { AdminService } from '../../../../../Services/admin.service';
import { CarrierService } from '../../../../../Services/carrier.service';
import { ReportResponse } from '../../../../../model/reportModel/ReportResponse';
import { FormBuilder, FormGroup } from "@angular/forms";

@Component({
  selector: 'pcrf-tab',
  templateUrl: './qs-pcrf.component.html',
  styleUrls: ['./qs-pcrf.component.scss',
    '../../../../components/ngxtable/material.scss',
    '../../../../components/ngxtable/datatable.component.scss',
    '../../../../components/ngxtable/icons.css',
    '../../../../components/ngxtable/app.css'],
  animations: [routerTransition()],
  encapsulation: ViewEncapsulation.None
})

export class QsPCRFComponent implements OnInit, OnDestroy {
  readonly REFRESH_DATA_TIME_MS = 60000;
  public PCRFCOLUMS = [
    { name: 'xDate', prop: 'xDate' },
    { name: 'template', prop: 'pcrfParentName' },
    { name: 'orderType', prop: 'orderType' },
    { name: 'sumAllQ', prop: 'sumQ' },
    { name: 'sumAllL', prop: 'sumL' },
    { name: 'sumAllW', prop: 'sumW' },
    { name: 'sumAllS', prop: 'sumS' },
    { name: 'sumAllC', prop: 'sumC' },
    { name: 'sumAllF', prop: 'sumF' },
    { name: 'sumAllE', prop: 'sumE' },
    { name: 'sumOthers', prop: 'sumOthers' },
  ];

  private unsubscribe = new Subject<void>();
  public alerts: Array<any> = [];
  public showLoadingScreen: boolean;
  public pcrfrows = [];
  public pcrfMainRows: any = [];
  public pcrfcolumns = [];
  public pcrfreportDate: string;
  public pcrfreportSQL: string;
  public pcrfFrmGroupMain: FormGroup;
  public filteredPcrfValues: any = {};
  public filteredPcrfRows: any;

  ngOnInit() {
    this.pcrfcolumns = this.PCRFCOLUMS;
    this.createPcrfTableForm();
    this.getPCRFReportData();

    observableInterval(this.REFRESH_DATA_TIME_MS).pipe(
      takeUntil(this.unsubscribe))
      .subscribe((val) => { this.getPCRFReportData(); });
  }

  /**
   * Un-subscribe from all Observable.
   */
  public ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }

  constructor(protected http: HttpClient,
    protected adminService: AdminService,
    protected carrierService: CarrierService,
    protected modalService: NgbModal,
    private _formBuilder: FormBuilder,) { }


  //form for PCRF
  public createPcrfTableForm() {
    this.pcrfFrmGroupMain = this._formBuilder.group({
      xDate: [''],
      pcrfParentName: [""],
      orderType: [""],
      sumQ: [""],
      sumL: [""],
      sumW: [""],
      sumS: [""],
      sumC: [""],
      sumF: [""],
      sumE: [""],
      sumOthers: [""],
    });
  }

  // PCRF column filter
  public filterPcrfReportResults(): void {
    const filterFormObject = this.pcrfFrmGroupMain.value;
    this.filteredPcrfValues.xDate = filterFormObject.xDate;
    this.filteredPcrfValues.pcrfParentName = filterFormObject.pcrfParentName;
    this.filteredPcrfValues.orderType = filterFormObject.orderType;
    this.filteredPcrfValues.sumQ = filterFormObject.sumQ;
    this.filteredPcrfValues.sumL = filterFormObject.sumL;
    this.filteredPcrfValues.sumW = filterFormObject.sumW;
    this.filteredPcrfValues.sumS = filterFormObject.sumS;
    this.filteredPcrfValues.sumC = filterFormObject.sumC;
    this.filteredPcrfValues.sumF = filterFormObject.sumF;
    this.filteredPcrfValues.sumE = filterFormObject.sumE;
    this.filteredPcrfValues.sumOthers = filterFormObject.sumOthers;
    const newRows = Object.keys(filterFormObject).reduce((acc, key) => {
      if (!filterFormObject[key].length) return acc;
      const filteredRows = acc.filter(val => filterFormObject[key].indexOf(val[key]) > -1);
      return filteredRows;
    }, this.pcrfMainRows);

    this.pcrfrows = newRows;
  }

  public generatePcrfFilters(): void {
    this.filteredPcrfRows = Object.keys(this.PCRFCOLUMS)
      .map(i => this.PCRFCOLUMS[i].prop)
      .reduce((filterObject, columnName) => {
        const uniqueValuesPerRow = this.pcrfrows.reduce((set, row) => set.add(row[columnName]), new Set());
        let val: any = Array.from(uniqueValuesPerRow);
        if (!isNaN(Date.parse(val[0]))) {
          filterObject[columnName] = val.sort(function (date1, date2) {
            date1 = new Date(date1);
            date2 = new Date(date2);
            if (date1 > date2) return 1;
            if (date1 < date2) return -1;
          })
        } else if (/^[0-9]*$/.test(val[0])) {
          filterObject[columnName] = val.sort(function (a, b) { return a - b });
        } else {
          filterObject[columnName] = val.sort((a, b) => {
            a = a || '';
            b = b || '';
            return a.localeCompare(b);
          });
        }
        return filterObject;
      }, {});
  }

  // to fetch pcrf monitor report data
  public getPCRFReportData(): void {
    this.showLoadingScreen = true;

    try {
      this.carrierService.getReportPCRFMonitorQueue().pipe(
        takeUntil(this.unsubscribe))
        .subscribe(
          data => {
            if (data[0] === null || data[0] === undefined) {
              this.showLoadingScreen = false;
              return;
            }
            if(data[0].jsonResponse){
              let monitorJsonResponse = data[0].jsonResponse;
              this.pcrfrows = JSON.parse(monitorJsonResponse);
              this.pcrfMainRows = [...this.pcrfrows];
              this.pcrfreportDate = data[0].createDate;
              this.pcrfreportSQL = data[0].reportSQL;
              this.generatePcrfFilters();
              this.filterPcrfReportResults();
            }else{
              this.pcrfrows = [];
              this.pcrfMainRows = [...this.pcrfrows];
              this.successAlert("No transactions found.");
            }
            this.showLoadingScreen = false;
          },
          (err: any) => {
            this.failedAlert(err.error);
            this.showLoadingScreen = false;
          }
        );
    }
    catch (Exception) {
      this.pcrfrows = [];
      this.pcrfreportSQL = "Unable to load data.";
      this.failedAlert("Unable to retrieve Report.");
    }
  }

  public refreshPage() {
    window.location.reload();
  }

  /**
   * Opens the modal with the SQL that was used 
   * to retrieve the report.
   */
  public viewSqlModal(content) {
    this.modalService.open(content, { size: 'lg' });
  }

  /**
   * Receives event of bar chart clicked.
   */
  public chartClicked(e: any): void { }

  public closeAlert(alert: any) {
    const index: number = this.alerts.indexOf(alert);
    this.alerts.splice(index, 1);
  }

  public successAlert(successMsg: string) {
    this.alerts = [];
    this.alerts.push(
      {
        id: 1,
        type: 'success',
        message: successMsg
      }
    );
  }

  public warningAlert(warningMsg: string) {
    window.scrollTo(0, 0);
    this.alerts = [];
    this.alerts.push(
      {
        id: 3,
        type: 'warning',
        message: warningMsg
      }
    );
  }

  public failedAlert(errorMsg: string) {
    window.scrollTo(0, 0);
    this.alerts = [];
    this.alerts.push(
      {
        id: 4,
        type: 'danger',
        message: errorMsg
      }
    );
  }

}
