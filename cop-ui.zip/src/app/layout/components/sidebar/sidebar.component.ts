import { Component, OnInit, Input } from '@angular/core';
import { AdminService } from './../../../Services/admin.service';
import { UserGroup } from './../../../model/serviceModel/UserGroup';
import { UserProfile } from './../../../model/serviceModel/UserProfile';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
    selector: 'app-sidebar',
    templateUrl: './sidebar.component.html',
    styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent {
    @Input() open: boolean;

    isActive: boolean = false;
    showMenu: string = '';
    userProfile: UserProfile;

    constructor(private adminService: AdminService) {
        this.userProfile = new UserProfile(null, null, null);
    }

    ngOnInit() {
        let currentUser = JSON.parse(sessionStorage.getItem('currentUser'));

        //console.log("Sidebar user: " + (currentUser.userId));

        //TODO handle if userId is empty.
        this.getProfile(currentUser.userId);
    }

    getProfile(userId: number): void {
        this.adminService.getProfile().subscribe(
            userProfile => {
                this.userProfile = userProfile;
            },
            (err: HttpErrorResponse) => {
                if (err.error instanceof Error) {
                    //Client side/network error
                    //console.log("Layout error, client/netowork issue.");
                } else {
                    //Back-end service returned unsuccessful code.
                    //TODO route to DASHBOARD and display warning message.
                    //console.log(`Back-end Service error, client/netowork issue: returned code ${err.status}, body error: ${err.error}.`);
                }
            }
        );
    }

    addExpandClass(element: any) {
        if (element === this.showMenu) {
            this.showMenu = '0';
        } else {
            this.showMenu = element;
        }
    }
}
