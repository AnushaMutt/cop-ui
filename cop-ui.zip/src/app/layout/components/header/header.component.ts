import { Subject, interval } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { Component, OnInit, OnDestroy, Output, EventEmitter, ChangeDetectorRef } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { AuthService } from './../../../Services/auth.service';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit, OnDestroy {
    pushRightClass: string = 'push-right';
    username: String;
    countDownDate: any
    timerData: any

    @Output() toggleSideBarEvent: EventEmitter<boolean> = new EventEmitter();

    // Subject to handle subscription.
    private unsubscribe = new Subject<void>();

    constructor(public router: Router, private modalService: NgbModal, private authService: AuthService, private changeDetector: ChangeDetectorRef) {
        this.router.events.subscribe(val => {
            if (val instanceof NavigationEnd && window.innerWidth <= 992 && this.isToggled()) {
                this.toggleSidebar();
            }
        });
    }

    ngOnInit() {
        let currentUser = JSON.parse(sessionStorage.getItem(this.authService.LOCALSTORAGE_USER));

        if (currentUser == null) {
            this.onLoggedout();
        } else {
            this.username = currentUser.userName;
            this.getcountDownDate();
        }
    }

    //getting countDownDate
    getcountDownDate() {
        this.countDownDate = localStorage.getItem('startDate');
        if (this.countDownDate) {
            this.countDownDate = new Date(this.countDownDate);
        } else {
            this.countDownDate = new Date();
            localStorage.setItem('startDate', this.countDownDate);
        }
        this.setTimer();
    }

    setTimer() {
        this.timerData = setInterval(() => {
            // Get todays date and time
            let now = new Date().getTime();

            // Find the distance between now an the count down date
            let distance = now - this.countDownDate.getTime();

            // Time calculations for hours, minutes and seconds
            let hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            let minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            let seconds = Math.floor((distance % (1000 * 60)) / 1000);

            // Output the result in an element with id="timer"
            if (document.getElementById("timer"))
                document.getElementById("timer").innerHTML = " Logged in since " + "<span style='color:green;'>" + hours + "h " + minutes + "m " + seconds + "s " + "</span>";
        }, 1000);

    }

    stopTimer(){
        if (this.timerData) {
            clearInterval(this.timerData);
        }
    }
    /**
     * Unsubscribe from all Observable.
     */
    public ngOnDestroy() {
        this.unsubscribe.next();
        this.unsubscribe.complete();
        this.stopTimer();
    }

    isToggled(): boolean {
        const dom: Element = document.querySelector('body');
        return dom.classList.contains(this.pushRightClass);
    }

    public toggleSide(): void {
        this.toggleSideBarEvent.emit();
    }

    toggleSidebar() {
        const dom: any = document.querySelector('body');
        dom.classList.toggle(this.pushRightClass);
    }

    rltAndLtr() {
        const dom: any = document.querySelector('body');
        dom.classList.toggle('rtl');
    }

    goToProfile() {
        this.router.navigateByUrl('/dashboard');
    }
    //Modal for COP User Manual
    openLg(content) {
        this.modalService.open(content, { size: 'lg' });
    }

    /**
     * Logs out user by requesting the delete of the auth token and clearing all local session variable.s
     */
    public onLoggedout() {
        try {
            this.authService
                .logout()
                .pipe(takeUntil(this.unsubscribe))
                .subscribe(
                    data => {
                        let response = data[0];
                        if (this.timerData) {
                            clearInterval(this.timerData);
                        }
                    },
                    (err: HttpErrorResponse) => {
                        if (err.error instanceof Error) {
                            //console.log(`Service issue: returned code ${err.status}, body error: ${err.error}.`);
                        } else {
                            //console.log(`Back-end Service error, client/netowork issue: returned code ${err.status}, body error: ${err.error}.`);
                        }
                    }
                );
        } catch (exception) {
            //console.log("HTTP Call unable to process logout.");
        } finally {
            this.router.navigateByUrl('/login');
        }
    }
}
