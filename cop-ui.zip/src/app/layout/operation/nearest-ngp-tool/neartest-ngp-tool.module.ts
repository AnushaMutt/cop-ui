import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NearestNgpToolRoutingModule } from './neartest-ngp-tool-routing.module';
import { NearestNgpToolComponent } from './neartest-ngp-tool.component';

import { PageHeaderModule } from './../../../shared';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { FormsModule } from "@angular/forms";
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  imports: [
    CommonModule,
    NearestNgpToolRoutingModule,
    PageHeaderModule, 
    NgxDatatableModule,
    NgbModule.forRoot(),
    FormsModule
  ],
  declarations: [NearestNgpToolComponent]
})
export class NearestNgpToolComponentModule { }
