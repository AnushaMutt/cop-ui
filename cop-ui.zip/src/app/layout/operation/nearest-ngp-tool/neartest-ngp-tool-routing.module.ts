import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NearestNgpToolComponent } from './neartest-ngp-tool.component';

const routes: Routes = [
	{
		path: '',
	    component: NearestNgpToolComponent
	},
	{
		path: ':id',
	    component: NearestNgpToolComponent
	}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class NearestNgpToolRoutingModule { }
