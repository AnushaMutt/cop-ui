
import { Subject } from "rxjs";
import {takeUntil} from 'rxjs/operators';
import { Component, OnInit, ViewEncapsulation, ViewChild, OnDestroy} from '@angular/core';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { NgForm } from '@angular/forms';
import { routerTransition } from '../../../router.animations';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpErrorResponse, HttpClient } from '@angular/common/http';
import { OperationService } from './../../../Services/operation.service';
import { CarrierService } from './../../../Services/carrier.service';

@Component({
  selector: 'ngbd-datepicker-basic',
  templateUrl: './neartest-ngp-tool.component.html',
  styleUrls: ['./neartest-ngp-tool.component.scss',
              '../../components/ngxtable/material.scss', 
              '../../components/ngxtable/datatable.component.scss', 
              '../../components/ngxtable/icons.css', 
              '../../components/ngxtable/app.css'],
animations: [routerTransition()],
encapsulation: ViewEncapsulation.None
})
export class NearestNgpToolComponent implements OnInit, OnDestroy {

    public Distance = [
        { value: '25', display: '25 Miles' },
        { value: '15', display: '15 Miles' },
        { value: '10', display: '10 Miles' },
        { value: '5', display: '5 Miles'},
        { value: '3', display: '3 Miles' },
      ];
    
    COLUMS =  [
        {name:'zip'},
        {name:'zip2'},
        {name:'distance'},
        {name:'popcy'},
        {name:'pop05'},  
      ];
    
    rows = [];
    temp = [];
    columns =[];
    public zip: string;
    public dist: string;
    public alerts: Array<any> = [];
    public showLoadingScreen: boolean;
    private hideAlert: boolean;
    
    // Subject to handle subscription.
    private unsubscribe = new Subject<void>();
    
    @ViewChild(DatatableComponent) 
     table: DatatableComponent;
    
      constructor(
              private http: HttpClient, 
              private carrierService: CarrierService,
              private optService: OperationService) { }

      ngOnInit(){
      this.showLoadingScreen = false;
      this.hideAlert = false;    
      }
    
       /**
        * Unsubscribe from all Observable.
        */
       public ngOnDestroy() {
            this.unsubscribe.next();
            this.unsubscribe.complete();
        }
      
      getNgbToolColums():void{         
          this.columns = this.COLUMS;
      }

    getNgbToolDetails(sourcezip:string, distance:string):void{
          this.showLoadingScreen = true;
        try{
          this.optService.getNgbToolsDetailsJoined(sourcezip, distance).pipe(
              takeUntil(this.unsubscribe))  
              .subscribe(
                  data => {                  
                      this.rows = data[0];
                      this.temp = data[0];
                      this.getNgbToolColums();
                      this.showLoadingScreen = false;
                    },
                    (err: HttpErrorResponse) => {
                        if(err.error instanceof Error){
                            //Client side/network error
                            //console.log("Layout error, client/netowork issue.");
                            this.showLoadingScreen = false;
                            this.failedAlert("Failed to retrieve data. Please try again");
                            
                            setTimeout(function() {
                               this.hideAlert = true;
                               }.bind(this), 3000);
                        }
                        else{
                            //Back-end service returned unsuccessful code.
                            //TODO route to DASHBOARD and display warning message.
                            //console.log(`Back-end Service error, client/netowork issue: returned code ${err.status}, body error: ${err.error}.`);
                            this.showLoadingScreen = false;
                            this.failedAlert("Failed to retrieve data. Please try again");
                            
                            setTimeout(function() {
                               this.hideAlert = true;
                               }.bind(this), 3000);
                        }
                    }
                  );
            }
        catch(Exception) {
            //console.log("NgbTool Details Request Failed");
        }
        finally{
            
        }
    }
    
    onSubmit(f: NgForm) {
        
        //console.log("Is it valid" + f.valid );  
        if(f.valid){
            this.getNgbToolColums();
            this.getNgbToolDetails(f.value.sourcezip, f.value.distance);
           
        }
    }
    
    updateFilter(event) {
        const val = event.target.value.toLowerCase();
        //console.log("ZIP: " + val);

        // filter our data
        const temp = this.temp.filter(function(d) {
        	return d.zip2.indexOf(val) !== -1 || !val;
        });

        // update the rows
        this.rows = temp;
        // Whenever the filter changes, always go back to the first page
//        this.table.offset = 0;
    }
 
   toggle(col) {
    const isChecked = this.isChecked(col);

    if(isChecked) {
      this.columns = this.columns.filter(c => { 
        return c.name !== col.name; 
      });
    } else {
      this.columns = [...this.columns, col];
    }
  }

  isChecked(col) {
    return this.columns.find(c => {
      return c.name === col.name;
    });
  }
  
  onInput($event) {
    $event.preventDefault();
    //console.log('selected: ' + $event.target.value);
  }
    
  public closeAlert(alert: any) {
        const index: number = this.alerts.indexOf(alert);
        this.alerts.splice(index, 1);
    }
    
    private successAlert(successMsg:string){
        this.alerts.push(
            {
                id: 1,
                type: 'success',
                message: successMsg
            }
        );
    }
    
    private failedAlert(errorMsg:string){
        this.alerts.push(
            {
                id: 4,
                type: 'danger',
                message: errorMsg
            }
        );
    }
}
