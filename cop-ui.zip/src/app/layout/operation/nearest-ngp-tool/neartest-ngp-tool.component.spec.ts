import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NearestNgpToolComponent } from './neartest-ngb-tool.component';

describe('NearestNgpToolComponent', () => {
  let component: NearestNgpToolComponent;
  let fixture: ComponentFixture<NearestNgpToolComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NearestNgpToolComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NearestNgpToolComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
