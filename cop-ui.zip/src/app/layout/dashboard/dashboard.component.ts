import { Component, OnInit, ViewChild } from '@angular/core';
import { routerTransition } from '../../router.animations';
import { NgbModal, ModalDismissReasons, NgbTabset} from '@ng-bootstrap/ng-bootstrap';
import {MatAccordion} from '@angular/material/expansion';

@Component({
    selector: 'app-dashboard',
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.scss'],
    animations: [routerTransition()]
})
export class DashboardComponent implements OnInit {
    public alerts: Array<any> = [];
    @ViewChild("tabRef") tabs: NgbTabset;
    @ViewChild(MatAccordion) accordion: MatAccordion;
    newItems = [
            {'parent':'Micro-frontends', 'childrens':['Service Plan Wizard', 'View Aid', 'Retail Management View', 'User Inquiry',
        'View Users', 'User', 'View Actions', 'View Groups', 'Group', 'User Audit']},
            ];
    oldItems = [
                {
                    'title': 'Sprint 37',
                    'items': [
                        {'parent':'Micro-frontends', 'childrens':['Carrier Maintenance','Carrier Outage', 'Insert Transaction', 
                            'Carrier Zones Deployment']},
                        {'parent':'Carrier Maintenance Fixes', 'childrens':['NPANXX2 Carrier Zones', 'AR USA MARKET']}
                    ]
                },
                {
                    'title': 'Sprint 36',
                    'items': [
                        {'parent':'Micro-frontends', 'childrens':['Service Rate Plan Maintenance','Service Rate Plan View', 'Retail Management', 
                        'IG Carrier', 'IG Fail Logs', 'DB2Intergate View', 'Tracfone 360']},
                        {'parent':'DB2Intergate', 'childrens':['Wildcard search enabled on Templates']},
                        {'parent':'Carrier Outage', 'childrens':['Fixed data interchange issue in csv export file']},
                        {'parent':'User Inquiry', 'childrens':['Fixed the internal server error thrown for inactive lines']}
                    ]
                },
                {
                    'title': 'Sprint 35',
                    'items': [
                        {'parent':'Retail Management', 'childrens':['Export option for View-Traits data']},
                        {'parent':'View-Aid', 'childrens':['E_SIM_Flag added in Rework and Rework All screens','Additional Address fields added in Rework and Rework All screens','Option to copy field values in Rework and Rework All screens']},
                        {'parent':'Micro-frontends', 'childrens':['Throttle-Transactions','Carrier Zip2Tech']},
                    ]
                },
                {
                    'title': 'Sprint 34',
                    'items': [
                        {'parent':'Insert Transaction and Insert Wizard Enhancement', 'childrens':['Added E_SIM column in Insert transaction and Insert wizards']},
                        {'parent':'Micro-frontends', 'childrens':['Error','Not-Found','PCRF-Transactions','Insert-Wizard-History','Coverage-Map','Dashboard','Geocode']},
                    ]
                },
                {
                    'title': 'Sprint 33',
                    'items': [
                        {'parent':'Carrier Maintenance Enhancements', 'childrens':['Bulk Delete for AR_USA_POSTAL_ZIPS', 'Bulk Delete for AR_USA_MARKET', 'Bulk Delete for npanxx2carrierzones']},
                        {'parent':'Carrier Zones Enhancements', 'childrens':['Existing Zip codes']},
                        {'parent':'Geocoding', 'childrens':['Export map', 'Query carrier coverage based on X and Y values']},
                        {'parent':'Intergate Enhancement', 'childrens':['Option to Add new Configurations']}
                    ]
                },
                {
                    'title': 'Sprint 32',
                    'items': [
                        {'parent':'Carrier Maintenance Enhancements', 'childrens':['Maintenance screen for C_RTL_ZIP_GEOLOC', 'Maintenance screen for Carrierzones' , 'Bulk Insert & Export for AR_USA_POSTAL_ZIPS', 'Bulk Insert & Export for AR_USA_MARKET', 'Option to navigate to maintenance screen']},
                        {'parent':'Retail Tool Enhancements', 'childrens':['Sales View Report']},
                        {'parent':'View Aid', 'childrens':['Link to Kibana for Transaction ID']},
                        {'parent':'User Inquiry', 'childrens':['Bulk Inquiry']},
                        {'parent':'Intergate Enhancement', 'childrens':['Option to Add new Configurations']},
                        {'parent':'Insert Wizard & Insert Transaction Enhancement', 'childrens':['Option to choose another environment post insertion']},
                        {'parent':'Service RatePlan Maintenance Enhancement', 'childrens':['Option to choose X_DATA & Priority in Edit Linked Rateplan screen']},
                        {'parent':'Carrier Outage Enhancement', 'childrens':['Option to export search results']}
                ]},
                {
                    'title': 'Sprint 31',
                    'items': [
                        {'parent':'Retail', 'childrens':['Carrier Coverage API', 'Parent Store automatically closed']},
                        {'parent':'Carrier Maintenance', 'childrens':['npanxx2carrierzones', 'AR_USA_POSTAL_ZIPS', 'AR_USA_MARKET']},
                        {'parent':'View Aid', 'childrens':['Identify assigned Transactions']},
                        {'parent':'User Inquiry', 'childrens':['Validate SIM in Bulk for VRZ and TMO', 'Validate SIM TMO']},
                        {'parent':'IG Fail Logs Enhancements', 'childrens':[]}
                ]},
                {
                    'title': 'Sprint 30',
                    'items': [
                        {'parent':'IG Fail Logs', 'childrens':['Handling IG Fail Logs']},
                        {'parent':'Carrier Service Testing', 'childrens':['Tool for Intergate to trigger Carrier Notification/CallBacks']},
                        {'parent':'View Aid', 'childrens':['Prepopulating Transaction Ids when user moves from My Transaction to Manage Transaction', 'Handling Dynamic DB Column Updates']},
                        {'parent':'Retail Tool Enhancements', 'childrens':['Support for LTE in Sales View', 'Inactivate Parent automatically once all stores under it are closed']},
                        {'parent':'Zip2Tech Enhancements', 'childrens':['Provided option to Export search results in Zip2Tech and BPTech']},
                        {'parent':'Other Enhancements', 'childrens':['Option to access COP Confluence Page', 'Listing all the columns without horizontal scrollbar in ELRP update profile window', 'Prepopulating Bucket fields once user chooses a existing BucketId in Add Bucket and Add Child Bucket of RPA & ELRP screens', 'Accessing Kibana in COP Tool under MonitorQS reports']}
                ]},
                {
                    'title': 'Sprint 29',
                    'items': [
                        {'parent':'Throttle', 'childrens':['Add Notes to a Transaction']},
                        {'parent':'View Aid', 'childrens':['Support for status message regular expression', 'Link to Fail Logs']},
                        {'parent':'Geo Coder', 'childrens':['Find Address Locator']},
                        {'parent':'Zip2Tech Enhancements', 'childrens':['Option to bulk update zipcodes', 'Showing missed column X_PREF_PARENT']},
                        {'parent':'Carrier Zones Deployment', 'childrens':['Support for Claro carrier']},
                        {'parent':'Service Rateplan Maintenance Enhancement', 'childrens':['Support for Multiple delete of profile features', 'ELRP increasing profile window', 'Removing confirmation popups when we switch over tabs']}
                ]},
                {
                    'title': 'Sprint 28',
                    'items': [
                        {'parent':'Throttle', 'childrens':['Ability to Insert Throttle Transactions in SIT and TST']},
                        {'parent':'Insert Transactions', 'childrens':['Ability to retrieve Bucket information and pre-population in Insert transaction']},
                        {'parent':'Insert Wizard', 'childrens':['Ability to filter profile Ids using Features names', 'Ability to retain the selected profile id in Insert Wizard']},
                        {'parent':'Microfrontend', 'childrens':['COP Microfrontends - View Actions completed']}
                ]},
                {
                    'title': 'Sprint 27',
                    'items': [
                        {'parent':'Bulk Insert Transactions', 'childrens':['Network Registration  - All Carriers']},
                        {'parent':'Retail Management', 'childrens':['Edit and update Rank', 'View Last Trait run on parent', 'Summary Screen for Traits completed', 'Carrier Zones - Showing failure reason  (both Business and Technical reason ) for each record in the Summary step']},
                        {'parent':'Intergate 2.0', 'childrens':['New TMO Query Micro Service for Order Types  - UI,IDD,BI,VD,ITAC,RS']},
                        {'parent':'Carrier Maintenance', 'childrens':['Maintenance screen for CarrierSimPref']},
                        {'parent':'TMO TAAP Changes', 'childrens':['Changes for TMO COP Inquiry Microservice to use new TMO TAAP authentication']},
                        {'parent':'COP DashBoard', 'childrens':['New tab in Dashboard showing previous release and current release items']}
                ]},
                {
                    'title': 'Carrier Zones Emergency Fix',
                    'color': '#fff3cd',
                    'items': [
                        {'parent':'Carrier Zones Emergency Fix', 'childrens':['Fixed the issue while adding new carrier zones records for a zip and carrier combination']}
                ]},
                {
                    'title': 'Sprint 26',
                    'items': [
                        {'parent':'Insert IG Transaction', 'childrens':['Bulk Insert to support more columns', 'Ability to insert ESN details into Test OTA tables and Test ESN tables']}, 
                        {'parent':'Service Plan Maintenance','childrens':['Ability to delete Multi Rate Plan ESN using Bulk mode', 'Profile Description check']}, 
                        {'parent':'Carrier Maintenance COP Enhancements', 'childrens':['Maintenance Screen for TABLE_X_NOT_CERTIFY_MODELS']},
                        {'parent':'Retail Management', 'childrens':['Carrier Zones wizard ATT & TMOBILE', 'Bulk Update TMO_NGP_ZIP', 'ZIP2Tech updated the template']},
                ]}
               ];
    color = 'green';
    
    userName:string;
    userId:string;
    email:string;
    
    
    checked = false;
//    indeterminate = false;
//    labelPosition = 'after';
//    disabled = false;

    constructor() {}

    ngOnInit() {
    	let currentUser = JSON.parse(sessionStorage.getItem('currentUser')); 	
    	this.userName = currentUser.userName;
    	this.userId = currentUser.userId;
    	this.email = currentUser.email;
		setTimeout(() => {
			let animationElement = <HTMLSelectElement>document.getElementsByClassName('ninja')[0];
			if(animationElement){
				animationElement.style.animationPlayState='paused';
				animationElement.style.webkitAnimationPlayState='paused';
				animationElement.style.display='none';
			}
		}, 10000);
    }  

    changeTabs(event){
        if(event.nextId == "dashboard"){
			setTimeout(() => {
				let animationElement = <HTMLSelectElement>document.getElementsByClassName('ninja')[0];
				if(animationElement){
					animationElement.style.animationPlayState='paused';
					animationElement.style.webkitAnimationPlayState='paused';
					animationElement.style.display='none';
				}
			}, 10000);
        }
    }
}