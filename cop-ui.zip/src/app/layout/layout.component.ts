import { Component, OnInit } from '@angular/core';
import { Router, NavigationStart, NavigationEnd, NavigationCancel } from '@angular/router';

@Component({
    selector: 'app-layout',
    templateUrl: './layout.component.html',
    styleUrls: ['./layout.component.scss']
})
export class LayoutComponent implements OnInit {
    public open: boolean = true;
    public routing: boolean;

    constructor(private router: Router) {}

    ngOnInit() {
        this.router.events.subscribe(event => {
            if (event instanceof NavigationStart) {
                this.routing = true;
            } else if (event instanceof NavigationEnd || event instanceof NavigationCancel) {
                this.routing = false;
            }
        });
    }

    openCloseSideBar() {
        this.open = !this.open;
    }
}
