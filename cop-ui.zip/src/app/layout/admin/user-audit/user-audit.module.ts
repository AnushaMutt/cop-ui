import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbAlertModule } from '@ng-bootstrap/ng-bootstrap';
import { UserAuditComponent } from './user-audit.component';
import { UserAuditPageRoutingModule } from './user-audit-routing.module';
import { PageHeaderModule } from './../../../shared';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { FormsModule } from "@angular/forms";

@NgModule({
  imports: [CommonModule, UserAuditPageRoutingModule, PageHeaderModule, NgxDatatableModule,FormsModule, NgbAlertModule.forRoot()],
  declarations: [UserAuditComponent]
})
export class UserAuditModule { }
