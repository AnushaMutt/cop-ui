
import { takeUntil } from 'rxjs/operators';
import { Component, OnInit, ViewEncapsulation, ViewChild, Input, OnDestroy} from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { routerTransition } from '../../../router.animations';
import { ActivatedRoute } from '@angular/router';
import { NgForm } from '@angular/forms';
import { forkJoin, Subject, Observable } from "rxjs";
import { AuditService } from './../../../Services/audit.service';
import { DatatableComponent } from '@swimlane/ngx-datatable';

@Component({
  selector: 'app-useraudit',
  templateUrl: './user-audit.component.html',
  styleUrls: ['./user-audit.component.scss', 
	  		  '../../components/ngxtable/material.scss', 
	  		  '../../components/ngxtable/datatable.component.scss', 
	  		  '../../components/ngxtable/icons.css', 
	  		  '../../components/ngxtable/app.css'],
  animations: [routerTransition()],
  encapsulation: ViewEncapsulation.None
})

export class UserAuditComponent implements OnInit, OnDestroy  { 
    
    COLUMS =  [
        {name:'action'},
        {name:'createdDate'},
        {name:'details'},
        {name:'carrierid'},  
      ];
    
    rows = [];
    temp = [];
    columns =[];
    selected = [];
    
    public alerts: Array<any> = [];
    public showLoadingScreen: boolean;
    private hideAlert: boolean;
    
    // Subject to handle subscription.
    private unsubscribe = new Subject<void>();
    
    
    @ViewChild(DatatableComponent) 
     table: DatatableComponent;
    
      constructor(private route: ActivatedRoute,private auditService: AuditService) { }

      ngOnInit(){
          
      this.showLoadingScreen = false;
      this.hideAlert = false; 
      const userId = +this.route.snapshot.paramMap.get('id');
      this.getAuditDetails(userId);
            
      }
    
       /**
        * Unsubscribe from all Observable.
        */
       public ngOnDestroy() {
            this.unsubscribe.next();
            this.unsubscribe.complete();
        }
      
      getAuditColums():void{         
          this.columns = this.COLUMS;
      }
       
      /**
       * Retrieve the events the user has taken.
       */
      public getAuditDetails(userId: number):void{
        this.showLoadingScreen = true;
         try{
              this.auditService.getAuditDetailsJoined(userId).pipe(
                  takeUntil(this.unsubscribe))  
                  .subscribe(
                      data => {                  
                          this.rows = data[0];
                          this.temp = data[0];
                          this.getAuditColums();
                          this.showLoadingScreen = false;
                        },
        				(err: any) => {		
        					this.failedAlert(err.error);
        					this.showLoadingScreen = false;
        				}
                      );
             }
             catch(Exception) {
                 this.showLoadingScreen = false;
                 this.failedAlert("Failed to retrieve data. Please try again");
             }
    }
      
    onSelect({ selected }) {
        this.selected.splice(0, this.selected.length);
        this.selected.push(...selected);
      }

      onActivate(event) {
        //console.log('Activate Event', event);
      }

      add() {
        this.selected.push(this.rows[1], this.rows[3]);
      }

      update() {
        this.selected = [this.rows[1], this.rows[3]];
      }

      remove() {
        this.selected = [];
      }
    
    updateFilter(event) {
        const val = event.target.value.toLowerCase();

        const temp = this.temp.filter(function(d) {
            return d.action.toLowerCase().indexOf(val) !== -1 || !val;
        });

        // update the rows
        this.rows = temp;
    }
 
   toggle(col) {
    const isChecked = this.isChecked(col);

    if(isChecked) {
      this.columns = this.columns.filter(c => { 
        return c.name !== col.name; 
      });
    } else {
      this.columns = [...this.columns, col];
    }
  }

  isChecked(col) {
    return this.columns.find(c => {
      return c.name === col.name;
    });
  }
  
  onInput($event) {
    $event.preventDefault();
  }
    
  public closeAlert(alert: any) {
        const index: number = this.alerts.indexOf(alert);
        this.alerts.splice(index, 1);
    }
    
    private successAlert(successMsg:string){
    	this.alerts = [];
        this.alerts.push(
            {
                id: 1,
                type: 'success',
                message: successMsg
            }
        );
    }
    
    private failedAlert(errorMsg:string){
    	this.alerts = [];
        this.alerts.push(
            {
                id: 4,
                type: 'danger',
                message: errorMsg
            }
        );
    }
}