import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserAuditComponent } from './user-audit.component';

const routes: Routes = [
    {
        path: '',
        component: UserAuditComponent
    },
    {
        path: ':id',
        component: UserAuditComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class UserAuditPageRoutingModule {}
