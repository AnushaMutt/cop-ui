import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ViewActionsRoutingModule } from './view-actions-routing.module';
import { ViewActionsComponent } from './view-actions.component';
import { PageHeaderModule } from './../../../shared';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { NgbAlertModule } from '@ng-bootstrap/ng-bootstrap';
import { UsersbyactionDialogComponent } from './dialogs/usersbyaction-dialog/usersbyaction-dialog.component';

import { 
	MatButtonModule,
    MatExpansionModule,
    MatDialogModule
} 
from '@angular/material';

@NgModule({
  imports: [
    CommonModule,
    ViewActionsRoutingModule,
    NgxDatatableModule,
    PageHeaderModule,
    MatButtonModule, MatExpansionModule, MatDialogModule,
    NgbAlertModule.forRoot()
  ],
  declarations: [ViewActionsComponent, UsersbyactionDialogComponent],
  entryComponents: [UsersbyactionDialogComponent],
})
export class ViewActionsModule { }
