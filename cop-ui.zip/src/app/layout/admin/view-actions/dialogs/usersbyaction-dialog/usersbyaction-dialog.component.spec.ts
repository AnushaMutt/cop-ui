import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UsersbyactionDialogComponent } from './usersbyaction-dialog.component';

describe('UsersbyactionDialogComponent', () => {
  let component: UsersbyactionDialogComponent;
  let fixture: ComponentFixture<UsersbyactionDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UsersbyactionDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UsersbyactionDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
