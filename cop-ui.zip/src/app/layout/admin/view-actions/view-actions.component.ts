import { Subject } from "rxjs";
import { takeUntil } from 'rxjs/operators';
import { Component, OnInit,ViewChild, OnDestroy } from '@angular/core';
import { routerTransition } from '../../../router.animations';
import { ViewEncapsulation } from '@angular/core';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { AdminService } from './../../../Services/admin.service';
import { UserInfo } from './../../../model/serviceModel/UserInfo';

import { UsersbyactionDialogComponent } from './dialogs/usersbyaction-dialog/usersbyaction-dialog.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'chkbox-selection-template-demo',
  templateUrl: './view-actions.component.html',
  styleUrls: ['./view-actions.component.scss',
  			  '../../components/ngxtable/material.scss', 
	  		  '../../components/ngxtable/datatable.component.scss', 
	  		  '../../components/ngxtable/icons.css', 
	  		  '../../components/ngxtable/app.css'],
  animations: [routerTransition()],
  encapsulation: ViewEncapsulation.None
  })

export class ViewActionsComponent implements OnInit, OnDestroy {

 	public rows = [];
 	public temp = [];
 	public selected = [];
    public showLoadingScreen: boolean;
    public alerts: Array<any> = [];
    
    // Subject to handle subscription.
    private unsubscribe = new Subject<void>();

    @ViewChild(DatatableComponent) table: DatatableComponent;
    
	constructor(private http: HttpClient, private adminService: AdminService, public dialog: MatDialog) {}
    
    ngOnInit(){
        this.showLoadingScreen = false;
    	let currentUser = JSON.parse(sessionStorage.getItem('currentUser')); 	
    	this.getActions(currentUser.userId);
   }
    
    /**
	 * Unsubscribe from all Observable.
	 */
    public ngOnDestroy() {
        this.unsubscribe.next();
        this.unsubscribe.complete();
    }
    
    /**
     * Retrieves all active actions that are available to use.
     */
    public getActions(userId: string): void{
		  this.showLoadingScreen = true;
		  try{
		      this.adminService.getAllActions(userId).pipe(
		          takeUntil(this.unsubscribe))  
		          .subscribe(
		            (rows) => {
		                this.rows = rows, this.temp = rows
		                this.showLoadingScreen = false;
		            },
					(err: any) => {		
						this.failedAlert(err.error);
						this.showLoadingScreen = false;
					}
		        );
		      }
		  catch(Exception) {
				this.failedAlert("Unabled to retrieve actions.");
	      }
    }
    
    /**
     * Retrieves all users that have the selected action and displays them 
     * in a dialog box.
     */
    openUsersByActionDialog(actionId: string): void {
    	
        try{
		      this.adminService.getAllUsersWithAction(actionId).pipe(
		          takeUntil(this.unsubscribe))  
		          .subscribe(
	        	  data => {
                    this.showLoadingScreen = false;

                    if(data === null || data === undefined){
                        this.failedAlert("Unable to display users for this action. Service not available.");
                        return;
                    }
                    
                    let users = data;
                    
                    // Open Dialog to print carrier response.
                    const dialogRef = this.dialog.open(UsersbyactionDialogComponent, {
	                    /*width: this.DIALOG_PXWIDTH_CARRIERRESP,*/	                    	
	                    data: { usersWithAction: users }
	                    
	                 });
	
                    /*dialogRef.afterClosed().subscribe(result => {
	                   console.log("Result is : " + result);
	                 });*/
                    
                },
				(err: any) => {		
					this.failedAlert(err.error);
					this.showLoadingScreen = false;
				}
            );
        }
        catch(Exception){
            this.showLoadingScreen = false;
            this.failedAlert("Unable to retrieve users for selected action. Please try again");
        }
    }
    
    
    
    
    
//    public getAllUsersWithAction(row){
//		  this.showLoadingScreen = true;
//		  try{
//		      this.adminService.getAllUsersWithAction("30").pipe(
//		          takeUntil(this.unsubscribe))  
//		          .subscribe(
//		            (userListByAction) => {
//		                console.log("Response: " + userListByAction);
//		                this.showLoadingScreen = false;
//		            },
//					(err: any) => {		
//						this.failedAlert(err.error);
//						this.showLoadingScreen = false;
//					}
//		        );
//		      }
//		  catch(Exception) {
//				this.failedAlert("Unabled to retrieve actions.");
//	      }
//    }

    onSelect({ selected }) {
	    this.selected.splice(0, this.selected.length);
	    this.selected.push(...selected);
	  }

	  onActivate(event) {
	    // console.log('Activate Event', event);
	  }

	  add() {
	    this.selected.push(this.rows[1], this.rows[3]);
	  }

	  update() {
	    this.selected = [this.rows[1], this.rows[3]];
	  }

	  remove() {
	    this.selected = [];
	  }
	  
	  updateFilter(event) {
		    const val = event.target.value.toLowerCase();

		    // filter our data
		    const temp = this.temp.filter(function(d) {
		      return d.actionName.toLowerCase().indexOf(val) !== -1 || !val;
		    });

		    // update the rows
		    this.rows = temp;
		    // Whenever the filter changes, always go back to the first page
		    this.table.offset = 0;
	  }
	  
	    public closeAlert(alert: any) {
		    const index: number = this.alerts.indexOf(alert);
		    this.alerts.splice(index, 1);
	    }
	    
	    private successAlert(successMsg:string){
	    	this.alerts = [];
	        this.alerts.push(
	            {
	                id: 1,
	                type: 'success',
	                message: successMsg
	            }
	        );
	    }
	    
	    private failedAlert(errorMsg:string){
	    	this.alerts = [];
	        this.alerts.push(
	            {
	                id: 4,
	                type: 'danger',
	                message: errorMsg
	            }
	        );
	    }
}
