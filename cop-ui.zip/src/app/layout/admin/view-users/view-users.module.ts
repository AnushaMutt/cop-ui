import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ViewUsersRoutingModule } from './view-users-routing.module';
import { ViewUsersComponent } from './view-users.component';
import { PageHeaderModule } from './../../../shared';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { NgbAlertModule } from '@ng-bootstrap/ng-bootstrap';

import { MatButtonModule, 
         MatCheckboxModule, 
         MatDatepickerModule, 
         MatNativeDateModule, 
         MatInputModule} 
    from '@angular/material';

@NgModule({
  imports: [
    CommonModule,
    ViewUsersRoutingModule,
    NgxDatatableModule,
    PageHeaderModule,
    MatButtonModule, MatCheckboxModule,MatDatepickerModule, MatNativeDateModule,MatInputModule,
    NgbAlertModule.forRoot()
  ],
  declarations: [ViewUsersComponent]
})
export class ViewUsersModule { }
