
import { Subject } from "rxjs";
import { takeUntil } from 'rxjs/operators';
import { Component, OnInit,ViewChild, OnDestroy } from '@angular/core';
import { routerTransition } from '../../../router.animations';
import { ViewEncapsulation } from '@angular/core';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { AdminService } from './../../../Services/admin.service';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'chkbox-selection-template-demo',
  templateUrl: './view-users.component.html',
  styleUrls: ['./view-users.component.scss',
  			  '../../components/ngxtable/material.scss', 
	  		  '../../components/ngxtable/datatable.component.scss', 
	  		  '../../components/ngxtable/icons.css', 
	  		  '../../components/ngxtable/app.css'],
  animations: [routerTransition()],
  encapsulation: ViewEncapsulation.None
})

export class ViewUsersComponent implements OnInit, OnDestroy {

	rows = [];
	temp = [];
	selected = [];
    public alerts: Array<any> = [];
    public showLoadingScreen: boolean;
	private deleteUserResponse: string;
    private hideAlert: boolean;
    
    // Subject to handle subscription.
    private unsubscribe = new Subject<void>();
	
	@ViewChild(DatatableComponent) 
	table: DatatableComponent;
 
	constructor(private router: Router, private adminService: AdminService) {}
    
    ngOnInit(){
        this.showLoadingScreen = false;
        this.hideAlert = false;
    	this.getUsers();
    }
    
    /**
     * Unsubscribe from all Observable.
     */
    public ngOnDestroy() {
        this.unsubscribe.next();
        this.unsubscribe.complete();
    }
    
    /**
     * Retrieve list of users from service.
     */
    public getUsers(): void{
      this.showLoadingScreen = true;
      try{
          this.adminService.getAllUsers().pipe(
            takeUntil(this.unsubscribe))
            .subscribe(
                (rows) => {
                    this.rows = rows, this.temp = rows
                    this.showLoadingScreen = false;
                },
				(err: any) => {		
					this.failedAlert(err.error);
					this.showLoadingScreen = false;
				}
            );
          }
        catch(Exception) {
			this.failedAlert("Failed to load list of users.");
			this.showLoadingScreen = false;
      }
    }
    
    /**
     * Delete user request. 
     */
    public deleteUser(userId: string): void{
        this.showLoadingScreen = true;
        try{
            this.adminService.deleteUser(userId).pipe(
                takeUntil(this.unsubscribe))
                .subscribe(
                  (response) => {
                	  
                	// Reload updated list of users.
                    this.hideAlert = false;
                  	this.getUsers();
                	  
                      this.successAlert("User has been deleted successfully");   
                      this.showLoadingScreen=false;                 
                  },
  				(err: any) => {		
  					this.failedAlert(err.error);
  					this.showLoadingScreen = false;
  				}
              );
            }
        catch(Exception) {
			this.failedAlert("Failed to delete user.");
			this.showLoadingScreen = false;
        }
      }

	  onSelect({ selected }) {
	    this.selected.splice(0, this.selected.length);
	    this.selected.push(...selected);
	  }

	  onActivate(event) {
	    //console.log('Activate Event', event);
	  }

	  add() {
	    this.selected.push(this.rows[1], this.rows[3]);
	  }

	  update() {
	    this.selected = [this.rows[1], this.rows[3]];
	  }

	  remove() {
	    this.selected = [];
	  }
	  
	  updateFilter(event) {
		    const val = event.target.value.toLowerCase();

		    // filter our data
		    const temp = this.temp.filter(function(d) {
		      return d.userName.toLowerCase().indexOf(val) !== -1 || !val;
		    });

		    // update the rows
		    this.rows = temp;
		    // Whenever the filter changes, always go back to the first page
		    this.table.offset = 0;
	  }
	  
	  btnEditUser= function (row) {
        this.router.navigateByUrl('/user/' + row.userId);
	}
    
      btnAuditUser= function (row) {
        this.router.navigateByUrl('/user-audit/' + row.userId);
    }
	
	 btnDeleteUser= function (row) {
	  	
	  	if(confirm("Are you sure to delete user " + row.userName + "?")) {
	  		this.deleteUser(row.userId);
  		}
	}
    
    public closeAlert(alert: any) {
	    const index: number = this.alerts.indexOf(alert);
	    this.alerts.splice(index, 1);
    }
    
    private successAlert(successMsg:string){
    	this.alerts = [];
        this.alerts.push(
            {
                id: 1,
                type: 'success',
                message: successMsg
            }
        );
    }
    
    private failedAlert(errorMsg:string){
    	this.alerts = [];
        this.alerts.push(
            {
                id: 4,
                type: 'danger',
                message: errorMsg
            }
        );
    }
}
