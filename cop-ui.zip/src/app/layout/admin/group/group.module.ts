import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbAlertModule } from '@ng-bootstrap/ng-bootstrap';

import { GroupRoutingModule } from './group-routing.module';
import { GroupComponent } from './group.component';
//import { AlertComponent } from './alert.component';
import { PageHeaderModule } from './../../../shared';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { FormsModule } from "@angular/forms";

import { MatButtonModule, 
         MatCheckboxModule, 
         MatDatepickerModule, 
         MatNativeDateModule, 
         MatInputModule} 
    from '@angular/material';

@NgModule({
  imports: [
    CommonModule,
    GroupRoutingModule,
    PageHeaderModule, 
    NgxDatatableModule,
    FormsModule,
    MatButtonModule, MatCheckboxModule,MatDatepickerModule, MatNativeDateModule,MatInputModule,
    NgbAlertModule.forRoot()
  ],
  declarations: [GroupComponent]//AlertComponent]
})
export class GroupModule { }
