
import { Component, OnInit, ViewEncapsulation, ViewChild, OnDestroy} from '@angular/core';
import { takeUntil } from 'rxjs/operators';
import { ActivatedRoute } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import { routerTransition } from '../../../router.animations';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { AdminService } from './../../../Services/admin.service';
import { UserGroup } from './../../../model/serviceModel/UserGroup';
import { Subject } from "rxjs";

@Component({
  selector: 'app-group',
  templateUrl: './group.component.html',
  styleUrls: ['./group.component.scss',
  			  '../../components/ngxtable/material.scss', 
  			  '../../components/ngxtable/datatable.component.scss', 
  			  '../../components/ngxtable/icons.css', 
  			  '../../components/ngxtable/app.css'],
animations: [routerTransition()],
encapsulation: ViewEncapsulation.None
})
export class GroupComponent implements OnInit, OnDestroy {
	public alerts: Array<any> = [];
	rows = [];
	temp = [];
	selected = [];
	isReadOnly = true;
	  
	@ViewChild(DatatableComponent) 
	table: DatatableComponent;
	
	private newGroupRequested: boolean;
    public showLoadingScreen: boolean;
    private hideAlert: boolean;
	userGroup:UserGroup;
	groupName:string;
	groupDesc:string;
    
    // Subject to handle subscription.
    private unsubscribe = new Subject<void>();
	
	  constructor(private route: ActivatedRoute, private adminService: AdminService){
		  this.userGroup = new UserGroup();
	  }

	  ngOnInit() {	
		  this.showLoadingScreen = false;
          this.hideAlert = false;
		  let currentLoggedUser = JSON.parse(sessionStorage.getItem('currentUser'));
		  
		  const groupId = this.route.snapshot.paramMap.get('id');
		  const adminUserId = currentLoggedUser.userId;
		  
		  if(groupId){
			  this.newGroupRequested = false;
			  this.loadExistingGroupFields(groupId, adminUserId);
		  }
		  else{
			  this.newGroupRequested = true;
			  this.loadNewGroupFields(adminUserId);	 
		  }
	  }
    
        /**
         * Unsubscribe from all Observable.
         */
        public ngOnDestroy() {
            this.unsubscribe.next();
            this.unsubscribe.complete();
        }
    
	  /**
	   * Request the Group informations and all available actions for it.
	   */
	  public loadExistingGroupFields(groupId: string, adminUserId: string){
		   try{ 
               this.adminService.getGroupAndAvilableActions(groupId, adminUserId).pipe(
                   takeUntil(this.unsubscribe)) 
                   .subscribe(
    			      data => {
    			    	  this.userGroup = data[0];	
    			    	  this.rows = data[1];
    			    	  this.temp = data[1];
    			    	  this.buildGroupDisplayInfo();
    			        },
        				(err: any) => {		
        					this.failedAlert(err.error);
        					this.showLoadingScreen = false;
        				}
    			      );
               }
              catch(Exception) {
					this.failedAlert("Failed to load group information.");
					this.showLoadingScreen = false;
               }
	  }
	  
	  /**
	   * Request all available actions for a new group.
	   */
	  public loadNewGroupFields(adminUserId: string):void{
          try{
    		  this.adminService.getAllActions(adminUserId).pipe(
                  takeUntil(this.unsubscribe))
                  .subscribe(
    				(allActions) => {
    					this.rows = allActions, this.temp = allActions
					},
    				(err: any) => {		
    					this.failedAlert(err.error);
    					this.showLoadingScreen = false;
    				}
    			);
              }
          catch(Exception) {
				this.failedAlert("Failed to load group information.");
          }
	  }
	  
	  /**
	   * Build the page to display all information for the selected Group.
	   */
	  public buildGroupDisplayInfo():void{
		  this.groupName = this.userGroup.groupName;
		  this.groupDesc = this.userGroup.groupDescription;

		  if(!this.userGroup.tfActions)
			  return;
		  
			for(var i = 0; i < this.userGroup.tfActions.length;i++){			
			    for (var j = 0; j < this.rows.length;j++ ){
			        if((this.rows[j].actionId) === (this.userGroup.tfActions[i].actionId))
			        this.selected.push(this.rows[j]);
			    }   
		    }
	  }
	  
	    /**
	     * Receives the submit request to save user information.
	     */
		  public onSubmit(f: NgForm) {
			  
              this.showLoadingScreen = true;
			    let group = new UserGroup();
			    group.groupId = this.userGroup.groupId;
			    group.groupName = this.groupName;
			    group.groupDescription = this.groupDesc;
			    group.tfActions = this.selected;
			    
			    if(this.newGroupRequested){
			    	this.createGroup(group);
                }
			    else{
			    	this.updateGroup(group);
			    }
			    this.isReadOnly = true;
		  }
		  
		  /**
		   * Create group with information required.
		   */
		  public createGroup(group: UserGroup){
	            this.hideAlert = false;
	            try{ 
	    		    this.adminService.createGroup(group).pipe(
	                    takeUntil(this.unsubscribe))
	                    .subscribe(
	    			      data => {
	                          this.showLoadingScreen = false;
	                          this.successAlert("Group has been created successfully.");
	                          this.isReadOnly = true;
	    			        },
	        				(err: any) => {		
	        					this.failedAlert(err.error);
	        					this.showLoadingScreen = false;
	        				}
	    			      );
	                }
	          catch(Exception) {
					this.failedAlert("Failed to create group.");
					this.showLoadingScreen = false;
	            }
		  }
		
		  /**
		   * Update group with information provided.
		   */
		  public updateGroup(group: UserGroup){
	            this.hideAlert = false;
	            try{ 
	    		    this.adminService.updateGroup(group).pipe(
	                    takeUntil(this.unsubscribe))
	                    .subscribe(
	    			      data => {
	                          this.showLoadingScreen = false;
	    			    	  this.successAlert("Group has been updated successfully");
	                          this.isReadOnly = true;
	    			        },
	        				(err: any) => {		
	        					this.failedAlert(err.error);
	        					this.showLoadingScreen = false;
	        				}
	    			      );
	                }
	              catch(Exception) {
                      this.failedAlert("Failed to update group.");
                      this.showLoadingScreen = false;
                  }
		  }

	  onSelect({ selected }) {
	    this.selected.splice(0, this.selected.length);
	    this.selected.push(...selected);
	  }

	  onActivate(event) {
	    //console.log('Activate Event', event);
	  }

	  add() {
	    this.selected.push(this.rows[1], this.rows[3]);
	  }

	  update() {
	    this.selected = [this.rows[1], this.rows[3]];
	  }

	  remove() {
	    this.selected = [];
	  }
      
      cancel(): void {
        window.location.reload();
      }
      
	  updateFilter(event) {
		    const val = event.target.value.toLowerCase();

		    // filter our data
		    const temp = this.temp.filter(function(d) {
		      return d.actionName.toLowerCase().indexOf(val) !== -1 || !val;
		    });

		    // update the rows
		    this.rows = temp;
		    // Whenever the filter changes, always go back to the first page
		    this.table.offset = 0;
	  }
	  
	public closeAlert(alert: any) {
	    const index: number = this.alerts.indexOf(alert);
	    this.alerts.splice(index, 1);
	}
	
	private successAlert(successMsg:string){
		this.alerts = [];
		this.alerts.push(
            {
                id: 1,
                type: 'success',
                message: successMsg
            }
        );
	}
	
	private failedAlert(errorMsg:string){
		this.alerts = [];
        this.alerts.push(
            {
                id: 4,
                type: 'danger',
                message: errorMsg
            }
        );
	}
	
	public enableEditMode(){
		
		if(this.isReadOnly)
			this.isReadOnly = false;
		else
			this.isReadOnly = true;
	}

}
