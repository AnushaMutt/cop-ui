import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ViewGroupsRoutingModule } from './view-groups-routing.module';
import { ViewGroupsComponent } from './view-groups.component';
import { PageHeaderModule } from './../../../shared';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { NgbAlertModule } from '@ng-bootstrap/ng-bootstrap';

import { MatButtonModule, 
         MatCheckboxModule, 
         MatDatepickerModule, 
         MatNativeDateModule, 
         MatInputModule} 
    from '@angular/material';

@NgModule({
  imports: [
    CommonModule,
    ViewGroupsRoutingModule,
    NgxDatatableModule,
    PageHeaderModule,
    MatButtonModule, MatCheckboxModule,MatDatepickerModule, MatNativeDateModule,MatInputModule,
    NgbAlertModule.forRoot()
  ],
  declarations: [ViewGroupsComponent]
})
export class ViewGroupsModule { }
