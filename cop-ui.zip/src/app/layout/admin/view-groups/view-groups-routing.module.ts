import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ViewGroupsComponent} from './view-groups.component';

const routes: Routes = [
		{
		path:'',
		component: ViewGroupsComponent
		}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ViewGroupsRoutingModule { }
