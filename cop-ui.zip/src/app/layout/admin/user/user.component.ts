
import { Subscription, forkJoin, Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { Component, OnInit, ViewEncapsulation, ViewChild, Input, OnDestroy} from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { routerTransition } from '../../../router.animations';
import { ActivatedRoute } from '@angular/router';
import { NgForm } from '@angular/forms';

import { DatatableComponent } from '@swimlane/ngx-datatable';
import { AdminService } from './../../../Services/admin.service';
import { UserProfile } from './../../../model/serviceModel/UserProfile';
import { UserRole } from './../../../model/serviceModel/UserRole';
import { UserGroup } from './../../../model/serviceModel/UserGroup';
import { UserInfo } from './../../../model/serviceModel/UserInfo';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss', 
	  		  '../../components/ngxtable/material.scss', 
	  		  '../../components/ngxtable/datatable.component.scss', 
	  		  '../../components/ngxtable/icons.css', 
	  		  '../../components/ngxtable/app.css'],
  animations: [routerTransition()],
  encapsulation: ViewEncapsulation.None
})

export class UserComponent implements OnInit, OnDestroy {
	
	@ViewChild(DatatableComponent)
	table: DatatableComponent;
	
	public alerts: Array<any> = [];
	rows = [];
	temp = [];
	selected = [];
	roles:UserRole[];
	userProfile:UserProfile;

	private newUserRequested: boolean;
    public showLoadingScreen: boolean;
    private hideAlert: boolean;
    
    // Subject to handle subscription.
    private unsubscribe = new Subject<void>();
  
    isReadOnly = true;
	username: string;
	email: string;
    description: string;
	selectedRole:UserRole;
	setRoleAsUser : number ;
	constructor(private route: ActivatedRoute, private adminService: AdminService){  
		this.selectedRole= new UserRole(null, null, null);
	}
	  
	/**
	 * Checks if request came with a user ID (from manage user or create new user).
	 * If new user, only pull available roles and groups. If modify user, request
	 * user profile information.
	 */
	ngOnInit(){
        this.showLoadingScreen = false;
        this.hideAlert = false;
		let currentLoggedUser = JSON.parse(sessionStorage.getItem('currentUser'));
		
		const userId = +this.route.snapshot.paramMap.get('id');
		const adminUserId = currentLoggedUser.userId;
		
		if(userId){
			this.newUserRequested = false;
			this.loadExistingUserFields(adminUserId, userId);
		}
		else{	    	 	
			this.newUserRequested = true;
			this.loadNewUserFields(adminUserId);
		}
	}
    
    /**
     * Unsubscribe from all Observable.
     */
    public ngOnDestroy() {
        this.unsubscribe.next();
        this.unsubscribe.complete();
    }
	
	/**
	 * Loads available fields to create a new user.
	 */
	public loadNewUserFields(userId: number)
	{
        try{
    	    this.adminService.getRolesAndGroups(userId).pipe(
                takeUntil(this.unsubscribe))
                .subscribe(
    		      data => {
    			      this.roles = data[0];
    			      this.rows = data[1];
    			      this.temp = data[1];	
    			      
    			      if(this.roles.length > 0)
						  this.selectedRole = this.roles[0];
						  this.setRoleAsUser = this.roles[0].roleId;
    		        },
    				(err: any) => {		
    					this.failedAlert(err.error);
    				}				
    		      );
            }
        catch(Exception) {
        	this.failedAlert("Unabled to load fields.");
        }
	}
	
	/**
	 * Loads fields for an existing user in order to display it.
	 */
	loadExistingUserFields(adminUserId: number, userId: number)
	{	
        this.hideAlert = false;
        
        try{
    		this.adminService.getProfileRolesAndGroups(adminUserId, userId).pipe(
                takeUntil(this.unsubscribe))
                .subscribe(
    		      data => {
    				  this.userProfile = data[0];
    			      this.roles = data[1];
    			      this.rows = data[2];
    			      this.temp = data[2];
    			      this.buildProfile();
    			  		
    		        },
    				(err: any) => {
    					this.failedAlert(err.error);
    				}
    		      );
            }
        catch(Exception) {
			this.failedAlert("Error occured while preparing request.");
        }
	}
	
		
	/**
	 * Build the page to present the user's information from its profile.
	 */
	buildProfile():void{
		this.username = this.userProfile.tfUser.userName;
		this.email = this.userProfile.tfUser.email;
        this.description = this.userProfile.tfUser.description;
		this.selectedRole = this.userProfile.tfRole;
		
		// Pre-select groups already owned by user. 
		for(var i = 0; i < this.userProfile.tfGroups.length; i++){	
		    for (var j = 0; j < this.rows.length;j++ ){
		        if((this.rows[j].groupName) === (this.userProfile.tfGroups[i].groupName)){
		        	this.selected.push(this.rows[j]);
		        }
		    }   
	    }
	}
	
    /**
     * Receives the submit request to save user information.
     */
	 public onSubmit(f: NgForm) {
		  this.showLoadingScreen = true;  
		  let userInfo = new UserInfo();
		  userInfo.userName = this.username;
		  userInfo.email = this.email;
		  userInfo.description = this.description;
          
		  if(this.userProfile)
			  userInfo.userId = this.userProfile.tfUser.userId;
		  
		  let userProfile = new UserProfile(userInfo, this.selected, this.selectedRole);
		  
		  if(this.newUserRequested){
              //this.resetFormFields();
			  this.createUser(userProfile);
		  }
		  else{
			  this.updateUser(userProfile);
              this.isReadOnly = true;
		  }
	  }
	  
	  /**
	   * Service call to create user.
	   */
	 public createUser(userProfile: UserProfile){
          this.hideAlert = false;
          try{
    		  this.adminService.createUser(userProfile).pipe(
                  takeUntil(this.unsubscribe))  
                  .subscribe(
    			      data => {    	  
                          this.isReadOnly = true;
                          this.successAlert("User has been created successfully"); 
    			    	  this.showLoadingScreen = false;                          
    			        },
        				(err: any) => {
        					this.failedAlert(err.error);
      			    	  	this.showLoadingScreen = false;
        				}
    			      );
              }
              catch(Exception) {
            	  this.failedAlert("Failed to update user. Please try again");
		    	  this.showLoadingScreen = false;    
              }
	  }
	  
	 /**
	  * Update user profile.
	  */
	 public updateUser(userProfile: UserProfile){
          this.hideAlert = false;
          try{
    		  this.adminService.updateUser(userProfile).pipe(
                  takeUntil(this.unsubscribe))  
                  .subscribe(
    		      data => {	    	  	    	 
                      this.successAlert("User has been updated successfully");   
                      this.isReadOnly = true;
                      this.showLoadingScreen=false;
    		        },
    				(err: any) => {
    					this.failedAlert(err.error);
  			    	    this.showLoadingScreen = false;
    				}
    		      );
          }
          catch(Exception) {
        	  this.failedAlert("Failed to process request.");
	    	  this.showLoadingScreen = false;
          }
	  }
	    
	  public onSelect({ selected }) {
	    this.selected.splice(0, this.selected.length);
	    this.selected.push(...selected);
	  }

	  onActivate(event) {
	    //console.log('Activate Event', event);
	  }

	  add() {
	    this.selected.push(this.rows[1], this.rows[3]);
	  }

	  update() {
	    this.selected = [this.rows[1], this.rows[3]];
	  }

	  remove() {
	    this.selected = [];
	  }
    
      cancel(): void {
    	  this.isReadOnly = true;
        //window.location.reload();
      }
    
      resetFormFields(){
          this.username = "";
          this.email = "";
          this.description = "";
      
      }
	  
	  updateFilter(event) {
		    const val = event.target.value.toLowerCase();

		    // filter our data
		    const temp = this.temp.filter(function(d) {
		      return d.groupName.toLowerCase().indexOf(val) !== -1 || !val;
		    });

		    // update the rows
		    this.rows = temp;
		    // Whenever the filter changes, always go back to the first page
		    this.table.offset = 0;
	  }
    
    public closeAlert(alert: any) {
        const index: number = this.alerts.indexOf(alert);
        this.alerts.splice(index, 1);
    }
    
    private successAlert(successMsg:string){
    	this.alerts = [];
        this.alerts.push(
            {
                id: 1,
                type: 'success',
                message: successMsg
            }
        );
    }
    
    private failedAlert(errorMsg:string){
    	this.alerts = [];
        this.alerts.push(
            {
                id: 4,
                type: 'danger',
                message: errorMsg
            }
        );
    }
    
    public enableEditMode(){
        if(this.isReadOnly)
            this.isReadOnly = false;
        else
            this.isReadOnly = true;
	}

	reset() {
		   this.username = '';
		   this.email = '';
		   this.description = '';
		   this.selectedRole.roleId=this.setRoleAsUser;
	}
}