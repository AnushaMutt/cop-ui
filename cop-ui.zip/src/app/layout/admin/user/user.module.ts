import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbAlertModule } from '@ng-bootstrap/ng-bootstrap';
import { UserComponent } from './user.component';
import { UserPageRoutingModule } from './user-routing.module';
import { PageHeaderModule } from './../../../shared';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { FormsModule } from "@angular/forms";

import { MatButtonModule, 
         MatCheckboxModule, 
         MatDatepickerModule, 
         MatNativeDateModule, 
         MatInputModule} 
    from '@angular/material';

@NgModule({
  imports: [CommonModule, 
            UserPageRoutingModule, 
            PageHeaderModule, 
            NgxDatatableModule,
            FormsModule,
            MatButtonModule, MatCheckboxModule,MatDatepickerModule, MatNativeDateModule,MatInputModule, 
            NgbAlertModule.forRoot()],
  declarations: [UserComponent]
})
export class UserModule { }
