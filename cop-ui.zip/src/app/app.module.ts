import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HttpClient, HTTP_INTERCEPTORS} from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AuthGuard } from './shared';

import { ViewAidComponentUtil } from './layout/research/view-aid/view-aid.util';
import { TokenInterceptor } from './Services/Interceptors/auth.interceptor';

import { AdminService } from './Services/admin.service';
import { AuthService } from './Services/auth.service';
import { CarrierService } from './Services/carrier.service';
import { OperationService } from './Services/operation.service';
import { AuditService } from './Services/audit.service';
import { URLHandlerService } from './Services/urlhandler.service';
import { DatabaseEnvService } from './Services/dbenv.service';
import { APIFullService } from './Services/apifull.service';
import { InsertWizardService } from './Services/insertWizard.service';
import { UserInquiryService } from './Services/userInquiry.service';
import { ToastModule } from 'primeng/toast';
import { ServiceRateplanMaintenanceService } from './Services/serviceRateplanMaintenance.service';
import { ToasterService } from './Services/toaster.service';
import { MessageService } from 'primeng/primeng';
import {ServicePlanViewService} from './Services/servicePlanView.service';
import { MirrorServicePlanWizardService } from './Services/mirrorServicePlan.service';
import { CarrierMaintenanceService } from './Services/carrierMaintenance.service';
import { RetailStoreService } from './Services/retailStore.service';
import { RetailTraitsService } from './Services/retailTraits.service';
import { CarrierOutageService } from './Services/carrier-outage.service';
import { ExportPdfService } from './Services/export-pdf.service';
import { UserReportingService } from './Services/user-reporting.service';
import { ThrottleService } from './Services/throttle.service';
import { PCRFService } from './Services/pcrf-transaction.service';
import { DB2IntergateService } from './Services/db2ig-view.service';
import { DB2IntergateMaintenanceService } from './Services/db2ig-maintenance.service';
import { IGCarrierConfigService } from './Services/IgCarrierConfig.service';
import { IGCarrierConfigMaintenanceService } from './Services/igCarrierConfigMaintenance.service';
import { CarrierZonesService } from './Services/carrier-zones.service';
import { GeoCoderService } from './Services/geocoder.service';
import { IgFailLogsService } from './Services/IgFailLogsService';

@NgModule({
    imports: [
        CommonModule,
        BrowserModule,
        BrowserAnimationsModule,
        HttpClientModule,
        AppRoutingModule,
        ToastModule
    ],
    declarations: [AppComponent ],
    providers: [AuthGuard, AdminService, AuthService, CarrierService, OperationService, UserInquiryService,
                AuditService,ServiceRateplanMaintenanceService, URLHandlerService, ViewAidComponentUtil, DatabaseEnvService, APIFullService, InsertWizardService,
                ServicePlanViewService,MirrorServicePlanWizardService,CarrierMaintenanceService,RetailStoreService,RetailTraitsService,CarrierOutageService,
                ExportPdfService, UserReportingService, ThrottleService,PCRFService,DB2IntergateService,DB2IntergateMaintenanceService,IGCarrierConfigService,
                IGCarrierConfigMaintenanceService,CarrierZonesService,GeoCoderService,IgFailLogsService,
    {
        provide: HTTP_INTERCEPTORS,
        useClass: TokenInterceptor,
        multi: true
    }, ToasterService, MessageService],
    bootstrap: [AppComponent]
})
export class AppModule {}
